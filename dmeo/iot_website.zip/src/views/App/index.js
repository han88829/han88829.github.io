/*
 * @Author: lai.haibo 
 * @Date: 2017-03-03 14:37:51 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-17 10:55:59
*/

import React, { Component } from 'react';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';

import Login from '../Login';
import Logined from '../Logined/Logined';
import safeCenter from '../safeCenter';
import Admin from '../Admin';

import EquipManage from '../Equipment/EquipManage';
import EquipMapMonitore from '../Equipment/EquipMapMonitore';
import EquipStatistics from '../Equipment/EquipStatistics';
import EquipTypeManage from '../Equipment/EquipTypeManage';
import EditType from '../Equipment/EquipTypeManage/EditType';
import NewType from '../Equipment/EquipTypeManage/NewType';

import EquipTypeDetail from '../Equipment/EquipTypeManage/TypeDetail';
import EquipPreserve from '../Equipment/EquipPreserve';
import EquipPreserveCreate from '../Equipment/EquipPreserve/preserveCreate';
import EquipPreserveComplete from '../Equipment/EquipPreserve/preserveComplete';
import EquipPreserveMember from '../Equipment/EquipPreserve/preserveMember';

import EquipBrandManage from '../Equipment/EquipBrandManage';
import EditBrand from '../Equipment/EquipBrandManage/EditBrand';
import NewBrand from '../Equipment/EquipBrandManage/NewBrand';

import EquipModelManage from '../Equipment/EquipBrandManage/EquipModel';
import EquipModelDetail from '../Equipment/EquipBrandManage/EquipModel/EquipModelDetail';
import EquipModelNew from '../Equipment/EquipBrandManage/EquipModel/EquipModelNew';
import EquipModelEdit from '../Equipment/EquipBrandManage/EquipModel/EquipModelEdit';

import EquipWarning from '../Equipment/EquipWarning';
import Device from '../Equipment/Device';
import EditDevice from '../Equipment/Device/EditDevice';
import DeviceMaintenance from '../Equipment/Device/DeviceMaintenance';
import DeviceDetection from '../Equipment/Device/DeviceDetection';

import NewDevice from '../Equipment/Device/NewDevice';
//建筑物平面图
import Buildx from '../Building/Build';
import Building from '../Building';

import OrgStatistics from '../Org/OrgStatistics';

import BuildingManage from '../Building/Building/BuildingManage';
import NewBuildImage from '../Building/Building/NewBuildImage';
import NewBuilding from '../Building/Building/NewBuilding';
import EditBuilding from '../Building/Building/EditBuilding';

import Floor from '../Building/Floor';
import Area from '../Building/Area';
import NewArea from '../Building/Area/NewArea';
import NewAreaImage from '../Building/Area/NewAreaImage';
import EditArea from '../Building/Area/EditArea';
import Areacontent from '../Building/Areacontent';
import NewAreaContent from '../Building/Areacontent/NewAreaContent';
import AreaContentImage from '../Building/Areacontent/image';
import AreaInfo from '../Building/Areacontent/info';
import AreaInfoImage from '../Building/Areacontent/infoimage';
import EditAreaContent from '../Building/Areacontent/editarea';

import Org from '../Org';
import OrgManage from '../Org/OrgManage';
import OrgPreserve from '../Org/OrgPreserve';
import OrgPreserveCreate from '../Org/OrgPreserve/preserveCreate';
import OrgPreserveComplete from '../Org/OrgPreserve/preserveComplete';
import OrgPreserveMember from '../Org/OrgPreserve/preserveMember';
import Orgs from '../Org/Orgs';
import NewOrg from '../Org/Orgs/NewOrg';
import NewOrgImage from '../Org/Orgs/NewOrgImage';
import EditOrg from '../Org/Orgs/EditOrg';

import OrgTypeManage from '../Org/OrgTypeManage';
import NewOrgType from '../Org/OrgTypeManage/NewOrgType';
import EditOrgType from '../Org/OrgTypeManage/EditOrgType';
import OrgTypeInfo from '../Org/OrgTypeManage/OrgTypeInfo';

import BuildTypeManage from '../Building/BuildTypeManage';
import NewBuildType from '../Building/BuildTypeManage/NewBuildType';
import EditBuildType from '../Building/BuildTypeManage/EditBuildType';
import BuildTypeInfo from '../Building/BuildTypeManage/BuildTypeInfo';

//监控中心
import MonitorManage from '../Monitor/MonitorManage';
import EditMonitor from '../Monitor/MonitorManage/EditMonitor';
import MonitorInfo from '../Monitor/MonitorManage/MonitorInfo';
import NewMonitor from '../Monitor/MonitorManage/NewMonitor';
import RealTimeMonitor from '../Monitor/RealTimeMonitor';
import MonitorScreens from '../Monitor/RealTimeMonitor/MonitoringScreen';
import TestMonit from '../Monitor/RealTimeMonitor/TestMonit';
import ResourceManage from '../Monitor/ResourceManage';
import PictureManager from '../Monitor/ResourceManage/PictureManager';
import Printscreen from '../Monitor/ResourceManage/Printscreen';
import MonitManag from '../Application/MonitManag';

import Staff from '../Member/Staff';
import Map from '../Member/Staff/Baidu';
import AuthorityMan from '../Member/Staff/AuthorityMan';
import StaffManSet from '../Member/Staff/StaffManSet';
import Performance from '../Member/Performance';
import Group from '../Member/Group';
import PerformanceDetail from '../Member/Performance/PerformanceDetail';
import NewStaff from '../Member/Staff/NewStaff';
import EditStaff from '../Member/Staff/EditStaff';
import StaffDetail from '../Member/Staff/StaffDetail';
import NewGroup from '../Member/Group/NewGroup';
import EditGroup from '../Member/Group/EditGroup';
import GroupDetail from '../Member/Group/GroupDetail';
import Invite from '../Member/Group/Invite';
import Personal from '../Member/Staff/Personal';
import StaffStat from '../Member/Staff/StaffStat';
import GroupMember from '../Member/Group/GroupMember';
import GroupFrame from '../Member/Group/GroupFrame';
import AuthoritySet from '../Member/Group/AuthoritySet';
import GroupPermit from '../Member/Group/GroupPermit';
import StaffPermission from '../Member/Staff/PermissionView';
import GroupPermission from '../Member/Group/PermissionView';

//任务中心
import TaskList from '../Task/TaskList';
import ListDetail from '../Task/TaskList/ListDetail';

//新增单位任务清单
import TaskListOrg from '../Task/TaskList/OrgTaskList';
import ListDetailOrg from '../Task/TaskList/OrgTaskList/ListDetail';
import TaskRules from '../Task/TaskRules';
import Newbasis from '../Task/TaskRules/Newbasis';
import NewEquip from '../Task/TaskRules/NewEquip';
import NewGenerate from '../Task/TaskRules/NewGenerate';
import Newpeople from '../Task/TaskRules/Newpeople';
import RulesDetail from '../Task/TaskRules/RulesDetail';
import Addpeople from '../Task/TaskRules/Addpeople';
import Addequip from '../Task/TaskRules/Addequip';
import TaskReport from '../Task/TaskReport';
import Design from '../Task/TaskReport/Design';
import Detail from '../Task/TaskReport/Detail';
import EditDesing from '../Task/TaskReport/EditDesingNew';
import TaskEquip from '../Task/TaskRules/TaskEquip';
import TaskEquipBasis from '../Task/TaskRules/TaskEquip/Newbasis';
import TaskEquipEquip from '../Task/TaskRules/TaskEquip/NewEquip';
import TaskEquipPeople from '../Task/TaskRules/TaskEquip/Newpeople';
import TaskEquipGener from '../Task/TaskRules/TaskEquip/NewGenerate';
import TaskEquipDetail from '../Task/TaskRules/TaskEquip/RulesDetail';

import ConcenManage from '../Concentrate/ConcenManage';
import ConcenHistory from '../Concentrate/ConcenHistory';
import ConcenStatistics from '../Concentrate/ConcenStatistics';
import ConcenSettings from '../Concentrate/ConcenSettings';
import ConcenGraph from '../Concentrate/ConcenStatistics/ConcenGraph';
import ConcenDetails from '../Concentrate/ConcenDetails';


import ConcenHandle from '../Concentrate/ConcenHandle';
import ConcenBasic from '../Concentrate/ConcenHandle/ConcenBasic';
import ConcenEquipment from '../Concentrate/ConcenHandle/ConcenEquipment';
import ConcenFloor from '../Concentrate/ConcenHandle/ConcenFloor';
import ConcenMonitoring from '../Concentrate/ConcenHandle/ConcenMonitoring';
import ConcenResources from '../Concentrate/ConcenHandle/ConcenResources';
import ConcenRoute from '../Concentrate/ConcenHandle/ConcenRoute';
import ConcenHistoryDetail from '../Concentrate/ConcenHistory/ConcenHistoryDetail';

import Task from '../Task';
import Conct from '../Concentrate/Conct';
import Equip from '../Equipment/Equip';
import Memb from '../Member/Memb';
import Moni from '../Monitor/Moni';
import Orgx from '../Org/Org';
import Noti from '../Notification';

//短信通知
import ContantManage from '../Notification/ContantManage';
import SMSManage from '../Notification/SMSManage';
import SMSStencil from '../Notification/SMSStencil';

//个人中心
import Account from '../Account';
import Basis from '../Account/Basis';
import Real from '../Account/Real';
import Safe from '../Account/Safe';
import NewSend from '../Account/NewSend';
import NewManage from '../Account/NewManage';

// 消息
import Message from '../Message';
import Allnews from '../Message/Allnews';
import Unread from '../Message/Unread';
import Haveread from '../Message/Haveread';
import Send from '../Message/Send';
import MessageManage from '../Message/Manage';

//综合应用
import DutyMonitor from '../Application/DutyMonitor';
import TrackHistory from '../Application/DutyMonitor/TrackHistory';
import AlarmCentralize from '../Application/AlarmCentralize';
import AlarmRealTimeMonitor from '../Application/AlarmCentralize/AlarmRealTimeMonitor';
import AlarmMonitoringScreens from '../Application/AlarmCentralize/AlarmRealTimeMonitor/AlarmMonitoringScreens';
import AlarmEquipMapMonitore from '../Application/AlarmCentralize/AlarmEquipMapMonitore';
import AlarmConcenFloor from '../Application/AlarmCentralize/AlarmConcenFloor';
import AlarmConcenEquipment from '../Application/AlarmCentralize/AlarmConcenEquipment';
import AlarmConcenResources from '../Application/AlarmCentralize/AlarmConcenResources';
import AlarmConcenRoute from '../Application/AlarmCentralize/AlarmConcenRoute';
import AlarmConcenBasicMes from '../Application/AlarmCentralize/AlarmConcenBasicMes';

//设备地图
import AlarmLeft from '../Application/EquipDefault/EquipCenter/AlarmLeft';
import EquipRight from '../Application/EquipDefault/EquipCenter/EquipRight';
import EquipCen from '../Application/EquipDefault/EquipCenter';
import EquipDefault from '../Application/EquipDefault';
import AlarmOne from '../Application/EquipDefault/EquipCenter/AlarmOne';
import SixCentralize from '../Application/EquipDefault/AlarmSix';
import SixRealTimeMonitor from '../Application/EquipDefault/AlarmSix/AlarmRealTimeMonitor';
import SixMonitoringScreens from '../Application/EquipDefault/AlarmSix/AlarmRealTimeMonitor/AlarmMonitoringScreens';
import SixEquipMapMonitore from '../Application/EquipDefault/AlarmSix/AlarmEquipMapMonitore';
import SixConcenFloor from '../Application/EquipDefault/AlarmSix/AlarmConcenFloor';
import SixConcenEquipment from '../Application/EquipDefault/AlarmSix/AlarmConcenEquipment';
import SixConcenResources from '../Application/EquipDefault/AlarmSix/AlarmConcenResources';
import SixConcenRoute from '../Application/EquipDefault/AlarmSix/AlarmConcenRoute';
import SixConcenBasicMes from '../Application/EquipDefault/AlarmSix/AlarmConcenBasicMes';

// 设备统一管理
import EquipCenter from '../Application/EquipCenter';

import Backstage from '../Application/Backstage';
import PatrolX from '../patrolSta';
import Patrol from '../patrolSta/Patrol/index';
import PatrolDetail from '../patrolSta/Patrol/PatrolDetail';
import PatrolMan from '../patrolSta/Patrol/PatrolMan';
import PatrolManEdit from '../patrolSta/Patrol/PatrolManEdit';
import PatrolManDetail from '../patrolSta/Patrol/PatrolManDetail';
import PatrolPoint from '../patrolSta/Patrol/PatrolPoint';
import PatrolPointDetail from '../patrolSta/Patrol/PatrolPointDetail';

// 扫描内容
// import ScanBuilding from '../Scancontent/Building';
// import ScanEquipment from '../Scancontent/Equipment';
// import ScanOrg from '../Scancontent/Org';
// import ScanPatrol from '../Scancontent/Patrol';
import Sindex from '../Scancontent';

// 消防知识
import FireKnowledge from '../Application/FireKnowledge';
import FireDetail from '../Application/FireKnowledge/FireDetail';
import FireNew from '../Application/FireKnowledge/FireNew';
import FireEdit from '../Application/FireKnowledge/FireEdit';

// const Sindex = (location, cb) => {
//   require.ensure([], require => {
//     cb(null, require('../Scancontent'))
//   })
// }
const ScanOrg = (location, cb) => {
  require.ensure([], require => {
    cb(null, require('../Scancontent/Org').default)
  }, "ScanOrg")
}
const ScanBuilding = (location, cb) => {
  require.ensure([], require => {
    cb(null, require('../Scancontent/Building').default)
  }, "ScanBuilding")
}
const ScanEquipment = (location, cb) => {
  require.ensure([], require => {
    cb(null, require('../Scancontent/Equipment').default)
  }, "ScanEquipment")
}
const ScanPatrol = (location, cb) => {
  require.ensure([], require => {
    cb(null, require('../Scancontent/Patrol').default)
  }, "ScanPatrol")
}

//登陆验证
const validate = function (next, replace, callback) {
  const isLoggedIn = !!window.sessionStorage.getItem('token')
  if (!isLoggedIn && next.location.pathname !== '/login') {
    replace('/login')
  }
  callback()
}

//路由
class App extends Component {
  render() {

    return (
      <Router history={browserHistory}>
        <Route path="/login" component={Login} />
        <Route path="/logined" component={Logined} />
        <Route path="/safecenter" component={safeCenter} />

        {/*二维码扫描显示内容*/}
        {/* <Route path="/SBuilding/:id" component={ScanBuilding} />
        <Route path="/SEquipment/:id" component={ScanEquipment} />
         <Route path="/SOrg/:id" component={ScanOrg} /> 
        <Route path="/SPatrol/:id" component={ScanPatrol} /> */}

        <Route path="/SEquipment/:id" getComponent={ScanEquipment} />
        <Route path="/SBuilding/:id" getComponent={ScanBuilding} />
        <Route path="/SPatrol/:id" getComponent={ScanPatrol} />
        <Route path="/SOrg/:id" getComponent={ScanOrg} />

        <Route breadcrumbName="消防知识" path="/fire" component={FireKnowledge} />
        <Route breadcrumbName="消防知识详情" path="/fire/detail/:id" component={FireDetail} />
        <Route breadcrumbName="消防知识新增" path="/fire/new" component={FireNew} />
        <Route breadcrumbName="消防知识编辑" path="/fire/edit/:id" component={FireEdit} />
        <Route breadcrumbName="Home" path="/" component={Admin} onEnter={validate}>
          <IndexRoute component={Orgx} />
          <Route breadcrumbName="后台中心首页" path="/back" component={Backstage} />

          {/*设备*/}
          <Route breadcrumbName="设备" path="/equip" component={Equip}>
            <Route breadcrumbName="设备管理">
              <IndexRoute component={EquipManage} />
              <Route breadcrumbName="设备管理" path="/equip/manage(/:type)" component={EquipManage} />>
              <Route breadcrumbName="设备保养" path="/equip/device/maint/:id" component={DeviceMaintenance} />
              <Route breadcrumbName="设备检测" path="/equip/detect/:id" component={DeviceDetection} />
              <Route breadcrumbName="设备详情" path="/equip/device/info/:id" component={Device} />
              <Route breadcrumbName="编辑设备" path="/equip/device/edit/:id" component={EditDevice} />
              <Route breadcrumbName="新建设备" path="/equip/device/new" component={NewDevice} />
              <Route breadcrumbName="设备统计" path="/equip/stati" component={EquipStatistics} />
              <Route breadcrumbName="地图监控" path="/equip/mapmoni" component={EquipMapMonitore} />
              <Route breadcrumbName="设备预警" path="/equip/warning(/:type)" component={EquipWarning} />
              <Route breadcrumbName="设备养护" path="/equip/preserve(/:type)" component={EquipPreserve} />
              <Route breadcrumbName="创建维护任务" path="/equip/preserve/create/:id" component={EquipPreserveCreate} />
              <Route breadcrumbName="维护人员选择" path="/equip/preserve/member/:id" component={EquipPreserveMember} />
              <Route breadcrumbName="完成" path="/equip/preserve/complete/:id" component={EquipPreserveComplete} />
            </Route>
            <Route breadcrumbName="设置">
              <Route breadcrumbName="类型管理" path="/equip/type/manage" component={EquipTypeManage} />
              <Route breadcrumbName="编辑类型" path="/equip/type/edit/:id" component={EditType} />
              <Route breadcrumbName="新建类型" path="/equip/type/new" component={NewType} />
              <Route breadcrumbName="类型详情" path="/equip/type/:id" component={EquipTypeDetail} />
              <Route breadcrumbName="品牌管理" path="/equip/brand/manage" component={EquipBrandManage} />
              <Route breadcrumbName="编辑品牌" path="/equip/brand/edit/:id" component={EditBrand} />
              <Route breadcrumbName="新建品牌" path="/equip/brand/new" component={NewBrand} />} />
              <Route breadcrumbName="型号管理" path="/equip/model/:id" component={EquipModelManage} />
              <Route breadcrumbName="编辑型号" path="/equip/model/edit/:id" component={EquipModelEdit} />
              <Route breadcrumbName="新建型号" path="/equip/model/new/:id" component={EquipModelNew} />
              <Route breadcrumbName="型号详情" path="/equip/model/detail/:id" component={EquipModelDetail} />
            </Route>
          </Route>

          {/*单位管理*/}
          <Route breadcrumbName="单位管理" path="/org" component={Orgx}>
            <IndexRoute component={OrgManage} />
            <Route breadcrumbName="单位信息" path="/org/manage" component={OrgManage} />
            <Route breadcrumbName="单位详情" path="/org/orgs/info/:id" component={Orgs} />
            <Route breadcrumbName="编辑单位" path="/org/orgs/edit/:id" component={EditOrg} />
            <Route breadcrumbName="新建单位" path="/org/orgs/new" component={NewOrg} />
            <Route breadcrumbName="新增营业执照" path="/org/org/img/:id" component={NewOrgImage} />
            <Route breadcrumbName="单位统计" path="/org/stati" component={OrgStatistics} />
            <Route breadcrumbName="单位整改" path="/org/preserve" component={OrgPreserve} />
            <Route breadcrumbName="创建整改任务" path="/org/preserve/create/:id" component={OrgPreserveCreate} />
            <Route breadcrumbName="整改人员选择" path="/org/preserve/member/:id" component={OrgPreserveMember} />
            <Route breadcrumbName="完成" path="/org/preserve/complete/:id" component={OrgPreserveComplete} />
            <Route breadcrumbName="设置" path="/org" component={Org} />
            <Route breadcrumbName="单位类型管理" path="/org/type/manage" component={OrgTypeManage} />
            <Route breadcrumbName="新增单位类型" path="/org/type/new" component={NewOrgType} />
            <Route breadcrumbName="编辑单位类型" path="/org/type/edit/:id" component={EditOrgType} />
            <Route breadcrumbName="单位类型详情" path="/org/type/:id" component={OrgTypeInfo} />
          </Route>

          {/*建筑管理*/}
          <Route breadcrumbName="建筑管理" path="/build" component={Buildx}>
            <IndexRoute component={BuildingManage} />
            <Route breadcrumbName="建筑管理" path="/org/bding/manage" component={BuildingManage} />
            <Route breadcrumbName="编辑建筑" path="/org/bding/edit/:id" component={EditBuilding} />
            <Route breadcrumbName="新建建筑" path="/org/bding/new" component={NewBuilding} />
            <Route breadcrumbName="新增建筑图片" path="/org/bding/img/:id" component={NewBuildImage} />
            <Route breadcrumbName="建筑详情" path="/org/floor/:id" component={Floor} />
            <Route breadcrumbName="楼层详情" path="/org/area/:id" component={Area} />
            <Route breadcrumbName="编辑楼层" path="/org/area/edit/:id" component={EditArea} />
            <Route breadcrumbName="新建楼层" path="/org/area/new/:id" component={NewArea} />
            <Route breadcrumbName="新增楼层图片" path="/org/area/img/:id" component={NewAreaImage} />
            <Route breadcrumbName="区域详情" path="/org/area/cont/:id" component={Areacontent} />
            <Route breadcrumbName="新增区域" path="/org/areat/newarea/:id" component={NewAreaContent} />
            <Route breadcrumbName="区域划分" path="/org/areat/image/:id/:type" component={AreaContentImage} />
            <Route breadcrumbName="区域详情" path='/org/areat/info/:id' component={AreaInfo} />
            <Route breadcrumbName="区域详情划分" path='/org/areat/infoimage/:id' component={AreaInfoImage} />
            <Route breadcrumbName="区域编辑" path='/org/areat/editarea/:id' component={EditAreaContent} />
            <Route breadcrumbName="设置" path="/build" component={Building} />
            <Route breadcrumbName="建筑类型管理" path="/org/bdtype/manage" component={BuildTypeManage} />
            <Route breadcrumbName="新增建筑类型" path="/org/bdtype/new" component={NewBuildType} />
            <Route breadcrumbName="编辑建筑类型" path="/org/bdtype/edit/:id" component={EditBuildType} />
            <Route breadcrumbName="建筑类型详情" path="/org/bdtype/:id" component={BuildTypeInfo} />
          </Route>

          {/*监控*/}
          <Route breadcrumbName="监控" path="/moni" component={Moni}>
            <IndexRoute component={MonitorManage} />
            <Route breadcrumbName="新增摄像头" path="/moni/manage/new" component={NewMonitor} />
            <Route breadcrumbName="修改摄像头" path="/moni/manage/edit/:id" component={EditMonitor} />
            <Route breadcrumbName="查看摄像头" path="/moni/manage/info/:id" component={MonitorInfo} />
            <Route breadcrumbName="监控管理" path="/moni/manage" component={MonitorManage} />
            <Route breadcrumbName="资源管理" path="/moni/resource" component={ResourceManage} />
            <Route breadcrumbName="实时监控" path="/moni/realtime" component={RealTimeMonitor} />
            <Route breadcrumbName="全屏显示" path="/moni/realtime/screens/:id" component={MonitorScreens} />
            <Route breadcrumbName="海康测试" path="/moni/realtime/test" component={TestMonit} />
            <Route breadcrumbName="图片管理" path="/moni/resource/pic" component={PictureManager} />
            <Route breadcrumbName="视频管理" path="/moni/resource/vedio" component={Printscreen} />
          </Route>

          {/*人员管理*/}
          <Route breadcrumbName="人员管理" path="/memb" component={Memb}>
            <IndexRoute component={Group} />
            <Route breadcrumbName="组织管理" path="/memb/group" component={Group} />
            <Route breadcrumbName="绩效管理" path="/memb/prfrm" component={Performance} />
            <Route breadcrumbName="人员信息" path="/memb/staff" component={Staff} />
            <Route breadcrumbName="轨迹展示" path="/memb/staff/map" component={Map} />
            <Route breadcrumbName="部门权限" path="/memb/frame" component={GroupFrame} />
            <Route breadcrumbName="部门权限配置" path="/memb/frame/set/:id" component={AuthoritySet} />
            <Route breadcrumbName="部门结构" path="/memb/permit" component={GroupPermit} />
            <Route breadcrumbName="人员菜单权限" path="/memb/staff/permission/:id" component={StaffPermission} />
            <Route breadcrumbName="部门菜单权限" path="/memb/group/permission/:id" component={GroupPermission} />
            <Route breadcrumbName="人员权限" path="/memb/staff/authority" component={AuthorityMan} />
            <Route breadcrumbName="人员权限配置" path="/memb/staff/authority/:id" component={StaffManSet} />
            <Route breadcrumbName="人员详情" path="/memb/staff/detail/:id" component={StaffDetail} />
            <Route breadcrumbName="编辑人员" path="/memb/staff/edit/:id" component={EditStaff} />
            <Route breadcrumbName="新建人员" path="/memb/staff/new" component={NewStaff} />
            <Route breadcrumbName="人员统计" path="/memb/staff/stat" component={StaffStat} />
            <Route breadcrumbName="组织详情" path="/memb/group/detail/:id" component={GroupDetail} />
            <Route breadcrumbName="新建组织" path="/memb/group/new" component={NewGroup} />
            <Route breadcrumbName="编辑组织" path="/memb/group/edit/:id" component={EditGroup} />
            <Route breadcrumbName="组织人员" path="/memb/group/memb" component={GroupMember} />
            <Route breadcrumbName="个人信息" path="/memb/person" component={Personal} />
            <Route breadcrumbName="邀请注册" path="/memb/invite/:id" component={Invite} />
            <Route breadcrumbName="绩效详情" path="/memb/prfrm/:id" component={PerformanceDetail} />
          </Route>

          {/*巡逻管理*/}
          <Route breadcrumbName="巡逻管理" path="/patrol" component={PatrolX}>
            <IndexRoute component={Patrol} />
            <Route breadcrumbName="巡逻设置" path="/memb/patrol" component={Patrol} />
            <Route breadcrumbName="巡逻详情查看" path="/memb/patrol/detail" component={PatrolDetail} />
            <Route breadcrumbName="巡逻人管理" path="/memb/patrol/man" component={PatrolMan} />
            <Route breadcrumbName="个人巡逻详情" path="/memb/patrol/man/detail" component={PatrolManDetail} />
            <Route breadcrumbName="巡逻人编辑" path="/memb/patrol/man/edit/:id" component={PatrolManEdit} />
            <Route breadcrumbName="巡逻点管理" path="/memb/patrol/point" component={PatrolPoint} />
            <Route breadcrumbName="巡逻点信息" path="/memb/patrol/point/info" component={PatrolPointDetail} />
          </Route>

          {/*警情集控中心*/}
          <Route breadcrumbName="警情集控中心" path="/conct" component={Conct}>
            <IndexRoute component={ConcenManage} />
            <Route breadcrumbName="报警管理" path="/conct/manage" component={ConcenManage} />
            <Route breadcrumbName="出警信息" path="/conct/handle/:id" component={ConcenHandle} />
            <Route breadcrumbName="出警路线图" path="/conct/route/:id" component={ConcenRoute} />
            <Route breadcrumbName="资源分布图" path="/conct/resources/:id" component={ConcenResources} />
            <Route breadcrumbName="监控" path="/conct/monitoring/:id" component={ConcenMonitoring} />
            <Route breadcrumbName="总平面图" path="/conct/floor/:id" component={ConcenFloor} />
            <Route breadcrumbName="设备定位图" path="/conct/equipment/:id" component={ConcenEquipment} />
            <Route breadcrumbName="基本信息" path="/conct/basic/:id" component={ConcenBasic} />
            <Route breadcrumbName="报警处理" path="/conct/history" component={ConcenHistory} />
            <Route breadcrumbName="报警处理详情" path="/conct/historydetail/:id" component={ConcenHistoryDetail} />
            <Route breadcrumbName="报警统计" path="/conct/statistics" component={ConcenStatistics} />
            <Route breadcrumbName="报警统计趋势图" path="/conct/graph" component={ConcenGraph} />
            <Route breadcrumbName="报警设定" path="/conct/settings" component={ConcenSettings} />
            <Route breadcrumbName="报警详情" path="/conct/details/:id" component={ConcenDetails} />
          </Route>

          {/*任务中心*/}
          <Route breadcrumbName="任务中心" path="/task" component={Task}>
            <Route breadcrumbName="任务清单" path="/task/list" component={TaskList} />
            <Route breadcrumbName="清单详情" path="/task/list/detail/:id" component={ListDetail} />
            <Route breadcrumbName="任务清单" path="/task/list/org" component={TaskListOrg} />
            <Route breadcrumbName="清单详情" path="/task/list/org/detail/:id" component={ListDetailOrg} />
            <Route breadcrumbName="设备任务规则" path="/task/rule" component={TaskRules} />
            <Route breadcrumbName="新建基础信息" path="/task/basis" component={Newbasis} />
            <Route breadcrumbName="新建设备信息" path="/task/equip/new" component={NewEquip} />
            <Route breadcrumbName="设备生成规则" path="/task/generate" component={NewGenerate} />
            <Route breadcrumbName="设备新建人员信息" path="/task/people" component={Newpeople} />
            <Route breadcrumbName="设备规则详情" path="/task/rule/detail/:id" component={RulesDetail} />
            <Route breadcrumbName="设备增加人员" path="/task/people/add" component={Addpeople} />
            <Route breadcrumbName="设备增加设备" path="/task/equip/add" component={Addequip} />
            <Route breadcrumbName="报表列表" path="/task/report" component={TaskReport} />
            <Route breadcrumbName="报表设计" path="/task/design" component={Design} />
            <Route breadcrumbName="报表详情" path="/task/report/info/:id" component={Detail} />
            <Route breadcrumbName="编辑报表" path="/task/report/edit/:id" component={EditDesing} />
            <Route breadcrumbName="单位任务规则" path="/task/rule/taskequip" component={TaskEquip} />
            <Route breadcrumbName="单位新建基础信息" path="/task/taskequip/basis" component={TaskEquipBasis} />
            <Route breadcrumbName="单位新建设备信息" path="/task/taskequip/equip" component={TaskEquipEquip} />
            <Route breadcrumbName="单位生成规则" path="/task/taskequip/generate" component={TaskEquipGener} />
            <Route breadcrumbName="单位新建人员信息" path="/task/taskequip/people" component={TaskEquipPeople} />
            <Route breadcrumbName="单位规则详情" path="/task/rule/taskequip/detail/:id" component={TaskEquipDetail} />
          </Route>

          {/*短信通知*/}
          <Route breadcrumbName="短信通知" path="/noti" component={Noti}>
            <Route breadcrumbName="联系人管理" path="/noti/cont" component={ContantManage} />
            <Route breadcrumbName="短信管理" path="/noti/manage" component={SMSManage} />
            <Route breadcrumbName="短信模版" path="/noti/stencil" component={SMSStencil} />
          </Route>

          {/*个人中心*/}
          <Route breadcrumbName="个人中心" path="/acc" component={Account}>
            <Route breadcrumbName="安全设置" path="/acc/safe" component={Safe} />
            <Route breadcrumbName="基本资料" path="/acc/basis" component={Basis} />
            <Route breadcrumbName="实名认证" path="/acc/real" component={Real} />
            <Route breadcrumbName="热点发布" path="/acc/newsend" component={NewSend} />
            <Route breadcrumbName="热点发布" path="/acc/new/manage" component={NewManage} />
          </Route>

          {/*消息*/}
          <Route breadcrumbName="消息" path="/mess" component={Message}>
            <IndexRoute component={Allnews} />
            <Route breadcrumbName="全部消息" path="/mess/all" component={Allnews} />
            <Route breadcrumbName="未读消息" path="/mess/un" component={Unread} />
            <Route breadcrumbName="已读消息" path="/mess/have" component={Haveread} />
            <Route breadcrumbName="消息发送" path="/mess/send" component={Send} />
            <Route breadcrumbName="消息接收管理" path="/mess/manage" component={MessageManage} />

          </Route>
        </Route>

        <Route breadcrumbName="执勤实时监督" path="/apply/duty" component={DutyMonitor} />
        <Route breadcrumbName="轨迹历史查询" path="/apply/track/:id" component={TrackHistory} />
        <Route breadcrumbName="警情集中处理" path='/apply/alarmcentral/:mesid' component={AlarmCentralize} />
        <Route breadcrumbName="监控综合管理" path='/apply/monitor' component={MonitManag} />
        <Route breadcrumbName="实时监控" path='/apply/alarmrealtimemonitor' component={AlarmRealTimeMonitor} />
        <Route breadcrumbName="实时监控全屏显示" path="/apply/alarmrealtimemonitor/screens/:mesid/:jkid" component={AlarmMonitoringScreens} />
        <Route breadcrumbName="园区地图监控" path='/apply/alarmequipmapmonitore/:type' component={AlarmEquipMapMonitore} />
        <Route breadcrumbName="建筑物平面图" path='/apply/alarmconcenfloor/:mesid/:type' component={AlarmConcenFloor} />
        <Route breadcrumbName="设备位置图" path='/apply/alarmconcenequipment/:mesid/:type' component={AlarmConcenEquipment} />
        <Route breadcrumbName="资源分布" path='/apply/alarmconcenresources/:mesid/:type' component={AlarmConcenResources} />
        <Route breadcrumbName="最近警力" path='/apply/alarmconcenroute/:mesid/:type' component={AlarmConcenRoute} />
        <Route breadcrumbName="基础信息" path='/apply/alarmconcenbasicmes/:mesid/:type' component={AlarmConcenBasicMes} />
        <Route breadcrumbName="设备统一管理" path='/apply/equipcenter' component={EquipCenter} />
        <Route breadcrumbName="基础信息" path='/apply/alarmconcenbasicmes/:type' component={AlarmConcenBasicMes} />
        <Route breadcrumbName="设备统一管理" path='/apply/equipcenter' component={EquipCenter} />

        {/*设备地图*/}
        <Route breadcrumbName="设备地图" path='/apply/equip(/:dstate)' component={EquipDefault} />
        <Route breadcrumbName="默认页面" path="/apply/equip/center" component={EquipCen} />
        <Route breadcrumbName="左侧报警" path="/apply/equip/AlarmLeft" component={AlarmLeft} />
        <Route breadcrumbName="右侧设备信息" path="/apply/equip/EquipRight" component={EquipRight} />
        <Route breadcrumbName="六屏左侧" path="/apply/equip/one" component={AlarmOne} />
        <Route breadcrumbName="警情集中处理" path='/apply/equip/six/alarm/:mesid' component={SixCentralize} />
        <Route breadcrumbName="实时监控" path='/apply/equip/six/alarmtime' component={SixRealTimeMonitor} />
        <Route breadcrumbName="实时监控全屏显示" path="/apply/equip/six/alarmtime/screens/:mesid/:jkid" component={SixMonitoringScreens} />
        <Route breadcrumbName="园区地图监控" path='/apply/alarmMap/:type' component={SixEquipMapMonitore} />
        <Route breadcrumbName="建筑物平面图" path='/apply/alarmfloor/:mesid/:type' component={SixConcenFloor} />
        <Route breadcrumbName="设备位置图" path='/apply/alarmequip/:mesid/:type' component={SixConcenEquipment} />
        <Route breadcrumbName="资源分布" path='/apply/alarmsources/:mesid/:type' component={SixConcenResources} />
        <Route breadcrumbName="最近警力" path='/apply/alarmroute/:mesid/:type' component={SixConcenRoute} />
        <Route breadcrumbName="基础信息" path='/apply/alarmbasicmes/:mesid/:type' component={SixConcenBasicMes} />
      </Router>
    )
  }
}

export default App;