/*
 * @Author: lai.haibo 
 * @Date: 2017-03-07 09:06:33 
 * @Last Modified by: xmj
 * @Last Modified time: 2017-04-07 13:02:59
 */

import React, { Component } from 'react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Tabs, Icon } from 'antd';
import TaskInspect from './containers/TaskInspect';
import TaskRandom from './containers/TaskRandom';
import TaskResult from './containers/TaskResult';
import './concentStatistics.css';
import { Link } from 'react-router';

const { TabPane } = Tabs;
class ConcenStatistics extends Component {
  state = {
    //filteredInfo: null,
    alarmtype: 'block',
    devicetype: 'none',
    location: 'none',
  };
  showContent = (idName) => {
    switch (idName) {
      case 'alarmtypecontent':
        this.setState({
          alarmtype: 'block',
          devicetype: 'none',
          location: 'none',
        });
        break;
      case 'devicetypecontent': {
        this.setState({
          alarmtype: 'none',
          devicetype: 'block',
          location: 'none',
        });
        break;
      }
      case 'locationcontent': {
        this.setState({
          alarmtype: 'none',
          devicetype: 'none',
          location: 'block',
        });
        break;
      }
      default: {

      }
    }
  }
  render() {
    return (

      <div className="ConcenStatistics" style={{ padding: 0 }}>
        <Tabs defaultActiveKey="1" style={{ height: '100%', fontSize: '0.75em' }} className='concentinfoTabOne'>
          <TabPane tab={<span><Icon type="info-circle-o" />报警类型统计</span>} style={{ height: '100%', marginRight: 6 }} key="1">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/conct/statistics' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警统计</Link>
            </div>

            <TaskInspect />

          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" style={{ height: '100%', marginRight: 6 }} />设备类型统计</span>} key="2">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/conct/statistics' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警统计</Link>
            </div>
            <TaskRandom />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" style={{ height: '100%', marginRight: 6 }} />安装位置统计</span>} key="3">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/conct/statistics' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警统计</Link>
            </div>
            <TaskResult />
          </TabPane>
        </Tabs>

      </div>

    );
  }
}


export default ConcenStatistics;