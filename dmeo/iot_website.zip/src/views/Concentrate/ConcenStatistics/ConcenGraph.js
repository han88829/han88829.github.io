/*
 * @Author: lai.haibo 
 * @Date: 2017-03-07 09:06:33 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-07 09:20:57
 */

import React, { Component } from 'react';

class ConcenGraph extends Component {
  render() {
    return (
      <div className="ConcenGraph">
        趋势图
      </div>
    );
  }
}

export default ConcenGraph;