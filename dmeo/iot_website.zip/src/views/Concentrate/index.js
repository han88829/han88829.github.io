/*
 * @Author: lai.haibo 
 * @Date: 2017-03-07 09:06:33 
 * @Last Modified by: xmj
 * @Last Modified time: 2017-03-28 15:42:17
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { Layout, Menu, Breadcrumb } from 'antd';


import task_pic from '../../assets/images/logined/achievementsManage-icon.png';
import equipment_inspection_pic from '../../assets/images/logined/taskCenter-icon.png';
import equipwarning_pic from '../../assets/images/logined/departmentManage-icon.png';
//import device_pic from '../../assets/images/logined/device-button.png';
import equipment_manage_pic from '../../assets/images/logined/personMes-icon.png';

import departmentMes_pic from '../../assets/images/logined/departmentMes-icon.png';
import departmentPerson_pic from '../../assets/images/logined/departmentPerson-icon.png';
import departmentJurisdiction_pic from '../../assets/images/logined/departmentJurisdiction-icon.png';
import departmentStructure_pic from '../../assets/images/logined/departmentStructure-icon.png';

import achievementsManageTwo_pic from '../../assets/images/logined/achievementsManageTwo-icon.png';


import personCount_pic from '../../assets/images/logined/personCount-icon.png';
import device_bread_pic from '../../assets/images/logined/device-bread.png';
import user_button from '../../assets/images/logined/personManage-icon.png';

import equipTaskCount_pic from '../../assets/images/logined/equipTaskCount-icon.png';
import equipTask_pic from '../../assets/images/logined/equipTask-icon.png';
import orgTaskCount_pic from '../../assets/images/logined/orgTaskCount-icon.png';
import orgTask_pic from '../../assets/images/logined/orgTask-icon.png';



const { SubMenu } = Menu;
const { Content, Sider } = Layout;

class Concentrate extends Component {
  constructor() {
    super();
    this.state = {
      breadRight: '人员信息',
      breadTitle: '警情集控中心',
      breadLink: '/concen'
    }
    this.handClick = this.handClick.bind(this);
  }
  handClick(e) {
    this.setState({
      breadRight: e.target.innerText,
      breadTitle: e.target.getAttribute('data-parent'),
      breadLink: e.target.getAttribute('data-link')
    })
  }
  componentDidMount() {
    //查设备类型
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let dtypes = [{ name: '/' }];
      for (let value of result) {
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes', JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })

    // window.rpc.device.getArray(0, 0).then((result) => {
    //   let locations = [{name: '/'}];
    //   for(let value of result){
    //     locations[value.id] = value;
    //   }
    //   sessionStorage.setItem('locations',JSON.stringify(locations));
    // }, (err) => {
    //   console.warn(err);
    // })
    //查安装位置
    window.rpc.area.getArray(0, 0).then((result) => {
      let locations = [{ name: '/' }];
      for (let value of result) {
        locations[value.id] = value;
      }
      sessionStorage.setItem('locations', JSON.stringify(locations));
    }, (err) => {
      console.warn(err);
    })
    //查报警类型
    window.rpc.alias.getValueByName('device.alarm.type').then((result) => {
      let alarmTypes = [{ name: '/' }];
      for (let value of result) {
        alarmTypes[value.id] = value;
      }
      sessionStorage.setItem('alarmTypes', JSON.stringify(alarmTypes));
    }, (err) => {
      console.warn(err);
    })

  }

  render() {

    return (
      <Layout className="Member" style={{ background: '#333744' }}>
        <Sider
          width={200}
          style={{ background: '#333744', height: '100%' }}>

          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['sub1', 'sub2', 'sub3', 'sub4']}
            style={{ height: '100%', backgroundColor: '#333744' }}

          >
            <SubMenu
              key="sub1"
              className="sub-menu-1"
              title={<span style={{ background: '#333744', fontFamily: '苹方特细', fontWeight: 400, height: 50, fontstyle: 'normal', fontSize: '14px', color: ' #FFFFFF', textAlign: 'left' }}><img src={task_pic} alt="" style={{ padding: '0 20px 0 30px', verticalAlign: 'middle' }} />报警管理</span>}
            >
              <Menu.Item key="1"><Link to="/concen/manage" onClick={this.handClick} data-link="/concen/manage" data-parent="报警管理"><img src={personCount_pic} alt="" style={{ padding: '0 10px 0 10px' }} /><span style={{ fontFamily: '苹方特细', fontSize: '12px' }}>报警管理</span></Link></Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub2"
              className="sub-menu-2"
              title={<span style={{ background: '#333744', fontFamily: '苹方特细', fontWeight: 400, height: 50, fontstyle: 'normal', fontSize: '14px', color: ' #FFFFFF', textAlign: 'left' }}><img src={user_button} alt="" style={{ padding: '0 20px 0 30px', verticalAlign: 'middle' }} />报警统计</span>}
            >
              <Menu.Item key="2"><Link to="/concen/statistics" onClick={this.handClick} data-link="/concen/statistics" data-parent="警情集控中心"><img src={personCount_pic} alt="" style={{ padding: '0 10px 0 10px' }} /><span style={{ fontFamily: '苹方特细', fontSize: '12px' }}>报警统计</span></Link></Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub3"
              className="sub-menu-3"
              title={<span style={{ background: '#333744', fontFamily: '苹方特细', fontWeight: 400, height: 50, fontstyle: 'normal', fontSize: '14px', color: ' #FFFFFF', textAlign: 'left' }}><img src={equipwarning_pic} alt="" style={{ padding: '0 20px 0 30px', verticalAlign: 'middle' }} />报警处理</span>}
            >
              <Menu.Item key="4"><Link to="/concen/history" onClick={this.handClick} data-link="/concen/history" data-parent="报警处理"><img src={equipment_manage_pic} alt="" style={{ padding: '0 10px 0 10px' }} /><span style={{ fontFamily: '苹方特细', fontSize: '12px' }}>报警处理</span></Link></Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub4"
              className="sub-menu-4"
              title={<span style={{ background: '#333744', fontFamily: '苹方特细', fontWeight: 400, height: 50, fontstyle: 'normal', fontSize: '14px', color: ' #FFFFFF', textAlign: 'left' }} ><img src={equipment_inspection_pic} alt="" style={{ padding: '0 20px 0 30px', verticalAlign: 'middle' }} />报警设定</span>}
            >
              <Menu.Item key="5"><Link to="/concen/settings" onClick={this.handClick} data-link="/concen/statistics" data-parent="报警统计"><img src={personCount_pic} alt="" style={{ padding: '0 10px 0 10px' }} /><span style={{ fontFamily: '苹方特细', fontSize: '12px' }}>报警设定</span></Link></Menu.Item>
            </SubMenu>
          </Menu>
        </Sider>
        <Layout style={{ paddingRight: '20px', background: "#fff" }}>
          <Content style={{ marginRight: '16px', padding: '0 20px ', background: "#fafafa" }}>
            <Breadcrumb style={{ margin: '12px 0', width: '500px', height: '30px', fontFamily: 'Microsoft YaHei', fontWeight: 'normal', color: '#666', fontSize: '16px', lineHeight: '30px' }}>
              <Breadcrumb.Item style={{ fontWeight: '600' }}><Link to="/logined"><img src={device_bread_pic} alt="" style={{ padding: '0 10px 0 0', verticalAlign: 'middle' }} />主页</Link></Breadcrumb.Item>
              <Breadcrumb.Item style={{ fontWeight: '600' }}><Link to={this.state.breadLink}>{this.state.breadTitle}</Link></Breadcrumb.Item>
              <Breadcrumb.Item style={{ fontWeight: '600' }}><Link to={this.state.breadLink}>{this.state.breadRight}</Link></Breadcrumb.Item>
            </Breadcrumb>
            <div style={{ padding: 0, background: '#fff', minHeight: 600, height: '100%' }}>
              {this.props.children}
            </div>
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Concentrate;