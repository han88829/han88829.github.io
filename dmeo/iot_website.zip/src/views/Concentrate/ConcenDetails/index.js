/*
 * @Author: lai.haibo 
 * @Date: 2017-03-07 09:06:33 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-07 09:38:30
 */

import React, { Component } from 'react';

class ConcenDetails extends Component {
  render() {
    return (
      <div className="ConcenDetails">
        报警详情
      </div>
    );
  }
}

export default ConcenDetails;