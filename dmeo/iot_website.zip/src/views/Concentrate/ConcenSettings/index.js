import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Modal, Radio, Slider, InputNumber } from 'antd';
//import moment from 'moment';
import './concenSettings.css';

//const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;


// 设置message消息
message.config({
  top: 216,
  duration: 2
})

// 结构出参量表
//const { rStateList } = listStore;

// 取出类型
let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];


// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null
    })
  }
}

class AdvancedSearchForm extends React.Component {
  componentDidMount() {
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        if (dtype) {
          values = { ...values, dtype }
        }

        console.log('Received values of form: ', values);

        window.rpc.device.getArrayAlarmParamByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          console.log(result);
          let devices = result.map((x) => ({ ...x, key: x.id, dtype: x.dtype, name: x.name }));
          this.props.appState.tableData = devices;

        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let typeChildren = [];

    // let res=[];
    //   let json = {};
    //   for (let i = 0; i < dtypes.length; i++) {
    //     if (!json[dtypes[i].id]) {
    //       res.push(dtypes[i]);
    //       json[dtypes[i].id] = 1;
    //     }
    //   }
    // for(let value of res) {
    //   if (value && value.id) {
    //     typeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
    //   }
    // }

    console.log(dtypes);
    for (let value of dtypes) {
      if (value && value.id) {
        typeChildren.push(<Option key={`${value.id}`} >{value.name}</Option>)
      }
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={5} key={1}>
            <FormItem label={`设备名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 180 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={5} key={2}>
            <FormItem label={`设备类型`}>
              {getFieldDecorator(`dtype`)(
                <Select multiple style={{ width: 180 }} placeholder="请选择">
                  {typeChildren}
                </Select>
              )}
            </FormItem>
          </Col>

          <Col span={1} key={4}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);


// @observer
const ConcenSettingsC = observer(class ConcenSettingsC extends Component {

  state = {
    display: "none",
    ModalText: '请选择处理结果',
    visible: false,
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
    console.info
      ([...this.props.appState.selectArr])
  }
  handleOk = (type) => {

    console.log(type)
    this.setState({
      visible: false,
      modal1Visible: false,
      modal2Visible: false,
      modal3Visible: false,
      modal4Visible: false,
    });

    if (type === 2) {

      window.rpc.device.setRangeValueById(this.state.keyID, this.state.inputValue).then(() => {
        message.info('设置阈值成功！');
      }, (err) => {
        console.log(err);
      })
    } else if (type === 1) {

      window.rpc.device.setBoolValueById(this.state.keyID, this.state.value).then(() => {
        message.info('设置开关成功！');
      }, (err) => {
        console.log(err);
      })
    } else if (type === 4) {
      window.rpc.device.setRangeValueByArrayId(this.state.selectedRowKeys, this.state.inputValue).then(() => {
        message.info('批量设置阈值成功！');
      }, (err) => {
        console.log(err);
      })
    } else {
      window.rpc.device.setBoolValueByArrayId(this.state.selectedRowKeys, this.state.value).then(() => {
        message.info('批量设置开关成功！');
      }, (err) => {
        console.log(err);
      })
      window.rpc.device.setRangeValueById(this.state.keyID, this.state.inputValue);

    }
    window.rpc.device.getArrayAlarmParamByContainer(null, 0, 0).then((result) => {
      let devices = result.map((x) => ({ ...x, key: x.id, typeName: x.typeName, name: x.name }));
      this.props.appState.tableData = devices;

    }, (err) => {
      console.warn(err);
    })

  }

  handleCancel = () => {
    console.log('Clicked cancel button');
    this.setState({
      visible: false,
      modal1Visible: false,
      modal2Visible: false,
      modal3Visible: false,
      modal4Visible: false,
    });
  }


  setModal1Visible(modal1Visible, record) {
    this.state.keyID = record.id;
    this.state.inputValue = [record.leftValue, record.rightValue];
    this.setState({ modal1Visible });

    return false;
  }
  setModal2Visible(modal2Visible, record) {
    this.state.keyID = record.id;
    this.state.inputValue = [record.leftValue, record.rightValue];
    // if(id>=0&&modal2Visible===false){
    //   this.state.keyID = id;

    //browserHistory.push('/concen/settings');
    //}
    console.log(this.state.keyID);
    this.setState({ modal2Visible });
  }

  setModal3Visible(modal3Visible) {
    console.log(this.state.value);
    if (this.state.selectedRowKeys.length > 0) {
      this.setState({ modal3Visible });
    } else {
      message.info("请选择要设置的项！");
    }

  }
  setModal4Visible(modal4Visible) {
    console.log(this.state.inputValue);
    if (this.state.selectedRowKeys.length > 0) {
      this.setState({ modal4Visible });
    } else {
      message.info("请选择要设置的项！");
    }

  }
  state = {
    selectedRowKeys: [],  // Check here to configure the default column
    loading: false,
    modal1Visible: false,
    modal2Visible: false,
    modal3Visible: false,
    modal4Visible: false,
    inputValue: [20, 50],
    value: 1,
    keyID: -1,
  };
  onChange1 = (value) => {
    this.setState({
      inputValue: value,
    });
  }
  onChange = (e) => {
    console.log('radio checked', e.target.value);
    this.setState({
      value: e.target.value,
    });
  }
  // start = () => {
  //   this.setState({ loading: true });
  //   // ajax request after empty completing
  //   setTimeout(() => {
  //     this.setState({
  //       selectedRowKeys: [],
  //       loading: false,
  //     });
  //   }, 1000);
  // }
  onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    this.setState({ selectedRowKeys });
  }
  componentDidMount() {
    window.rpc.device.getArrayAlarmParamByContainer(null, 0, 0).then((result) => {
      //console.table(levels)
      let devices = result.map((x) => ({ ...x, key: x.id, name: x.name, typeName: x.typeName }));
      this.props.appState.tableData = devices;
      console.info(devices);

    }, (err) => {
      console.warn(err);
    })

  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
    });
  }
  render() {
    const { loading, selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };
    //const hasSelected = selectedRowKeys.length > 0;
    const columns = [
      {
        title: '序号',
        dataIndex: 'id',
        key: 'id',
        height: 10
      },
      { title: '设备名', dataIndex: 'name', key: 'name' },
      { title: '设备类型', dataIndex: 'typeName', key: 'typeName' },
      { title: '阀值最低值', dataIndex: 'leftValue', key: 'leftValue' },
      { title: '阀值最高值', dataIndex: 'rightValue', key: 'rightValue' },
      // {
      //   title: '阀值',
      //   children: [{
      //     title: '最低值',
      //     dataIndex: 'leftValue',
      //     key: 'leftValue',
      //     height: 10
      //   }, 
      //    {
      //     title: '最高值',
      //     dataIndex: 'rightValue',
      //     key: 'rightValue',
      //     height: 10
      //   }],
      // },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <a href="javascript:;" disabled={record.rightValue} onClick={() => this.setModal1Visible(true, record)}>设置开关</a>
            <span className="ant-divider" />
            <a href="javascript:;" disabled={!record.rightValue} onClick={() => this.setModal2Visible(true, record)}>设置阀值</a>

          </span>
        )
      },
    ];

    const data = [...this.props.appState.tableData];


    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };

    return (

      <div className="ConcenHistory">




        <div style={{ fontSize: '0.75em', height: 35, paddingBottom: '1.125em', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='/conct/settings' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>报警设定</Link>
          </div>
          <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }} className="TaskRules">
            <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={() => this.setModal3Visible(true)}
              loading={loading}
            >批量设置开关</Button>
            <Modal title="批量设置开关" visible={this.state.modal3Visible}
              onOk={(event) => this.handleOk(3)}
              onCancel={this.handleCancel} className="ModalSize"
            >
              <RadioGroup onChange={this.onChange} value={this.state.value}>
                <Radio value={1}>开</Radio>
                <Radio value={0}>关</Radio>
              </RadioGroup>
            </Modal>
            <Button style={{ float: 'left', background: '#d9dee4', color: '#373e41', padding: '0 15px', height: '32px', borderRadius: 0, marginLeft: 5 }} onClick={() => this.setModal4Visible(true)}
              loading={loading}
            >批量设置阀值</Button>
            <Modal title="批量设置阀值" visible={this.state.modal4Visible}
              onOk={(event) => this.handleOk(4)}
              onCancel={this.handleCancel} className="ModalSize"
            >

              <Col span={15}>
                <Slider range onChange={this.onChange1} value={this.state.inputValue} step={0.01} />
              </Col>

            </Modal>
          </div>
          <Modal title="设置开关" visible={this.state.modal1Visible}
            onOk={(event) => this.handleOk(1)}
            onCancel={this.handleCancel} className="ModalSize"
          >
            <RadioGroup onChange={this.onChange} value={this.state.value}>
              <Radio value={1}>开</Radio>
              <Radio value={0}>关</Radio>
            </RadioGroup>
          </Modal>
          <Modal title="设置阀值" visible={this.state.modal2Visible}
            onOk={(evnet) => this.handleOk(2)}
            onCancel={this.handleCancel} className="ModalSize"
          >
            <Col span={15}>
              <Slider range onChange={this.onChange1} value={this.state.inputValue} step={0.01} />
            </Col>

          </Modal>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} style={{ width: '80%', textAlign: 'center' }} />

        <Row style={{ padding: '5px 0 0', marginTop: 10 }}>
          <Col span={24}>

            <Table
              bordered
              columns={columns}
              dataSource={data}
              pagination={pagination}
              onChange={this.handleChange}
              rowSelection={rowSelection}
            />
          </Col>
        </Row>
      </div>
    );
  }
})


class ConcenSettings extends Component {
  render() {
    return (
      <ConcenSettingsC appState={new appState()} />
    );
  }
}

export default ConcenSettings;