/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: mikey.zhaopeng
<<<<<<< HEAD
 * @Last Modified time: 2017-03-28 15:47:46
=======
 * @Last Modified time: 2017-06-13 13:03:04
>>>>>>> 84a9beca2f3f38cc1a9532537d5e40984652240a
 */
import React, { Component } from 'react';
import { Row, Col, Button} from 'antd';
import { Link } from 'react-router';
import background from '../../../assets/images/concentrate/bg-image.png';
import moment from 'moment';
import './concenFloor.css';
const DemoBox = props => <p className={`height-${props.value}`}>{props.children}</p>;

class ConcenEquipment extends Component {
   constructor() {
    super();
    this.state = {
      id:null,
      device:[],
    };
  }
  componentDidMount() {
    const id = parseInt(this.props.params.id, 10);
    this.setState({ id });
    //建筑
    window.rpc.device.getInfoById(id).then((result) => {
      const device = { ...result,name:result.name,location:result.location,networkAddr:result.networkAddr,lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };
      this.setState({ device });
    }, (err) => {
    console.warn(err);
     function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  render() {
    return (
      <div className="ConcenEquipment" style={{fontSize:14,fontFamily:'苹方中等'}}>
        <Row type="flex" justify="center" align="middle" style={{marginLeft:'5%'}}>
          <Col span={10} style={{marginTop:10}}>
            <DemoBox value={50}>
              设备名称： {this.state.device.name}
            </DemoBox>
          </Col>
          <Col span={12} style={{marginTop:10}}>
            <DemoBox value={50}>
              网关地址： {this.state.device.networkAddr}
            </DemoBox>
          </Col>
        </Row>
        <Row type="flex" justify="center" align="top" style={{marginLeft:'5%'}}>
          <Col span={10} style={{marginTop:10}}>
            <DemoBox value={50}>
              点状位置： {this.state.device.location}
            </DemoBox>
          </Col>
          <Col span={12} style={{marginTop:10}}>
            <DemoBox value={50}>
              发生时间： {this.state.device.lastTime}
            </DemoBox>
          </Col>
        </Row>
        <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD', marginTop:10 }} />     
        <Row style={{width:'100%', margin: '10% 0 ', position:'relative'}}>
          <Col span={18}>
          <img src={background} alt="设备定位图" style={{width:'100%',zIndex:1,marginLeft:'15%'}} />
          <span style={{width:12,height:12,borderRadius:30,background:'red',zIndex:2,position:'absolute',left:350,top:120}}></span>
          </Col>
        </Row>
        <br />
        <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
        <Row>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={6}></Col>
              <Col span={9}></Col>          
              <Col span={9}>
              <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px',marginTop:20,marginRight:30 }}><Link to={`/conct/handle/${this.state.id}`}>返回</Link></Button>
              </Col>
          </Row>
          </Col>
        </Row>
      </div>
    );
  }
}

export default ConcenEquipment;