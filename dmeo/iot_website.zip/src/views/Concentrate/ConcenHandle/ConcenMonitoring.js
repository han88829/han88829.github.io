/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:03:14
 */
import React, { Component } from 'react';

class ConcenMonitoring extends Component {
  render() {
    return (
      <div className="ConcenMonitoring">
       <video src="10.0.1.8" width="500" height="250" controls="controls">您的浏览器不支持此种视频格式。</video> 
      </div>
    );
  }
}

export default ConcenMonitoring;