/*
 * @Author: lai.haibo 
 * @Date: 2017-03-08 15:44:01 
 * @Last Modified by: xmj
<<<<<<< HEAD
 * @Last Modified time: 2017-03-28 15:49:42
=======
 * @Last Modified time: 2017-03-29 10:29:59
>>>>>>> 84a9beca2f3f38cc1a9532537d5e40984652240a
 */

import React, { Component } from 'react';
import { Row, Col, Card } from 'antd';
import { browserHistory } from 'react-router';
import ConcenRoute from './ConcenRoute';
import ConcenFloor from './ConcenFloor';
import ConcenBasic from './ConcenBasic';
import ConcenResources from './ConcenResources';
import ConcenEquipment from './ConcenEquipment';

export default class ConcenHandle extends Component {
  render() {
    let id = this.props.params.id;

    return (
      <div className="ConcenHandle" style={{ padding: '24px' }}>
        <Row gutter={16} style={{ padding: '5px 0'}}>
          <Col span={8}>
            <Card style={{ height: '400px', padding: '0',cursor:'pointer'  }} onDoubleClick={() => browserHistory.push(`/conct/basic/${id}`)}>
              <ConcenBasic params={this.props.params} />
            </Card>
          </Col>
          <Col span={8}>
            <Card style={{ height: '400px', padding: '0' }} onDoubleClick={() => browserHistory.push(`/conct/route/${id}`)}>
              <ConcenRoute params={this.props.params} />
            </Card>
          </Col>
          <Col span={8}>
            <Card style={{ height: '400px', padding: '0' }} onDoubleClick={() => browserHistory.push(`/conct/floor/${id}`)}>
              <ConcenFloor params={this.props.params}/>
            </Card>
          </Col>
        </Row>
        <Row gutter={16} style={{ padding: '5px 0'}}>
          <Col span={8}>
            <Card style={{ height: '400px', padding: '0' }} onDoubleClick={() => browserHistory.push(`/conct/resources/${id}`)}>
              <ConcenResources params={this.props.params} />
            </Card>
          </Col>
          <Col span={8}>
            <Card style={{ height: '400px', padding: '0',cursor:'pointer' }} onDoubleClick={() => browserHistory.push(`/conct/equipment/${id}`)}>
              <ConcenEquipment params={this.props.params} />
            </Card>
          </Col>
          <Col span={8}>
            <Card>
              处警监控
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}