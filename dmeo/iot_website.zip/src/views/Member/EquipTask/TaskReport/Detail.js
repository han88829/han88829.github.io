import React, { Component } from 'react';

class Detail extends Component {
  render() {
    return (
      <div>报表详情</div>
    )
  }
}

export default Detail;