import React, { Component } from 'react';

class TaskRules extends Component {
  render() {
    return (
      <div>报表列表</div>
    )
  }
}

export default TaskRules;