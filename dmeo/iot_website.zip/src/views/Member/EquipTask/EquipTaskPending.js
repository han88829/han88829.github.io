import React, { Component } from 'react';
import EquipTaskPendTr from './containers/EquipTaskPendTr.js';
import './containers/EquipTaskPend.css';


class MEquipTaskPending extends Component {
  render() {
    return (
      <div className="MEquipTaskPending" style={{ padding: '24px' }}>
          <EquipTaskPendTr/>
      </div>
    );
  }
}

export default MEquipTaskPending;