/*
 * @Author: Han.beibei 
 * @Date: 2017-03-03 16:24:19 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-03-04 10:22:16
 */
import React from 'react';
import { Form, Input, Cascader, Select, DatePicker, Row, Col,Button } from 'antd';
import { Link } from 'react-router';
import moment from 'moment';

const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;
const equipTypes = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const builds = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const EquipTaskRandomDetail = Form.create()(React.createClass({
  /*componentWillMount() {
    //console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    window.rpc.user.getInfoById(id).then((result) => {
      //console.log(result);
      this.props.form.setFieldsValue({
        name: result.name,
        number: result.number,
        username: result.username,
        password: result.password,
        email: result.email,
        mobile: result.mobile,
        level: result.level,
        groupId: result.groupId,
        ownerId: result.ownerId,
        gender: result.gender,
      });
      let time;
      if(result.setupTime==null){
        time=new Date().toLocaleString()
      }else{
        time=result.setupTime.toLocaleString()
      }
      const user = { ...result,name: result.name, expiryTime: result.expiryTime.toLocaleString(), setupTime:time};
      this.setState({ user });
    }, (err) => {
      console.warn(err);
    })
  },*/
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    // const config = {
    //   rules: [{ type: 'array', required: true, message: '请选择时间!' }],
    // };
    //const dateFormat = 'YYYY-MM-DD';

    return (
      <Form onSubmit={this.handleSubmit}>
        <Row style={{marginTop:20}}>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务标题："
            >
              {getFieldDecorator('name', {
                initialValue: '标题',
                rules: [{ type: 'string'}],
              })(
                <Input style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务说明："
            >
              {getFieldDecorator('task', { 
                initialValue:  "第一次抽检",
                rules: [{ type: 'string' }],
              })(
                <Input type="textarea" rows={3} style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
        </Row>
         <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
            >
              {getFieldDecorator('auditMethon', {
                initialValue:  "人工",
                rules: [
                  { type:'string'},
                ],
              })(
                <Input style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="任务开始--截至时间："
            >
                {/*<RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                  disabled
                  defaultValue={[moment('2015-09-26 08:50:08'), moment('2015-09-26 08:50:08')]}
                  style={{border:'none',background:'none'}}
                />*/
                getFieldDecorator('TaskDate', {
                initialValue:  "2015-09-26 08:50:08 ~ 2015-09-26 08:50:08",
                rules: [
                  { type:'string'},
                ],
              })(
                <Input style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检人选择："
            >
              {getFieldDecorator('Inspectors', {
                initialValue:  "自动分配",
                rules: [
                  { type:'string' },
                ],
              })(
                <Input style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检报表选择"
            >
              {getFieldDecorator('report', {
                initialValue:  "总表",
                rules: [
                  { type:'string' },
                ],
              })(
                <Input style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备类型选择："
            >
              {getFieldDecorator('equipType', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{}],
              })(
                <Input style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备建筑选择："
            >
              {getFieldDecorator('build', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{}],
              })(
                <Input  style={{border:'none',background:'none'}} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 30, right: 140 }}>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={9}>
                <FormItem {...tailFormItemLayout}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px' }}><Link to="/member/equiptask">返回</Link></Button>
                </FormItem>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    );
  },
}));

export default EquipTaskRandomDetail;