import React, { Component } from 'react';

class NewEquip extends Component {
  render() {
    return (
      <div>新建设备信息</div>
    )
  }
}

export default NewEquip;