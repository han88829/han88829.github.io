import React, { Component } from 'react';

class RulesDetail extends Component {
  render() {
    return (
      <div>规则详情</div>
    )
  }
}

export default RulesDetail;