/*
 * @Author: Han.beibei 
 * @Date: 2017-03-03 16:24:32 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-03-04 10:22:05
 */
import React from 'react';
import { Form, Input, Cascader, Select, Button, DatePicker, Row, Col, message } from 'antd';
import { Link, browserHistory } from 'react-router';
import listStore from '../listStore';

const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;
const {auditMethonType, InspectorsType, reportType} = listStore;

const equipTypes = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const builds = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const EquipTaskRandomEdit = Form.create()(React.createClass({
  /*componentWillMount() {
    //console.log(this.props)
    const id = parseInt(this.props.params.id, 10);
    window.rpc.user.getInfoById(id).then((result) => {
      //console.log(result);
      this.props.form.setFieldsValue({
        name: result.name,
        number: result.number,
        username: result.username,
        password: result.password,
        email: result.email,
        mobile: result.mobile,
        level: result.level,
        groupId: result.groupId,
        ownerId: result.ownerId,
        gender: result.gender,
      });
      let time;
      if(result.setupTime==null){
        time=new Date().toLocaleString()
      }else{
        time=result.setupTime.toLocaleString()
      }
      const user = { ...result,name: result.name, expiryTime: result.expiryTime.toLocaleString(), setupTime:time};
      this.setState({ user });
    }, (err) => {
      console.warn(err);
    })
  },*/
  handleSubmit(e) {
    e.preventDefault();
    const id = parseInt(this.props.params.id, 10);
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        // console.log('Received values of form: ', values);
       let {name, number, username, password, email, mobile, level, groupId, ownerId, gender} = values;
        let obj = {name,  number: parseInt(number, 10), username,password,email,mobile: parseInt(mobile, 10),level,groupId,ownerId, gender};

        console.log(obj);
        window.rpc.user.setInfoById(id, obj).then(() => {
          message.info('修改成功！');
          browserHistory.push('/member/equiptask');
        }, (err) => {
          console.log(err);
        })
      }
    });
  },
 
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    
    //取出结构表里的数据添加到选项中
    let auditMethonChildren = [];
    let InspectorsChildren = [];
    let dreportChildren = [];
    for(let i = 1; i < auditMethonType.length; i++) {
      auditMethonChildren.push(<Option key={`${i}`}>{auditMethonType[i]}</Option>)
    }
    for(let i = 1; i < InspectorsType.length; i++) {
      InspectorsChildren.push(<Option key={`${i}`}>{InspectorsType[i]}</Option>)
    }
    for(let i = 1; i < reportType.length; i++) {
      dreportChildren.push(<Option key={`${i}`}>{reportType[i]}</Option>)
    }

    const config = {
      rules: [{ type: 'array', required: true, message: '请选择时间!' }],
    };
    //const dateFormat = 'YYYY-MM-DD';

    return (
      <Form onSubmit={this.handleSubmit}>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务标题："
              hasFeedback
            >
              {getFieldDecorator('name', {
                initialValue:'第一次抽检',
                rules: [{ type:'string',required: true, message: '请输入任务标题!' }],
              })(
                <Input />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务说明："
              hasFeedback
            >
              {getFieldDecorator('task', {
                initialValue:'今天天气好',
                rules: [{ type:'string', required: true, message: '请输入任务说明!' }],
              })(
                <Input type="textarea" rows={3} />
              )}
            </FormItem>
          </Col>
        </Row>
         <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
              hasFeedback
            >
              {getFieldDecorator('auditMethon', {
                initialValue:'人工',
                rules: [
                  {type:'string', required: true, message: '请选择审核方式！' },
                ],
              })(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {auditMethonChildren}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="任务开始--截至时间："
            >
               {getFieldDecorator('TaskDate', config)(
                <RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                  /*onChange={onChange}*/
                  //defaultValue={[moment('2015-09-26 08:50:08'), moment('2015-09-26 08:50:08')]}
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检人选择："
              hasFeedback
            >
              {getFieldDecorator('Inspectors', {
                initialValue:'自动分配',
                rules: [
                  { type:'string', required: true, message: '请选择巡检人！' },
                ],
              })(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {InspectorsChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检报表选择"
              hasFeedback
            >
              {getFieldDecorator('report', {
                initialValue:'总表',
                rules: [
                  { type:'string', required: true, message: '请选择报表方式！' },
                ],
              })(
                <Select multiple style={{ width: 120 }} placeholder="请选择">
                  {dreportChildren}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备类型选择："
            >
              {getFieldDecorator('equipType', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{ type: 'array', required: true, message: '请选择类型!' }],
              })(
                <Cascader options={equipTypes} />
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备建筑选择："
            >
              {getFieldDecorator('build', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{ type: 'array', required: true, message: '请选择建筑!' }],
              })(
                <Cascader options={builds} />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row style={{ margin: '10px 0', position: 'absolute', bottom: 30, right: 140 }}>
          <Col span={20}></Col>
          <Col span={4}>
            <Row style={{ margin: '0' }}>
              <Col span={6}></Col>
              <Col span={9}>
                <FormItem {...tailFormItemLayout}>
                  <Button type="primary" htmlType="submit" size="large" style={{ backgroundColor: '#108ee9', color: '#fff', fontFamily: '微软雅黑', fontSize: '14px', borderRadius: '5px', position: 'absolute', right: 10 }}>确认修改</Button>
                </FormItem>
              </Col>
              <Col span={9}>
                <FormItem {...tailFormItemLayout}>
                  <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px' }}><Link to="/member/equiptask">返回</Link></Button>
                </FormItem>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    );
  },
}));

export default EquipTaskRandomEdit;