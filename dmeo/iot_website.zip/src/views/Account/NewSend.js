import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { Card, Row, Icon, Input, Select, Modal, Tag, Tooltip, Button, Menu, Dropdown, message, } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import LzEditor from 'react-lz-editor'
import './NewSend.css';

import redian from '../../assets/images/back/全网-0.png';

class appState {
    constructor() {
        extendObservable(this, {
            content: null,
        })
    }
}

const Option = Select.Option;
let ImageSrc = {};

const Draft = observer(class Draft extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            content: ``
        }
        this.receiveHtml = this.receiveHtml.bind(this);
    }

    receiveHtml(content) {
        this.props.appState.content = content;
    }
    render() {
        const uploadConfig = {
            QINIU_URL: "http://up.qiniu.com", //上传地址，现在暂只支持七牛上传
            QINIU_IMG_TOKEN_URL: "http://www.yourServerAddress.mobi/getUptokenOfQiniu.do", //请求图片的token
            QINIU_PFOP: {
                url: "http://www.yourServerAddress.mobi/doQiniuPicPersist.do" //七牛持久保存请求地址
            },
            QINIU_VIDEO_TOKEN_URL: "http://www.yourServerAddress.mobi/getUptokenOfQiniu.do", //请求媒体资源的token
            QINIU_FILE_TOKEN_URL: "http://www.yourServerAddress.mobi/getUptokenOfQiniu.do?name=patch", //其他资源的token的获取
            QINIU_IMG_DOMAIN_URL: "https://image.yourServerAddress.mobi", //图片文件地址的前缀
            QINIU_DOMAIN_VIDEO_URL: "https://video.yourServerAddress.mobi", //视频文件地址的前缀
            QINIU_DOMAIN_FILE_URL: "https://static.yourServerAddress.com/", //其他文件地址前缀
        }
        return <LzEditor
            active={true}
            image={false}
            video={false}
            audio={false}
            importContent={this.state.content}
            cbReceiver={this.receiveHtml}
            fullScreen={false}
            convertFormat="html" />
    }
})

const NewSendC = observer(class NewSendC extends Component {
    state = {
        visible: false,
        tags: [],
        inputVisible: false,
        inputValue: '',
        key: "2",
        title: null,
        type: "企业新闻",
        oldTag: [],
        value: "",

    }
    //图片上传
    componentWillMount() {
        window.rpc.upload.images.getDefaultConfig().then((res) => {
            let { domain, uptoken } = res;
            window.Qiniu.uploader({
                runtimes: 'html5,flash,html4',    //上传模式,依次退化
                browse_button: 'upload',       //上传选择的点选按钮，**必需**
                // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                uptoken: uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                //unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                //save_key: true,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
                // domain: `http://omdwajej6.bkt.clouddn.com/`,
                get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
                // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
                max_file_size: '5mb',           //最大文件体积限制
                unique_names: true,
                multi_selection: false,
                // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
                max_retries: 3,                   //上传失败最大重试次数
                // dragdrop: true,                   //开启可拖曳上传
                // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                chunk_size: '4mb',                //分块上传时，每片的体积
                auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                filters: {
                    max_file_size: '5mb',
                    prevent_duplicates: true,
                    // Specify what files to browse for
                    mime_types: [
                        { title: "Image files", extensions: "jpg,gif,png" }, // 限定jpg,gif,png后缀上传
                    ]
                },
                init: {
                    'FilesAdded': function (up, files) {
                        //plupload.each(files, function (file) {
                        // 文件添加进队列后,处理相关的事情
                        //});
                    },
                    'BeforeUpload': function (up, file) {
                        // 每个文件上传前,处理相关的事情

                    },
                    'UploadProgress': function (up, file) {
                        // 每个文件上传时,处理相关的事情
                    },
                    'FileUploaded': function (up, file, info) {
                        let domain = up.getOption('domain');
                        let res = JSON.parse(info);
                        var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
                        //console.log(sourceLink);
                        var asc = sourceLink;
                        document.getElementById('file_name').innerHTML = file.name + "上传成功！";
                        ImageSrc[file.name] = sourceLink;

                        let p = document.createElement("p");
                        p.style.float = "right";
                        p.style.margin = "0 10px";
                        p.style.cursor = "pointer"
                        p.innerHTML = `<span style="color:blue">${file.name}</span><p id=${file.name} style="float:right;margin-left:3px;width:15px;height:15px;text-align:center;title:点击删除;border:1px solid red;color:red;border-radius:50%;line-height:15px">X</p>`

                        document.getElementById("file_url").appendChild(p)
                        document.getElementById(file.name).onclick = function () {
                            let pp = document.getElementById(file.name).parentNode;
                            document.getElementById("file_url").removeChild(pp)
                            delete ImageSrc[file.name];
                            document.getElementById('file_name').innerHTML = file.name + "删除成功！";
                            setTimeout(function () {
                                document.getElementById('file_name').innerHTML = "";
                            }, 1500)
                        }
                    },
                    'Error': function (up, err, errTip) {
                        console.log(err)
                        //上传出错时,处理相关的事情
                        if (err.code === -600) {
                            document.getElementById('file_name').innerHTML = '图片过大，请上传4M以内的图片！';
                        } else if (err.code === -601) {
                            document.getElementById('file_name').innerHTML = '仅支持上传图片，请重新上传！';
                        } else if (err.code === -602) {
                            document.getElementById('file_name').innerHTML = '请勿重复上传图片！';
                        } else {
                            document.getElementById('file_name').innerHTML = '上传失败，请稍后重试！';
                        }
                    },
                    'UploadComplete': function () {
                        //队列文件处理完毕后,处理相关的事情
                    },
                    'Key': function (up, file) {
                        // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
                        // 该配置必须要在 unique_names: false , save_key: false 时才生效
                        var key = ``;
                        // do something with key here
                        return key
                    }
                }
            });
        }, (err) => {
            console.warn(err);
            function existError(err) {
                let t = err.toString();
                let r = /E(\d+): (.+)/;
                let e = r.exec(t);
                if (e && e.length >= 3) {
                    alertError(e[1], e[2]);
                }
            }
            function alertError(code, msg) {
                console.log('CODE:', code, "MSG:", msg);
                if (msg = 'Insufficient permissions') {
                    alert(`暂无权限!`);
                }
            }
            existError(err);
        })
    }

    componentDidMount() {
        window.rpc.term.getArrayIdNameByContainer(null, 0, 0).then((res) => {
            let tags = [];
            res.forEach((x) => {
                tags.push(x.name)
            })
            this.setState({ tags, oldTag: tags });
        }), (err) => {
            console.log(err)
        }
    }

    handleChange = (value) => {
        this.setState({
            type: value.label
        });
    }
    showModal = () => {
        this.setState({
            visible: true,
        });
    }
    handleOk = (e) => {
        this.setState({
            visible: false,
        });
    }
    handleCancel = (e) => {
        this.setState({
            visible: false,
        });
    }
    handletags = () => {
        let { tags, oldTag } = this.state;
        oldTag.forEach((x) => {
            if (tags.indexOf(x) < 0) {
                window.rpc.term.removeByName(x).then((res) => {
                    //console.log(res)
                })
            }
        })
        tags.forEach((x) => {
            if (oldTag.indexOf(x) < 0) {
                window.rpc.term.create({ name: x }).then((res) => {
                    // console.log(res)
                })
            }
        })
        message.info("保存成功！")
        this.setState({
            visible: false,
        });
    }

    // tag标签
    handleClose = (removedTag) => {
        const tags = this.state.tags.filter(tag => tag !== removedTag);
        this.setState({ tags });
    }

    showInput = () => {
        this.setState({ inputVisible: true }, () => this.input.focus());
    }

    handleInputChange = (e) => {
        this.setState({ inputValue: e.target.value });
    }

    handleInputConfirm = () => {
        const state = this.state;
        const inputValue = state.inputValue;
        let tags = state.tags;
        if (inputValue && tags.indexOf(inputValue) === -1) {
            tags = [...tags, inputValue];
        }
        this.setState({
            tags,
            inputVisible: false,
            inputValue: '',
        });
    }
    saveInputRef = input => this.input = input
    handleMenu = (e) => {
        this.setState({ key: e.key });
    }
    handleSubmit = () => {
        let { type, title, key } = this.state;
        if (!title) {
            message.info("请输入标题！");
            return
        }
        let content = this.props.appState.content;
        if (!content) {
            message.info("请输入内容！")
            return
        }
        window.rpc.term.getArrayByContainer({ name: type }, 0, 0).then((x) => {
            if (typeof ImageSrc === "object" && !(ImageSrc instanceof Array)) {
                var hasProp = false;
                for (var prop in ImageSrc) {
                    hasProp = true;
                    break;
                }
                if (!hasProp) {
                    message.info("请上传图片！");
                    return
                }
            }
            let value = { termId: x[0].id, file: ImageSrc, name: title, type: key, body: content }
            window.rpc.article.create(value).then((res) => {
                if (res) {
                    message.info("发布成功！")
                    browserHistory.push("/back")
                }
            })
        })

    }
    render() {
        const { tags, inputVisible, inputValue } = this.state;
        let tagsChild = [];
        tags.forEach((item, index, arr) => {
            tagsChild.push(<Option key={index.toString()} value={index.toString()}>{item}</Option>)
        })
        const menu = (
            <Menu onClick={this.handleMenu} className="NewSend_menu_c">
                <Menu.Item key="1">全网用户可见</Menu.Item>
                <Menu.Item key="2">单位用户可见</Menu.Item>
            </Menu>
        );
        return (
            <div className="NewSend">
                <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
                    <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>热点发布</Link>
                </div> <br />
                <div style={{ marginTop: 20, borderTop: "1px solid rgb(203, 202, 202)", width: "100%" }}></div>
                <Card style={{ marginTop: 20, paddingBottom: 18 }}>
                    <Row>
                        <div style={{ float: "left", width: "4%", textAlign: "left", paddingTop: 5 }}>标题：</div>
                        <Input style={{ width: "96%", borderRadius: 0 }} onChange={(e) => {
                            this.setState({
                                title: e.target.value
                            });
                        }} />
                    </Row>
                    <Row style={{ marginTop: 10 }} className="Draft">
                        <Draft appState={this.props.appState} />
                    </Row>
                    <Row style={{ marginTop: 20 }}>
                        <label htmlFor="Select">分类 ：</label>
                        <Select id="Select" labelInValue defaultValue={{ key: "0", label: "企业新闻" }} style={{ width: 120 }} onChange={this.handleChange}>
                            {tagsChild}
                        </Select>
                        <span onClick={this.showModal} style={{ cursor: "pointer", marginLeft: 10, fontSize: 12, color: "#be161e", fontFamily: "SimSun", textDecoration: "underline" }}>目录分类管理</span>
                        <Modal
                            title="目录分类管理"
                            visible={this.state.visible}
                            onOk={this.handleOk}
                            onCancel={this.handleCancel}
                            className="NewSend_Modal"
                        >
                            <div>
                                {tags.map((tag, index) => {
                                    const isLongTag = tag.length > 20;
                                    const tagElem = (
                                        <Tag key={tag} closable={!index == 0} afterClose={() => this.handleClose(tag)}>
                                            {isLongTag ? `${tag.slice(0, 20)}...` : tag}
                                        </Tag>
                                    );
                                    return isLongTag ? <Tooltip title={tag}>{tagElem}</Tooltip> : tagElem;
                                })}
                                {inputVisible && (
                                    <Input
                                        ref={this.saveInputRef}
                                        type="text"
                                        size="small"
                                        style={{ width: 78 }}
                                        value={inputValue}
                                        onChange={this.handleInputChange}
                                        onBlur={this.handleInputConfirm}
                                        onPressEnter={this.handleInputConfirm}
                                    />
                                )}
                                {!inputVisible && <Button size="small" type="dashed" onClick={this.showInput}> + 新增分类</Button>}
                                <div className="NewSend_Modal_save">
                                    <Button size="small" onClick={this.handletags}>保存设置</Button>
                                </div>
                            </div>
                        </Modal>
                        <div style={{ float: "right" }}>

                            <Button id="upload">
                                <Icon type="upload" />上传图片
                            </Button>
                            <span id="file_name" style={{ marginLeft: 15 }}>

                            </span>
                        </div>
                        <div style={{ textAlign: "right", marginTop: 10 }} id="file_url">

                        </div>
                    </Row>
                    <div style={{ width: "100vw", borderTop: "1px solid #e6b85c", marginTop: 50, marginLeft: "-50px" }}></div>
                    <Row style={{ marginTop: 10, position: "absolute", right: 10, width: 220 }}>
                        <img src={redian} alt="" style={{ position: "absolute", top: 1 }} />
                        <span style={{ marginLeft: 35, borderLeft: "1px solid #ede8d1", paddingLeft: 10 }}>可见范围 ： </span>
                        <Dropdown overlay={menu} placement="bottomRight">
                            <span style={{ cursor: "pointer" }}>
                                {this.state.key == 1 ? "公开" : "站内"}
                            </span>
                        </Dropdown>
                        <div style={{ float: "right", width: 50, height: 28, marginTop: "-3px", textAlign: "center", lineHeight: "25px", cursor: "pointer", marginLeft: 15, backgroundColor: "#e6b85c", color: "white", border: "1px solid d6a647" }} onClick={this.handleSubmit}>发布</div>
                    </Row>
                </Card>
            </div >
        );
    }
})


class NewSend extends Component {
    render() {
        return (
            <NewSendC appState={new appState()} />
        );
    }
}

export default NewSend;
