/*
 * @Author: Han.beibei 
 * @Date: 2017-04-06 09:35:10 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-27 10:42:42
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { observer } from 'mobx-react';
import { extendObservable } from 'mobx';
import { Form, message, Input, Select, Button, Row, Col, Radio } from 'antd';
import './Account.css';
import listStore from './Area';

const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const FormItem = Form.Item;
const { City } = listStore;
const Option = Select.Option;
// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      number: null,
      CityChild: [],
      shiChild: [],
    })
  }
}
const NewStaff = observer(Form.create()(React.createClass({
  getInitialState() {
    return {

    };
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        message.info('已提交')
      }
    });
  },
  onChange(e) {
    //console.log(`radio checked:${e.target.value}`);
  },
  handleChange(value) {
    //console.log(value)
    let shiChild = [];
    //let shiData = City[value].city;
    for (let i = 0; i < City[value]['city'].length; i++) {
      shiChild.push(<Option key={`${i + '@'}`}>{City[value]['city'][i].name}</Option>)
    }
    this.props.appState.shiChild = shiChild;
    //console.log(this.props.appState.shiChild)
  },
  componentDidMount() {

  },
  render() {
    let CityChild = [];
    for (let i = 0; i < City.length; i++) {
      CityChild.push(<Option key={`${i}`}>{City[i].name}</Option>)
    }
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    return (
      <div className="Basis">
        <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
          <Link to='' style={{ padding: '2px 12px 2px 10px', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>基本资料</Link>
        </div><br />
        <div style={{ widht: '100%', fontSize: 12, color: '#666666', fontFamily: '苹方中等', height: 30, marginTop: 20, background: '#f9f9f9', lineHeight: '30px', border: '1px solid #dddddd' }}>&nbsp;&nbsp;&nbsp;请完善以下信息，方便我们更好的为您服务</div>
        <Form onSubmit={this.handleSubmit} >
          <div style={{ marginTop: 10, color: '#373d41', fontFamily: '苹方中等' }}>基本信息</div>
          <div style={{ marginLeft: '3%', marginTop: 10, fontSize: '12px',lineHeight :'36px'}}>
            <div><span style={{ color: 'red' }}>*&nbsp;</span>会员身份 ： &nbsp;&nbsp;&nbsp;个人</div>
            <div><span style={{ color: 'red' }}>*&nbsp;</span>真实姓名 ： &nbsp;&nbsp;&nbsp;王小明</div>
          </div>
          <div style={{ marginTop: 10, color: '#373d41', fontFamily: '苹方中等' }}>业务信息</div>
          <div style={{ marginLeft: '3%' }}>
            <Row style={{ marginTop: 10 }}>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="主要行业应用："
                  hasFeedback
                >
                  {getFieldDecorator('username', {
                    initialValue: '1',
                    rules: [{ required: true, message: '请选择应用类型!' }],
                  })(
                    <Select placeholder="请选择应用">
                      <Option value="1">网站</Option>
                      <Option value="2">手机应用</Option>
                    </Select>
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row style={{ marginLeft: '8.3%' }}>
              <Col span={20}>
                <FormItem
                  {...formItemLayout}
                  hasFeedback
                >
                  {getFieldDecorator('type', {
                    rules: [{ required: true, message: '请选择应用类型!' }],
                  })(
                    <RadioGroup onChange={this.onChange}>
                      <RadioButton style={{ background: '#eaeef2' }} value="社区/论坛/博客">社区/论坛/博客</RadioButton>
                      <RadioButton style={{ marginLeft: 10, background: '#eaeef2' }} value="企业官网">企业官网</RadioButton>
                      <RadioButton style={{ marginLeft: 10, background: '#eaeef2' }} value="综合门户">综合门户</RadioButton>
                      <RadioButton style={{ marginLeft: 10, background: '#eaeef2' }} value="个人站长">个人站长</RadioButton>
                      <RadioButton style={{ marginLeft: 10, background: '#eaeef2' }} value="网建公司">网建公司</RadioButton>
                      <RadioButton style={{ marginLeft: 10, background: '#eaeef2' }} value="其他">其他</RadioButton>
                    </RadioGroup>
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="主营业务："
                  hasFeedback
                >
                  {getFieldDecorator('name', {
                    rules: [{ required: true, message: '请输入产品名称！!' }],
                  })(
                    <Input placeholder="产品名" />
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="&nbsp;网址："
                  hasFeedback
                >
                  {getFieldDecorator('www', {
                    rules: [{ required: false, message: '请输入网址！' }],
                  })(
                    <Input placeholder="www.baidu.com" />
                    )}
                </FormItem>
              </Col>
            </Row>
          </div>
          <div style={{ color: '#373d41', fontFamily: '苹方中等' }}>联系信息</div>
          <div style={{ marginLeft: '3%' }}>
            <Row style={{ marginTop: 10 }}>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="&nbsp;国家/地区："
                  hasFeedback
                >
                  {getFieldDecorator('china', {
                    initialValue: '中国',
                    rules: [{ required: false, message: '请输入国家！' }],
                  })(
                    <Input disabled />
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="所在地区："
                  hasFeedback
                >
                  {getFieldDecorator('province', {
                    rules: [{ required: true, message: '请选择省份！' }],
                  })(
                    <Select placeholder="请选择省份！" onChange={this.handleChange}>
                      {CityChild}
                    </Select>
                    )}
                </FormItem>
              </Col>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  hasFeedback
                >
                  {getFieldDecorator('city', {
                    rules: [{ required: true, message: '请选择城市！' }],
                  })(
                    <Select placeholder="请选择城市！">
                      {this.props.appState.shiChild}
                    </Select>
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="&nbsp;街道地址："
                  hasFeedback
                >
                  {getFieldDecorator('street', {
                    rules: [{ required: true, message: '请输入街道地址！' }],
                  })(
                    <div>
                      <Input />
                    </div>
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="&nbsp;联系电话："
                  hasFeedback
                >
                  {getFieldDecorator('tel', {
                    rules: [{ required: false, message: '请输入联系电话!' }],
                  })(
                    <div>
                      <Input />
                    </div>
                    )}
                </FormItem>
              </Col>
            </Row>
            <Row>
              <Col span={6}>
                <FormItem
                  {...formItemLayout}
                  label="&nbsp;传真："
                  hasFeedback
                >
                  {getFieldDecorator('fax', {
                    rules: [{ required: false, message: '请输入传真！' }],
                  })(
                    <Input />
                    )}
                </FormItem>
              </Col>
            </Row>
            <FormItem style={{ marginLeft: '-22%' }} {...tailFormItemLayout}>
              <Button type="primary" htmlType="submit" size="large" style={{ color: '#fff', fontSize: '12px', fontFamily: '苹方中等' }}>保存</Button>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  }
})));

class Basis extends Component {
  render() {
    return (
      <div className="NewStaff">
        <NewStaff appState={new appState()} />
      </div>
    );
  }
}

export default Basis;