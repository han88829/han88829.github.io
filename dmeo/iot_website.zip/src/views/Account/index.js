/*
 * @Author: Han.beibei 
 * @Date: 2017-04-06 09:35:10 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-07-28 15:41:09
 */
import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router';
const { Sider, Content } = Layout;

const routes = {
  list: [{
    name: '安全设置',
    path: '/acc/safe',
    key: '1'
  }],
  rule: [{
    name: '基本信息',
    path: '/acc/basis',
    key: '2'
  }],
  report: [{
    name: '实名认证',
    path: '/acc/real',
    key: '3'
  }],
  newsend: [{
    name: '热点发布',
    path: '/acc/newsend',
    key: '4'
  },{
    name: '热点信息',
    path: '/acc/new/manage',
    key: '5'
  }]
}

class Account extends Component {
  state = {
    collapsed: false,
    seconds: {
      background: '#eaedf1'
    },
    route: routes.list,
    routeName: '个人中心',
    routeKey: '1'
  };
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
      seconds: {
        background: '#eaedf1',
        display: this.state.collapsed ? 'block' : 'none'
      }
    });
  };
  componentWillMount() {
    if (this.props.children) {
      let path = this.props.children.props.route.path;
      if (path === '/acc/safe') {
        this.setState({
          route: routes.list,
          routeName: '安全设置',
          routeKey: '1'
        })
      } else if (path === '/acc/basis') {
        this.setState({
          route: routes.rule,
          routeName: '基本信息',
          routeKey: '2'
        })
      } else if (path === '/acc/real') {
        this.setState({
          route: routes.report,
          routeName: '实名认证',
          routeKey: '3'
        })
      }else if (path === '/acc/newsend') {
        this.setState({
          route: routes.newsend,
          routeName: '热点发布',
          routeKey: '4'
        })
      }
    }
  };
  componentWillReceiveProps(nextProps) {
    let path = nextProps.children.props.route.path;
    if (path === '/acc/safe') {
      this.setState({
        route: routes.list,
        routeName: '安全设置',
        routeKey: '1'
      })
    } else if (path === '/acc/basis') {
      this.setState({
        route: routes.rule,
        routeName: '基本信息',
        routeKey: '2'
      })
    } else if (path === '/acc/real') {
      this.setState({
        route: routes.report,
        routeName: '实名认证',
        routeKey: '3'
      })
    }else if (path === '/acc/newsend') {
        this.setState({
          route: routes.newsend,
          routeName: '热点发布',
          routeKey: '4'
        })
      }
    let routerkeys = Object.keys(routes);
    let route = [...routes[routerkeys[0]], ...routes[routerkeys[1]], ...routes[routerkeys[2]]];
    let routeKey = route.filter(x => x.path === path)[0] ? route.filter(x => x.path === path)[0].key : '10000';
    this.setState({
      routeKey
    });
  };
  render() {
    return (
      <Layout className="Task">
        <Sider
          trigger={null}
          collapsible
          collapsed={this.state.collapsed}
          style={this.state.seconds}
          width={180}
        >
          <div className="logo" style={{ background: '#eaedf1', height: '70px', lineHeight: '70px', paddingLeft: '24px' }}>{this.state.routeName}</div>
          <Menu theme="light" mode="inline" defaultSelectedKeys={[this.state.routeKey]} selectedKeys={[this.state.routeKey]} style={{ background: '#eaedf1' }}>
            {this.state.route.map(route => (<Menu.Item key={route.key} style={{ height: '40px' }}><Link to={route.path} style={{ color: "#666" }}>{route.name}</Link></Menu.Item>))}
          </Menu>
        </Sider>
        <Layout style={{ padding: '0', position: 'static!important' }}>
          <div className="toggle" style={{ height: '32px', width: '18px', background: this.state.collapsed ? '#eaedf1' : '#fff', textAlign: 'center', position: 'absolute', top: '50vh', marginLeft: this.state.collapsed ? 0 : '-18px' }}>
            <Icon
              className="trigger-right"
              type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
              onClick={this.toggle}
            />
          </div>
          <Content style={{ margin: 0, padding: 24, background: '#fff', minHeight: 280 }}>
            {this.props.children}
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Account;