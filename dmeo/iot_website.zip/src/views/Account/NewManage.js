/*
 * @Author: Han.beibei 
 * @Date: 2017-04-06 09:35:10 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-07-29 11:39:48
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { Card, Row,Col, Icon, Input, Select, Modal, Tag, Table, Button, Menu, Dropdown, message, } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import QuitScreen from '../../assets/images/application/exit-fullscreen.png';;
import Close from '../../assets/images/application/shut-o.png';
import moment from 'moment';
import $ from 'jquery';
// import suss from '../../assets/images/account/suss.png';
// import man from '../../assets/images/account/head.png';
// import tex from '../../assets/images/account/tex.png';
// import qqq from '../../assets/images/account/qqq.png';
let number=0;
class appState {
  constructor() {
    extendObservable(this, {
      articleId:null,
      article:{},
      tableData:[],
      obj:{}
    })
  }
}
const ArticleDetails = observer(class appState extends React.Component {
  state={
    obj:{
    name:'',
    body:'',
    userId:'',
    type:''
   }
  }
    // componentDidMount(){
    //    // let articleId = JSON.parse(sessionStorage.getItem('articleId')) || null;
    //     //let id=this.props.id||articleId;
    //     let id=this.props.appState.articleId||0;
    //     //console.log(this.props.)
    //     window.rpc.article.getInfoById(id).then(res=>{
    //       window.rpc.alias.getValueByName('article.type').then(name=>{
    //         window.rpc.user.getInfoById(res.userId).then(user=>{
    //          let data={...res,type:name[res.type],userId:user.name}
    //          this.setState({obj:data});
    //          this.props.appState.obj=data;
    //          $('#body')[0].innerHTML=data.body;
    //        })
    //       })
          
    //     },err=>{
    //       console.warn(err);
    //     })
    // }
    render(){
          //console.log(this.props.appState.articleId);
          //console.log(this.props.appState.article);
         return (
           <div style={{display:this.props.appState.articleId?'block':'none',width:'100vw'}}>
             <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等',padding:'20px 0 10px 20px'}}>
               <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
                 <Link to=''  onClick={() => this.setState({warnInfoId:null})} style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>解决方案</Link>
               </div>
              </div>
              <div style={{width: '60%',margin: '0 20%',fontSize: '14px'}}>
               <h3 style={{textAlign:'center',fontSize:28}}>{this.props.appState.article.name||'题目'}</h3>
               <div style={{textAlign:'center',color:'#999'}}>{this.props.appState.article.userId}</div>
               <div style={{fontSize:12,color:"#ccc"}}>分类：{this.props.appState.article.type}</div>
               <div id='body' style={{padding:'20px 0'}}>{this.props.appState.article.body}</div>
              </div>
           </div>       
         )
     }
 });
class NewManageC extends Component {
  state = {
    data:[]
  }
  componentWillMount() {
    //查用户信息
    window.rpc.article.getArray(0,0).then(data=>{
       
      window.rpc.alias.getValueByName('article.type').then(type=>{
        window.rpc.user.getMapIdNameByContainer({},0,0).then(name=>{
          //console.log(data);
          number=data.length;
          let article=data.map(x=>({...x,key:x.id,type:type[x.type],body:x.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'').length>32?`${x.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'').substring(0,30)}...`:x.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,''),name:x.name||'',author:name[x.userId]||x.userId,createTime:moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss')}));
          this.setState({data:article});
          this.props.appState.tableData=article;
      })
     })
    },err=>{
        console.warn(err);
    })
    
  }
   handleStaffLine = (index) => {
      //console.log(index); //deviceId get
      //sessionStorage.setItem('articleId', JSON.stringify(index));
      this.setState({articleId:index});
      this.props.appState.articleId=index;
      let id=parseInt(index,10);
        window.rpc.article.getInfoById(id).then(res=>{
          window.rpc.alias.getValueByName('article.type').then(name=>{
            window.rpc.user.getInfoById(res.userId).then(user=>{
             let data={...res,type:name[res.type],userId:user.name,body:res.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'').length>32?`${res.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'').substring(0,30)}...`:res.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'')}
             //this.setState({obj:data});
             this.props.appState.article=data;
             //$('#body')[0].innerHTML=data.body;
           })
          })
          
        },err=>{
          console.warn(err);
        })
 }
  render() {
    let   data=this.state.data;
    
    //console.log(data);
    
   const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      //sorter: (a, b) => a.id - b.id,
      //sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
     }, {
       title: '题目',
       dataIndex: 'name',
       key: 'name'
     },
      { title: '作者', dataIndex: 'author', key: 'author' },
      { title: '类别', dataIndex: 'type', key: 'type' },// text.body.
      { title: '内容', dataIndex: 'body', key: 'body' , render: (text, record) => (
        <span>
         {//text.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'').length>50?`${text.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'').substring(0,48)}...`:text.body.replace(/<\/?[^>]*>/g,'').replace(/&nbsp;/ig,'')
         text
         }
        </span>
      )
    },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link  onClick={()=>this.handleStaffLine(text.id)} to={``}>详情</Link>
       
        </span>
      )
    }];

    const pagination = {
      total:number,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        //console.log('Current: ', current);
      },
    };

    return (
      <div className="OrgManage" style={{ position: 'relative' }}>
        <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
             <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>热点信息</Link>
         </div> <br />
         <div>
           <div style={{position:'fixed ',display:this.state.articleId?'flex':'none',background:'#fff',width:'100%',height:'100%', top: 0,left: 0,zIndex:99}}>  
                <div className="pingmiantu-top" style={{position:'absolute' ,top:0,right:2}}>
                    {/*<Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState(() => ({articleId:null}))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>*/}
                    <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState(() => ({articleId:null}))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
                </div>
                <ArticleDetails  id={this.state.articleId} appState={this.props.appState}  />
            </div>
         </div>
         <div>      
           <Row style={{ padding: '5px 0 0' }}>
             <Col span={24}>
               <Table
                 style={{ textAlign: 'center', color: '#999' }}
                 columns={columns}
                 dataSource={data}
                 //rowSelection={rowSelection}
                 //pagination={pagination}
                />
             </Col>
           </Row>
         </div>
      </div>
    );
  }
}

class NewManage extends Component {
    render(){
         return (
             <div >
               <NewManageC  appState={new appState()} params={this.props.params}  />
             </div>       
         )
    }
}
export default NewManage;