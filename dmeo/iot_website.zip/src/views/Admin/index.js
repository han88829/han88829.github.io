import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { Layout, Menu, Icon, Badge, message, Tooltip, Modal} from 'antd';
import moment from 'moment';
const { Header, Content, Sider } = Layout;
const SubMenu = Menu.SubMenu;

import hot from '../../assets/images/back/hot.png';
import logo from '../../assets/logo.png';
import safe from '../../assets/images/account/safe.png';
import basis from '../../assets/images/account/basis.png';
import real from '../../assets/images/account/real.png';
import pic_1_2 from '../../assets/images/task/单位统计.png';
import pic_1_3 from '../../assets/images/task/消防整改.png';
import pic_1_4 from '../../assets/images/menu/单位管理.png';
import pic_1_1 from '../../assets/images/menu/设置.png';
import pic_2_1 from '../../assets/images/menu/建筑管理.png';
import pic_3_1 from '../../assets/images/menu/人员管理.png';
import pic_3_2 from '../../assets/images/menu/部门管理.png';
import pic_3_3 from '../../assets/images/menu/绩效管理.png';
import pic_4_1 from '../../assets/images/menu/设备管理.png';
import pic_5_1 from '../../assets/images/menu/监控管理.png';
import pic_5_2 from '../../assets/images/menu/文件管理.png';
import pic_5_3 from '../../assets/images/menu/实时监控.png';
import pic_6_3 from '../../assets/images/menu/报警处理.png';
import pic_6_1 from '../../assets/images/menu/报警管理.png';
import pic_6_2 from '../../assets/images/menu/报警统计.png';
import pic_6_4 from '../../assets/images/menu/报警-设定.png';

import pic_7_1 from '../../assets/images/menu/联系人管理.png';
import pic_7_2 from '../../assets/images/menu/短信管理.png';
import pic_7_3 from '../../assets/images/menu/短信模版.png';

import pic_9_1 from '../../assets/images/menu/巡逻管理.png';

import pic_9_4 from '../../assets/images/menu/巡逻点管理.png';
import pic_9_3 from '../../assets/images/menu/巡逻人管理.png';
import pic_9_5 from '../../assets/images/menu/巡逻统计.png';
import pic_9_2 from '../../assets/images/menu/巡逻详情查看.png';

import pic_8_1 from '../../assets/images/menu/任务清单.png';
import pic_8_2 from '../../assets/images/menu/任务报表.png';
import pic_8_3 from '../../assets/images/menu/任务规则.png';
import './admin.css';
let menuObj = {
  '1-1': pic_1_1, '1-2': pic_1_2, '1-3': pic_1_3, '1-4': pic_1_4,
  '2-1': pic_2_1, '2-2': pic_1_4,
  '3-1': pic_3_1, '3-2': pic_3_2, '3-3': pic_3_3,'3-4': pic_9_3,
  '4-1': pic_4_1, '4-2': pic_1_4,
  '5-1': pic_5_1, '5-2': pic_5_2, '5-3': pic_5_3,
  '6-1': pic_6_1, '6-2': pic_6_2, '6-3': pic_6_3, '6-4': pic_6_4,
  '7-1': pic_7_1, '7-2': pic_7_2, '7-3': pic_7_3,
  '8-1': pic_8_1, '8-2': pic_8_2, '8-3': pic_8_3,
  '9-1': pic_9_1, '9-2': pic_9_2, '9-3': pic_9_3, '9-4': pic_9_4, '9-5': pic_9_5
};
let menuListObj = {
  '1-1': '/org/manage', '1-2': '/org/stati', '1-3': '/org/preserve', '1-4': '/org/type/manage',
  '2-1': '/org/bding/manage', '2-2': '/org/bdtype/manage', '3-1': '/memb/staff',
  '3-2': '/memb/group', '3-3': '/memb/prfrm','3-4': '/memb/staff/map',
  '4-1': '/equip/manage', '4-2': '/equip/type/manage',
  '5-1': '/moni', '5-2': '/moni/resource/vedio', '5-3': '/moni/realtime',
  '6-1': '/conct/manage', '6-2': '/conct/statistics', '6-3': '/conct/history', '6-4': '/conct/settings',
  '7-1': '/noti/cont', '7-2': '/noti/manage', '7-3': '/noti/stencil',
  '8-1': '/task/list', '8-2': '/task/rule', '8-3': '/task/report',
  '9-1': '/memb/patrol', '9-2': '/memb/patrol/detail', '9-3': '/memb/patrol/man',
  '9-4': '/memb/patrol/point',
  '9-5': '/memb/patrol/point/info'
};
function store(key, value) {
  sessionStorage.setItem(key, JSON.stringify(value));
}
let messageList = ['产品消息', '安全消息', '服务消息', '活动消息', '历史消息', "故障消息"];
class Admin extends Component {
  state = {
    collapsed: false,
    mode: 'inline',
    openkeys: [],
    visible: false,
    menuModal: false,
    Message: false,
    number: null,
    groupPermissionData: [],
    userPermissionData: [],
    messData: []
  };
  componentDidMount() {
    // 消息
    window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then((result) => {
      let data = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01 8:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
      this.setState({ messData: data, number: result.length });
    }), (err) => {
      console.warn(err)
    }
    let that = this;
    window.rpc.menu.getInfo().then(result => {
      let trueArrLayerOne = [];
      for (let i = 0; i < result.length; i++) {
        if (result[i].default === true) {
          let trueArrLayerTwo = [];
          for (let j = 0; j < result[i].data.length; j++) {
            if (result[i].data[j].default === true) {
              trueArrLayerTwo.push(result[i].data[j]);
              if (j === result[i].data.length - 1) {
                result[i].data = trueArrLayerTwo;
                trueArrLayerOne.push(result[i])
              }
            } else {
              if (j === result[i].data.length - 1) {
                result[i].data = trueArrLayerTwo;
                trueArrLayerOne.push(result[i])
              }
            }
          }
        }
      }
      that.setState({ userPermissionData: trueArrLayerOne });
    }, err => {
      console.warn(err)
    })

  }



  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
    });
  }

  logout(e) {
    e.preventDefault();
    if (window.rpc) {
      window.rpc.user.session.destroy().then(result => {
        message.success('注销成功！');
        window.location.href = '/login';
      }, err => {
        console.warn(err)
      })
    };
  }
  openChange = (openkeys) => {
    const state = this.state;
    const latestOpenKey = openkeys.find(key => !(state.openkeys.indexOf(key) > -1));
    const latestCloseKey = state.openkeys.find(key => !(openkeys.indexOf(key) > -1));
    let nextOpenKeys = [];
    if (latestOpenKey) {
      nextOpenKeys = [latestOpenKey];
    }
    if (latestCloseKey) {
      nextOpenKeys = [];
    }
    this.setState({ openkeys: nextOpenKeys });
  };

  handleChange = (value) => {
    browserHistory.push(value);
  };

  // componentDidMount() {
  // }

  componentWillReceiveProps(nextProps) {
    // 消息
    window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then(result => {
      let data = result.map((x) => ({ ...x, key: x.id, name: x.name, type: messageList[x.type], createTime: moment(x.createTime || new Date('2017-01-01 8:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
      this.setState({ messData: data, number: result.length });
    }), err => {
      console.warn(err)
    }
    this.setState({
      collapsed: true
    })
  }

  //个人中心
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOk = (e) => {
    // //console.log(e);
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    // //console.log(e);
    this.setState({
      visible: false,
    });
  }

  //消息
  showModalMessage = () => {
    this.setState({
      Message: true,
    });
  }

  handleOkMessage = (e) => {
    // //console.log(e);
    this.setState({
      Message: false,
    });
  }

  handleCancelMessage = (e) => {
    // //console.log(e);
    this.setState({
      Message: false,
    });
  }

  // 菜单Modal
  showMenuModal = () => {
    this.setState({
      menuModal: !this.state.menuModal,
    });
  }

  handleMenuModalOk = (e) => {
    // //console.log(e);
    this.setState({
      menuModal: false,
    });
  }

  handleMenuModalCancel = (e) => {
    // //console.log(e);
    this.setState({
      menuModal: false,
    });
  }

  render() {
    /*const menu = (
      <Menu>
        <Menu.Item key="0">
          <Link to="/apply/alarmequipmapmonitore/1">警情集中处理</Link>
        </Menu.Item>
        <Menu.Item key="1">
          <Link to="/apply/monitor">监控综合管理</Link>
        </Menu.Item>
       
        <Menu.Item key="4">
          <Link to="/apply/equipcenter">设备统一管理</Link>
        </Menu.Item>
      </Menu>
    );*/
    //let userdata = this.state.userPermissionData;
    return (
      <Layout className={this.state.collapsed ? "Admin" : "Admin Admin-not-collapsed"}>
        <Header className="header">
          <div className="logo" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <img src={logo} className="App-logo" alt="logo" />
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', backgroundColor: '#373d41', width: 560, borderLeft: '1px solid #333', borderBottom: 'none', textAlign: 'center' }}
            >
              <Menu.Item key="l0" style={{ width: 130 }}><Link to="/safecenter"> 安全云中心</Link></Menu.Item>
              <Menu.Item key="l1" style={{ width: 130 }}><Link to="/back"> 工作台</Link></Menu.Item>
              <Menu.Item key="l2" style={{ width: 130 }}><Link to="/apply/equip"> 应急中心</Link></Menu.Item>
              <Menu.Item key="l3" style={{ width: 130 }}><Link to="/fire"> 消防知识库</Link></Menu.Item>
              <Menu.Item key="5"><div style={{ position: "relative", width: 100, textAlign: "right", }}><Link to="/acc/newsend" className="menuR"><img src={hot} alt="" style={{ top: 18, right: 70, position: "absolute",width: 20,height: 16,borderRadius: 0,margin: 0}} />热点发布</Link></div></Menu.Item>
            </Menu>
            {/* <div style={{ lineHeight: '50px', backgroundColor: this.state.menuModal ? "#fff" : "#373d41", width: 112, padding: 0, borderLeft: '1px solid #333', borderRight: '1px solid #333', borderBottom: 'none', textAlign: 'center' }}>
              <Dropdown overlay={menu} trigger={['click']} onClick={this.showMenuModal} getPopupContainer={() => document.querySelector('.Admin')}>
                <a className="ant-dropdown-link" href="#" style={{ color: this.state.menuModal ? "#000" : "#fff" }}>
                  GIS应用 <Icon type={!this.state.menuModal ? "caret-down" : "caret-up"} />
                </a>
              </Dropdown>
              <Modal className="menuModal" visible={this.state.menuModal}
                onOk={this.handleMenuModalOk} onCancel={this.handleMenuModalCancel}
                footer={null} width="100vw" style={{ top: 50, height: 240 }}
              >
              </Modal>
            </div> */}
          </div>
          <Menu
            theme="dark"
            mode="horizontal"
            style={{ lineHeight: '50px', backgroundColor: '#373d41' ,fontSize:15}}
          >
           {/*<Menu.Item key="6"><div style={{ position: "relative", width: 100, textAlign: "right", }}><Link to="/acc/newsend" className="menuR"><img src={hot} alt="" style={{ top: 18, right: 70, position: "absolute" }} />热点发布</Link></div></Menu.Item>*/}
            {/*<Menu.Item key="6"><Link to="/mess/send">站内消息</Link></Menu.Item>*/}
            <Menu.Item key="2">技术支持</Menu.Item>
            <Menu.Item key="3" style={{ borderLeft: '1px solid #333' }}>
              <div onClick={this.showModalMessage} style={{ position: 'relative' }} >
                <Icon type="mail" />通知<Badge count={this.state.number} />
                <Modal
                  className="Message"
                  visible={this.state.Message}
                  onOk={this.handleOkMessage}
                  onCancel={this.handleCancelMessage}
                  footer={null}
                  style={{ top: 50 }}
                >
                  <div>
                    <div className="messageOne">
                      <div className="Oneone">站内消息通知</div>
                      <div className="OneThree" onClick={this.handleCancelMessage}><Link to='/mess/send' style={{ color: "#111111" }}>站内消息发送</Link></div>
                      <div className="Onetwo" onClick={this.handleCancelMessage}><Link to='/mess/manage' style={{ color: "#111111" }}>消息接受管理</Link></div>
                    </div>
                    <div className="messageTwo">
                      {this.state.messData.map((x) => (
                        <div key={x.id} className="message-Detail" onClick={() => {
                          browserHistory.push('/mess/all');
                          this.setState({
                            Message: false,
                          });
                        }} >
                          <Link to='mess/all' onClick={() => {
                            {/*browserHistory.push('')*/ }
                            this.setState({
                              Message: false,
                            });

                          }}>{x.name}</Link>
                          < br />
                          {x.createTime}
                        </div>
                      ))}
                      {this.state.messData.length === 0 ? "您暂时没有新消息！" : ""}
                    </div>
                    <div className="messageThree">
                      <Link to="/mess/all" onClick={this.handleCancelMessage}>查看更多</Link>
                    </div>
                  </div>
                </Modal>
              </div>
            </Menu.Item>
            <Menu.Item key="4" style={{ backgroundColor: '#2a2f32' }} >
              <div onClick={this.showModal} style={{ position: 'relative' }}>
                <Icon type="user" />
                <span >个人</span>
                <Modal
                  visible={this.state.visible}
                  onOk={this.handleOk} onCancel={this.handleCancel}
                  style={{ top: 50 }}
                  className="Account"
                >
                  <div className="basis" onClick={this.handleCancel}>
                    <Link to="/acc/basis">
                      <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                        <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                          <img src={basis} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="basis" />
                        </div>
                        <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                          <span style={{ color: '#111111' }} >基本信息</span>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="basis" onClick={this.handleCancel}>
                    <Link to="/acc/real">
                      <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                        <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                          <img src={real} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="real" />
                        </div>
                        <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                          <span style={{ marginTop: 30, color: '#111111' }}> 实名认证</span>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="basis" onClick={this.handleCancel}>
                    <Link to="/acc/safe">
                      <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                        <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                          <img src={safe} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="safe" />
                        </div>
                        <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                          <span style={{ marginTop: 30, color: '#111111' }}> 安全设置</span>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="easc" onClick={this.logout}>退出管理控制台</div>
                </Modal>
              </div>
            </Menu.Item>
          </Menu>
        </Header>
        <Layout>
          <Sider
            trigger={null}
            collapsible
            collapsed={this.state.collapsed}
            width={200}
          >
            <div className="logo" style={{ height: '30px', background: '#4a5064', textAlign: 'center' }}>
              <i className="iconfont-lszp trigger" onClick={this.toggle} dangerouslySetInnerHTML={{ __html: this.state.collapsed ? '&#xe62d;' : '&#xe6df;' }} />
            </div>
            <Menu theme="dark" mode={this.state.mode} defaultSelectedKeys={['1']} onOpenChange={this.openChange} openKeys={this.state.openkeys}>
              {this.state.userPermissionData.map((point, index) => (//未巡逻
                <SubMenu
                  key={point.key}
                  title={<Tooltip placement="right" title={`${point.name}`} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === `${point.key}`).length ? "caret-down" : "caret-right"} /><span className="nav-text">{point.name}</span></span></Tooltip>}
                >
                  {this.state.userPermissionData[index].data.map((child, ind) => (
                    <Menu.Item key={child.key}>
                      <Tooltip placement="right" title={`${child.name}`} getPopupContainer={() => document.querySelector('.Admin')}>
                        <Link to={`${menuListObj[`${child.key}`]}`} onClick={() => store('route', `${menuListObj[`${child.key}`]}`)}>
                          <img className="iconfont-lszp" src={menuObj[`${child.key}`]} style={{ width: 14, height: 14, }} />
                          <span className="nav-text">{child.name}</span>
                        </Link>
                      </Tooltip>
                    </Menu.Item>
                  ))}

                </SubMenu>
              ))}
              {/*<SubMenu
                key="1"
                disabled
                title={<Tooltip placement="right" title={'单位管理'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub1').length ? "caret-down" : "caret-right"} /><span className="nav-text">单位管理</span></span></Tooltip>}
              >
                <Menu.Item key="1-1">
                  <Tooltip placement="right" title={'单位管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/org/manage" onClick={() => store('route', '/org/manage')}>
                       <img className="iconfont-lszp" src={orgManage_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">单位管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                  <Menu.Item key="1-2">
                  <Tooltip placement="right" title={'单位统计'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/org/stati" onClick={() => store('route', '/org/stati')}>
                      <img className="iconfont-lszp" src={staic_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">单位统计</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                  <Menu.Item key="1-3">
                  <Tooltip placement="right" title={'消防整改'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/org/preserve" onClick={() => store('route', '/org/preserve')}>
                        <img className="iconfont-lszp" src={preserve_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">消防整改</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="1-4">
                  <Tooltip placement="right" title={'设置'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/org/type/manage" onClick={() => store('route', '/org/type/manage')}>
                      <i className="iconfont-lszp">&#xe61f;</i>
                      <span className="nav-text">设置</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
              <SubMenu
                key="2"
                title={<Tooltip placement="right" title={'建筑管理'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub2').length ? "caret-down" : "caret-right"} /><span className="nav-text">建筑管理</span></span></Tooltip>}
              >
                <Menu.Item key="2-1">
                  <Tooltip placement="right" title={'建筑管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/org/bding/manage" onClick={() => store('route', '/org/bding/manage')}>
                      <i className="iconfont-lszp">&#xe681;</i>
                      <span className="nav-text">建筑管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="2-2">
                  <Tooltip placement="right" title={'设置'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/org/bdtype/manage" onClick={() => store('route', '/org/bdtype/manage')}>
                      <i className="iconfont-lszp">&#xe61f;</i>
                      <span className="nav-text">设置</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
              <SubMenu
                key="3"
                title={<Tooltip placement="right" title={'人员管理'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub3').length ? "caret-down" : "caret-right"} /><span className="nav-text">人员管理</span></span></Tooltip>}
              >
                <Menu.Item key="3-1">
                  <Tooltip placement="right" title={'人员管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/staff">
                      <i className="iconfont-lszp">&#xe61d;</i>
                      <span className="nav-text">人员管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="3-2">
                  <Tooltip placement="right" title={'部门管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/group">
                      <i className="iconfont-lszp">&#xe689;</i>
                      <span className="nav-text">部门管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="3-3">
                  <Tooltip placement="right" title={'绩效管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/prfrm">
                      <i className="iconfont-lszp">&#xe632;</i>
                      <span className="nav-text">绩效管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
             
              </SubMenu>
              <SubMenu
                key="sub4"
                title={<Tooltip placement="right" title={'设备管理'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub4').length ? "caret-down" : "caret-right"} /><span className="nav-text">设备管理</span></span></Tooltip>}
              >
                <Menu.Item key="11">
                  <Tooltip placement="right" title={'设备管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/equip/manage">
                      <i className="iconfont-lszp">&#xe965;</i>
                      <span className="nav-text">设备管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="12">
                  <Tooltip placement="right" title={'设置'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/equip/type/manage">
                      <i className="iconfont-lszp">&#xe61f;</i>
                      <span className="nav-text">设置</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
               <SubMenu
                key="sub5"
                title={<Tooltip placement="right" title={'监控中心'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub5').length ? "caret-down" : "caret-right"} /><span className="nav-text">监控中心</span></span></Tooltip>}
              >
                <Menu.Item key="13">
                  <Tooltip placement="right" title={'监控中心'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/moni">
                      <i className="iconfont-lszp">&#xe602;</i>
                      <span className="nav-text">监控管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="14">
                  <Tooltip placement="right" title={'文件管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/moni/resource/vedio">
                      <i className="iconfont-lszp">&#xe6d1;</i>
                      <span className="nav-text">文件管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="15">
                  <Tooltip placement="right" title={'实时监控'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/moni/realtime">
                      <i className="iconfont-lszp">&#xe604;</i>
                      <span className="nav-text">实时监控</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
              <SubMenu
                key="sub6"
                title={<Tooltip placement="right" title={'报警中心'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub6').length ? "caret-down" : "caret-right"} /><span className="nav-text">报警中心</span></span></Tooltip>}
              >
                <Menu.Item key="16">
                  <Tooltip placement="right" title={'报警管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/conct/manage">
                      <img className="iconfont-lszp" src={warnManage_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">报警管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="17">
                  <Tooltip placement="right" title={'报警统计'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/conct/statistics">
                      <i className="iconfont-lszp">&#xe611;</i>
                      <span className="nav-text">报警统计</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="18">
                  <Tooltip placement="right" title={'报警处理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/conct/history">
                      <i className="iconfont-lszp">&#xe61c;</i>
                      <span className="nav-text">报警处理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="19">
                  <Tooltip placement="right" title={'报警设定'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/conct/settings">
                      <i className="iconfont-lszp">&#xe716;</i>
                      <span className="nav-text">报警设定</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
              <SubMenu
                key="sub7"
                title={<Tooltip placement="right" title={'短信通知'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub7').length ? "caret-down" : "caret-right"} /><span className="nav-text">短信通知</span></span></Tooltip>}
              >
                <Menu.Item key="20">
                  <Tooltip placement="right" title={'联系人管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/noti/cont">
                      <i className="iconfont-lszp">&#xe81f;</i>
                      <span className="nav-text">联系人管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="21">
                  <Tooltip placement="right" title={'短信管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/noti/manage">
                      <i className="iconfont-lszp">&#xe627;</i>
                      <span className="nav-text">短信管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="22">
                  <Tooltip placement="right" title={'短信模板'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/noti/stencil">
                      <i className="iconfont-lszp">&#xe6b6;</i>
                      <span className="nav-text">短信模板</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
               <SubMenu
                key="sub8"
                title={<Tooltip placement="right" title={'安全检查'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub8').length ? "caret-down" : "caret-right"} /><span className="nav-text">安全检查</span></span></Tooltip>}
              >
                <Menu.Item key="23">
                  <Tooltip placement="right" title={'任务清单'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/task/list">
                       <img className="iconfont-lszp" src={task_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">任务清单</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="24">
                  <Tooltip placement="right" title={'任务规则'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/task/rule">
                       <img className="iconfont-lszp" src={ taskRule_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">任务规则</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="25">
                  <Tooltip placement="right" title={'任务报表'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/task/report">
                       <img className="iconfont-lszp" src={ taskTable_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">任务报表</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>
              <SubMenu
                key="sub9"
                title={<Tooltip placement="right" title={'巡逻管理'} getPopupContainer={() => document.querySelector('.Admin')} overlayClassName="submenu-tooltip"><span><Icon type={this.state.openkeys.filter(x => x === 'sub9').length ? "caret-down" : "caret-right"} /><span className="nav-text">巡逻管理</span></span></Tooltip>}
              >
                <Menu.Item key="26">
                  <Tooltip placement="right" title={'巡逻设置'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/patrol">
                       <img className="iconfont-lszp" src={patrol_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">巡逻设置</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>

                <Menu.Item key="27">
                  <Tooltip placement="right" title={'巡逻详情查看'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/patrol/detail">
                       <img className="iconfont-lszp" src={patrolDetail_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">巡逻详情查看</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="28">
                  <Tooltip placement="right" title={'巡逻人管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/patrol/man">
                      <img className="iconfont-lszp" src={patrolMan_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">巡逻人管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
    
                <Menu.Item key="29">
                  <Tooltip placement="right" title={'巡逻点管理'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/patrol/point">
                       <img className="iconfont-lszp" src={patrolPoint_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">巡逻点管理</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
                <Menu.Item key="30">
                  <Tooltip placement="right" title={'巡逻统计'} getPopupContainer={() => document.querySelector('.Admin')}>
                    <Link to="/memb/patrol/point/info">
                      <img className="iconfont-lszp" src={patrolStc_pic}  style={{width: 14,height: 14,}} />
                      <span className="nav-text">巡逻统计</span>
                    </Link>
                  </Tooltip>
                </Menu.Item>
              </SubMenu>*/}

            </Menu>
          </Sider>
          <Layout style={{ padding: '0' }}>
            <Content style={{ background: '#fff', padding: 0, margin: 0, minHeight: 280 }}>
              {this.props.children}
            </Content>
          </Layout>
        </Layout>
      </Layout>
    );
  }
}

export default Admin;