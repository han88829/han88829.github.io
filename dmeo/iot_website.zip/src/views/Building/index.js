import React, { Component } from 'react';
import { Link } from 'react-router';
import { Layout, Menu, Breadcrumb } from 'antd';
//import '../Oorg.css';


import task_center_pic from '../../assets/images/logined/task-center.png';
import map_pic from '../../assets/images/logined/map.png';
// import equipwarning_pic from '../../assets/images/logined/equipwarning-but.png';
import user_button from '../../assets/images/logined/user-button.png';

import org_message_pic from '../../assets/images/orgs/org-message-icon.png';
import org_type_pic from '../../assets/images/orgs/org-type-icon.png';
import build_message_pic from '../../assets/images/orgs/build-message-icon.png';
import set_pic from '../../assets/images/orgs/set-icon.png';
import type_manage_pic from '../../assets/images/orgs/type-manage-icon.png';
import build_pic from '../../assets/images/orgs/build-icon.png';


 import device_bread_pic from '../../assets/images/logined/device-bread.png';

const { SubMenu } = Menu;
const { Content, Sider } = Layout;

class Building extends Component {
  constructor(){
    super();
    this.state={
      breadRight:'建筑信息',
      breadTitle:'建筑管理',
      breadLink:'/org/bding/manage'
    }
    this.handClick=this.handClick.bind(this);
  }
  handClick(e){
    this.setState({
      breadRight:e.target.innerText,
      breadTitle:e.target.getAttribute('data-parent') ,
      breadLink:e.target.getAttribute('data-link') 
    })  
  }
  componentWillMount() {
    // console.log(this.props.routes);
    // let a=4;
    // if(this.props.routes.length>=4){
    //      a=12;
    //     console.log(a);
    // }else{
    //   a=0;
    //    console.log(a);
    //  }
    //查类型
    // window.rpc.device.types.getArray(0, 0).then((result) =>{
    //   console.log(0,0)
    //   let dtypes = [{name: '/'}];
    //   for(let value of result){
    //     dtypes[value.id] = value;
    //   }
    //   sessionStorage.setItem('dtypes',JSON.stringify(dtypes));
    // }, (err) => {
    //   console.warn(err);
    // })

    //查区域
    window.rpc.area.getArray(0, 0).then((result) => {
      let locations = [{name: '/'}];
      for(let value of result){
        locations[value.id] = value;
      }
      sessionStorage.setItem('locations',JSON.stringify(locations));
    }, (err) => {
      console.warn(err);
    })

     //查建筑
    window.rpc.area.getArray(0, 0).then((result) => {
      let fildes = [{name: '/'}];
      for(let value of result){
        fildes[value.id] = value;
      }
      sessionStorage.setItem('fildes',JSON.stringify(fildes));
    }, (err) => {
      console.warn(err);
    }) 

    //获取户籍类型
    window.rpc.owner.types.getArray(0, 0).then((result) =>{
      let Orgtypes = [{name: '/'}];
      for(let value of result){
        Orgtypes[value.id] = value;
      }
      sessionStorage.setItem('Orgtypes',JSON.stringify(Orgtypes));
    }, (err) => {
      console.warn(err);
    })

    //获取安全等级
     window.rpc.fire.getInfo().then((result) => {
      let safetys = [{name: '/'}];
      for(let value of result){
        safetys[value.id] = value;
      }
      sessionStorage.setItem('safetys',JSON.stringify(safetys));
    }, (err) => {
      console.warn(err);
    })

    //获取监管等级
    window.rpc.fire.getInfo().then((result) => {
      let Supervisions = [{name: '/'}];
      for(let value of result){
        Supervisions[value.id] = value;
      }
      sessionStorage.setItem('Supervisions',JSON.stringify(Supervisions));
    }, (err) => {
      console.warn(err);
    })

    //获取户籍状态
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let OrgStates = [{name: '/'}];
      for(let value of result){
        OrgStates[value.id] = value;
      }
      sessionStorage.setItem('OrgStates',JSON.stringify(OrgStates));
    },(err) => {
      console.warn(err);
    })
    // 查产品
    window.rpc.product.getArray(0,0).then((result) => {
      let products = [{name: '/'}];
      for(let value of result){
        products[value.id] = value;
      }
      sessionStorage.setItem('products',JSON.stringify(products));
    }, (err) => {
      console.warn(err);
    })


    //查户籍名称
    // window.rpc.owner.getArrayBriefByContainer(null,0,0,console.log,console.error).then((result) => {
     window.rpc.owner.getArrayIdNameByContainer(null,0,0,console.log,console.error).then((result) => {
     // getArrayIdNameByContainer
      let ownerNames = [{name: '/'}];
      for(let value of result){
        ownerNames[value.id] = value;
      }
      sessionStorage.setItem('ownerNames',JSON.stringify(ownerNames));
    }, (err) => {
      console.warn(err);
    })
    //查建筑类型
    // window.rpc.area.getArrayIdNameByContainer(null,0,0,console.log,console.error).then((result) => {
    window.rpc.area.types.getArrayIdNameByContainer(null,0,0,console.log,console.error).then((result) => {
      let buildTypeNames = [{name: '/'}];
      for(let value of result){
        buildTypeNames[value.id] = value;
      }
      sessionStorage.setItem('buildTypeNames',JSON.stringify(buildTypeNames));
    }, (err) => {
      console.warn(err);
    })
    //查建筑火灾危险性
       window.rpc.area.getArrayIdNameByContainer(null,0,0,console.log,console.error).then((result) => {
      let buildfireDangers = [{name: '/'}];
      for(let value of result){
        buildfireDangers[value.id] = value;
      }
      sessionStorage.setItem('buildfireDangers',JSON.stringify(buildfireDangers));
    }, (err) => {
      console.warn(err);
    })


  }
  render() {
    // function itemRender(route, params, routes, paths) {
    //   const last = routes.indexOf(route) === routes.length - 1;
    //   return last ? <span>{route.breadcrumbName}</span> : <Link to={paths.join('/')}>{route.breadcrumbName}</Link>;
    // }
  
    return (
      <Layout className="Org" style={{ background: '#333744' }}>
        <Sider
          width={200}
          style={{ background: '#333744' ,height: '100%'}}>

          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['sub1']}
            style={{ height: '100%' , backgroundColor:'#333744'}}
            
          >
            <SubMenu 
              key="sub1"
              className="sub-menu-1"
              title={<span   style={{background:'#333744',fontFamily: '苹方特细',fontWeight: 400, height:60,fontstyle: 'normal',fontSize:'14px',color:' #FFFFFF',textAlign:'left'}} ><img src={user_button} alt="" style={{padding:'0 20px 0 30px',verticalAlign:'middle'}}/>户籍管理</span>}
              >
            
              <Menu.Item key="1"><Link to="/org/buildingManage" onClick={this.handClick} data-link="/org/buildingManage" data-parent="户籍管理"><img src={build_message_pic} alt="" style={{padding:'0 10px 0 10px'}} /><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>建筑管理</span></Link></Menu.Item>
            </SubMenu>
            {/*<SubMenu 
              key="sub2" 
              className="sub-menu-2"
              title={<span  style={{background:'#333744',fontFamily: '苹方特细',fontWeight: 400, height:60,fontstyle: 'normal',fontSize:'14px',color:' #FFFFFF',textAlign:'left'}}><img src={build_pic} alt="" style={{padding:'0 20px 0 30px',verticalAlign:'middle'}}/>户籍巡查</span> }
              >
              
              <Menu.Item key="4"><Link to="/org/orgtasksetting" onClick={this.handClick} data-link="/org/orgtasksetting" data-parent="户籍巡查"><img src={type_manage_pic} alt="" style={{padding:'0 10px 0 10px'}} /><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>任务设置</span></Link></Menu.Item>
              <Menu.Item key="5"><Link to="/org/orgtask" onClick={this.handClick} data-link="/org/orgtask" data-parent="户籍巡查"><img src={task_center_pic} alt="" style={{padding:'0 10px 0 10px'}} /><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>任务中心</span></Link></Menu.Item>
              <Menu.Item key="6"><Link to="/org/orgtaskstatistics" onClick={this.handClick} data-link="/org/orgtaskstatistics" data-parent="户籍巡查"><img src={map_pic} alt="" style={{padding:'0 10px 0 10px'}} /><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>任务统计</span></Link></Menu.Item>
            </SubMenu>*/}
            <SubMenu 
              key="sub3" 
              className="sub-menu-3"
              title={<span   style={{background:'#333744',fontFamily: '苹方特细',fontWeight: 400, height: 60,fontstyle: 'normal',fontSize:'14px',color:' #FFFFFF',textAlign:'left'}} ><img src={set_pic} alt="" style={{padding:'0 20px 0 30px',verticalAlign:'middle'}} />设置</span>}
              >

              <Menu.Item key="2"><Link to="/org/buildtypemanage"  onClick={this.handClick} data-link="/org/buildtypemanage" data-parent="设置"><img src={type_manage_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>建筑类型管理</span></Link></Menu.Item>
            </SubMenu>
          </Menu>
        </Sider>
        <Layout style={{ paddingRight:'20px',background:"#fff"}}>
          <Content >
         
            <Breadcrumb separator=""  style={{height:60,lineHeight:'60px',paddingLeft:'20px',background:"#fafafa",width: '393px', fontWeight: 'normal',fontSize: '16px',color:'#666',fontFamily: '苹方中等'}}>
              <Breadcrumb.Item  style={{  fontWeight: '500'}}><Link to={this.state.breadLink}><img src={device_bread_pic} alt=""style={{padding:'0 10px 0 0',verticalAlign:'middle'}}/>{this.state.breadTitle}</Link></Breadcrumb.Item>
              <Breadcrumb.Item  style={{  fontWeight: '500'}}><Link to={this.state.breadLink}>>{this.state.breadRight}</Link></Breadcrumb.Item>
            {/* <Breadcrumb.Item  style={{fontWeight: '500'}} ><Link to={this.props.children.props.routes[2].path}> {this.state.breadRight!==this.props.children.props.routes[2].breadcrumbName?'>':'' }{this.state.breadRight!==this.props.children.props.routes[2].breadcrumbName?this.props.children.props.routes[2].breadcrumbName:''}</Link></Breadcrumb.Item>*/}
            
              {/* <Breadcrumb.Item>App</Breadcrumb.Item> */}
            </Breadcrumb>
            <div style={{ padding:'0 20px', background: '#fff', minHeight: 600 ,height:'100%'}}>
              {this.props.children}
            </div>
         
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Building;