import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Table, Row, Col, Button, Popconfirm, message } from 'antd';

class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      timer: 0
    })
  }
}
const BuildingTypeManageC = observer(class appState extends React.Component {

  constructor() {
    super();
    this.state = {
      types: [],
      dataList: [],
      loopList: [],
      data: [],
      ownerId: null,
      laryerlit: null
    };

    this.columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '类型名称', dataIndex: 'name', key: 'name' },
      { title: '备注', dataIndex: 'remark', key: 'remark' },
      {
        title: '操作', key: 'operation', render: (record, index) =>
          <div>
            <Link to={`/org/bdtype/${record.key}`} style={{ color: '#999' }}>详情</Link>
            <span className="ant-divider" />
            <Link to={`/org/bdtype/edit/${record.key}`} style={{ color: '#999' }}>编辑</Link>
            <span className="ant-divider" />
            <span to="">
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(record.key)}>
                <a href="#" style={{ color: '#0099cc' }}>删除</a>
              </Popconfirm>
            </span>
          </div>
      },
    ];
  }
  onSelect(info) {
  }

  onCheck(info) {
  }

  onSearch(info) {
    this.props.typeState.onSearch(info);
  }
  onDelete(index) {
    if (index != null) {
      window.rpc.area.types.removeById(index).then((res) => {
        this.state.data.splice(index, 1);
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    } else {
      message.info('不可删除！');
    }
  }
  componentDidMount() {
    function pushChildren(data) {
      let arr = [...data];
      let layer = arr.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = arr.filter(x => x.layer === layer);
      let layerUp = arr.filter(x => x.layer !== layer);
      for (let i = 0; i < layerUp.length; i++) {
        for (let j = 0; j < layerNow.length; j++) {
          if (layerNow[j].parentId === layerUp[i].id) {
            if (layerUp[i].children) {
              layerUp[i].children.push({ ...layerNow[j] });
            } else {
              layerUp[i].children = [{ ...layerNow[j] }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp);
      }
    }
    window.rpc.owner.getId().then(data => {
      this.setState({ ownerId: data });
      window.rpc.area.types.getArrayByContainer({ ownerId: data }, 0, 0).then((res) => {
        let tableDate = res.map(x => ({ ...x, key: x.id }));
        let lay = tableDate.map(x => x.layer).sort((a, b) => b - a);
        let laryerlit = lay[lay.length - 1];
        this.setState({ laryerlit })
        if (lay.length == 1) {
        } else {
          pushChildren(tableDate);
        }
        this.setState({
          data: tableDate
        })
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    }, (err) => {
      console.warn(err);
    })
  }

  render() {
    const columns = this.columns;
    return (
      <div className="typeManage brandManage" >
        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等' }}>
          <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/org/bdtype/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>建筑类型管理</Link>
          </div>
          <div style={{ float: 'left', width: 120, height: 32, marginRight: 4 }}>
            <div className="new-button" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0, width: 110 }} ><Link to="/org/bdtype/new">新增建筑类型</Link></div>
          </div>
        </div>
        <Row>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={this.state.data.filter(x => x.layer === this.state.laryerlit)}
            />
          </Col>
        </Row>
      </div>
    )
  }
})


class BuildTypeManage extends Component {
  render() {
    return (
      <div>
        <BuildingTypeManageC appState={new appState()} />
      </div>
    )
  }
}

export default BuildTypeManage;