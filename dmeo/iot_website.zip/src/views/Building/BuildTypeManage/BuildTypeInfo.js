/*
 * @Author: szj 
 * @Date: 2017-03-27 18:35:04 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 12:54:58
 */

import React from 'react';
import { Input, Button, Form, Row, Col  } from 'antd';
import { Link } from 'react-router';

const FormItem = Form.Item;


const BuildTypeInfo = Form.create()(React.createClass({
  getInitialState() {
    return {
      value: undefined,
      types: null,
      data:[],
      ownerId:null
    };
  },

  componentWillMount(){
      //, key:layerNow[j].id, label: layerNow[j].name, value: `${layerNow[j].id}`
    const id = parseInt(this.props.params.id, 10);
    window.rpc.owner.getId().then(data=>{
      this.setState({ownerId:data});
    window.rpc.area.types.getArrayByContainer({ownerId:data},0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      console.log(tableDate);
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let mine = res.filter(x => x.id === id)[0];
      //let date = pushChildren(tableDate)
      this.setState({ types, data: tableDate });
       window.rpc.area.types.getInfoById(mine.parentId).then((result) => {
         console.log(result);
        this.props.form.setFieldsValue({
          name: mine.name,
          parentId:result.name,
          remark:mine.remark
        });
        this.setState({
          value:result.name
        })
      },(err) =>{
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })


    }, (err) => {
       console.warn(err);
    })
 })

  },
  
  onChange(value) {
    console.log(arguments);
    this.setState({ value });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    //const Name=this.state.types.name;
   // console.log(Name);
    return (
      <div >
       <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',fontSize:'0.75rem',fontFamily:'苹方中等'}}>
          <div style={{float:'left',width:100,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
            <Link to='/org/bdtype/manage' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>建筑类型管理</Link>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">建筑类型详情</Link></Button>
          </div>
        </div>
         <div> 
       <Form onSubmit={this.handleSubmit} className="NewTypes" style={{ padding: 24 ,height:'100%',fontSize:'14px'}}>
        <FormItem>
        <span style={{paddingRight:10}}>类型名称：</span>
          {getFieldDecorator('parentId', {
            rules: [{ required: true, message: '请输入建筑类型名称!' }],
          })(
            <Input  style={{height:30 ,width:'70%'}} disabled/>
          )}
          </FormItem>
        <FormItem>
          <span style={{paddingRight:10}}>类型名称：</span>
          {getFieldDecorator('name', {
            rules: [{ required: true, message: '请输入建筑类型名称!' }],
          })(
            <Input  style={{height:30 ,width:'70%'}} disabled  />
          )}
        </FormItem>
        <FormItem>
         <span style={{paddingRight:30,display:' inlineBlock',height:'68px',lineHeight:'68px'}}> 备注：</span>
          {getFieldDecorator('remark', {
          })(
             <Input type="textarea" autosize={{ minRows: 3, maxRows: 6 }} style={{width:'70%'}} disabled />
          )}
        </FormItem>
         <div style={{ position: 'absolute', bottom: 60 }} className="search-btn" >
         <FormItem >  
           <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to="/org/bdtype/manage">返回</Link></span> 
           {/*<Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑'}}><Link to="/org/bdtype/manage">返回</Link></Button>*/}
         </FormItem>  
        </div>
      </Form>
       </div>
      </div>
    );
  },
}));

export default BuildTypeInfo;