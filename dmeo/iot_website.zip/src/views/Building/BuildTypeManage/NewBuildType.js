/*
 * @Author: 宋珍君 
 * @Date: 2017-03-22 19:54:07 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-07-19 14:39:41
 */


import React from 'react';
import { Input, Button, Form, TreeSelect, message} from 'antd';
import { Link } from 'react-router';

const FormItem = Form.Item;
const  NewBuildType= Form.create()(React.createClass({
  getInitialState() {
    return {
      value: undefined,
      types: [],
      data:[],
      laryerlit:null,
      ownerId:null
    };
  },
  componentWillMount(){
     function pushChildren(data){
		 let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
       pushChildren(layerUp)
      }
		}
    const id = parseInt(this.props.params.id, 10);
    window.rpc.owner.getId().then(data=>{
        this.setState({ownerId:data});   
    window.rpc.area.types.getArrayByContainer({ownerId:data},0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      //console.log(tableDate);
      //tableDate.unshift({ key: 0, label: "无", value: 0 })
      let mine = res.filter(x => x.id === id)[0];
      let lay=tableDate.map(x => x.layer).sort((a, b) => b-a);
      //console.log(lay);
      let laryerlit=lay[lay.length-1];
      this.setState({laryerlit})
     if(lay.length>1) pushChildren(tableDate);
     
      //pushChildren(tableDate);
      tableDate.unshift({ key: 0, label: "无", value: 0 });
      this.setState({ types, data: tableDate });

    }, (err) => {
        console.log(err)
    })
    }, (err) => {
       console.log(err)
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        //console.log('Received values of form: ', values);
        let obj = {...values}
        //console.log(obj);
        //window.rpc.device.types.create(obj).then(() => {
        window.rpc.area.types.create(obj).then((res) => {
          if(res){
          message.info('创建成功！');
          window.location.href='/org/bdtype/manage';
          }else{
          
             message.info("创建失败")
          
          }
            // console.log(res);
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }
    });
  },
  onChange(value) {
    console.log(arguments);
    this.setState({ value });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <div >
         <div style={{fontSize: '0.75em', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',fontSize:'0.75em',fontFamily:'苹方中等'}}>
          <div style={{float:'left',width:100,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
            <Link to='/org/bdtype/manage' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75em',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>建筑类型管理</Link>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">新增建筑类型</Link></Button>
          </div>
        </div>
        <Form onSubmit={this.handleSubmit} className="NewTypes" style={{ padding: 24 ,height:'100%',fontSize:'14px'}}>
          <FormItem>
              <span style={{paddingRight:10}}>上级类型：</span>
              {getFieldDecorator('parentId', {
              })(
                <TreeSelect
                  style={{height:30 ,width:'70%'}}
                  value={this.state.value}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer === this.state.laryerlit)}
                  placeholder="Please select"
                 // treeDefaultExpandAll
                  //onChange={this.onChange}
                />
              )}
          </FormItem>
          <FormItem >
            <span style={{paddingRight:10}}>类型名称：</span>
             {getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入建筑类型名称!' }],
             })(
                <Input  style={{height:30 ,width:'70%'}}/>
             )}
          </FormItem>
          <FormItem>
             <span style={{paddingRight:35,display:' inlineBlock',height:'68px',lineHeight:'68px'}}> 备注：</span>
               {getFieldDecorator('remark', {
               })(
                 <Input type="textarea" autosize={{ minRows: 3, maxRows: 6 }} style={{width:'70%'}}  />
               )}
          </FormItem>
        <div style={{ position: 'absolute', bottom: 60 }} className="search-btn" >
           <FormItem >  
             <Button htmlType="submit"> 保存</Button>
             {/*<Button style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑',marginLeft:10 }}><Link to="/org/bdtype/manage">返回</Link></Button>*/}
             <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to="/org/bdtype/manage">返回</Link></span>   
         </FormItem> 
       </div>     
        </Form>
      </div>
    );
  },
}));

export default NewBuildType;