/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-04 09:50:51 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-15 17:10:19
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, Select, message, Popconfirm } from 'antd';
import './buildManage.css';

const { Option } = Select;
const FormItem = Form.Item;
var number = '';

message.config({
  top: 216,
  duration: 2
})

class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      timer: 0
    })
  }
}

class BuildAdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      buildingType: [],
      OrgsType: [],
      fireDanger: []
    }
  }
  componentWillMount() {
    window.rpc.owner.getArrayIdNameByContainer(null, 0, 0).then((res) => {
      let OrgsType = res.map((x) => ({ ...x }));
      let arr = OrgsType;
      for (let a = 0; a < arr.length; a++) {
        for (let b = a; b < arr.length; b++) {
          if (arr[a].id > arr[b].id) {
            let cnbm = arr[a];
            arr[a] = arr[b];
            arr[b] = cnbm;
          }
        }
      };
      this.setState({
        OrgsType: arr
      })
    }, (err) => {
      console.warn(err);
    });
    window.rpc.area.types.getArrayIdNameByContainer(null, 0, 0).then((res) => {
      let buildingType = res.map((x) => ({ ...x }));
      this.setState({
        buildingType
      });
    }, (err) => {
      console.warn(err);
    });
    window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
      let arr = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arr.push(values);
      }
      let fireDanger = arr;
      this.setState({
        fireDanger
      })
    }, (err) => {
      console.warn(err);
    });

  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {

        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const orgtype = fieldsValue['orgSelect'];
        const buildtype = fieldsValue['buildingtype'];
        const risk = fieldsValue['risk'];
        let values = {};
        if (name) {
          values = { ...values, name: `  ${name}  ` };
        }
        if (orgtype) {
          values = { ...values, ownerId: orgtype };
        }
        if (buildtype) {
          values = { ...values, subtype: buildtype };
        }
        if (risk) {
          values = { ...values, fireDanger: fieldsValue['risk'].map(x => x) };
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }
        values = { ...values, type: 50 }

        window.rpc.area.getArrayBriefByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.length}条数据`);
          let fireDanger = this.state.fireDanger;
          let devices = [];
          result.forEach(function (x) {
            if (x) {
              devices.push({ ...x, key: x.id, id: x.id, buildingname: x.name, ownerName: x.ownerName, areatype: x.typeName, fireDanger: fireDanger[x.fireDanger] });
            }
          });
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let Orgtypes = this.state.OrgsType || [];
    let BuildTypes = this.state.buildingType || [];
    let OrgtypeChildren = [];
    let buildTypeChildren = [];
    let fireDanger = this.state.fireDanger;

    let fireDangerLists = [];

    for (let i = 1; i < fireDanger.length + 1; i++) {

      fireDangerLists.push(<Option key={`${i}`}>{fireDanger[i]}</Option>)

    }
    //如果有数据就存储到子数组中
    for (let value of Orgtypes) {
      if (value && value.id) {
        OrgtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>);
      }
    }
    for (let value of BuildTypes) {
      if (value && value.id) {
        buildTypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>);
      }
    }

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row style={{ margin: '15px 0 15px', height: '32px', lineHight: '32px' }}>
          <Col span={5} key={1}>
            <FormItem label={`建筑名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 200, height: 32 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          {/*<Col span={5} key={2}>
            <FormItem label={`户籍选择`}>
              {getFieldDecorator(`orgSelect`)(
                <Select size="large" style={{ width: 200 }} placeholder="请选择">
                  {OrgtypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>*/}
          <Col span={5} key={3}>
            <FormItem label={`建筑类型`}>
              {getFieldDecorator(`buildingtype`)(
                <Select size="large" multiple style={{ width: 200, color: 'red', fontSize: 10 }} placeholder="请选择 " >
                  {buildTypeChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={4}>
            <FormItem label={`火灾危险性`}>
              {getFieldDecorator(`risk`)(
                <Select size="large" multiple style={{ width: 200 }} placeholder="请选择" >
                  {fireDangerLists}
                </Select>
              )}
            </FormItem>
          </Col>

          <Col span={3} key={5} className="search-btn" >
            <FormItem style={{ float: 'right' }}>
              <Button
                type="primary"
                onClick={this.handleSearch}
                style={{ height: '32px', width: '80px', padding: 0, margin: 0, fontSize: '0.75em' }}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const BuildingAdvancedSearchForm = Form.create()(BuildAdvancedSearchForm);

const BuildingManageC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: 0
      },
      data: [],
      fireDanger: []
    }
  }
  //获取数据
  componentDidMount() {
    window.rpc.area.getCountByContainer({type: 50 }).then((res) => {
      number = res;
    }, (err) => {
      console.warn(err);
    })
    window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
      let arr = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arr.push(values);
      }
      let fireDanger = arr;
      this.setState({
        fireDanger
      });
      window.rpc.owner.getId().then(data => {
        window.rpc.area.getArrayBriefByContainer({ type: 50}, 0, 10).then((result) => {
          let devices = [];
          result.forEach(function (x) {
            if (x) {
              devices.push({ ...x, key: x.id, id: x.id, buildingname: x.name, ownerName: x.ownerName, areatype: x.typeName, fireDanger: res[x.fireDanger] })
            }
          })
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);
          function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }, err => {
        console.warn(err)
      })

    }, (err) => {
      console.warn(err);
    });

  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) };
    this.setState({ Selected: Selected });
  }

  handleStaff = () => {
    if (this.state.Selected.Id) {
      browserHistory.push(`/org/bding/edit/${this.state.Selected.Id}`);
    } else {
      message.info('请选择建筑！');
    }
  }
  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id) {
      browserHistory.push(`/org/floor/${this.state.Selected.Id}`);
    } else {
      message.info('请选择建筑！');
    }
  }
  //是否删除
  remove = () => {
    if (this.state.Selected.Id != null) {
      window.rpc.area.removeById(this.state.Selected.Id).then((res) => {
        if (res) {
          message.info('删除成功！');

        } else {
          message.info('删除失败！');
        }
        let devices = [];
        res.forEach(function (x) {
          if (x) {
            devices.push({ ...x, key: x.id, id: x.id, buildingname: x.name, ownerName: x.ownerName, areatype: x.typeName, fireDanger: x.fireDanger })
          }
        })
        this.props.appState.tableData = devices;
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })

    } else {
      message.info('请选择建筑！');
    }
  }
  onDelete = (index, key) => {
    window.rpc.area.removeById(index).then((res) => {
      if (res) {
        message.info('删除成功！');

      } else {
        message.info('删除失败！');
      }
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    this.props.appState.tableData.splice(key, 1);
  }
  render() {
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '楼宇名称', dataIndex: 'buildingname', key: 'buildingname', render: (text, record) => (<Link to={`/org/floor/${record.id}`} style={{ color: '#0099cc' }}>{text}</Link>) },
      { title: '所属户籍', dataIndex: 'ownerName', key: 'ownerName' },
      { title: '建筑类型', dataIndex: 'areatype', key: 'areatype' },
      { title: '火灾危险性', dataIndex: 'fireDanger', key: 'fireDanger' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (
          <div>
            <Link to={`/org/floor/${record.key}`} style={{ color: '#999' }}>详情</Link>
            <span className="ant-divider" />
            <Link to={`/org/bding/edit/${record.key}`} style={{ color: '#999' }} >编辑</Link>
            <span className="ant-divider" />
            <span to="">
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(record.key, index)}>
                <a href="#" style={{ color: '#0099cc' }}>删除</a>
              </Popconfirm>
            </span>
          </div>
        )
      },
    ];
    const data = [...this.props.appState.tableData];
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };

    const pagination = {
      total: number,
      showTotal: total => `共 ${number} 条`,
      pageSize: 10,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (page, pageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * 10;
        window.rpc.area.getArrayByContainer({type:50}, pagenum, 10).then((result) => {
          let devices = [];

          let fireDanger = this.state.fireDanger;
          result.forEach(function (x) {
            devices.push({ ...x, key: x.id, id: x.id, buildingname: x.name, ownerId: x.ownerId, areatype: x.type, fireDanger: fireDanger[x.fireDanger] });
          })
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);
        })
      },
    };

    return (
      <div className="BuildingManage" style={{ padding: '0 12px' }}>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '25px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 7 }}>
            <Link to='/org/bding/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>建筑信息</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <div className="new-button" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="/org/bding/new">新增建筑</Link></div>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <div className="other-button" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff}>编辑建筑</div>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <div className="other-button" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne}>建筑详情</div>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Popconfirm title="确认删除?" onConfirm={this.remove} onCancel={this.cancel} okText="确定" cancelText="取消">
              <div className="other-button" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="">删除建筑</Link></div>
            </Popconfirm>
          </div>

        </div>
        <BuildingAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24} >
            <Table
              style={{ textAlign: 'center' }}
              columns={columns}
              dataSource={data}
              rowSelection={rowSelection}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
})

class BuildingManage extends Component {
  render() {
    return (
      <BuildingManageC appState={new appState()} />
    )
  }
}


export default BuildingManage;