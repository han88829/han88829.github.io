import React from 'react';
import { Form, Button, Row, Col, Modal, Tabs, Icon, Table, Popconfirm, message } from 'antd';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';//extendObservable
import $ from 'jquery';
import moment from 'moment';
import './floor.css';
import BuildImg from './BuildImg';
import build from '../../../assets/images/build/build.png';
import Area from '../../../assets/images/build/Area.png';
import bDate from '../../../assets/images/build/bDate.png';
import bArea from '../../../assets/images/build/bArea.png';
import bd from '../../../assets/images/build/bd.png';
import bHeight from '../../../assets/images/build/bHeight.png';
import build_remark from '../../../assets/images/build/build-remark.png';
import build_time from '../../../assets/images/build/build-time.png';
import fireEleNum from '../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../assets/images/build/maxTotleNum.png';
import nature from '../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../assets/images/build/safety.png';
import standardFloorArea from '../../../assets/images/build/standardFloorArea.png';
import subType from '../../../assets/images/build/subType.png';

import totalElevator from '../../../assets/images/build/totalElevator.png';


import underArea from '../../../assets/images/build/underArea.png';

import underNumber from '../../../assets/images/build/underNumber.png';
import upDown from '../../../assets/images/build/upDown.png';
import upperNumber from '../../../assets/images/build/upperNumber.png';
import workMen from '../../../assets/images/build/workMen.png';

import workPersonDay from '../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../assets/images/build/fireLevel.png';
import floorArea from '../../../assets/images/build/floorArea.png';

const { TabPane } = Tabs;
var num = '';
message.config({
  top: 216,
  duration: 2
})
class appState {
  constructor() {
    extendObservable(this, {
      tableData: []
    })
  }
}

class QrCode extends React.Component {
  componentDidMount() {
    //console.log(this.props)
  }

  state = {
    modal2Visible: false
  }
  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }
  preview = () => {
    let id = 'PrintContentDiv';
    var sprnhtml = document.getElementById(id).innerHTML;
    var selfhtml = window.document.body.innerHTML; //获取当前页的html
    window.document.body.innerHTML = sprnhtml;
    window.print();
    // note
    // Re-refresh the page to load, replace the html structure directly, the binding event is destroyed
    window.location.href = `/org/floor/${this.props.builds.id}`;
  }
  render() {
    let ie = `http://qr.liantu.com/api.php?&bg=ffffff&text=http://xiot.lszpcn.com/SBuilding/${this.props.builds.id}`
    return (
      <span className="QrCode">
        <Button type="primary" onClick={() => this.setModal2Visible(true)} style={{ borderColor: "#ccc", color: "#000", backgroundColor: "white" }}>点我查看二维码</Button>
        <Modal
          title="请扫以下二维码"
          wrapClassName="vertical-center-modal"
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          style={{ height: "400px" }}
          className="QrCode"
        >
          <Button name="print" onClick={this.preview} style={{ position: 'absolute', left: 12, bottom: 12, zIndex: 999 }}>打印</Button>
          <span id="PrintContentDiv">
            <img src={ie} alt="" style={{ position: 'absolute', left: '50%', top: '50%', marginLeft: '-150px', marginTop: '-150px' }} />
          </span>
        </Modal>
      </span>
    );
  }
}

const Floors = Form.create()(React.createClass({
  getInitialState() {
    return {
      data: '',
      builds: {
        Fname: '',
        Frisk: '',
        Fuse: '',
        Fstructure: '',
        Frefractory: '',
        Farea: '',
        Felevator: '',
        Earea: '',
        Ftotal: '',
        Fday: '',
        Fnote: '',
        createTime: '',
        tag: ''
      },
      buildImg: '',
      buildingType: [],
      id: null,
      type: [],
      id:null
    }
  },

  componentDidMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    this.setState({ id: str });
    window.rpc.area.getCountByContainer({ type: 51, parentId: str }).then((res) => {
      num = res;
    }, (err) => {
      console.warn(err);
    })
    window.rpc.area.getArrayByContainer({ type: 51, parentId: str }, 0, 0).then((result) => {
      let devices = [];
      result.forEach(function (x) {
        devices.push({ ...x, key: x.id, id: x.id, Floornum: x.name, Floorarea: x.number })
      })
      this.props.appState.tableData = devices;
      this.setState({
        'data': devices
      })
    }, (err) => {
      console.warn(err);
      function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
    })
    window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
      let arr = ['/'];
      for (let key in res) {
        let values = `${res[key]}`
        arr.push(values);
      }
      var str = window.location.href;
      var index = str.lastIndexOf("\/");
      str = str.substring(index + 1, str.length);
      this.setState({id:str});
      window.rpc.area.getInfoById(str).then((x) => {
        let asc = x.mapUrl;
        $("#buildImg").attr("src", asc);
        this.setState({
          buildImg: asc
        });
        window.rpc.owner.types.getMapIdNameByContainer(null, 0, 0).then(data => {
          let type = data[`${x.type}`] || '';//x.extend.subtype  subtype:x.extend.stype,
          let subtype = data[`${x.subtype}`] || '';
          let builds = {
            ...x,
            Fname: x.name, Frisk: res[x.fireDanger], createTime: moment(x.buildTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'),
            key: x.id, Type: type, Farea: subtype, Fstructure: x.galleryful, Frefractory: x.layer, Felevator: x.ownerId, Earea: x.parentId, Ftotal: x.subtype,
            Fday: x.type, Fnote: x.number, galleryful: x.galleryful,
            x: x.x, y: x.y,
            tag: x.tag,
            usetype: x.extend.usetype || '',
            rangebuild: x.extend.rangebuild || '', rangebase: x.extend.rangebase, overgroundarea: x.extend.overgroundarea || '', overgroundfloor: x.extend.overgroundfloor || '', undergroundfloor: x.extend.undergroundfloor || '', undergroundarea: x.extend.undergroundarea || '', refugestoreyarea: x.extend.refugestoreyarea || '', refugestoreyfloor: x.extend.refugestoreyfloor || ''
          };
          builds = {
            ...builds,
          };
          this.setState({
            builds
          })
        });

      }, (err) => {
        console.warn(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
    }, (err) => {
      console.warn(err);
    });
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
      }
    });
  },
  onSelectChange(selectedRowKeys) {
    const Selected = { Id: parseInt(selectedRowKeys[0]) };
    this.setState({ Selected: Selected });
  },

  handleStaff() {
    if (this.state.Selected.Id) {
      browserHistory.push(`/org/area/edit/${this.state.Selected.Id}`);
    } else {
      message.info('请选择楼层！');
    }
  },
  //详情跳转
  handleStaffOne() {
    if (this.state.Selected.Id) {
      browserHistory.push(`/org/area/cont/${this.state.Selected.Id}`);
    } else {
      message.info('请选择楼层！');
    }
  },
  //是否删除
  remove() {
    if (this.state.Selected.Id != null) {
      window.rpc.area.removeById(this.state.Selected.Id).then((res) => {
        if (res) {
          message.info('删除成功！');
          window.rpc.area.getCountByContainer({ type: 51, parentId: this.state.id }).then((res) => {
            let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
            let types = type.reverse();
            this.setState({ types });
            this.props.appState.tableData = types;
          }, (err) => {
            console.warn(err);

          })
        } else {
          message.info('删除失败！');
        }
      }, (err) => {
        console.warn(err);
        function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //刷新页面

    } else {
      message.info('请选择楼层！');
    }
  },
  onDelete(index) {
    window.rpc.area.removeById(index).then((res) => {
      if (res) {
        message.info('删除成功！');
        window.rpc.area.getCountByContainer({ type: 51, parentId: this.state.id }).then((res) => {

          let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
          let types = type.reverse();
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      } else {
        message.info('删除失败！');
      }
    }, (err) => {
      console.warn(err);
      function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
    })
  },
  render() {

    //区域表格信息
    const data = [...this.state.data];
    //console.log(data)
    // console.log(data);
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
    //基础信息
    const FloorInformation = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '楼层', dataIndex: 'Floornum', key: 'Floornum', render: (text, record) => (
          <span>
            <Link to={`/org/area/cont/${record.key}`} style={{ color: '#0099cc' }}>{text}</Link>
          </span>
        )

      },
      { title: '区域数', dataIndex: 'Floorarea', key: 'Floorarea' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/org/area/cont/${record.key}`} style={{ color: '#999' }}>详情</Link>
            <span className="ant-divider" />
            <Link to={`/org/area/edit/${record.key}`} style={{ color: '#999' }}>修改</Link>
            <span className="ant-divider" />
            <Link to="">
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(record.key)}>
                <a href="#" style={{ color: '#0099cc' }}>删除</a>
              </Popconfirm>
            </Link>
          </span>
        )
      },
    ];
    const pagination = {
      total: num,
      showTotal: total => `共 ${num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (page, pageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * 10;
        // window.rpc.area.getArrayByContainer({type:51,parentId:this.state.id}, pagenum, 10).then((result) => {
        //   console.log(pagenum);
        //   console.log(result)
        //   let devices = [];

        //   let fireDanger = this.state.fireDanger;
        //   result.forEach(function (x) {
        //     devices.push({ ...x, key: x.id, id: x.id, buildingname: x.name, ownerId: x.ownerId, areatype: x.type, fireDanger: fireDanger[x.fireDanger] });
        //   })
        //   this.props.appState.tableData = devices;
        //   this.setState({data:devices})
        // }, (err) => {
        //   console.warn(err);
        // })
      },
    };
    return (
      <div style={{ height: '100%', overflow: 'auto' }} className='Floor'>
        <Tabs style={{ fontSize: "20px", padding: '15px' }} style={{ height: '100%', fontSize: '0.75rem' }} className='buildInfoTabOne' >
          <TabPane className="firstTabInfo" tab={<span><Icon type="info-circle-o" />基础信息</span>} style={{ height: '100%', }} key="1">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 135, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <span style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>
                <Link to={`/org/bding/manage`} style={{ color: '#373e41' }} >建筑信息</Link><span style={{ padding: '0 4px' }}>/</span>
                <Link to={`org/floor/${this.state.id}`} style={{ color: '#373e41' }} >楼层信息</Link>
              </span>
            </div>
            <div style={{ marginTop: -4, paddingTop: 5, height: '100%', maxHeight: '76vh', overflow: 'auto', }}>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41', borderTop: '1px solid #ddd' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>基础信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><span><img src={build} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物名称：{this.state.builds.name}</span> <a id="seeImgInfo" style={{ display: 'inline-block', height: 20, width: 20, marginLeft: 10, borderRadius: '100%', background: '#fff', border: '1px solid #ccc', float: 'right', display: "none" }}><Icon type="upload" style={{ marginLeft: 4, }} /></a> </div>
                    <div className="Row-info-right"> <img src={build_time} style={{ padding: '0 15px 0 12px' }} alt="" />建筑日期：{this.state.builds.createTime} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物类型：{this.state.builds.Type} </div>
                    <div className="Row-info-right"> <img src={safety} style={{ padding: '0 15px 0 12px' }} alt="" />火灾危险性:{this.state.builds.Frisk} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"> <img src={nature} style={{ padding: '0 15px 0 12px' }} alt="" />使用性质：{this.state.builds.usetype} </div>
                    <div className="Row-info-right">  <img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />结构类型:{this.state.builds.Farea} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"> <img src={fireLevel} style={{ padding: '0 15px 0 12px' }} alt="" />耐火等级：{this.state.builds.Frefractory} </div>
                    <div className="Row-info-right">  <img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />NFC:{this.state.builds.Farea}  </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"> <img src={fireLevel} style={{ padding: '0 15px 0 12px' }} alt="" />建筑二维码：<QrCode builds={this.state.builds} /> </div>
                  </div>
                </div>
              </div>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>建筑信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={bHeight} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物高度： {this.state.builds.hight}</div>
                    <div className="Row-info-right"> <img src={Area} style={{ padding: '0 15px 0 12px' }} alt="" />占地面积（平方米）：{this.state.builds.Earea} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={bArea} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物面积(平方米)：{this.state.builds.rangebuild} </div>
                    <div className="Row-info-right"><img src={standardFloorArea} style={{ padding: '0 15px 0 12px' }} alt="" />标准层面积(平方米)：{this.state.builds.rangebase} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={nature} style={{ padding: '0 15px 0 12px' }} alt="" />建筑坐标x：{this.state.builds.x} </div>
                    <div className="Row-info-right"><img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />建筑坐标y：{this.state.builds.y} </div>
                  </div>
                </div>
              </div>

              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                  {/*<p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>建筑信息</p>*/}
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={upperNumber} style={{ padding: '0 15px 0 12px' }} alt="" />地上层数：{this.state.builds.overgroundfloor} </div>
                    <div className="Row-info-right"><img src={floorArea} style={{ padding: '0 15px 0 12px' }} alt="" />地上面积(平方米)： {this.state.builds.undergroundarea} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"> <img src={underNumber} style={{ padding: '0 15px 0 12px' }} alt="" />地下层数：{this.state.builds.undergroundfloor} </div>
                    <div className="Row-info-right"> <img src={underArea} style={{ padding: '0 15px 0 12px' }} alt="" />地下面积(平方米)： {this.state.builds.undergroundarea} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={refugeFloor_number} style={{ padding: '0 15px 0 12px' }} alt="" />避难层数量：{this.state.builds.refugestoreyfloor} </div>
                    <div className="Row-info-right"> <img src={refugeFloor_totalArea} style={{ padding: '0 15px 0 12px' }} alt="" />避难层总面积(平方米)：{this.state.builds.refugestoreyarea} </div>
                  </div>
                </div>
              </div>


              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                  {/*<p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>建筑信息</p>*/}
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={fireEleNum} style={{ padding: '0 15px 0 12px' }} alt="" />消防电梯数量：{this.state.builds.elevator}  </div>
                    <div className="Row-info-right"><img src={totalElevator} style={{ padding: '0 15px 0 12px' }} alt="" />电梯容量：{this.state.builds.elevatornum}  </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"> <img src={maxTotleNum} style={{ padding: '0 15px 0 12px' }} alt="" />最大容纳人数：{this.state.builds.galleryful} </div>
                    <div className="Row-info-right"><img src={workPersonDay} style={{ padding: '0 15px 0 12px' }} alt="" />日常工作时间人数：{this.state.builds.everyday} </div>
                  </div>
                </div>
              </div>

              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>备注</p>
                  <div className="Row-info-left"><img src={build_remark} style={{ padding: '0 15px 0 12px' }} alt="" />备注：{this.state.builds.remark}  </div>
                </div>
              </div>
            </div>
            <div>
              <Row style={{ paddingTop: 35, background: '#fff', }}>
                {/*<Button size="large" type="success" style={{ marginLeft: '0px',backgroundColor:'#ccc' }}><Link to="/org/bding/manage" style={{color:'#fff'}}>返回</Link></Button>*/}
                <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', marginLeft: 10, fontFamily: '微软雅黑', borderRadius: '5px', width: 60, height: 32, borderRadius: 0 }}><Link to="/org/bding/manage">返回</Link></div>
              </Row>
            </div>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />楼层</span>} key="2">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 135, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <span style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>
                <Link to={`/org/bding/manage`} style={{ color: '#373e41' }} >建筑信息</Link>
                <span style={{ padding: '0 4px' }}>/</span>
                <Link to={`org/floor/${this.state.id}`} style={{ color: '#373e41' }} >楼层信息</Link></span>
            </div>

            <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125rem', paddingTop: '1.125rem', color: '#333', borderTop: '1px solid #ddd', fontSize: '0.75em', fontFamily: '苹方中等', }}>
              {/*<div style={{float:'left',width:75,height:'27px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:5}}>
                 <Link to={`org/floor/${this.state.id}`}style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75em',color:'#373e41',borderLeft:'2px solid #88b7e0',zIndex:99}}>楼层信息</Link>
              </div>*/}
              <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
                <div className="new-button" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} >
                  <Link to={`/org/area/new/${this.state.id}`}>新增楼层</Link>
                </div>
              </div>
              <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
                <Button type="" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff}>编辑楼层</Button>
              </div>
              <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
                <Button type="" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne}>楼层详情</Button>
              </div>
              <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
                <Popconfirm title="确认删除?" onConfirm={this.remove} onCancel={this.cancel} okText="确定" cancelText="取消">
                  <Button type="" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="">删除楼层</Link></Button>
                </Popconfirm>
              </div>
            </div>
            <Row >
              <Col span={24} className='floor-table'>
                <Table
                  className="table-equipTask"
                  rowSelection={rowSelection}
                  columns={FloorInformation}
                  dataSource={data}
                  pagination={pagination}
                />
              </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />平面图</span>} key="3">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 135, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <span style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>
                <Link to={`/org/bding/manage`} style={{ color: '#373e41' }} >建筑信息</Link><span style={{ padding: '0 4px' }}>/</span>
                <Link to={`org/floor/${this.state.id}`} style={{ color: '#373e41' }} >楼层信息</Link></span>
            </div>
            <div className="img">
              {/*<img src={this.state.buildImg} id="buildImg" alt="" style={{height:`auto`}}/>   */}
              < BuildImg />
            </div>
          </TabPane>
        </Tabs>
      </div >
    );
  },
}));

const Floor = () => (
  <Floors appState={new appState()} />
)

export default Floor;