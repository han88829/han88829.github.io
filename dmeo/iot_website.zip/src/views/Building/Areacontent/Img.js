 
 import React, { Component } from 'react';
import $ from 'jquery';
import moment from 'moment';
import './areacontent.css';
//import Viewer from 'viewerjs';
import {Checkbox,Tooltip,Button} from 'antd';
import delete_pic from '../../../assets/images/build/delete.png';
import big_pic from '../../../assets/images/build/big.png';
import small_pic from '../../../assets/images/build/small.png';
import left_pic from '../../../assets/images/build/left.png';
import right_pic from '../../../assets/images/build/right.png';
import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
class Img extends Component {
  constructor() {
    super();
    this.state = {
      new_pingmiantu:false,
      areaId:[],
      building: {
      id:null,
      name: '',
      buildTime: '',
      createTime: '',
      fireDanger: '',
      fireLevel: '',
      galleryful: '',
      mapUrl: '',
      extend: {
        height: '',
        overgroundarea: '',
        overgroundfloor: '',
        rangebase: '',
        rangebuild: '',
        refugestoreyarea: '',
        refugestoreyfloor: '',
        subtype: '',
        undergroundarea: '',
        undergroundfloor: '',
        usetype: ''
      }
    },
     mapPoints: [],
    mapPointsIcon: [],
      buildImg:'',
      drag : 0,
      move:0,
      isdrag:false,
    };
  }
  componentWillMount(){
     //  console.log(arr);
     var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str =parseInt(str.substring(index + 1, str.length),10) ;
    //   window.rpc.area.getInfoById(str).then((x) => {
    //      //console.log(x);
    //     let asc=x.mapUrl;
    //      $("#buildImg").attr("src",asc);
    //      this.setState({
    //        buildImg:asc
    //      });//dres[x.subType
    //   })
     window.rpc.area.getArrayByContainer({parentId:str},0,0).then((res) => {
       let cont=[];
        let mapCont = res.map(res=>{
          cont.push(res.id)
        })
        //console.log(cont);
        this.setState({areaId:cont});
      });
      window.rpc.area.getInfoById(str).then((x) => {
         //console.log(x);
        // let asc=x.mapUrl;
        //  $("#buildImg").attr("src",asc);
         this.setState({
           building:x
         });//dres[x.subType
      });
      console.log(str);
      window.rpc.device.getArrayByContainer({storey:str},0,0).then((res) => {
         //window.rpc.device.getArrayByContainer({location:str},0,0).then((res) => {
                  console.log(res);
                  let mapPoints = res.filter(point => point.mapX);
                  let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point =>point.dtype)));
                  console.log(mapPoints);
               
                  mapPointsIcon.map((x,index)=>{
                    window.rpc.device.types.getNameById(x).then(data=>{
                         mapPointsIcon[index]={dtype:x,name:data};
                        if(index===mapPointsIcon.length-1)  this.setState({ mapPoints,mapPointsIcon });
                     })
                  })
                   //  console.log(mapPointsIcon);
                  //this.setState({ mapPoints,mapPointsIcon });
                  //console.log(mapPointsIcon);
        });
        window.rpc.area.getInfoById(str).then((res) => {
             let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
             // console.log(123);
             this.setState({ building });
             //this.setState({new_pingmiantu:true});
        })
  }
  componentDidMount(){
  

  }
  onWheelZoom=(obj)=>{  //滚轮缩放
      let zoom = parseFloat(obj.style.zoom);
      let tZoom = zoom + (event.wheelDelta>0 ? 0.05 : -0.05);
      if(tZoom<0.1 ) return true;
      obj.style.zoom=tZoom;
      return false;
   }
  
  Mousewheel=(e)=>{
      // return onWheelZoom(this);
   }
  //自定义函数
 
  render() {
    let that=this;
   $('.unpack').click(function () {
       $("body").css({'height':'100vh!import',width:'100vw;!import','overflow':'hidden'});
        that.setState({new_pingmiantu:true});
    });
  $(function () {
      var _move = false;//移动标记
      var _x, _y;//鼠标离控件左上角的相对位置
      $(".showImg").click(function () {
      }).mousedown(function (e) {
        _move = true;
        _x = e.pageX - parseInt($(".showImg").css("left"));
        _y = e.pageY - parseInt($(".showImg").css("top"));
        $(".showImg").fadeTo(20, 1);//点击后开始拖动并透明显示
      });
      $(document).mousemove(function (e) {
        if (_move) {
          var x = e.pageX - _x;//移动时根据鼠标位置计算控件左上角的绝对位置
          var y = e.pageY - _y;
          $(".showImg").css({ top: y, left: x });//控件新位置
        }
      }).mouseup(function () {
        _move = false;
        $(".showImg").fadeTo("fast", 1);//松开鼠标后停止移动并恢复成不透明
      });

    });
      $(function () {
      var currents = 0;
      var sWidth = 1;
      $('.showImg').on("mousewheel DOMMouseScroll", function (e) {
      var delta = (e.originalEvent.wheelDelta && (e.originalEvent.wheelDelta > 0 ? 1:-1))||(e.originalEvent.detail && (e.originalEvent.detail > 0 ? -1 : 1));  
      //console.log(delta);
      //console.log(event);
      if (delta < 0) {    
         sWidth=sWidth>=0.3?0.9*sWidth:sWidth;
          //sHeight=sWidth>=0.3?0.9*sHeight:sHeight;
        }else if(delta >0){
          sWidth=sWidth<=2.5?1.1*sWidth:sWidth;
          //sHeight=sWidth<=2?1.1*sHeight:sHeight;
       }
         //$myDiv.css(`-webkit-transform`,`scale(${sWidth},${sHeight})`); 
           $(".showImg").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
    });
  });
    return (
       <div className="areaImgLook">
        {/*<Checkbox style={{ position: "absolute", top: 2, left: 2, borderRadius: "10px" }}></Checkbox>*/}
          
          <span>
            <img className="unpack" style={{textAlign:`center`,cursor:`move`, display: "block", border: "1px solid #ffffff", marginLeft: 18, marginTop: 10 }} src={this.state.building.mapUrl} />
          </span>
          <div className="new_pingmiantu" style={{ display: this.state.new_pingmiantu ? 'flex': 'none',position:'fixed',top:0,left:0,zIndex:1000,height:'100vh',width:'100vw',backgroundColor:'#fff' }}>
          <div className="pingmiantu-top">
            <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu}))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu}))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <div className="pingmiantu-left" >
            <div className="showImg" style={{position:'relative'}}>
            <img id="img2" src={this.state.building.mapUrl} alt="right-pic" />
            {this.state.mapPoints.map((point,index) => (
              <div key={index} className={`map-point map-point-${point.dtype}`} style={{ position: 'absolute', height:20, width: 20, top:`${point.mapY}%`, left:`${point.mapX}%`}}></div>
            ))}
            </div>
          </div>
          <div className="pingmiantu-right">
            <div className="pingmiantu-oprate" title="正常" onClick={() => {
                console.log(this.state.areaId);//this.state.building.id
                window.rpc.device.getArrayByContainer({location:this.state.areaId,rstate:1},0,0).then((res) => {
                  console.log(res);
                  let mapPoints = res.filter(point => point.mapX);
                  {/*let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));*/}
                  console.log(mapPoints);
                  this.setState({ mapPoints });
                });
              }}><i className="iconfont-lszp">&#xe62a;</i></div>
            <div className="pingmiantu-oprate" title="异常" onClick={() => {
                //console.log(this.state);
                window.rpc.device.getArrayByContainer({location:this.state.areaId,rstate:2},0,0).then((res) => {
                  //console.log(res);
                  let mapPoints = res.filter(point => point.mapX);
                  {/*let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));*/}
                  console.log(mapPoints);
                  this.setState({ mapPoints });
                });
              }}><i className="iconfont-lszp">&#xe7e6;</i></div>
            <div className="pingmiantu-oprate" title="离线" onClick={() => {
                //console.log(this.state);
                window.rpc.device.getArrayByContainer({location:this.state.areaId,rstate:3},0,0).then((res) => {
                  //console.log(res);
                  let mapPoints = res.filter(point => point.mapX);
                  {/*let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));*/}
                  console.log(mapPoints);
                  this.setState({ mapPoints });
                });
              }}><i className="iconfont-lszp">&#xe613;</i></div>
            {this.state.mapPointsIcon.map((point, index) => (//title={types[point]}
              <div key={index} className={`pingmiantu-oprate pingmiantu-oprate-commen pingmiantu-oprate-${point.dtype}`} 
              title={point.name} onClick={() => {

                window.rpc.device.getArrayByContainer({location:this.state.areaId,dtype:point.dtype},0,0).then((res) => {
                  //console.log(res);
                  let mapPoints = res.filter(point => point.mapX);
                  {/*let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));*/}
                 // console.log(mapPoints);
                  this.setState({ mapPoints });
                });
              }}>
                
                </div>
            ))}
          </div>
        </div>
        {/*<Tooltip title="点击图片查看">
          <div className="overlay" style={{backgroundColor:'#555'}}>
            <div style={{ position: "fixed", width: 560, height: 32, color: "white", cursor: "pointer", position: "fixed", left: 690, top: 730, zIndex: 100000000000000 }} >
              <ul className="selects">
                <li className="toleft" title="点击左旋转"><img src={left_pic} /></li>
                <li className="toRight" title="点击右旋转"><img src={right_pic} /></li>
                <li className="bigger" title="点击放大"><img src={big_pic} /></li>
                <li className="smaller" title="点击缩小"><img src={small_pic} /></li>
              </ul>
            </div>
            <div style={{ width: 40, height: 40, fontSize: 30, float: "right", color: "white", borderRadius: "0 0 0 80%", background: "#cccccc", cursor: "pointer", padding: "0 0 30px 15px" }} className="open">X</div>
            <div style={{ zIndex: 90, padding: 10,top: 0,position: "fixed", left: "50%", marginLeft: "-300px", zIndex: 100000000,display: "block" }} className="showImg">
              <a href={'javascript:;'} ><img className="unpack" style={{  height: "100vh", display: "block", border: "1px solid #ffffff", padding: 10 }} src={this.state.buildImg} /></a>
            </div>
          </div>
        </Tooltip>*/}
        {/*<p style={{ textAlign: "center", lineHeight: "20px" }}>11</p>*/}
      </div>
    )
  }
}

export default Img;
 
 