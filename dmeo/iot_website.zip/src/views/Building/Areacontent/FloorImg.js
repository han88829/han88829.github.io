import React, { Component } from 'react';
import $ from 'jquery';
import './areacontent.css';
//import Viewer from 'viewerjs';
import {Tooltip} from 'antd';
import delete_pic from '../../../assets/images/build/delete.png';
import big_pic from '../../../assets/images/build/big.png';
import small_pic from '../../../assets/images/build/small.png';
import left_pic from '../../../assets/images/build/left.png';
import right_pic from '../../../assets/images/build/right.png';

class FloorImg extends Component {
  constructor() {
    super();
    this.state = {
      buildImg:'',
      drag : 0,
      move:0,
      isdrag:false,
    };
  }
  componentWillMount(){
         //  console.log(arr);
     var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str =parseInt(str.substring(index + 1, str.length),10) ;
      window.rpc.area.getInfoById(str).then((x) => {
         //console.log(x);
        let asc=x.mapUrl;
         $("#buildImg").attr("src",asc);
         this.setState({
           buildImg:asc
         });//dres[x.subType
      })
  }
  componentDidMount(){
    //  console.log(Viewer);
    // let unpack=$('.unpack').eq(0);
    // Viewer(unpack);
    // console.log(Viewer);
   
  }
  onWheelZoom=(obj)=>{  //滚轮缩放
      let zoom = parseFloat(obj.style.zoom);
      let tZoom = zoom + (event.wheelDelta>0 ? 0.05 : -0.05);
      if(tZoom<0.1 ) return true;
      obj.style.zoom=tZoom;
      return false;
   }
            // MouseOver=()=>{
            //  //  dragObj=block1;
            //   //  drag=1;
            // }
  Mousewheel=(e)=>{
      // return onWheelZoom(this);
   }
  //自定义函数
 
  render() {
    // console.log(Viewer);
    // let unpack=$('.unpack').eq(0);
    // Viewer(unpack);
   var sWidth=1;
   var sHeight=1;
   var $myDiv=$('.show').find('img'); 
  $(function () {
      $(".unpack").click(function () {
        $(".overlay").height(document.body.scrollHeight);
        $(".overlay").width(document.body.scrollWidth);
        // fadeTo第一个参数为速度，第二个为透明度
        // 多重方式控制透明度，保证兼容性，但也带来修改麻烦的问题
        $(".overlay").fadeTo(200, 1);
        // 解决窗口缩小时放大后不全屏遮罩的问题
        // 简单来说，就是窗口重置的问题
        $(window).resize(function () {
          $(".overlay").height(document.body.scrollHeight);
          $(".overlay").width(document.body.scrollWidth);
        });
      })

      $(".open").click(function () {
        $(".overlay").fadeOut(200,0);
      })

      var _move = false;//移动标记
      var _x, _y;//鼠标离控件左上角的相对位置
      $(".show").click(function () {
      }).mousedown(function (e) {
        _move = true;
        _x = e.pageX - parseInt($(".show").css("left"));
        _y = e.pageY - parseInt($(".show").css("top"));
        $(".show").fadeTo(20, 1);//点击后开始拖动并透明显示
      });
      $(document).mousemove(function (e) {
        if (_move) {
          var x = e.pageX - _x;//移动时根据鼠标位置计算控件左上角的绝对位置
          var y = e.pageY - _y;
          $(".show").css({ top: y, left: x });//控件新位置
        }
      }).mouseup(function () {
        _move = false;
        $(".show").fadeTo("fast", 1);//松开鼠标后停止移动并恢复成不透明
      });

    });
      $(function () {
      var currents = 0;

      $(".toleft").click(function () {
        currents = (currents + 90) % 360;
        //console.log(currents);
        $(".show").css("transform", 'rotate(' + currents + 'deg)');

      })
      var current = 0.1;

      var sWidth = 1;
      $(".bigger").click(function () {
        if (sWidth < 2) {
          sWidth = 1.1 * sWidth;
          $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
        }
      });

      $(".smaller").click(function () {
        if (sWidth > 0.3) {
          sWidth = 0.9 * sWidth;
          $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
          //console.log(sWidth);
        }
      });

      $(".toRight").click(function () {
        currents = -((currents + 90) % 360);
        //console.log(currents);
        $(".show").css("transform", 'rotate(' + currents + 'deg)');

      });
       $('.overlay').on("mousewheel DOMMouseScroll", function (e) {
      var delta = (e.originalEvent.wheelDelta && (e.originalEvent.wheelDelta > 0 ? 1:-1))||(e.originalEvent.detail && (e.originalEvent.detail > 0 ? -1 : 1));  
      //console.log(delta);
      //console.log(event);
      if (delta < 0) { 
        
            sWidth=sWidth>=0.3?0.9*sWidth:sWidth;
            sHeight=sWidth>=0.3?0.9*sHeight:sHeight;
            let newWidth=1080*sWidth;
            let newHeight=1080*sHeight;
            let ClientWidth=document.body.clientWidth,ClientHeight=document.body.clientHeight;
            //   console.log(ClientHeight);
            //   console.log(event.clientY-newHeight/2);
            sWidth=sWidth>=0.3?0.9*sWidth:sWidth;
             sHeight=sWidth>=0.3?0.9*sHeight:sHeight;
            if(newWidth>ClientWidth||newHeight>ClientHeight){
                $myDiv.parent().css({
                position:"fixed",
                top:"0",
                left:'50%',
                marginLeft:`-${newHeight/2}`,
                marginTop:`-${event.clientY-newHeight/2}`,
                width:`${newWidth}px`,
                height:`${newHeight}px`,
             }); 

         }

        }else if(delta >0){
          sWidth=sWidth<=2.5?1.1*sWidth:sWidth;
          sHeight=sWidth<=2?1.1*sHeight:sHeight;
            let newWidth=1080*sWidth;
            let newHeight=1080*sHeight;
            let ClientWidth=document.body.clientWidth,ClientHeight=document.body.clientHeight;
            //console.log(ClientHeight);
            //console.log(event.clientY-newHeight/2);
            if(newWidth>ClientWidth||newHeight>ClientHeight){
                $myDiv.css({
                  position:"fixed",
                  top:"0",
                  left:'0',
                  marginLeft:`-${event.clientX-newWidth/2}`,
                  marginTop:`-${event.clientY-newHeight/2}`,
                  width:`${newWidth}px`,
                  height:`${newHeight}px`,
             });
         }
       }
         //$myDiv.css(`-webkit-transform`,`scale(${sWidth},${sHeight})`); 
           $(".show").css("transform", 'scale(' + sWidth + ',' + sWidth + ')');
        
      
    });
    })


    return (
       <div className="areaImgLook">
        {/*<Checkbox style={{ position: "absolute", top: 2, left: 2, borderRadius: "10px" }}></Checkbox>*/}
        <Tooltip title="点击图片查看">
          <span>
            <img className="unpack" style={{textAlign:`center`,cursor:`move`, display: "block", border: "1px solid #ffffff", marginLeft: 18, marginTop: 10 }} src={this.state.buildImg} />
          </span>
          <div className="overlay" style={{backgroundColor:'#555'}}>
            <div style={{ position: "fixed", width: 560, height: 32, color: "white", cursor: "pointer", position: "fixed", left: 690, top: 730, zIndex: 100000000000000 }} >
              <ul className="selects">
                <li className="toleft" title="点击左旋转"><img src={left_pic} /></li>
                <li className="toRight" title="点击右旋转"><img src={right_pic} /></li>
                <li className="bigger" title="点击放大"><img src={big_pic} /></li>
                <li className="smaller" title="点击缩小"><img src={small_pic} /></li>
              </ul>
            </div>
            <div style={{ width: 40, height: 40, fontSize: 30, float: "right", color: "white", borderRadius: "0 0 0 80%", background: "#cccccc", cursor: "pointer", padding: "0 0 30px 15px" }} className="open">X</div>
            <div style={{ zIndex: 90, padding: 10,top: 0,position: "fixed", left: "50%", marginLeft: "-300px", zIndex: 100000000,display: "block" }} className="show">
              <a href={'javascript:;'} ><img className="unpack" style={{  height: "100vh", display: "block", border: "1px solid #ffffff", padding: 10 }} src={this.state.buildImg} /></a>
            </div>
          </div>
        </Tooltip>
        {/*<p style={{ textAlign: "center", lineHeight: "20px" }}>11</p>*/}
      </div>
    )
  }
}

export default FloorImg;