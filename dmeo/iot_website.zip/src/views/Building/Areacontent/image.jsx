import React, { Component } from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';

class AreaContentImage extends Component {
    state = {
        image: "",
        flag: 1,
        url: ""
    }
    componentWillMount() {

    }
    componentDidMount() {
        //let id = '';
          let  id = this.props.params.id
        console.log(this.props.params.type);
        if (this.props.params.type === '51') {
            id = this.props.params.id
            console.log(id);
            this.setState({
                url: `/org/areat/newarea/${id}`,
                id
            })
        } else {
            window.rpc.area.getInfoById(this.props.params.id).then(res => {
                console.log(res)
                this.setState({
                    url: `/org/areat/editarea/${this.props.params.id}`,
                    id:res.parentId
                });
               
                let arr2 = [];
                var Canvas = document.getElementsByTagName('canvas')[0];
                var myCanvas = Canvas.getContext('2d');
                let arrcon = res.mapPoint.split(';');
                arrcon.forEach((x) => {
                    arr2.push({ x: x.split(',')[0], y: x.split(',')[1] })
                })
                console.log(arr2)
                myCanvas.beginPath();
                myCanvas.moveTo(arr2[0].x, arr2[0].y);
                myCanvas.strokeStyle = 'red';
                arr2.map(x => { myCanvas.lineTo(x.x, x.y); })
                myCanvas.lineWidth = 2;
                myCanvas.stroke();
                myCanvas.closePath();
            })
        }
        //console.log(this.state.id);
       //id=this.state.id;
       window.rpc.area.getInfoById(this.props.params.id).then(info => {
           window.rpc.area.getInfoById(info.parentId).then(res => {
             this.setState({
                image: res.mapUrl
             })
             console.log(res);
           },err=>{
             console.log(err);
          })
       },err=>{
          console.log(err);
       })
        let arr = [];
        var Canvas = document.getElementsByTagName('canvas')[0];
        var myCanvas = Canvas.getContext('2d');
        const self = this;
        Canvas.onmousedown = function (ev) {
            var ev = ev || window.event;
            var initx = ev.layerX;
            var inity = ev.layerY;
            arr.push({ x: initx, y: inity })
            myCanvas.beginPath();
            myCanvas.moveTo(initx, inity);
            Canvas.onmousemove = function (ev) {
                var ev = ev || window.event;
                var x = ev.layerX;
                var y = ev.layerY;
                if (self.state.flag) {
                     myCanvas.strokeStyle = 'red';
                     myCanvas.lineTo(x, y);
                    if (self.props.params.type === '51') {               
                        arr.push({ x, y })
                    } else {
                        let arr3 = [];
                        window.rpc.area.getInfoById(self.props.params.id).then(res => {
                            res.mapPoint.split(';').forEach((x) => {
                                arr3.push({ x: x.split(',')[0], y: x.split(',')[1] })
                            })
                            //arr = arr3;
                            arr.push({ x, y })
                        })           
                    }
                    console.log(arr)
                } else {
                   // let arr3 = [],arr=[];
                    window.rpc.area.getInfoById(self.props.params.id).then(res => {
                        res.mapPoint.split(';').forEach((x) => {
                            //arr3.push({ x: x.split(',')[0], y: x.split(',')[1] })
                            arr.push({ x: x.split(',')[0], y: x.split(',')[1] })
                        })
                       // arr = arr3; 
                    })
                    myCanvas.clearRect(x, y, 30, 30)
                    console.log({ x:JSON.stringify(x), y:JSON.stringify(y) })
                    console.log(arr.indexOf({ x:JSON.stringify(x), y:JSON.stringify(y) }))
                    arr.splice(arr.indexOf({ x, y }), 1);
                }
                myCanvas.lineWidth = 2;
                myCanvas.stroke();
            }
            document.onmouseup = function () {
                console.log(arr)
                Canvas.onmousemove = null;
                document.onmouseup = null;
                myCanvas.closePath();
                sessionStorage.setItem(`arr${id}`, JSON.stringify(arr))
            }
        }
    }
    handleHref(){
        location.href=`${this.state.url}`;
    }
    render() {
        return (
            <div className="areaContent" style={{ position: "relative" }}>
                <div style={{ width: 40, height: 40, fontSize: 30, position:'fixed',right:0,top:50, color: "white", zIndex: 99999, borderRadius: "0 0 0 80%", background: "#cccccc", cursor: "pointer", padding: "0 0 30px 15px" }} className="open">
                    <Link to={`/org/areat/info/${this.props.params.id}`}>X</Link>
                </div>
                <canvas width="1600" height="800" style={{ position: "absolute", left: 0, top: 0, zIndex: 9 }}></canvas>
                <div style={{ position: "absolute", left: 0, top: 0 }}><Button onClick={() => { this.setState({ flag: 1 }) }}>画笔</Button> <Button onClick={() => { this.setState({ flag: 0 }) }}>橡皮</Button> <Button onClick={this.handleHref}>保存</Button></div>
                <p style={{ width: 1600, height: 800, position: "absolute", left: 0, top: 0 }}><img src={this.state.image} alt="" style={{ width: "100%", height: "100%" }} /></p>
                <div style={{position:"absolute",top:803,background:'#ccc'}}><Button style={{background:'#ccc'}}><Link style={{color:'#fff'}} to={`/org/areat/info/${this.props.params.id}`}>返回</Link></Button></div>
            </div>
        )
    }
}

export default AreaContentImage;