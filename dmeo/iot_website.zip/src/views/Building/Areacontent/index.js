/*
 * @Author: szj
 * @Date: 2017-03-27 16:23:46 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 12:47:07
 */


import React from 'react';
import { Card, Form, Button, Row, Col, Tabs, Icon, Table } from 'antd';
import { Link } from 'react-router';
//import moment from 'moment';
import $ from 'jquery';
//import  FloorImg from './FloorImg';
//import  FloorImg from './ImgFview';
import  FloorImg from './Img';
//ImgFview
//const FormItem = Form.Item;
//const Option = Select.Option;
//const { RangePicker } = DatePicker;
import '../Floor/floor.css';
import './index.css';

import build from '../../../assets/images/build/build.png';
import Area from '../../../assets/images/build/Area.png';
import bDate from '../../../assets/images/build/bDate.png';
import bArea  from '../../../assets/images/build/bArea.png';
import bd from '../../../assets/images/build/bd.png';
import bHeight from '../../../assets/images/build/bHeight.png';
import build_remark from '../../../assets/images/build/build-remark.png';
import build_time from '../../../assets/images/build/build-time.png';
import fireEleNum from '../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../assets/images/build/maxTotleNum.png';
import nature from '../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../assets/images/build/safety.png';
import standardFloorArea from '../../../assets/images/build/standardFloorArea.png';
import subType from '../../../assets/images/build/subType.png';
import totalElevator from '../../../assets/images/build/totalElevator.png';
import underArea from '../../../assets/images/build/underArea.png';

import underNumber from '../../../assets/images/build/underNumber.png';
import upDown from '../../../assets/images/build/upDown.png';
import upperNumber from '../../../assets/images/build/upperNumber.png';
import workMen from '../../../assets/images/build/workMen.png';
import workPersonDay from '../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../assets/images/build/fireLevel.png';
import floorArea from '../../../assets/images/build/floorArea.png';

const { TabPane } = Tabs;

const Areacontent = Form.create()(React.createClass({
  getInitialState() {
    return {
      data: '',
      builds: {
        Fname: '',
        Frisk: '',
        Fuse: '',
        Fstructure: '',
        Frefractory: '',
        Farea: '',
        Felevator: '',
        Earea: '',
        Ftotal: '',
        Fday: '',
        Fnote: '',
        elevator:'',
        Pcapacity:'',
        
        PMaxWork:''

      },
      buildImg: '',
      Id: null,
      parentId:null,
      datacon: [],
      selectedRowKeys: []
    }
  },
  componentWillMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    console.log(str);
    this.setState({ Id: str });
    let name = '', locaname = '';
    window.rpc.area.getInfoById(str).then((x) => {
      console.log(x);
      let parentId=x.parentId;
       this.setState({parentId});
      let asc = x.mapUrl;
      $("#seeImgInfoAreaCount").attr({ "href": asc });
      this.setState({
        buildImg: asc
      });
      name = x.name;
       window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
          let builds = { ...x, Fname: x.name, Frisk: x.fireLevel, key: x.id, Fuse: res[x.fireDanger], Fstructure: x.galleryful, Frefractory: x.layer, Farea: x.number, Felevator: x.ownerId, Earea: x.parentId, Ftotal: x.subtype, Fday: x.type, Fnote: x.number,elevator:x.extend.elevator||'',elevatornum:x.extend.elevatornum||'',galleryful:x.galleryful,everyday:x.extend.everyday,nature:x.extend.nature };
          this.setState({
            builds
          })
       },(err) =>{
        console.warn(err);
       });
     
      return window.rpc.area.getInfoById(x.parentId)
    }, (err) => {
      console.warn(err);
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    }).then(data => {
      locaname = data.name
      return window.rpc.area.getArrayByContainer({ type: 52, parentId: str }, 0, 0)
    }).then((res) => {
      console.log(locaname)
      console.log(res)
      let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark, location: name, Floorarea: locaname }));
      console.log(type)
      let types = type.reverse();
      this.setState({ types, datacon: type });
    }, (err) => {
      console.warn(err);
      console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
  onSelectChange(selectedRowKeys) {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    const Selected = { Id: parseInt(selectedRowKeys[0]) };
    console.log(Selected);
    this.setState({ Selected: Selected });
    console.log(this.state.Selected);
  },
  render() {
    // const { getFieldDecorator } = this.props.form;

    //区域表格信息
    const data = this.state.data;
    console.log(data)
    //基础信息
    const Floorbasis = [{ key: 1, id: 1, Fname: '一楼', Frisk: '危险', Fuse: '民用', Fstructure: '未知', Frefractory: '高级', Farea: '300', Felevator: '10', Earea: '300', Etotal: '200', Ftotal: '500', Fday: '100', Fnote: '无' }];
    const FloorInformation = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '区域名', dataIndex: 'name', key: 'name' , render: (text, record) => (
          <span>
            <Link to={`/org/areat/info/${record.key}`}>{text}</Link>
            
          </span>
        )
    
  },
      { title: '所属楼层', dataIndex: 'location', key: 'location' },
      { title: '所属建筑', dataIndex: 'Floorarea', key: 'Floorarea' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/org/areat/info/${record.key}`}>详情</Link>
            <span className="ant-divider" />
            <Link to={`/org/areat/editarea/${record.key}`}>修改</Link>
          </span>
        )
      },
    ];

    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };

    const pagination = {
      total: 20,
      showTotal: total => `共 20 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return (
      <div style={{ height: '100%', }} className='Floor Area'>
        <Tabs style={{ height: '100%', fontSize: '0.75rem' }} className='buildInfoTabOne' >
          <TabPane className="firstTabInfo" tab={<span><Icon type="info-circle-o" />基础信息</span>} style={{ height: '80vh', }} key="1">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 195, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
             
               <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>
                 <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link><span style={{padding:'0 4px'}}>/</span>
                 <Link to={`/org/floor/${this.state.parentId}`}  style={{color:'#373e41'}} >楼层信息</Link><span style={{padding:'0 4px'}}>/</span>
                 <Link to='' style={{color:'#373e41'}} >区域信息</Link>
               </span>
            </div>

            <div style={{ marginTop: -4, paddingTop: 5, height: '100%', maxHeight: '77vh', overflow: 'auto', }}>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41', borderTop: '1px solid #ddd' }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>基础信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><span><img src={build} style={{padding:'0 15px 0 12px'}} alt=""/>楼层名：{this.state.builds.name}</span> <a id="seeImgInfoAreaCount" style={{ display: 'inline-block', height: 20, width: 20, marginLeft: 10, borderRadius: '100%', background: '#fff', border: '1px solid #ccc', float: 'right',display:'none' }}><Icon type="upload" style={{ marginLeft: 4 }} /></a> </div>
              
                    <div className="Row-info-right"><img src={safety} style={{padding:'0 15px 0 12px'}} alt=""/>火灾危险性：{this.state.builds.Fuse} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={nature} style={{padding:'0 15px 0 12px'}} alt=""/>使用性质：{this.state.builds.nature} </div>
                    <div className="Row-info-right"><img src={subType} style={{padding:'0 15px 0 12px'}} alt=""/>结构类型:{this.state.builds.Farea} </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={fireLevel} style={{padding:'0 15px 0 12px'}} alt=""/>耐火等级：{this.state.builds.Frefractory}级 </div>
                  </div>
                </div>
            </div>
             
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41', }}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>更多信息</p>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={fireEleNum} style={{padding:'0 15px 0 12px'}} alt=""/>消防电梯数量：{this.state.builds.elevator}  </div>
                    <div className="Row-info-right"><img src={totalElevator} style={{padding:'0 15px 0 12px'}} alt=""/>电梯容量：{this.state.builds.elevatornum}  </div>
                  </div>
                  <div className="Row-info">
                    <div className="Row-info-left"><img src={maxTotleNum} style={{padding:'0 15px 0 12px'}} alt=""/>最大容纳人数：{this.state.builds.galleryful} </div>
                    <div className="Row-info-right"><img src={workPersonDay} style={{padding:'0 15px 0 12px'}} alt=""/>日常工作时间人数：{this.state.builds.everyday} </div>
                  </div>
                </div>
              </div>
              <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div style={{ fontsize: '0.75rem', color: '#373e41',}}>
                  <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>备注</p>
                  <div className="Row-info-left"><img src={build_remark} style={{padding:'0 15px 0 12px'}} alt=""/>备注：{this.state.builds.Fnote}  </div>
                </div>
              </div>

            </div>
            <div>
              <Row>
                {/*<Button type="success" style={{ marginLeft: '0' ,left: 0, bottom:'30px',width:60,height:32,background:'#ccc'}}><Link to={`org/floor/${this.state.parentId}`}  style={{color:'#fff'}}>返回</Link></Button>*/}
                <span className="new-button" style={{display:`inline-block`, marginLeft: '0' ,left: 0, bottom:'30px',width:60,height:32,background:'#ccc',borderRadius:0 }}><Link to={`org/floor/${this.state.parentId}`}>返回</Link></span>
              </Row>
            </div>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />区域</span>} key="2">
             <div className='floor-table' style={{ position: 'absolute', left: 0, top: 10, width: 195, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
               <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>
                 <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link><span style={{padding:'0 4px'}}>/</span>
                 <Link to={`/org/floor/${this.state.parentId}`}  style={{color:'#373e41'}} >楼层信息</Link><span style={{padding:'0 4px'}}>/</span>
                 <Link to='' style={{color:'#373e41'}} >区域信息</Link>
               </span>
              </div>
            <div style={{ height: 46, marginRight: 4 ,marginBottom: '14px'}}>
              <div className="new-button" type="" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to={`/org/areat/newarea/${this.props.params.id}`} onClick={this.handelClick} >新增区域</Link></div>
            </div>
            <div  className='floor-table'>
              <Table
                className="table-equipTask"
                rowSelection={rowSelection}
                columns={FloorInformation}
                dataSource={this.state.datacon}
                pagination={pagination}
              />
            </div>
           
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />平面图</span>} key="3">
            <div style={{ position: 'absolute', left: 0, top: 10, width: 195, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
               <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>
                 <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link><span style={{padding:'0 4px'}}>/</span>
                 <Link to={`/org/floor/${this.state.parentId}`}  style={{color:'#373e41'}} >楼层信息</Link><span style={{padding:'0 4px'}}>/</span>
                 <Link to='' style={{color:'#373e41'}} >区域信息</Link>
               </span>
              </div>
            <div className="img">
              {/*<img src={this.state.buildImg} id="buildImgcount" alt="" />*/}
              <FloorImg  />
            </div>
          </TabPane>
        </Tabs>
      </div>
    );
  },
}));

export default Areacontent;