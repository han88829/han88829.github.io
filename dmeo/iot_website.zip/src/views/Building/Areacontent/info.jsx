import React, { Component } from 'react';
import { Link } from 'react-router';
import { Modal, Button, Icon } from 'antd';
import './areacontent.css';
import './index.css';
// import org_name_pic from '../../../assets/images/orgs/org-name.png';
// import business_license_pic from '../../../assets/images/orgs/business-license.png';
// import create_time_pic from '../../../assets/images/orgs/create-time.png';
// import last_time_pic from '../../../assets/images/orgs/last-time.png';
// import fix_asset_pic from '../../../assets/images/orgs/fix-asset.png';
// import org_address_pic from '../../../assets/images/orgs/org-address.png';
// import org_state_pic from '../../../assets/images/orgs/org-state.png';

// import owner_area_pic from '../../../assets/images/orgs/owner-area.png';
// import quit_time_pic from '../../../assets/images/orgs/quit-time.png';
// import remark_pic from '../../../assets/images/orgs/remark.png';
// import innet_time_pic from '../../../assets/images/orgs/innet-time.png';
// import setup_time_pic from '../../../assets/images/orgs/setup-time.png';

// import unit_area_pic from '../../../assets/images/orgs/unit-area.png';
// import worker_staff_pic from '../../../assets/images/orgs/worker-staff.png';
import build from '../../../assets/images/build/build.png';
import Area from '../../../assets/images/build/Area.png';
import bDate from '../../../assets/images/build/bDate.png';
import bArea  from '../../../assets/images/build/bArea.png';
import bd from '../../../assets/images/build/bd.png';
import bHeight from '../../../assets/images/build/bHeight.png';
import build_remark from '../../../assets/images/build/build-remark.png';
import build_time from '../../../assets/images/build/build-time.png';
import fireEleNum from '../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../assets/images/build/maxTotleNum.png';
import nature from '../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../assets/images/build/safety.png';
import standardFloorArea from '../../../assets/images/build/standardFloorArea.png';
import subType from '../../../assets/images/build/subType.png';
import totalElevator from '../../../assets/images/build/totalElevator.png';
import underArea from '../../../assets/images/build/underArea.png';

import underNumber from '../../../assets/images/build/underNumber.png';
import upDown from '../../../assets/images/build/upDown.png';
import upperNumber from '../../../assets/images/build/upperNumber.png';
import workMen from '../../../assets/images/build/workMen.png';
import workPersonDay from '../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../assets/images/build/fireLevel.png';
import floorArea from '../../../assets/images/build/floorArea.png';
class AreaInfocon extends React.Component {

    componentWillMount() {
        window.rpc.area.getInfoById(this.props.props.params.id).then(res => {
            let arr = res.mapPoint.split(';')
            sessionStorage.setItem('arr', JSON.stringify(arr))
            return window.rpc.area.getInfoById(res.parentId)
        }).then(info => {
            this.setState({
                image: info.mapUrl
            })
        })
    }
    render() {
        return (
            <div style={{ float: "right" }} className='areaInfo'>
                <Button><Link to={`/org/areat/infoimage/${this.props.props.params.id}`}>点击查看区域</Link></Button>
            </div>
        );
    }
}

class AreaInfo extends React.Component {
    state = {
        areatChild: [],
        extend: {},
        ID:"",
        id:''
    }
    componentWillMount() {
        window.rpc.area.getInfoById(this.props.params.id).then(res => {
            console.log(res);
           // res={...res,}
           window.rpc.alias.getValueByName('area.fireDanger').then((fres) => {
              console.log(res.fireLevel);
              console.log( fres[res.fireLevel]);
          let build= { ...res,fireDanger: fres[res.fireDanger]||''};
          console.log(build);
           this.setState({
             areatChild:build,
                 
            })       
           
          console.log(fres);
        //   this.setState({
        //     builds
        //   })
         
          },(err) =>{
             console.warn(err);
             console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
           });
           if(res){
               window.rpc.area.getInfoById(res.parentId).then(result => {
                 console.log(result.id);
                 this.setState({
                 // areatChild:build,
                  extend: res.extend,
                  ID:res.parentId,
                  id:result.parentId
                
            })       
           
             
          },err=>{
              console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
          })
         }
            
        })
    }
    render() {
        return (
          <div style={{ marginTop: -4, paddingTop: 5, maxHeight: '90vh', overflow: 'auto', }}>
             <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',borderBottom:'1px solid #ddd',fontSize:'0.75rem',fontFamily:'苹方中等',}}>
                <div style={{float:'left',width:195,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
                  <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}> 
                    <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link><span style={{padding:'0 4px'}}>/</span>
                    <Link to={`/org/floor/${this.state.id}`}  style={{color:'#373e41'}} >楼层信息</Link><span style={{padding:'0 4px'}}>/</span>
                    <Link to={`/org/area/cont/${this.state.ID}`} style={{color:'#373e41'}} >区域信息</Link>
                  </span>
                </div>
                <div  style={{float:'left',width:80,height:32,marginRight:4}}>
                  <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">区域详情</Link></Button>
                </div>
              </div>
              <div style={{ height: '72vh',}}>   
                <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                        <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>基础信息</p>
                        <div className="Row-info">
                            <div className="Row-info-left"><span><img src={build} style={{padding:'0 15px 0 12px'}} alt=""/>区域名：{this.state.areatChild.name}</span> <AreaInfocon props={this.props} /></div>
                            <div className="Row-info-right"><img src={safety} style={{padding:'0 15px 0 12px'}} alt=""/>火灾危险性： {this.state.areatChild.fireDanger}</div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left"><img src={nature} style={{padding:'0 15px 0 12px'}} alt=""/>使用性质: {this.state.extend.nature}</div>
                            <div className="Row-info-right"><img src={subType} style={{padding:'0 15px 0 12px'}} alt=""/>结构类型: {this.state.areatChild.subtype}</div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left"><img src={fireLevel} style={{padding:'0 15px 0 12px'}} alt=""/>耐火等级: {this.state.areatChild.galleryful}</div>
                             <div className="Row-info-right"><img src={Area} style={{padding:'0 15px 0 12px'}} alt=""/>占地面积（平方米）： {this.state.areatChild.face}</div>
                       
                        </div>
                    </div>
                </div>
                <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                    <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                        <div className="Row-info">
                            <div className="Row-info-left"><img src={fireEleNum} style={{padding:'0 15px 0 12px'}} alt=""/>消防电梯数量: {this.state.extend.elevator}</div>
                             <div className="Row-info-right"><img src={totalElevator} style={{padding:'0 15px 0 12px'}} alt=""/>电梯容纳总量： {this.state.extend.elevatornum}</div>
                        </div>
                       
                    </div>
                </div>
             
                <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
                    <div style={{ fontsize: '0.75rem', color: '#373e41'}}>
                        <div className="Row-info">
                            <div className="Row-info-left"><img src={maxTotleNum} style={{padding:'0 15px 0 12px'}} alt=""/>最大容纳人数: {this.state.areatChild.galleryful}</div>
                            <div className="Row-info-right"><img src={workPersonDay} style={{padding:'0 15px 0 12px'}} alt=""/>日常工作时间人数:  {this.state.extend.everyday}</div>
                        </div>
                        <div className="Row-info">
                            <div className="Row-info-left"><img src={build_remark} style={{padding:'0 15px 0 12px'}} alt=""/>备注: {this.state.areatChild.remark}</div>
                        </div>
                    </div>
                </div>
              </div>
                <div style={{marginTop:30}}>
                   {/*<Button type="success" style={{ marginLeft: '0' ,width:60,height:32,background:'#ccc'}}><Link to={`/org/area/cont/${this.state.ID}`}  style={{color:'#fff'}}>返回</Link></Button>*/}
                      <div className="new-button"style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/org/area/cont/${this.state.ID}`}>返回</Link></div>
                </div>
            </div>
        )
    }
}
export default AreaInfo;