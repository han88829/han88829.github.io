/*
 * @Author: szj
 * @Date: 2017-03-27 16:35:51 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-07-21 10:10:53
 */

import React, { Component } from 'react';
import { Input, Button, Form, Select, DatePicker, Row, Col,Icon,message,InputNumber} from 'antd';
import { Link } from 'react-router';
//import { observable } from 'mobx';
//import { observer } from 'mobx-react';
 import $ from 'jquery';
 
// //import org_name_pic from '../../../assets/images/orgs/org-name.png';
// //import business_license_pic from '../../../assets/images/orgs/business-license.png';
// import create_time_pic from '../../../assets/images/orgs/create-time.png';
// //import last_time_pic from '../../../assets/images/orgs/last-time.png';
// import fix_asset_pic from '../../../assets/images/orgs/fix-asset.png';
// import org_address_pic from '../../../assets/images/orgs/org-address.png';
// import org_state_pic from '../../../assets/images/orgs/org-state.png';

// //import owner_area_pic from '../../../assets/images/orgs/owner-area.png';
// //import quit_time_pic from '../../../assets/images/orgs/quit-time.png';
// import remark_pic from '../../../assets/images/orgs/remark.png';
// //import innet_time_pic from '../../../assets/images/orgs/innet-time.png';
// //import setup_time_pic from '../../../assets/images/orgs/setup-time.png';

// import unit_area_pic from '../../../assets/images/orgs/unit-area.png';
// //import worker_staff_pic from '../../../assets/images/orgs/worker-staff.png';
// import bd_name_pic from '../../../assets/images/orgs/bd-name.png';

import build from '../../../assets/images/build/build.png';
import Area from '../../../assets/images/build/Area.png';
import bDate from '../../../assets/images/build/bDate.png';
import bArea  from '../../../assets/images/build/bArea.png';
import bd from '../../../assets/images/build/bd.png';
import bHeight from '../../../assets/images/build/bHeight.png';
import build_remark from '../../../assets/images/build/build-remark.png';
import build_time from '../../../assets/images/build/build-time.png';
import fireEleNum from '../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../assets/images/build/maxTotleNum.png';
import nature from '../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../assets/images/build/safety.png';
import standardFloorArea from '../../../assets/images/build/standardFloorArea.png';
import subType from '../../../assets/images/build/subType.png';
import totalElevator from '../../../assets/images/build/totalElevator.png';
import underArea from '../../../assets/images/build/underArea.png';

import underNumber from '../../../assets/images/build/underNumber.png';
import upDown from '../../../assets/images/build/upDown.png';
import upperNumber from '../../../assets/images/build/upperNumber.png';
import workMen from '../../../assets/images/build/workMen.png';
import workPersonDay from '../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../assets/images/build/fireLevel.png';
import floorArea from '../../../assets/images/build/floorArea.png';

const FormItem = Form.Item;
//const RangePicker = DatePicker.RangePicker;
const Option = Select.Option;


// const info = function () {
//   message.info('This is a normal message');
// };
class  NewArea extends Component {
  render() {
    return (
      <div className="NewBuilding">
        <FloorNew />
      </div>
    )
  }
}


const FloorNew = Form.create()(React.createClass({
   getInitialState() {
    return {
     imgLink:'',
     createValue:null,
     buildingType:[],
      fireDanger:[],
     createId:null,
     buildId:null,
    };
  },
   componentWillMount(){
     var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str = str.substring(index + 1, str.length);
     // buildId
     this.setState({buildId:str});
     window.rpc.area.types.getArrayIdNameByContainer(null,0,0).then((res) => {
        console.log(res);
        let buildingType=res.map((x)=>({...x}));
        this.setState({
        buildingType
     }) 
    },(err) =>{
        console.warn(err);
    })
     window.rpc.alias.getValueByName('area.fireDanger').then((res) => {
        let arr=['/'];
         for(let key in res){
            let values=`${res[key]}`
            arr.push(values);
         }
       //  console.log(arr);
      let fireDanger=arr;
       this.setState({
         fireDanger
       }) 
     },(err) =>{
        console.warn(err);
     });
   },
  componentDidMount() {
  
  },
  // uploadButton(){
  //      // console.log(11111);
  //      //console.log(this.state.createId);
  //      let createId=this.state.createId;
  //      window.rpc.upload.images.getAreaUniqueConfigById(createId).then((res) => {
  //      // window.rpc.upload.images.getDefaultConfig().then((res) => {
  //       console.info(res);
  //       let { domain, uptoken } = res;
  //         var uploader = window.Qiniu.uploader({
  //         runtimes: 'html5,flash,html4',    //上传模式,依次退化
  //         browse_button: 'pickfiles1',       //上传选择的点选按钮，**必需**
  //         // uptoken_url: '/token',            //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
  //         uptoken : uptoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
  //         //unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
  //          //save_key: true,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
  //         domain: `http://${domain}/`,   //bucket 域名，下载资源时用到，**必需**
  //        // domain: `http://omdwajej6.bkt.clouddn.com/`,
  //         get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
  //         // container: 'container',           //上传区域DOM ID，默认是browser_button的父元素，
  //         max_file_size: '100mb',           //最大文件体积限制
  //         unique_names: true,
  //         multi_selection: false,
  //         // flash_swf_url: 'https://cdn.staticfile.org/plupload/2.1.9/Moxie.swf',  //引入flash,相对路径
  //         max_retries: 3,                   //上传失败最大重试次数
  //         // dragdrop: true,                   //开启可拖曳上传
  //         // drop_element: 'container',        //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
  //         chunk_size: '4mb',                //分块上传时，每片的体积
  //         auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
  //         init: {
  //         'FilesAdded': function (up, files) {
  //           //plupload.each(files, function (file) {
  //           // 文件添加进队列后,处理相关的事情
  //           //});
  //         },
  //         'BeforeUpload': function (up, file) {
  //           // 每个文件上传前,处理相关的事情
  //         },
  //         'UploadProgress': function (up, file) {
  //           // 每个文件上传时,处理相关的事情
  //         },
  //         'FileUploaded': function (up, file, info) {
  //            let domain = up.getOption('domain');
  //            let res = JSON.parse(info);
  //            var sourceLink = domain + res.key;// {error: "key doesn't match with scope"}  error:"key doesn't match with scope" key不匹配范围
  //            console.log(sourceLink);//http://omdwajej6.bkt.clouddn.com/o_1bb8sld891s43nst12ia1hdbgin7.png
  //            // this.props.appState.imgLink=sourceLink;
  //            var asc=sourceLink;
  //             $("#seeImg").attr({"href":asc});
  //          },
  //          'Error': function (up, err, errTip) {
  //           //上传出错时,处理相关的事情
  //          },
  //          'UploadComplete': function () {
  //           //队列文件处理完毕后,处理相关的事情
  //          },
  //          'Key': function (up, file) {
  //           // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
  //           // 该配置必须要在 unique_names: false , save_key: false 时才生效
  //           var key = "";
  //           // do something with key here
  //           return key
  //         }
  //       }
  //     });
  //   },(err) =>{
  //       console.warn(err);
  //   })    
  // },
//  handleClickButton(){
//    //setInfo 上传图片
//    let createId=this.state.createId;
//    let value=this.state.createValue;
//    let imgUrl=$("#seeImg").attr('href');
//    let values = {...value,mapUrl:imgUrl};
//    console.log(values);
//    window.rpc.area.setInfoById(createId,values).then((res) => {
//      console.log(res);
//      if(res){
//      window.location.href=`/org/floor/${this.state.buildId}`;
//      }
//    },(err) =>{
//      console.warn(err);
//    });

// let imgUrl='baidu'
// let Object={name:"科技创业大厦",number:null,ownerId:1,parentId:0,point:null,remark:null,subtype:102,type:50,x:121.618835,y:29.92071}
//  let value = { ...Object, img:imgUrl};
//  console.log(value);
 //},
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form:', values);
        const value = { ...values,extend:{elevatornum:values.elevatornum,elevator:values.elevator,nature:values.nature, everyday:values.everyday},type:51,parentId:this.state.buildId };//buildTime:new Date(values.buildTime.format('YYYY-MM-DD')),
        console.log(value);
        this.setState({ createValue:value});
        window.rpc.area.create(value).then((res) => {
          console.log(res);
          let createId=res;
          if(createId){
            this.setState({createId:res});
            // console.log(this.state.createId);
            message.info("请上传图片");
            window.location.href=`/org/area/img/${createId}`;
            //qi(res);
            //qi(id){}
          }   
        },(err)=>{
          console.warn(err);console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      } else {
       // console.log('Received values of form: ', values.builtdate._d);
      }
    });
  },
  normFile(e) {
    // if (Array.isArray(e)) {
    //   return e;
    // }
    // return e && e.fileList;
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 },
    };
    
 //此处为楼，type=51  得到类型值 disabled
   let buildingType=this.state.buildingType;

   let buildingTypeLists=[];
    
    for (let value of buildingType) {
      if (value && value.id) {
      buildingTypeLists.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
     let  fireDanger=this.state.fireDanger;

    let  fireDangerLists=[];
    
    for (let i=1;i<fireDanger.length+1;i++) {
      
       fireDangerLists.push(<Option key={`${i}`}>{fireDanger[i]}</Option>)
      
    }
   // console.log( buildingTypeLists);
    return (
        <div className="NewArea EditOrg" style={{ background: '#fff', }}>
           <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',paddingTop:'1.125rem',color:'#333',borderBottom:'1px solid #ddd',fontSize:'0.75em',fontFamily:'苹方中等',}}>
              <div style={{float:'left',width:135,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
                 <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>
                   <Link to={`/org/bding/manage`} style={{color:'#373e41'}} >建筑信息</Link>
                   <span style={{padding:'0 4px'}}>/</span><Link to={`/org/floor/${this.state.buildId}`}  style={{color:'#373e41'}} >楼层信息</Link>
                   </span>
              </div>
              <div  style={{float:'left',width:80,height:32,marginRight:4}}>
                <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} ><Link to="">新增楼层</Link></Button>
              </div>
            </div>
          <Form onSubmit={this.handleSubmit} style={{ fontSize: '12px', marginTop: -4, paddingTop: 20,overflow: 'auto' }}>
            <div style={{textAlign:'left',marginBottom:'24px'}}>
              <p  style={{color:'#373d41',fontsize: '0.75rem',fontFamily:'苹方中等',padding:'8px 0 28px 10px',}}>楼层信息</p>
            </div> 
            <div style={{fontsize:'0.75rem',color: '#373e41'}}> 
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{float:'left',marginRight:50,height:32,lineHeight:'32px'}}>
                    <img src={build} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>楼层名：</span>
                  </div>
                  <FormItem
                    style={{float:'left'}}
                    hasFeedback
                  >
                    {getFieldDecorator('name', {
                      initialValue:'',
                      rules: [{  required: true, message: '请输入内容!' }],
                    })(
                      <Input placeholder="请输入内容!" />
                    )}
                  </FormItem>
              </div>
                <div className="Row-info-right clearfix" >
                <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                  <img src={safety} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span>火灾危险性：</span>
                </div>
                <FormItem
                 style={{float:'left'}}
                 hasFeedback
                >
                    {getFieldDecorator('fireDanger', {
                      initialValue:'',
                      rules: [{  required: true, message: '请输入内容!' }],
                    })(
                      <Select placeholder="请选择" style={{width:'162px'}}  >
                        {fireDangerLists}
                     </Select>
                    )}
                </FormItem>
               </div>
             </div>
           
          <div className="Row-info">
            <div className="Row-info-left clearfix">
              <div style={{float:'left',marginRight:36,height:32,lineHeight:'32px'}}>
                <img src={nature} style={{padding:'0 15px 0 12px'}} alt=""/>
                <span>使用性质：</span>
              </div>
              <FormItem
                style={{float:'left'}}
                hasFeedback
              >
                   {getFieldDecorator('Fuse', {
                      initialValue:'',
                      rules: [{ required: true, message: '请输入内容!' }],
                    })(
                      <Input placeholder="请输入内容!" />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix" >
                  <div style={{float:'left',marginRight:24,height:32,lineHeight:'32px'}}>
                    <img src={subType} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>结构类型：</span>
                 </div>
                 <FormItem
                     style={{float:'left'}}
                     hasFeedback
                  >
                    {getFieldDecorator('subtype', {
                      initialValue:'',
                      rules: [{required: true, message: '请输入内容!' }],
                    })(
                     <Select placeholder="请选择" style={{ width: 162 }}>
                      {buildingTypeLists}
                     </Select>
                    )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix">
                  <div style={{float:'left',marginRight:36,height:32,lineHeight:'32px'}}>
                    <img src={fireLevel} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>耐火等级：</span>
                  </div>
                  <FormItem
                    style={{float:'left'}}
                    hasFeedback
                  >
                    {getFieldDecorator('FireLevel', {
                      initialValue:'',
                      rules: [{required: true, message: '请输入内容!' }],
                    })(
                      <Input style={{ width: 162 }} placeholder="请输入" />
                    )}
                  </FormItem>
                </div> 
                <div className="Row-info-right clearfix" >
    
                </div>            
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix" >
                <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                  <img src={fireEleNum} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span>消防电梯数量：</span>
                </div>
                <FormItem
                  style={{float:'left'}}
                  hasFeedback
                >
                    {getFieldDecorator('elevator', {
                      initialValue:'',
                      rules: [{ required: true, message: '请输入内容!' }],
                    })(
                      <Input type='middle' placeholder='请输入消防电梯数量'  style={{width:309}} />
                    )}
                 </FormItem>
             </div>
             <div className="Row-info-right clearfix" >
               <div style={{float:'left',marginRight:14,height:32,lineHeight:'32px'}}>
                 <img src={Area} style={{padding:'0 15px 0 12px'}} alt=""/>
                 <span>占地面积（平方米）：</span>
               </div>
               <FormItem
                 style={{float:'left'}}
                 hasFeedback
               >
                  {getFieldDecorator('face', {
                    initialValue:'',
                    rules: [{ required: true, message: '请输入内容!' }],
                  })(
                    <Input type='middle' placeholder='请输入占地面积'  style={{width:309}}  />
                  )}
                  </FormItem>
                </div>
              </div>
              <div  className="Row-info">
                <div className="Row-info-left clearfix">
                <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                  <img src={totalElevator} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span>电梯容纳总量：</span>
                </div>
                <FormItem
                  style={{float:'left'}}
                  hasFeedback
                >
                    {getFieldDecorator('elevatornum', {
                      initialValue:'',
                      rules: [{ required: true, message: '请输入内容!' }],
                    })(
                      <Input  placeholder='请输入占地面积'  style={{width:309}}  />
                    )}
                  </FormItem>
                </div>
                <div className="Row-info-right clearfix">
                 <div style={{float:'left',marginRight:24,height:32,lineHeight:'32px'}}>
                   <img src={workPersonDay} style={{padding:'0 15px 0 12px'}} alt=""/>
                   <span>日常工作时间人数：</span>
                 </div>
                 <FormItem
                   style={{float:'left'}}
                   hasFeedback
                  >
                    {getFieldDecorator('everyday', {
                      initialValue:'',
                      rules: [{ required: true, message: '请输入内容!' }],
                    })(
                      <Input placeholder='请输入日常工作时间人数'  style={{width:309}}  />
                    )}
                  </FormItem>
                </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left clearfix" >
                  <div style={{float:'left',marginRight:12,height:32,lineHeight:'32px'}}>
                    <img src={maxTotleNum} style={{padding:'0 15px 0 12px'}} alt=""/>
                    <span>最大容纳人数：</span>
                  </div>
                  <FormItem
                      style={{float:'left'}}
                      hasFeedback
                  >
                    {getFieldDecorator('galleryful', {
                      initialValue:'',
                      rules: [{ required: true, message: '请输入内容!' }],
                    })(
                      <Input  placeholder='请输入最大容纳人数'  style={{width:309}}  />
                    )}
                  </FormItem>
               </div>
             
              </div>  
              <div className="Row-info" style={{background:'#f8fbfb',padding:'4px 0',height:100,}}>
                <div style={{float:'left',marginRight:12,height:92,lineHeight:'92px',padding:'4px 0'}}>
                  <img src={build_remark} style={{padding:'0 15px 0 12px'}} alt=""/>
                  <span style={{marginRight:24}}>备注：</span>
                </div>
                <FormItem
                  style={{float:'left',height:92}}
                  hasFeedback
                > 
                  {getFieldDecorator('remark', {
                 
                   })(
                    <Input type="textarea" size="large" placeholder="备注" style={{ width: 600, height: 92 }} />
                   )}
                </FormItem>
              </div>
              <div style={{ position: 'absolute', bottom:80, fontFamily:'苹方中等',fontsize:'0.75em'}} className="search-btn">
                <FormItem>
                  <Button type="primary" htmlType="submit" size="large" style={{borderColor: 'transparent'}} >保存</Button>
                  {/*<Button  style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑',marginLeft:'10px'}}><Link to={`/org/floor/${this.state.buildId}`}>返回</Link></Button>*/}
                  <div className="new-button" style={{display:`inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑',marginLeft:10, fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/org/floor/${this.state.buildId}`}>返回</Link></div>
                </FormItem>
             </div>
          </div>  
        </Form>
      </div>
    );
  },
}));

export default NewArea;