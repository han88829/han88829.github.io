import React from 'react';
import { Card, Form,Select, Button, DatePicker, Row, Col, Tabs, Icon, Table } from 'antd';
import { Link } from 'react-router';
//import moment from 'moment';
import $ from 'jquery';
//const FormItem = Form.Item;
//const Option = Select.Option;
//const { RangePicker } = DatePicker;
const { TabPane } = Tabs;

const Area = Form.create()(React.createClass({
   getInitialState() {
    return {
      data:'',
      builds: {
        Fname: '',
        Frisk: '',
        Fuse: '',
        Fstructure: '',
        Frefractory: '',
        Farea: '',
        Felevator: '',
        Earea: '',
        Ftotal: '',
        Fday: '',
        Fnote: ''
      }
    }
  },
  componentWillMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    console.log(str);
    window.rpc.area.getInfoById(str).then((x) => {
      console.log(x);
      let asc=x.mapUrl;
      $("#seeImgInfoArea").attr({"href":asc});
      let builds = { ...x, Fname: x.name, Frisk: x.fireDanger, key: x.id, Fuse: x.fireLevel, Fstructure: x.galleryful, Frefractory: x.layer, Farea: x.number, Felevator: x.ownerId, Earea: x.parentId, Ftotal: x.subtype, Fday: x.type, Fnote: x.number };
      this.setState({
        builds
      })
    },(err) =>{
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    window.rpc.area.getArrayByContainer({ type: 52, parentid: str }, 0, 0, console.log, console.error).then((result) => {
      console.log(result)
      let devices = [];
      result.forEach(function (x) {
        devices.push({ ...x, key: x.id, id: x.id, Floornum: x.name, Floorarea: x.number })
      })
      this.setState({
        'data': devices
      })
    },(err) =>{
        console.warn(err);
      })
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
  render() {
    // const { getFieldDecorator } = this.props.form;
    // const formItemLayout = {
    //   labelCol: { span: 6 },
    //   wrapperCol: { span: 14 },
    // };
    // const tailFormItemLayout = {
    //   wrapperCol: {
    //     span: 14,
    //     offset: 6,
    //   },
    // };

    //区域表格信息
    const data = this.state.data;
    console.log(data)
    //基础信息
    const Floorbasis = [{ key: 1, id: 1, Fname: '一楼', Frisk: '危险', Fuse: '民用', Fstructure: '未知', Frefractory: '高级', Farea: '300', Felevator: '10', Earea: '300', Etotal: '200', Ftotal: '500', Fday: '100', Fnote: '无' }];
    const FloorInformation = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '楼层', dataIndex: 'Floornum', key: 'Floornum' },
      { title: '所属建筑', dataIndex: 'Floortype', key: 'Floortype' },
      { title: '区域数', dataIndex: 'Floorarea', key: 'Floorarea' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to={`/org/areacontent/${record.key}`}>详情</Link>
            <span className="ant-divider" />
            <Link to={`/org/areacontent/${record.key}`}>修改</Link>
          </span>
        )
      },
    ];

    const pagination = {
      // total: this.props.equipTaskState.tableData.length,
      total: data.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (current) => {
        console.log('Current: ', current);
      },
    };
    return (
      <div>
        <Tabs>
          <TabPane tab={<span><Icon type="info-circle-o" />基础信息</span>} style={{ fontSize: "20px" }} key="1">
           <div style={{ marginTop: -4, paddingTop: 30, height: 550, overflow: 'auto' }}>
            <Card bodyStyle={{ fontSize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '0  0 5px', fontSize: '16px' }}>
                <Col span={8} >}<span>建筑物名称：{this.state.builds.name}</span> <a id="seeImgInfoArea" style={{display:'inline-block',height:30,width:30,marginLeft:10, borderRadius:'100%',background:'#fff',border:'1px solid #ccc'}}><Icon type="upload"  style={{marginLeft:7}}/></a></Col>
                <Col span={10}>建筑日期：{this.state.builds.Frisk} </Col>
              </Row>
              <Row style={{ padding: '5px 0', fontSize: '16px' }}>
                <Col span={8}>建筑物类别：{this.state.builds.Fuse} </Col>
                <Col span={10}>火灾危险性：{this.state.builds.Fstructure} </Col>
              </Row>
              <Row style={{ padding: '5px 0', fontSize: '16px' }}>
                <Col span={8}>使用性质：{this.state.builds.Frefractory} </Col>
                <Col span={10}>结构类型：{this.state.builds.Farea} </Col>
              </Row>
              <Row style={{ padding: '5px 0', fontSize: '16px' }}>
                <Col span={8}>耐火等级：{this.state.builds.Frefractory} </Col>
              </Row>
            </Card>
            <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

            <Card bodyStyle={{ fontsize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '0  0 5px', fontSize: '16px', }}>
                <Col span={8}>建筑物高度： {this.state.builds.Felevator}</Col>
                <Col span={10}>占地面积（平方米）：{this.state.builds.Earea} </Col>
              </Row>
              <Row style={{ padding: '5px 0', fontSize: '16px' }}>
                <Col span={8}>建筑物面积（平方米）：{this.state.builds.Etotal} </Col>
                <Col span={8}>标准层面积（平方米）：{this.state.builds.Etotal} </Col>
              </Row>
            </Card>
            <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

            <Card bodyStyle={{ fontSize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '0  0 5px', fontSize: '16px', }}>
                <Col span={8}>地上层数：{this.state.builds.Ftotal}</Col>
                <Col span={10}>地上面积（平方米）： {this.state.builds.Fday}</Col>
              </Row>
              <Row style={{ padding: '0  0 5px', fontSize: '16px', }}>
                <Col span={8}>地下层数：{this.state.builds.Ftotal}</Col>
                <Col span={10}>地下面积（平方米）： {this.state.builds.Fday}</Col>
              </Row>
              <Row style={{ padding: '0  0 5px', fontSize: '16px', }}>
                <Col span={8}>避难层数量：{Floorbasis[0].Ftotal}</Col>
                <Col span={10}>避难层总面积（平方米）：{Floorbasis[0].Fday}</Col>
              </Row>
            </Card>
            <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />

            <Card bodyStyle={{ fontSize: 16, color: '#666666' }} bordered={false}>
              <Row style={{ padding: '5px 0', fontSize: '16px' }}>
                <Col span={8}>消防电梯数量：{this.state.builds.Fnote} </Col>
                <Col span={8}>电梯容量：{this.state.builds.Fnote} </Col>
              </Row>
              <Row style={{ padding: '5px 0', fontSize: '16px' }}>
                <Col span={8}>最大容纳人数：{this.state.builds.Fnote} </Col>
                <Col span={8}>日常工作时间人数：{this.state.builds.Fnote} </Col>
              </Row>
            </Card>
            <hr style={{ border: 'none', height: '1px', color: '#EEE', background: '#DDD' }} />
            <Card bodyStyle={{ fontSize: 16, color: '#666666' }} bordered={false}>
              <Col span={12}>备注：{this.state.builds.Fnote} </Col>
            </Card>
           </div>
           <div> 
             <Row>
              {/*<Button type="success" style={{ marginLeft: '80%' }}><Link to={`org/floor/:id`}>返回</Link></Button>*/}
              <div className="new-button"style={{display:`inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑',marginLeft:10, fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to="org/floor/:id">返回</Link></div>
             </Row>
           </div>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />区域</span>} key="2">
            <Button type="primary">新增区域</Button>
            <Row style={{ padding: '5px 0 0' }}>
              <Col span={24}>
                <Table
                  className="table-equipTask"
                  columns={FloorInformation}
                  dataSource={data}
                  pagination={pagination}
                  bordered
                />
              </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />平面图</span>} key="3">
          </TabPane>
        </Tabs>
      </div>
    );
  },
}));

export default Area;