import React, { Component } from 'react';
import { Link} from 'react-router';
import { Layout, Menu, Breadcrumb } from 'antd';
import './equipment.css';
// import { $ } from 'jquery'

import task_pic from '../../assets/images/logined/equipment-button.png';
import task_center_pic from '../../assets/images/logined/task-center.png';
import task_statistics_pic from '../../assets/images/logined/task-statistics.png';

import equipment_inspection_pic from '../../assets/images/logined/equipment-inspection.png';
import map_pic from '../../assets/images/logined/map.png';
import equipwarning_pic from '../../assets/images/logined/equipwarning-but.png';
import device_pic from '../../assets/images/logined/device-button.png';
import equipment_manage_pic from '../../assets/images/logined/equipment-manage.png';
import device_bread_pic from '../../assets/images/logined/device-bread.png';

import set_pic from '../../assets/images/equipment/set-icon.png';
import type_pic from '../../assets/images/equipment/type-icon.png';
 import right_pic from '../../assets/images/equipment/to-right-button.png';

const { SubMenu } = Menu;
const { Content, Sider } = Layout;

class Equipment extends Component {
  constructor(){
    super();
    this.state={
      breadRight:'设备管理',
      breadTitle:'设备设施管理',
      breadLink:'/equipment/equipmanage'
    }
    this.handClick=this.handClick.bind(this);
  }
  handClick(e){
    this.setState({
      breadRight:e.target.innerText,
      breadTitle:e.target.getAttribute('data-parent') ,
      breadLink: e.target.getAttribute('data-link') 
    })  
    sessionStorage.removeItem('equipment')
    sessionStorage.removeItem('flag')
    sessionStorage.removeItem('number')
  }
  componentWillReceiveProps(){
    console.log(this.props.routes.length>4?this.props.routes[4].breadcrumbName:'');
  //  console.log(this.props.children.props.routes[2].breadcrumbName);
  }
  componentWillMount() {
  // console.log(this.props);
  //  const name = this.props.params;
   // console.log(this.props.children.props.routes.length);
     
   // 查类型
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let dtypes = [{name: '/'}];
      for(let value of result){
        dtypes[value.id] = value;
      }
      sessionStorage.setItem('dtypes',JSON.stringify(dtypes));
    }, (err) => {
      console.warn(err);
    })

   // 查区域
    window.rpc.area.getArray(0, 0).then((result) => {
      console.log(result)
      let locations = [{name: '/'}];
      for(let value of result){
        locations[value.id] = value;
      }
      sessionStorage.setItem('locations',JSON.stringify(locations));
    }, (err) => {
      console.warn(err);
    })

  //   查建筑
    window.rpc.area.getArray(0, 0).then((result) => {
      let fildes = [{name: '/'}];
      for(let value of result){
        fildes[value.id] = value;
      }
      sessionStorage.setItem('fildes',JSON.stringify(fildes));
    }, (err) => {
      console.warn(err);
    }) 

   // 获取户籍类型
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let Orgtypes = [{name: '/'}];
      for(let value of result){
        Orgtypes[value.id] = value;
      }
      sessionStorage.setItem('Orgtypes',JSON.stringify(Orgtypes));
    }, (err) => {
      console.warn(err);
    })

   // 获取安全等级
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let safetys = [{name: '/'}];
      for(let value of result){
        safetys[value.id] = value;
      }
      sessionStorage.setItem('safetys',JSON.stringify(safetys));
    }, (err) => {
      console.warn(err);
    })

    //获取监管等级
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let Supervisions = [{name: '/'}];
      for(let value of result){
        Supervisions[value.id] = value;
      }
      sessionStorage.setItem('Supervisions',JSON.stringify(Supervisions));
    }, (err) => {
      console.warn(err);
    })

   // 获取户籍状态
    window.rpc.device.types.getArray(0, 0).then((result) => {
      let OrgStates = [{name: '/'}];
      for(let value of result){
        OrgStates[value.id] = value;
      }
      sessionStorage.setItem('OrgStates',JSON.stringify(OrgStates));
    },(err) => {
      console.warn(err);
    })
   // 查厂家
    window.rpc.product.getArray(0,0).then((result) => {
      let products = [{name: '/'}];
      for(let value of result){
        products[value.id] = value;
      }
      sessionStorage.setItem('products',JSON.stringify(products));
    }, (err) => {
      console.warn(err);
    })
  }
  
  render() {
    // function itemRender(route, params, routes, paths) {
    //   const last = routes.indexOf(route) === routes.length - 1;
    //   return last ? <span>{route.breadcrumbName}</span> : <Link to={paths.join('/')}>{route.breadcrumbName}</Link>;
    // }
    // let lastName='';
    // if(this.props.children.props.routes[4].breadcrumbName){
    //    lastName=this.props.children.props.routes[4].breadcrumbName||''
    // }else{
    //   lastName=''
    // }
    //const    lastName=this.props.children.props.routes[4].breadcrumbName||'';
    return (
      <Layout className="Equipment" style={{ background: '#333744',overflow:'hidden'}}>
        <Sider
          width={200}
          style={{ background: '#333744' ,height: '100%'}}>

          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['sub1']}
            style={{ height: '100%' , backgroundColor:'#333744'}}
          >
            <SubMenu 
              key="sub1" 
              className="sub-menu-1"
              title={<span style={{background:'#333744',fontFamily: '苹方特细',fontWeight: 400, height: 50,fontstyle: 'normal',fontSize:'14px',color:' #FFFFFF',textAlign:'left'}} ><img src={task_pic} alt="" style={{padding:'0 20px 0 30px',verticalAlign:'middle'}} />设施设备管理</span>}
              >
              <Menu.Item key="1"><Link to="/equipment/equipmanage" onClick={this.handClick} data-link="/equipment/equipmanage" data-parent="设备设施管理"><img src={equipment_manage_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>设备管理</span></Link></Menu.Item>
              <Menu.Item key="2"><Link to="/equipment/equipstatistics" onClick={this.handClick} data-link="/equipment/equipstatistics" data-parent="设备设施管理"><img src={device_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>设备统计</span></Link></Menu.Item>
              <Menu.Item key="3"><Link to="/equipment/equipwarning" onClick={this.handClick} data-link="/equipment/equipwarning" data-parent="设备设施管理"><img src={equipwarning_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>设备预警</span></Link></Menu.Item>            
              <Menu.Item key="5"><Link to="/equipment/equipmapmonitore" onClick={this.handClick} data-link="/equipment/equipmapmonitore" data-parent="设备设施管理"><img src={map_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>地图监控</span></Link></Menu.Item>
            </SubMenu>
            <SubMenu 
              key="sub2" 
              className="sub-menu-2"
              title={<span style={{background:'#333744',fontFamily: '苹方特细',fontWeight: 400, height: 50,fontstyle: 'normal',fontSize:'14px',color:' #FFFFFF',textAlign:'left'}} ><img src={equipment_inspection_pic} alt="" style={{padding:'0 20px 0 24px',verticalAlign:'middle'}} />设施设备巡查</span> }
              >
              {/*
              <Menu.Item key="6"><img src={task_set_pic} alt="" style={{padding:'0 10px 0 0'}}/>任务设置</Menu.Item>
              <Menu.Item key="7"><img src={task_release_pic} alt="" style={{padding:'0 10px 0 0'}}/>发布任务</Menu.Item>
            */}
              <Menu.Item key="7"><Link to="/equipment/equiptasksetting" onClick={this.handClick} data-link="/equipment/equiptasksetting" data-parent="设施设备巡查"><img src={task_center_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>任务设置</span></Link></Menu.Item>
              <Menu.Item key="8"><Link to="/equipment/equiptask" onClick={this.handClick} data-link="/equipment/equiptask" data-parent="设施设备巡查"><img src={task_center_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>任务中心</span></Link></Menu.Item>
              <Menu.Item key="9"><Link to="/equipment/equiptaskstatistics" onClick={this.handClick} data-link="/equipment/equiptaskstatistics" data-parent="设施设备巡查"><img src={task_statistics_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>任务统计</span></Link></Menu.Item>
            </SubMenu>
            <SubMenu 
              key="sub3" 
              className="sub-menu-3"
              title={<span style={{background:'#333744',fontFamily: '苹方特细',fontWeight: 400, height: 50,fontstyle: 'normal',fontSize:'14px',color:' #FFFFFF',textAlign:'left'}} ><img src={set_pic} alt="" style={{padding:'0 20px 0 30px',verticalAlign:'middle'}}/>设置</span>}
             >
              <Menu.Item key="10"><Link to="/equipment/equiptypemanage" onClick={this.handClick} data-link="/equipment/equiptypemanage" data-parent="设置"><img src={type_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>类型管理</span></Link></Menu.Item>
              <Menu.Item key="11"><Link to="/equipment/equipbrandmanage" onClick={this.handClick} data-link="/equipment/equipbrandmanage" data-parent="设置"><img src={device_pic} alt="" style={{padding:'0 10px 0 10px'}}/><span style={{fontFamily: '苹方特细',fontSize:'12px'}}>品牌管理</span></Link></Menu.Item>
              {/*
              <Menu.Item key="6"><img src={task_set_pic} alt="" style={{padding:'0 10px 0 0'}}/>任务设置</Menu.Item>
              <Menu.Item key="7"><img src={task_release_pic} alt="" style={{padding:'0 10px 0 0'}}/>发布任务</Menu.Item>
            */}
            </SubMenu>
          </Menu>
        </Sider>
       <Layout style={{ paddingRight:'20px',background:"#fff"}}>
          <Content style={{ padding:'0 20px 0 15px',background:"#fafafa"}}>
           <Content style={{padding:'0'}}>
            <Breadcrumb separator="" style={{margin: '12px 0' ,width: '500px', height:'30px',fontFamily: '苹方中等', fontWeight: 'normal',color:'#666',fontSize: '16px',lineHeight:'30px'}}>
              <Breadcrumb.Item  style={{  fontWeight: '500'}}><Link to={this.state.breadLink}><img src={device_bread_pic} alt=""style={{padding:'0 10px 0 0',verticalAlign:'middle'}}/>{this.state.breadTitle}</Link></Breadcrumb.Item>
              <Breadcrumb.Item  style={{  fontWeight: '500'}}><Link to={this.state.breadLink}><span ><img src={right_pic} alt=""style={{padding:'0 3px 0 3px',verticalAlign:'middle'}}/></span>{this.state.breadRight}</Link></Breadcrumb.Item>
              {/* <Breadcrumb.Item>App</Breadcrumb.Item> */}
              {/*<Breadcrumb.Item  style={{  fontWeight: '500'}}><Link to={this.props.children.props.routes[3].path}>{this.state.breadRight!==this.props.children.props.routes[3].breadcrumbName?<img src={right_pic} alt=""style={{padding:'0 3px 0 3px',verticalAlign:'middle'}}/>:'' }{this.props.children.props.routes[3].breadcrumbName!== this.state.breadRight?this.props.children.props.routes[3].breadcrumbName:''}</Link></Breadcrumb.Item>*/}
           </Breadcrumb>
            <div style={{ padding: 0, background: '#fff', minHeight: 400 ,height:'100%'}}>
              {this.props.children}
            </div>
          </Content>
          </Content>
        </Layout>
      </Layout>
    );
  }
}

export default Equipment;