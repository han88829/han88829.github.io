/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:54:38 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-08-01 14:58:13
 */

import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Card, Table, Form, message } from 'antd';
import echarts from 'echarts';
const FormItem = Form.Item;

const { RangePicker } = DatePicker;

const columns = [{
	title: '巡检情况',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '数量',
	dataIndex: 'value',
	key: 'value',
}];

class deviceState {
	constructor() {
    extendObservable(this, {
			patrolData: [{key: 1, value: 20, name: '抽检总数' }, {key: 2, value: 14, name: '抽检合格数' }, {key: 3, value: 2, name: '现场整改数' }, {key: 4, value: 3, name: '限期整改数', selected: true }, {key: 5, value: 1, name: '过期抽检数'}],
			addPatrol: action(function() {
				this.patrolData = [{key: 1, value: 30, name: '巡检总数' }, {key: 2, value: 14, name: '巡检合格数' }, {key: 3, value: 6, name: '现场整改数' }, {key: 4, value: 5, name: '限期整改数', selected: true }, {key: 5, value: 5, name: '过期巡检数'}];

				let myChart = echarts.init(document.getElementById('TaskRandomEcharts'));

				myChart.setOption({
					title: { text: '抽检情况' },
					tooltip: {},
					color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
					series: [{
						name: '销量',
						type: 'pie',
						radius: '80%',
						data: [...this.patrolData].filter(x => x.key !== 1),
						itemStyle: {
							emphasis: {
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: 'rgba(0, 0, 0, 0.5)'
							},
							normal: {
								label: {
									show: true,
									formatter: '{b} \n\n {c}个 \n\n({d}%)'
								}
							},
							labelLine: { show: true }
						},
					}]
				});
			})
		})
  }
}

const PatrolSearchForm = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        const values = {
          ...fieldsValue,
          'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
        }
        console.log('Received values of form: ', values);
      });
      message.info('已更新');
    }catch(e) {
      console.log(e)
    }
    this.props.deviceState.addPatrol();
  },
  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
					{/*
					<Col span={6} key={2}>
						<FormItem>
							{getFieldDecorator('radio-group')(
								<Radio.Group>
									<Radio.Button value="week">周</Radio.Button>
									<Radio.Button value="month">月</Radio.Button>
									<Radio.Button value="seacon">季</Radio.Button>
								</Radio.Group>
							)}
						</FormItem>
					</Col>
					*/}
          <Col span={6} key={5}>
            <FormItem label={`时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker size="small" style={{width:200}} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
								size="small"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}));

// @observer
const TaskInspectC = observer(class TaskInspectC extends Component {
	constructor() {
		super();

		this.state = {
			size: 'default'
		};
	}

	componentDidMount() {
		console.info(this.props.deviceState.patrolData);

		let myChart = echarts.init(document.getElementById('TaskInspectEcharts'));

		myChart.setOption({
			title: { text: '巡检情况' },
			tooltip: {},
			color: ['#2db7f5','#7dc856','#808bc6','#5d6775'],
			series: [{
				name: '销量',
				type: 'pie',
				radius: '80%',
				data: [...this.props.deviceState.patrolData].filter(x => x.key !== 1),
				itemStyle: {
					emphasis: {
						shadowBlur: 10,
						shadowOffsetX: 0,
						shadowColor: 'rgba(0, 0, 0, 0.5)'
					},
					normal: {
						label: {
							show: true,
							formatter: '{b} \n\n {c}个 \n\n({d}%)'
						}
					},
					labelLine: { show: true }
				},
			}]
		});
	}

	render() {
		return ( 
			<div className="TaskInspect" style={{ padding: '5px' }}>
				<PatrolSearchForm deviceState={this.props.deviceState} />
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<Col span={8}>
						<Card>
							<Table showHeader={false} dataSource={[...this.props.deviceState.patrolData]} columns={columns} pagination={ false } />
						</Card>
					</Col> 
					<Col span={16}>
						<Card>
							<div id="TaskInspectEcharts" style={{ height: '50vh', width: '100%' }}></div> 
						</Card> 
					</Col>
				</Row>
			</div>
		);
	}
})

class TaskInspect extends Component {
    render() {
        return (
            <TaskInspectC deviceState={new deviceState()} />
        )
    }
}

export default TaskInspect;