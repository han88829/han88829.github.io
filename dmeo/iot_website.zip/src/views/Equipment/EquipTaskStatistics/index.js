/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:54:59 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:54:59 
 */

import React, { Component } from 'react';
import { Tabs, Icon } from 'antd';
import TaskInspect from './containers/TaskInspect';
import TaskRandom from './containers/TaskRandom';
import TaskResult from './containers/TaskResult';
//import './equipTaskStatistics.css';

const { TabPane } = Tabs;

class EquipTaskStatistics extends Component {
  render() {
    return (
      <div className="EquipTaskStatistics" style={{ padding: 24 }}>
        <Tabs defaultActiveKey="1">
          <TabPane tab={<span><Icon type="info-circle-o" />巡检统计</span>} key="1">
            <TaskInspect />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />抽检统计</span>} key="2">
            <TaskRandom />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />结果统计</span>} key="3">
            <TaskResult />
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

export default EquipTaskStatistics;