import React, { Component} from 'react';


class EquipBrandDetail extends Component {
  render() {
    return (
      <div>
        品牌详情
      </div>
    )
  }
}

export default EquipBrandDetail;