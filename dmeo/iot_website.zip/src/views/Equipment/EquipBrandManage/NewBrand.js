/*
 * @Author: Han.beibei 
 * @Date: 2017-06-10 14:54:23 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:17:59
 */

import React from 'react';
import { Input, Button, Form, message } from 'antd';
import { Link } from 'react-router';

const FormItem = Form.Item;


const NewBrand = Form.create()(React.createClass({
  getInitialState() {
    return {
      value: undefined,
      types: []
    };
  },
  componentWillMount() {

  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let obj = { ...values }
        window.rpc.brand.create(obj).then((res) => {
          message.info('创建成功！');
          window.location.href = "/equip/brand/manage";
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }
    });
  },
  onChange(value) {
    this.setState({ value });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <div style={{ position: 'relative' }}>
        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/brand/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>品牌信息</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="/equip/brand/new">新增品牌</Link></Button>
          </div>
        </div>
        <Form onSubmit={this.handleSubmit} className="NewTypes" style={{ padding: 24, height: '100%' }}>
          <FormItem>
            <span style={{ paddingRight: 10 }}>品牌名称：</span>
            {getFieldDecorator('name', {
              rules: [{ required: true, message: '请输入品牌名称!' }],
            })(
              <Input style={{ height: 30, width: '70%' }} />
              )}
          </FormItem>
          <FormItem>
            <span style={{ paddingRight: 10, display: ' inlineBlock', height: '68px', lineHeight: '68px' }}> 品牌备注：</span>
            {getFieldDecorator('remark', {
            })(
              <Input type="textarea" autosize={{ minRows: 3, maxRows: 6 }} style={{ width: '70%' }} />
              )}
          </FormItem>
          <div style={{ position: 'absolute', marginTop: 500, left: 0, zIndex: '99' }} className="search-btn">
            <FormItem >
              <Button htmlType="submit"> 保存</Button>
              <span className="new-button" style={{ display: 'inline-block', marginLeft: '10px', backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px', width: 60, height: 32, borderRadius: 0 }}><Link to="/equip/brand/manage">返回</Link></span>
            </FormItem>
          </div>
        </Form>
      </div>
    );
  },
}));

export default NewBrand;