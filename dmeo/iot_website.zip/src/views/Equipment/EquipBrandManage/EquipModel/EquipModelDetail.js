/*
 * @Author: szj 
 * @Date: 2017-03-27 16:52:12 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:13:20
 */


import React from 'react';
import {Input, Row, Col, Button,Form,Select} from 'antd';
import { Link } from 'react-router';

const FormItem = Form.Item;
//const Option = Select.Option;


const EquipModelDetail = Form.create()(React.createClass({
   getInitialState() {
    return {
      value: undefined,
      types: null,
      data:[],
      secret:[],
      flags:[],
      brandId:null,
      productId:null
    };
  },
  componentWillMount(){
     const id=this.props.params.id;
      window.rpc.product.getInfoById(id).then((res) => {
         const types=({...res});
         //    console.log(types.type);
         this.setState({ types});
         this.setState({ brandId:res.brandId});
         window.rpc.device.types.getInfoExById(types.type).then((result) => {
           //  console.log(result.flags);
            console.log(result);
           //console.log(res);
           window.rpc.brand.getInfoById(this.state.brandId).then((bResult) => {
             console.log(bResult.name);
             //  this.props.form.setFieldsValue({
             //    make:bResult.name,
             //    name: result.type,
             //    number:result.number,
             //  })
              this.props.form.setFieldsValue({
                 make:bResult.name,
                 name: result.name,
                 number:this.state.types.number,
         
               });
             //   this.setState({brandId:brandId});
              console.log(this.state.brandId);
             }, (err) => {
               console.log(err);
             }) 
        
       },(err) =>{
        console.warn(err);
      })


     
     },(err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
     })
     var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str = str.substring(index + 1, str.length);
      this.setState({productId:str});    
     window.rpc.product.getInfoExById(str).then((res) => {
     //  console.log(res);
     //  console.log(res.flags);
       if(res.flags.length!==0){
        let flags=[...res.flags];
      //  console.log(flags);
        this.setState({secret:flags});
       // console.log(this.state.secret);
      }else{
         this.setState({secret:[]});
      }
     },(err) =>{
        console.warn(err);
      })
  },
  render() {
  const { getFieldDecorator } = this.props.form;

    let secret=this.state.secret;
     var linksLists =null;
     if(secret.length!==0) {
          linksLists = secret.map(function(inps){
          if(inps.single){
            return(<div key={`${inps.id}`} id={inps.id}><Row><Col span={2}><span>{inps.name}:</span></Col><Col span={12}><FormItem><Input disabled value={inps.leftValue}  style={{width:80}} id={`inpsinps${inps.id}`} /><span  style={{marginLeft:5}}>{inps.unit}</span></FormItem></Col></Row></div>);
          }else{
             return(<div key={`${inps.id}`}><Row type="flex" justify="start"><Col span={2}><span>{secret[0].name}：</span></Col><Col span={18} style={{width:500}}><Row type="flex" justify="start"><Col span={13}  style={{width:150}}><FormItem><Input disabled value={inps.leftValue} id={`leftValue${inps.id}`}style={{width:80}} /><span  style={{marginLeft:5}}>{secret[0].unit}</span><span style={{marginLeft:8}}>至</span></FormItem></Col><Col span={11}  style={{width:150}}> <FormItem><Input disabled value={inps.rightValue} id={`rightValue${inps.id}`} style={{width:80}} /><span style={{marginLeft:5}}>{secret[0].unit}</span></FormItem></Col></Row></Col></Row></div>);
          }
        });
        // console.log(linksLists.length);
       }else{
          linksLists =null;
       }

  return (
    <div  style={{position:'relative'}}>
      <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',fontSize:'0.75rem',fontFamily:'苹方中等',borderBottom:'#ddd 1px solid'}}>
          <div style={{float:'left',width:135,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
            <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}><Link to={`/equip/brand/manage`} style={{color:'#373e41'}} >品牌信息</Link><span style={{padding:'0 2px'}}>/</span><Link to={`/equip/model/${this.state.brandId}`}  style={{color:'#373e41'}} >型号信息</Link></span>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} onClick={this.handleStaffNew} ><Link to="">修改型号</Link></Button>
          </div>
      </div>
      <div style={{width:'30%',marginLeft:'30%'}}>  
        <Form onSubmit={this.handleSubmit} className="NewTypes"  style={{fontSize:'14px'}}>    
    
        <Row type="flex" justify="start" style={{marginBottom:18,marginTop:30}}>
          <Col span={3} style={{width:110}}><span type="所有品牌" disabled="false">所属品牌：</span></Col>
          <Col span={6}>
            <FormItem>
            {getFieldDecorator('make', {
              rules: [{ required: true, message: '请输入品牌名称!' }],
            })(
             <Input  placeholder="" style={{width:300}} disabled  />
            )}
             </FormItem>
         </Col>
       </Row>
       <Row type="flex" justify="start"  style={{marginBottom:18}}>
         <Col span={3}  style={{width:110}}><span type="型号名称" disabled="false">型号名称：</span></Col>
         <Col span={6}>
          <FormItem>
           {getFieldDecorator('number', {
              rules: [{ required: true, message: '请输入型号名称!' }],
            })(
             <Input  placeholder="" style={{width:300}} disabled  />
            )}
           </FormItem>
        </Col>
      </Row>
      <Row type="flex" justify="start"  style={{marginBottom:18}}>
        <Col span={4}  style={{width:110}}><span type="所属设备类型" disabled>所属设备类型：</span></Col>
        <Col span={4}>
          <div>
            <FormItem>
            {getFieldDecorator('name', {
              rules: [{ required: true, message: '请输入设备类型!' }],
            })(
                <Select style={{ width: 110 }}  disabled>
                 
                </Select>
            )}
           </FormItem>
          </div>
        </Col>
      </Row> 
     
       <Row type="flex" justify="start"  style={{marginBottom:18}}>
        <Col span={4} style={{width:110}}><span type="私有属性" disabled="false">私有属性：</span></Col>
        <Col span={12}>   {linksLists} </Col> 
       </Row>
       <div style={{position:'absolute',marginTop:400,left:0,zIndex:'99'}} className="search-btn">
         <FormItem >  
             s 
           {/*<Button  style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑'}}><Link to={`/equip/model/${this.state.brandId}`}>返回</Link></Button>*/}
         </FormItem>  
        </div>
      </Form>   
      </div>
      </div>
    )
  }
}))

export default EquipModelDetail;