
/*
2017-3-8 by 宋珍君

修改单选与上方啊按钮形式，增加删除，与搜索框，编辑默认显示  2017-3-9 宋珍君
*/ 
import React, { Component} from 'react';
import { Link,browserHistory } from 'react-router';
import {extendObservable} from 'mobx';
import { observer } from 'mobx-react';
import { Table,Row, Col, Input, Button,message ,Form,Popconfirm} from 'antd';
//import moment from 'moment';
const FormItem = Form.Item;
import '../equipBrandManage.css';

var Num = '';
// class appState {
//   @observable tableData = [];
// }

class appState {
  constructor(){
    extendObservable(this,{
      tableData:[]
    })
  }
}
class ModelSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        names:[],
        numbers:[],
        makes:[]
      },
      value: undefined,
      types: [],
      mine: {},
      data:[]
    }
  }
  // componentWillMount() {
  //       // const id=this.props.params.id;
  //     var str = window.location.href;
  //     var index = str.lastIndexOf("\/");
  //      str = str.substring(index + 1, str.length);
  //     window.rpc.product.getArrayByContainer({brandId:str},0,10).then((res) => {
  //       console.log(res);
  //       let type = res.map(x => ({ name: x.name}));
  //       console.log(type);
  //       this.setState({names:type});
       
  //     })
  // }
  componentDidMount() {

  }
  handleSubmit = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, values) => {
    
    window.rpc.product.getArrayByContainer(values,0,10).then((res) => {
        console.log(res);
         //let types = res.map(x => ({ ...x, key: x.id,id:x.id, title: x.name,remark:x.remark }));
         // res.map(x => { key: x.id,id:x.id, title: x.name,remark:x.remark })
         // this.setState({ types });
         //   let types={...res,key: res.id,id:res.id,name:res.name,remark:res.remark};
         console.log(res);
         message.info(`共搜索到${res.length}条数据`);
         let types = res.map((x) => ({...x,id: x.id,key:x.id,name:x.name,number:x.number,make:x.make}));
         this.props.appState.tableData = types; 
         //返回对象，应以数组形式返回
         //let types=[{key: res.id,id:res.id,name:res.name,remark:res.remark}];
         console.log(types);
        //      this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
          
        })
      });

    } catch (e) {
      console.warn(e);
    }
  }

  render(){
    const { getFieldDecorator } = this.props.form;
 // for (let value of names) {
    //   if (value && value.id) {
    //     nameChildren.push(<Option key={`${value.name}`}>{value.name}</Option>)
    //   }
    // }
//   console.log(this.state.data);
  
    return (
      <Form layout="inline" onSubmit={this.handleSubmit} style={{ margin: 0 }}>
        <Row  style={{margin:'15px 0 15px',height:'32px',lineHight:'32px'}}>
           <Col span={12} key={1}>
            <FormItem label={`型号名称`}>
              {getFieldDecorator(`number`)(
                <Input style={{ width: 180, height: 32 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={12} className="search-btn" key={2}>
            <FormItem style={{float:'right'}}>
              <Button
                type="primary"
                htmlType="submit"
                style={{height:'32px',width:'80px',padding:0,margin:0,fontSize:'0.75rem'}}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}
const ModelNameAdvancedSearchForm = Form.create()(ModelSearchForm);
// @observer
// class EquipModelManageC extends Component {
const EquipModelManageC=observer(class appState extends React.Component {
 constructor() {
    super();
    this.state = {
      Selected: {
        Id: null
      },
      types:[],
      id:null,
    }
  }
  componentWillMount() {
       
      var str = window.location.href;
    
      var index = str.lastIndexOf("\/");
      // console.log(index);
       str = str.substring(index + 1, str.length);
       this.setState({id:str});
       window.rpc.product.getArrayByContainer({brandId:str},0,10).then((res) => { 
    
         let type = res.map(x => ({ ...x, key: x.id,id:x.id,name: x.name,remark:x.remark }));
         let types=type.reverse();
         this.setState({ types });
         this.props.appState.tableData = types;
         //console.log(types);
       }, (err) => {
         console.warn(err);
          function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
       })
 
     //var str = window.location.href;  
    // var index = str.lastIndexOf("\/");
    str = str.substring(index + 1, str.length);
    console.log(str);
    window.rpc.product.getCountByContainer({brandId:str}).then((num) =>{
        console.log(num);
         Num=num;
     },(err) =>{
        console.warn(err);
      })
  }

  componentDidMount() {

  }
 onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    const Selected={Id:parseInt(selectedRowKeys[0],10)};
    console.log(Selected);
    this.setState({ Selected });

    console.log(this.state.Selected.Id);

  }
  ///equipment/newmodel
    handleStaffNew = () => {
   //   let id=this.props.params.id;
    //  var str = window.location.href;  
    // var index = str.lastIndexOf("\/");
    //  str = str.substring(index + 1, str.length);
    //  console.log(str); this.state.id
    if (this.state.id != null) {
       browserHistory.push(`/equip/model/new/${this.state.id}`);
    } else {
      message.info('错误！');
    }
  }
   handleStaff = () => {
    if (this.state.Selected.Id != null) {
       browserHistory.push(`/equip/model/edit/${this.state.Selected.Id}`);
    } else {
      message.info('请选择型号！');
    }
  }
  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id  != null) {
     browserHistory.push(`/equip/model/detail/${this.state.Selected.Id}`);
    } else {
      message.info('请选择型号！');
    }
  }
  //是否删除
  remove=()=>{

   // console.log(111);
   //console.log(this.state.Selected.Id);
    if (this.state.Selected.Id  != null) {
     window.rpc.product.removeById(this.state.Selected.Id).then((res) => {
       if(res){
         message.info('删除成功！');
         window.rpc.product.getArrayByContainer({brandId:this.setState.id},0,10).then((res) => { 
    
           let type = res.map(x => ({ ...x, key: x.id,id:x.id,name: x.name,remark:x.remark }));
           let types=type.reverse();
           this.setState({ types });
           this.props.appState.tableData = types;
         //console.log(types);
         }, (err) => {
           console.warn(err);
         })
        //window.location.reload();
      }else{
         message.info('删除失败！');
      }
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    //刷新页面

     } else {
      message.info('请选择建筑！');
    }


  }
  onDelete = (index) => {
      // console.log(index);
      window.rpc.product.removeById(index).then((res) => {
      //console.log(res);
      if(res){
         message.info('删除成功！');
         window.rpc.product.getArrayByContainer({brandId:this.state.id},0,10).then((res) => { 
    
         let type = res.map(x => ({ ...x, key: x.id,id:x.id,name: x.name,remark:x.remark }));
         let types=type.reverse();
         this.setState({ types });
         this.props.appState.tableData = types;
         //console.log(types);
       }, (err) => {
         console.warn(err);
          function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
       })
        //window.location.reload();
      }else{
         message.info('删除失败！');
      }
     
    }, (err) => {
      console.warn(err);
    })

  }
  cancel() {
    message.error('已取消');
  }
  render (){
     console.log(this.state.types);
   const data = this.state.types;
//const data = [...this.props.appState.tableData];
   console.log( Num);
   const pagination = {
      total: Num,
      showTotal: total => `共 ${Num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
        console.log('Current: ', current, '; PageSize: ', pageSize);
      },
      onChange: (page,PageSize) => {
          console.log(page);
          let pagenum=(parseInt(page)-1)*10;
          //  console.log(pagenum);
          //console.log(page);
          //const Id=this.props.params;
           var str = window.location.href;  
           var index = str.lastIndexOf("\/");
           str = str.substring(index + 1, str.length);
           window.rpc.product.getArrayByContainer({brandId:str},pagenum,10).then((res) => {
             let types = res.map(x => ({...x, key: x.id,number:x.number,make:x.make,name: x.name,remark:x.remark }));
             this.setState({ types });
             this.props.appState.tableData = types;
           }, (err) => {
             console.warn(err);
           })
       },
      };
      //{`/equipment/modelmanage/${id}`}  {`/equipment/editbrand/${id}`}
       const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };

     const columns = [
    { title: '序号', dataIndex: 'id', key: 'id' },
    { title: '型号名称', dataIndex: 'number', key: 'number',render: (text, record) => (<Link to={`/equip/model/detail/${record.id}`} style={{color:'#0099cc'}}>{text}</Link>)},
    { title: '制造商', dataIndex: 'make', key: 'nake',render: (text, record) => ({text})},
    { title: '设备类型', dataIndex: 'name', key: 'name',render: (text, record) => ({text})},
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record,index) => (
        <div>
          <span>
          <Link to={`/equip/model/detail/${record.key}`} style={{color:'#999'}}>查看更多</Link>
           <span className="ant-divider" />
          <Link to={`/equip/model/edit/${record.key}`} style={{color:'#999'}}>编辑</Link>
           <span className="ant-divider" />
            <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(record.key)}>
              <a href="#" style={{color:'#0099cc'}}>删除</a>
            </Popconfirm>
          </span>
        </div>
      )
    },
  ];

 // const data = [];
    return (
      <div className="brandManage modelManage">
       <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125rem',color:'#333',fontSize:'0.75rem',fontFamily:'苹方中等',borderBottom:'#ddd 1px solid'}}>
          <div style={{float:'left',width:135,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
            <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}><Link to={`/equip/brand/manage`} style={{color:'#373e41'}} >品牌信息</Link><span style={{padding:'0 2px'}}>/</span><Link to=""  style={{color:'#373e41'}} >型号信息</Link></span>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            {/*<span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/equip/model/${this.state.brandId}`}>返回</Link></span>   */}
            <div className="new-button"  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} onClick={this.handleStaffNew} ><Link to="">新增型号</Link></div>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button type=""  style={{background:'#d8dfe4',padding:'0 15px',height:'32px',borderRadius:0}}    onClick={this.handleStaff}>编辑型号</Button>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button type=""  style={{background:'#d8dfe4',padding:'0 15px',height:'32px',borderRadius:0}}  onClick={this.handleStaffOne}>型号详情</Button>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Popconfirm title="确认删除?" onConfirm={this.remove}   onCancel={this.cancel} okText="确定" cancelText="取消">
              <Button type=""  style={{background:'#d8dfe4',padding:'0 15px',height:'32px',borderRadius:0}}><Link to="">删除型号</Link></Button>
            </Popconfirm> 
          </div>
        </div>
        <ModelNameAdvancedSearchForm   appState={this.props.appState} />
        <Row>
          <Col span={24}> 
            <Table
             columns={columns}
             rowSelection={rowSelection}
             bordered
             dataSource={data}
             pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    )
  }
})

class EquipModelManage extends Component {
  render() {
    return (
      <EquipModelManageC appState={new appState()} />
    )
  }
}


export default EquipModelManage;