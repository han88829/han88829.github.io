/*
 * @Author:szj
 * @Date: 2017-03-27 16:57:01 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:14:37
 */

import React from 'react';
import {Input, Row, Col, Button, message ,Form,TreeSelect} from 'antd';
import { Link } from 'react-router';
//import $ from 'jquery';

const FormItem = Form.Item;
//const Option = Select.Option;
const EquipModelNew = Form.create()(React.createClass({
   getInitialState() {
    return {
      value: undefined,
      types: [],
      mine: {},
      data:[],
      secret:[],
      flags:[],
      brandId:null

    };
  },

   componentWillMount(){
      //, key:layerNow[j].id, label: layerNow[j].name, value: `${layerNow[j].id}`
    //  function pushChildren(data){
		//  let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
    //   let layerNow = data.filter(x => x.layer === layer);
    //   let layerUp = data.filter(x => x.layer !== layer);
    //   for (var i = 0; i < layerNow.length; i++) {
    //     for (var j = 0; j < layerUp.length; j++) {
    //       if (layerNow[i].parentId === layerUp[j].id) {
    //         if (layerUp[j].children) {
    //           layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
    //         } else {
    //           layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
    //         }
    //       }
    //     }
    //   }
    //   if (layer === 2) {
    //     return layerUp;
    //   } else {
    //    pushChildren(layerUp)
    //   }
		// }
     //const id = parseInt(this.props.params.id, 10);
  window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
     // console.log(tableDate);
      tableDate.unshift({ key: 0, label: "无", value: 0 })
    //  let mine = res.filter(x => x.id === id)[0];
     // let date = pushChildren(tableDate)
      this.setState({ types, data: tableDate });

     var str = window.location.href;
     var index = str.lastIndexOf("\/");
     str = str.substring(index + 1, str.length);
     console.log(str);
     window.rpc.brand.getInfoById(str).then((result) => {
       console.log(result);
       let brandId=result.id;
       this.setState({brandId:brandId});
       window.rpc.brand.getInfoById(brandId).then((bResult) => {
         console.log(bResult.name);
         this.props.form.setFieldsValue({
         make:bResult.name,
         })
     //   this.setState({brandId:brandId});
       console.log(this.state.brandId);
       }, (err) => {
          console.log(err);
       }) 
    }, (err) => {

    })


    }, (err) => {

    })

   
  },
  componentDidMount(){
 
  },
   handleSubmit(e) {
   console.log(this.state.secret);
    let secret=this.state.secret;
    //map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
    let sec=secret.map(x =>(x.id));
    let Single=secret.map(x=>(x.single));
    let Name=secret.map(x=>(x.name));
    let Unit=secret.map(x=>(x.unit));
  //  console.log(sec);//[2, 3]
  //  console.log(Single);
    let flags=[];
    for(let i=0;i<sec.length;i++){
      if(Single[i]){
         //console.log(document.getElementById(`leftValue${sec[i]}`).value);//2
        let lValue=document.getElementById(`leftValue${sec[i]}`).value;
         let obj={leftValue:lValue,id:sec[i],name:Name[i],single:Single[i],unit:Unit[i]} ;
         flags.push(obj);
      }else{
       //  console.log(document.getElementById(`leftValue${sec[i]}`).value);//2
       //  console.log(document.getElementById(`rightValue${sec[i]}`).value)
           let lValue=document.getElementById(`leftValue${sec[i]}`).value;
             let rValue=document.getElementById(`rightValue${sec[i]}`).value;
             let obj={leftValue:lValue,rightValue:rValue,id:sec[i],name:Name[i],single:Single[i],unit:Unit[i]} ;
             flags.push(obj);
      }
     
    }
   console.log(flags);//[Object, Object]
   this.setState({flags});
   // const id=this.props.params.id;
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      let obj = {...values};
     console.log(obj);
    console.log(flags);
    let brandId=this.state.brandId;
    let objs={
      brandId:brandId,
      number:obj.number,
      type:obj.name,
      flags:flags
    }
     console.log(objs);

      // let values= document.getElementById('3').getElementsByTagName('input').value;
      // console.log(document.getElementById('3').getElementsByTagName('input').length);//[input#leftValue3.ant-input.ant-input-lg, leftValue3: input#leftValue3.ant-input.ant-input-lg]
      // console.log(document.getElementById('leftValue3').value);//2
      window.rpc.product.create(objs).then((ret) => {
        message.info('创建成功！')
        console.log(ret);
         window.location.href=`/equip/model/${this.state.brandId}`;
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      }
    });
    //  let values= document.getElementById('3').getElementsByTagName('input').value;
   

  },
  onChange(value) {
      console.log(value);
      this.setState({ value });
      window.rpc.device.types.getInfoExById(value).then((res)=>{
       console.log(res);
       console.log(res.flags);
       if(res.flags.length!==0){
        let flags=[...res.flags];
        console.log(flags);
        this.setState({secret:flags});
        console.log(this.state.secret);
      }else{
         this.setState({secret:[]});
      }
 
 },(err) =>{
        console.warn(err);
      })
  },
  render() {
    const { getFieldDecorator } = this.props.form;
//    const {getFieldValue} = this.props.form;
    let secret=this.state.secret;
     var linksLists =null;
     if(secret.length!==0) {
          linksLists = secret.map(function(inps){
         if(inps.single){
           return(<div key={`${inps.id}`} id={inps.id}><Row><Col span={2}><span>{inps.name}:</span></Col><Col span={12}><FormItem><Input style={{width:80}} id={`leftValue${inps.id}`} /><span  style={{marginLeft:5}}>{inps.unit}</span></FormItem></Col></Row></div>);
            }else{
             return(<div key={`${inps.id}`}><Row type="flex" justify="start"><Col span={2}><span>{secret[0].name}：</span></Col><Col span={18} style={{width:500}}><Row type="flex" justify="start"><Col span={13}  style={{width:150}}><FormItem><Input id={`leftValue${inps.id}`}style={{width:80}} /><span  style={{marginLeft:5}}>{secret[0].unit}</span><span style={{marginLeft:8}}>至</span></FormItem></Col><Col span={11}  style={{width:150}}> <FormItem><Input id={`rightValue${inps.id}`} style={{width:80}} /><span style={{marginLeft:5}}>{secret[0].unit}</span></FormItem></Col></Row></Col></Row></div>);
            }
        });
        // console.log(linksLists.length);
       }else{
         linksLists =null;
       }
   
    return (
    <div  style={{position:'relative'}}>
        <div style={{fontSize: '0.75rem', overflow:'hidden', paddingBottom:'1.125em',color:'#333',fontSize:'0.75rem',fontFamily:'苹方中等',borderBottom:'#ddd 1px solid'}}>
          <div style={{float:'left',width:135,height:'22px',linHeight:'22px',zIndex:99,backgroundColor:'#fff',marginTop:10}}>
            <span style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75rem',color:'#373e41',borderLeft:'2px solid #88b7e0'}}><Link to={`/equip/brand/manage`} style={{color:'#373e41'}} >品牌信息</Link><span style={{padding:'0 2px'}}>/</span><Link to={`/equip/model/${this.state.brandId}`}  style={{color:'#373e41'}} >型号信息</Link></span>
          </div>
          <div  style={{float:'left',width:80,height:32,marginRight:4}}>
            <Button  style={{background:'#536679',color:'#fff',padding:'0 15px',height:'32px',borderRadius:0}} onClick={this.handleStaffNew} ><Link to="">新增型号</Link></Button>
          </div>
      </div> 
      <div style={{width:'30%',marginLeft:'30%'}}>  
      <Form onSubmit={this.handleSubmit} className="NewTypes" tyle={{fontSize:'14px',padding:0,margin:0}}>    
      
        {/* <div style={{width:400,position:'absolute',left:'50%',marginLeft:'-200px'}}>
           <Form onSubmit={this.handleSubmit} className="Pre-create" style={{ height:400,fontSize:'14px',padding:0,margin:0}}>       
             <Row type="flex" justify="start" style={{marginBottom:18,marginTop:30}}>
              <Col span={3} style={{width:80}}><span type="所属品牌" disabled="false">维护主题：</span></Col>
              <Col span={6}>
                <FormItem>
                  {getFieldDecorator('name', {
                    //initialValue: objb.name || '',
                    rules: [{ required: true, message: '请输入内容!' }],
                  })(
                    <Input  placeholder="请输入内容" style={{width:300}} />
                  )}
                </FormItem>
              </Col>
             </Row>*/}
      <Row type="flex" justify="start" style={{marginBottom:18,marginTop:30}}>
          <Col span={3} style={{width:110}}><span type="所属品牌" disabled="false">所属品牌：</span></Col>
          <Col span={6}>
            <FormItem>
            {getFieldDecorator('make', {
              rules: [{ required: true, message: '请输入品牌名称!' }],
            })(
             <Input  placeholder="" style={{width:300}} disabled/>
            )}
             </FormItem>
         </Col>
      </Row>
    
   
      <Row type="flex" justify="start"  style={{marginBottom:18}}>
        <Col span={3}  style={{width:110}}><span type="型号名称" disabled="false">型号名称：</span></Col>
        <Col span={6}>
          <FormItem>
           {getFieldDecorator('number', {
              rules: [{ required: true, message: '请输入型号名称!' }],
            })(
             <Input  placeholder="" style={{width:300}}/>
            )}
           </FormItem>
        </Col>
      </Row>
   
   
      <Row type="flex" justify="start"  style={{marginBottom:18}}>
        <Col span={4}  style={{width:110}}><span type="所属设备类型" disabled="false">所属设备类型：</span></Col>
        <Col span={4}>
          <div>
            <FormItem>
            {getFieldDecorator('name', {
              rules: [{ required: true, message: '请输入设备类型!' }],
            })(
             <TreeSelect
                  style={{height:30 ,width:300}}
                  value={this.state.value}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer == 1)}
                  placeholder="Please select"
                  treeDefaultExpandAll
                  onChange={this.onChange}
                />
            )}
             </FormItem>
          </div>
        </Col>
      </Row>
    
      <Row type="flex" justify="start"  style={{marginBottom:18}}>
        <Col span={4} style={{width:110}}><span type="私有属性" disabled="false">私有属性：</span></Col>
         <Col span={12}>   {linksLists} </Col>
         
      </Row>
     
       <div style={{position:'absolute',marginTop:400,left:0,zIndex:'99'}} className="search-btn">
         <FormItem >  
           <Button  htmlType="submit"> 保存</Button> 
           <span className="new-button" style={{display:'inline-block', marginLeft:'10px',backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', borderRadius: '5px',width:60,height:32,borderRadius:0 }}><Link to={`/equip/model/${this.state.brandId}`}>返回</Link></span>   
           {/*<Button  style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑',marginLeft:10 }}><Link to={`/equip/model/${this.state.brandId}`}>返回</Link></Button>*/}
         </FormItem>  
        </div>
      </Form>  
      </div> 
      </div>
    )
  }
}))


export default EquipModelNew;