/*
 * @Author: szj
 * @Date: 2017-03-27 15:50:22 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:17:47
 */

import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Table, Row, Col, Input, Button, message, Form, Popconfirm } from 'antd';
const FormItem = Form.Item;
import './equipBrandManage.css';

var Num = '';
class appState {
  constructor() {
    extendObservable(this, {
      tableData: []
    })
  }
}

class BrandSearchForm extends React.Component {
  componentDidMount() {

  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, values) => {
        const name = values.name;
        window.rpc.brand.getInfoByName(name).then((res) => {
          let types = [{ key: res.id, id: res.id, name: res.name, remark: res.remark }];
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row style={{ margin: '15px 0 15px', height: '32px', lineHight: '32px' }} >
          <Col span={10} key={1}>
            <FormItem label={`品牌名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 180, height: 32 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={14} key={2}>
            <FormItem style={{ float: 'right' }}>
              <Button
                onClick={this.handleSearch}
                style={{ height: '32px', width: '80px', padding: 0, margin: 0, fontSize: '0.75rem', color: '#fff' }}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}


const BrandNameAdvancedSearchForm = Form.create()(BrandSearchForm);

const EquipBrandManageC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      Selected: {
        Id: null
      }
    }
  }
  componentWillMount() {
    window.rpc.brand.getArrayByContainer(null, 0, 10).then((res) => {
      let type = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
      let types = type.reverse();
      this.setState({ types });
      this.props.appState.tableData = types;
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
    window.rpc.brand.getCountByContainer(null).then((num) => {
      Num = num;
    }, (err) => {
      console.warn(err);
    })
  }

  componentDidMount() {
  }
  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) };
    this.setState({ Selected });
  }
  handleStaff = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/equip/brand/edit/${this.state.Selected.Id}`);
    } else {
      message.info('请选择品牌！');
    }
  }
  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/equip/model/${this.state.Selected.Id}`);
    } else {
      message.info('请选择品牌！');
    }
  }
  //是否删除
  remove = () => {
    if (this.state.Selected.Id != null) {
      window.rpc.brand.removeById(this.state.Selected.Id).then((res) => {
        if (res) {
          message.info('删除成功！');
          window.rpc.brand.getArrayByContainer(null, 0, 10).then((res) => {
            let types = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
            this.setState({ types });
            this.props.appState.tableData = types;
          }, (err) => {
            console.warn(err);
          })
        } else {
          message.info('删除失败！');
        }
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
      //刷新页面
    } else {
      message.info('请选择品牌！');
    }
  }
  onDelete = (index) => {
    window.rpc.brand.removeById(index).then((res) => {
      if (res) {
        message.info('删除成功！');
        window.rpc.brand.getArrayByContainer(null, 0, 10).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, id: x.id, name: x.name, remark: x.remark }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      } else {
        message.info('删除失败！');
      }
    }, (err) => {
      console.warn(err);
    })

  }
  cancel() {
    message.error('已取消');
  }
  render() {
    const data = [...this.props.appState.tableData];
    const pagination = {
      total: Num,
      showTotal: total => `共 ${Num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (page, PageSize) => {
        let pagenum = (parseInt(page, 10) - 1) * 10;
        window.rpc.brand.getArrayByContainer(null, pagenum, 10).then((res) => {
          let types = res.map(x => ({ ...x, key: x.id, name: x.name, remark: x.remark }));
          this.setState({ types });
          this.props.appState.tableData = types;
        }, (err) => {
          console.warn(err);
        })
      },
    };
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };

    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '品牌名称', dataIndex: 'name', key: 'name', render: (text, record) => (<Link to={`/equip/model/${record.id}`} style={{ color: '#0099cc' }}>{text}</Link>) },
      { title: '备注', dataIndex: 'remark', key: 'remark' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record, index) => (
          <div>
            <span>
              <Link to={`/equip/model/${record.key}`} style={{ color: '#999' }}>查看型号</Link>
              <span className="ant-divider" />
              <Link to={`/equip/brand/edit/${record.key}`} style={{ color: '#999' }}>编辑</Link>
              <span className="ant-divider" />
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(record.key)}>
                <a href="#" style={{ color: '#0099cc' }}>删除</a>
              </Popconfirm>
            </span>
          </div>
        )
      },
    ];

    return (
      <div className="brandManage" >

        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/brand/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>品牌信息</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <div className="new-button" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="/equip/brand/new">新增品牌</Link></div>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff}>编辑品牌</Button>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne}>查看型号</Button>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Popconfirm title="确认删除?" onConfirm={this.remove} onCancel={this.cancel} okText="确定" cancelText="取消">
              <Button type="" style={{ background: '#d8dfe4', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="">删除品牌</Link></Button>
            </Popconfirm>
          </div>
        </div>
        <BrandNameAdvancedSearchForm appState={this.props.appState} />
        <Row>
          <Col span={24}>
            <Table
              columns={columns}
              rowSelection={rowSelection}
              dataSource={data}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    )
  }
})



class EquipBrandManage extends Component {
  // const EquipBrandManage= observer(class appState extends React.Component{
  render() {
    return (
      <div>
        <EquipBrandManageC appState={new appState()} />
      </div>
    )
  }
}

export default EquipBrandManage;