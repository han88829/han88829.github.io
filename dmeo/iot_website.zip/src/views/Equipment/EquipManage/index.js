/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:34 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-07-28 11:31:02
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Form, Input, DatePicker, Select, message, Popconfirm, TreeSelect } from 'antd';
import moment from 'moment';
import './equipManage.css';
import normal from '../../../assets/images/apply/正常.png';
import unnormal from '../../../assets/images/apply/异常.png';
const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

let rStateChildren = [], rState = new Map(), number = 0, loca = '';
// 设置message消息
message.config({
  top: 216,
  duration: 2
})

let reg = /\,/ig;

class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      values: {},
      Num: '',
      name: null,
      rstate: [],
      dtype: [],
      location: [],
      setupTime: [],
      single:0

    })
  }
}
class AdvancedSearchForm extends React.Component {
  state = {
    data: []
  }
  componentWillMount() {
    function pushChildren(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp)
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = pushChildren(tableDate);
      this.setState({ data: tableDate });
    })
  }
  componentDidMount() {
    window.rpc.alias.getValueByName('device.rstate').then((res) => {
      for (let value in res) {
        rStateChildren.push(<Option key={`${value}`}>{res[value]}</Option>)
        rState[value] = res[value];
        rState[res[value]] = value;
      }
    });

  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['dstate'];
        let values = {};
        if (name) {
          values = { ...values, name };
          this.props.appState.name = values.name;
        }
        //设备类型
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => x) };
          this.props.appState.dtype = values.dtype;
        }
        //运行状态
        if (dstate) {
          values = { ...values, rstate: fieldsValue['dstate'].map(x => x) };
          this.props.appState.rstate = values.rstate;
        }
        //所属建筑
        if (location) {
          values = { ...values, location: fieldsValue['location'].map(x => x) };
          this.props.appState.location = values.location;
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
          this.props.appState.setupTime = values.setupTime;
        }
        this.props.appState.values = values;
        let hash = false;
        for (let i in values) {
          if (values[i].length > 0) {
            hash = true;
            break;
          }
        }
        window.rpc.device.getArrayByContainer(values, 0, 0).then((data) => {
          number= data.length;//num
          this.props.appState.Num = data.length;
          this.props.appState.single=1;
          message.info(`共搜索到${data.length}条数据`);
        })
        window.rpc.device.getArrayBriefByCondContainer({}, values, 0, 10).then((result) => {
          let devi = result.map((x) => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: rState[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          this.props.appState.tableData = devi;
          console.log(devi);
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let locations = JSON.parse(sessionStorage.getItem('locations')) || [];
    let dtypeChildren = [];
    let locationChildren = [];


    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    for (let value of locations) {
      if (value && value.id && value.type === 50) {
        locationChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    return (
      <Form layout="inline" style={{ margin: "12px 0" }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`设备名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 170 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`设备类型`}>
              {getFieldDecorator(`dtype`)(
                <TreeSelect
                  style={{ width: 170 }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  treeData={this.state.data.filter(x => x.layer === 1)}
                  placeholder="请选择类型"
                  multiple
                />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`设备状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 170 }} placeholder="请选择">
                  {rStateChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`所属建筑`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 170 }} placeholder="请选择">
                  {locationChildren}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`安装时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{ width: 250 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);

@observer

class EquipManageC extends React.Component {

  constructor() {
    super();
    this.state = {
      display: "none",
      Selected: {
        Id: null
      },
      pagenum: "",
      pageSize: 10
    }
  }
  componentDidMount() {
    let type = this.props.params;
    let obj = {};
    window.rpc.owner.getInfo().then(data => {
      switch (type.type) {
        case 'ok':
          obj = { rstate: 1, ownerId: data }
          break;
        case 'error':
          obj = { rstate: 2, ownerId: data }
          break;
        default:
          obj = { ownerId: data }
          break;
      }
      window.rpc.device.getCountByContainer({}).then(res => {
        this.props.appState.Num = res;
        console.log(res);
      }, err => {
        console.warn(err)
      })
    }, err => {
      console.warn(err)
    })

    if (sessionStorage.getItem('flag')) {
      this.setState({
        display: 'inline-block'
      })
    } else {
      this.setState({
        display: 'none'
      })
    }
    if (sessionStorage.getItem("equipment")) {
      let devic = JSON.parse(sessionStorage.getItem("equipment"));
      window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
        return { devic, rstate }
      }).then((data) => {
        let result = data.devic
        result.forEach(function (x) {
          if (x.location) {
            loca = x.location.replace(reg, '-');
          } else {
            loca = '';
          }
        })
        let equipmentMap = result.map((x) => ({ ...x, dtype: x.name, location: x.location, key: x.id, rstate: rState[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.props.appState.tableData = equipmentMap;
      })
    } else {
      window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
        return window.rpc.device.getArrayBriefByCondContainer({}, {}, 0, 10).then(device => { return { device, rstate } });
      }).then((data) => {
        let result = data.device
        let type = this.props.params;
        switch (type.type) {
          case 'ok':
            result = result.filter(decice => decice.rstate === 1)
            break;
          case 'error':
            result = result.filter(decice => decice.rstate === 2)
            break;
          default:
            break;
        }

        let devices;
        result.forEach(function (x) {
          if (x.location) {
            loca = x.location.replace(reg, '-');
          } else {
            loca = '';
          }
        })

        devices = result.map(x => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: data.rstate[x.rstate]||x.rstate, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
        this.props.appState.tableData = devices;
        this.setState({
          data: this.props.appState.tableData
        })
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
    }
    if (sessionStorage.getItem('number')) {
      number = parseInt(sessionStorage.getItem('number'), 10);
    } else {
      window.rpc.device.getCountByContainer(obj).then((res) => {
        number = res;
      }, (err) => {
        console.warn(err);
      })
    }
  }
  handAll = () => {
    if (sessionStorage.getItem('number')) {
      number = parseInt(sessionStorage.getItem('number'), 10);
    } else {
      window.rpc.device.getCountByContainer({}).then((res) => {
        number = res;
      }, (err) => {
        console.warn(err);
      })
    }
    window.rpc.device.getArrayBriefByCondContainer(null, null, 0, 10).then((result) => {
      let devices = [];
      result.forEach(function (x) {
        if (x.location) {
          loca = x.location.replace(reg, '-');
        } else {
          loca = '';
        }
        devices.push({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: x.dtype, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime).format('YYYY-MM-DD HH:mm:ss') })
      })
      this.props.appState.tableData = devices;
    }, (err) => {
      console.warn(err);
    })
  }

  onSelectChange = (selectedRowKeys) => {
    const Selected = { Id: parseInt(selectedRowKeys[0], 10) };
    this.setState({ Selected });

  }
  handleStaff = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/equip/device/edit/${this.state.Selected.Id}`);
    } else {
      message.info('请选择设备！');
    }
  }
  //详情跳转
  handleStaffOne = () => {
    if (this.state.Selected.Id != null) {
      browserHistory.push(`/equip/device/${this.state.Selected.Id}`);
    } else {
      message.info('请选择设备！');
    }
  }

  //是否删除
  remove = () => {
    if (this.state.Selected.Id != null) {
      window.rpc.device.removeById(this.state.Selected.Id).then((res) => {
        let types = res.map(x => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: x.rstate, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }));
        this.setState({ types });
        this.props.appState.tableData = types;
        this.setState({
          data: this.props.appState.tableData
        })
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
      let pagen = 0;
      if (this.state.pagenum !== "") {
        pagen = this.state.pagenum
      }
      window.rpc.device.getArrayBriefByCondContainer(null, null, pagen, 10).then((result) => {
        let devices = [];
        result.forEach(function (x) {
          if (x.location) {
            loca = x.location.replace(reg, '-');
          } else {
            loca = '';
          }
          devices.push({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: x.dtype, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') })
        })
        this.props.appState.tableData = devices;
        this.setState({
          data: this.props.appState.tableData
        })
      }, (err) => {
        console.warn(err);
         function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
      //刷新页面
    } else {
      message.info('请选择设备！');
    }
  }

  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  maintain() {
    message.success('保养成功');
  }

  check() {
    message.success('检测成功');
  }
  onDelete = (key, index) => {
    window.rpc.device.removeById(Number(index)).then((res) => {
    }, (err) => {
      console.warn(err);
    })
    this.props.appState.tableData.splice(key, 1);
  }
  cancel() {
    message.error('已取消');
  }
  handelClick(e) {
  }
  render() {
    /**保养检测 */
    const rowSelection = {
      type: 'radio',
      onChange: this.onSelectChange,
    };
    const columns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      {
        title: '设备名称', dataIndex: 'name', key: 'name', render: (text, record) => (
          <span>
            <Link to={`/equip/device/info/${record.key}`} style={{ color: '#00c1de' }}>{text}</Link>
          </span>
        ),
      },

      {
        title: '设备类型', dataIndex: 'dtype', key: 'dtype', render: (text, record) => (
          <span>
            <Link to={`/equip/type/${record.key}`} style={{ color: '#00c1de'  }}>{text}</Link>
          </span>
        ),

      },
      { title: '安装日期', dataIndex: 'setupTime', key: 'setupTime' },
      {
        title: '安装位置', dataIndex: 'location', key: 'location', render: (text, record, index) => {
          let textArr = text.split(',');
          if (textArr[2]) {
            return (
              <span>
                <Link style={{ color: '#00c1de' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link style={{ color: '#00c1de'  }} to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>--
                <Link style={{ color:'#00c1de'  }} to={`/org/area/cont/${textArr[2].split(':')[0]}`}>{textArr[2].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[1]) {
            return (
              <span>
                <Link style={{  color: '#00c1de' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>--
                <Link style={{ color: '#00c1de' }} to={`/org/area/${textArr[1].split(':')[0]}`}>{textArr[1].split(':')[1]}</Link>
              </span>
            )
          }
          if (textArr[0]) {
            return (
              <span>
                <Link style={{ color: '#00c1de' }} to={`/org/floor/${textArr[0].split(':')[0]}`}>{textArr[0].split(':')[1]}</Link>
              </span>
            )
          }

        }
      },
      { title: '运行状态', dataIndex: 'rstate', key: 'rstate' , render: (text, record, index) =>  { 
         if(text=="正常"){
            return(
               <span   style={{color:'green',position:'relative'}}>
                {"正常"}<img style={{paddingLeft:8,position:'absolute',top:0}} src={normal} alt="" />
               </span>
            )
        
        }else if(text=="异常"){
             return(
               <span onClick={()=>this.showModal(index,record)} style={{color:'red',position:'relative'}}>
                {"异常"}<img style={{paddingLeft:8,position:'absolute',top:0}} src={unnormal} alt="" />
               </span>
            )
        }else{
             return(
               <span style={{ color: '#00c1de' }}>
                {text}
               </span>
            )
        }
         
       }
      },
      { title: '最后巡查日期', dataIndex: 'lastTime', key: 'lastTime' },
      { title: '最后巡查人', dataIndex: 'userName', key: 'userName' },
      {
        title: '操作', dataIndex: '', key: 'x', width: "170px", render: (text, record, index) => (
          <span>
            <Link to={`/equip/device/info/${record.key}`} style={{ color: '#0099cc' }}>查看</Link>
            <span className="ant-divider" />
            <Link to={`/equip/device/edit/${record.key}`} style={{ color: '#0099cc' }}>编辑</Link>
            <span className="ant-divider" />
            <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(index, record.key)}>
              <a href="#" style={{ color: '#0099cc' }}>删除</a>
            </Popconfirm>
          </span>
        )
      },
    ];
    let num = this.props.appState.Num;
    const pagination = {
      total: num,
      showTotal: total => `共 ${num} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      current:this.props.appState.single?1:this.state.current,
      onShowSizeChange: (current, pageSize) => {
        //console.log(this.props.appState.single)
     if(this.props.appState.single)   current=1;this.setState({current:1})
        this.setState({
          pageSize,
          current
        })
        let pagenum = (parseInt(current, 10) - 1) * pageSize;
        let value = {}, fire = {};
        let name = this.props.appState.name;
        let dtype = [...this.props.appState.dtype];
        let rstate = [...this.props.appState.rstate];
        let location = [...this.props.appState.location];
        let setupTime = [...this.props.appState.setupTime];
        let value1 = this.props.appState.values;
        if (name) {
          value = { ...value, name: name, }
        }
        if (dtype.length !== 0) {
          value = { ...value, dtype: dtype }
        }
        if (rstate.length !== 0) {
          value = { ...value, rstate: rstate }
        }
        if (location.length !== 0) {
          value = { ...value, location: location }
        }
        if (setupTime.length !== 0) {
          value = { ...value, setupTime: [new Date(setupTime[0].format('YYYY-MM-DD')), new Date(setupTime[1].format('YYYY-MM-DD'))] }
        }
   
        let newId = sessionStorage.getItem('newId');
        if (sessionStorage.getItem('equipment')) {
          window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
            return window.rpc.device.getArrayBriefByCondContainer(null, value, pagenum, pageSize).then(device => { return { device, rstate } });
          }).then((data) => {
            this.props.appState.single=0;
            let result = data.device
            let devices;
            result.forEach(function (x) {
              if (x.location) {
                loca = x.location.replace(reg, '-');
              } else {
                loca = '';
              }
            })

            devices = result.map(x => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
            this.props.appState.tableData = devices;
            this.setState({
              data: this.props.appState.tableData
            })
          }, (err) => {
            console.warn(err);
          })
        } else {
          window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
            return window.rpc.device.getArrayBriefByCondContainer(null, null, pagenum, pageSize).then(device => { return { device, rstate } });
          }).then((data) => {
            let result = data.device
            let devices;
            result.forEach(function (x) {
              if (x.location) {
                loca = x.location.replace(reg, '-');
              } else {
                loca = '';
              }
            })

            devices = result.map(x => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
            this.props.appState.tableData = devices;
            this.setState({
              data: this.props.appState.tableData
            })
          }, (err) => {
            console.warn(err);
          })
        }
      },
      onChange: (page, pageSize,current) => {
        let pagenum = (parseInt(page, 10) - 1) * this.state.pageSize;
        this.setState({
          pagenum
        });
         this.setState({
            current:page
        })
         if(this.props.appState.single==1){
       
          this.props.appState.single=0;
        } ;
         //  number = devi.length;
         
        if (sessionStorage.getItem('equipment')) {
          window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
            return window.rpc.device.getArrayBriefByCondContainer(null, { floor: sessionStorage.getItem('newId') }, pagenum, this.state.pageSize).then(device => { return { device, rstate } });
          }).then((data) => {
            let result = data.device
            let devices;
            result.forEach(function (x) {
              if (x.location) {
                loca = x.location.replace(reg, '-');
              } else {
                loca = '';
              }
            })

            devices = result.map(x => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
            this.props.appState.tableData = devices;
            this.setState({
              data: this.props.appState.tableData
            })
          }, (err) => {
            console.warn(err);
          })
        } else {
          window.rpc.alias.getValueByName('device.rstate').then((rstate) => {
            return window.rpc.device.getArrayBriefByCondContainer(null, null, pagenum, this.state.pageSize).then(device => { return { device, rstate } });
          }).then((data) => {
            let result = data.device
            let devices;
            result.forEach(function (x) {
              if (x.location) {
                loca = x.location.replace(reg, '-');
              } else {
                loca = '';
              }
            })

            devices = result.map(x => ({ ...x, dtype: x.typeName, location: x.location, key: x.id, rstate: data.rstate[x.rstate], setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.patrolTime).format('YYYY-MM-DD HH:mm:ss') }))
            this.props.appState.tableData = devices;
            this.setState({
              data: this.props.appState.tableData
            })
          }, (err) => {
            console.warn(err);
          })
        }
      },
    };

    const data = [...this.props.appState.tableData]
    return (
      <div className="EquipManage" style={{ padding: '0' }}>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备管理</Link>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <div className="new-button" type="" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="/equip/device/new" onClick={this.handelClick} >新增设备</Link></div>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff}><Link to="" >编辑设备</Link></Button>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne}><Link to="">查看设备</Link></Button>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Popconfirm title="确认删除?" onConfirm={this.remove} onCancel={this.cancel} okText="确定" cancelText="取消">
              <Button type="" style={{ background: '#d9dee4', color: '#000', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="">删除设备</Link></Button>
            </Popconfirm>
          </div>
        </div>
        <WrappedAdvancedSearchForm appState={this.props.appState} />
        <Row style={{ padding: '5px 0 0' }}>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={data}
              rowSelection={rowSelection}
              pagination={pagination}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

class EquipManage extends Component {
  render() {
    return (
      <div className='EquipManageC'>
        <EquipManageC appState={new appState()} params={this.props.params} />
      </div>
    )
  }
}

export default EquipManage;