import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Radio, Card, Table, Form, message } from 'antd';
import echarts from 'echarts';
import moment from 'moment';
const FormItem = Form.Item;

const { RangePicker } = DatePicker;

const columns = [{
	title: '维护类型',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '维护次数',
	dataIndex: 'value',
	key: 'value',
}];


class deviceState {
	constructor() {
		extendObservable(this, {
			patrolData: [],
			addPatrol: action(function (e) {
				let before, now, date,flag=0,switcs=null;
				let dataArr = [];
				switch (e) {
					case 'week':
						date = 'date';
						before = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate() - 6);
						now = moment(new Date()).format('YYYY-MM-DD')
						for (let i = 6; i >= 0; i--) {
							(function () {
								dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}-${((new Date().getDate() - i).toString().length === 1 ? '0' + (new Date().getDate() - i) : (new Date().getDate() - i))}`)
							})(i)
						}
						break;
					case 'month':
						date = 'date';
						before = new Date().getFullYear() + '-' + (new Date().getMonth());
						now = moment(new Date()).format('YYYY-MM')
						dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}`)
						break;
					case 'seacon':
						date = 'month';
						before = new Date().getFullYear() + '-' + (new Date().getMonth() - 2);
						now = moment(new Date()).format('YYYY-MM')
						for (let i = 2; i >= 0; i--) {
							(function () {
								dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() - i).toString().length === 1 ? '0' + (new Date().getMonth() - i) : (new Date().getMonth() - i)}`)
							})(i)
						}
						break;
					default:
						break;
				}

				let number = [];
				const ght = () => {
					return window.rpc.alias.getValueByName('device.alarm.type')
				}
				const ghost = () => {
					return window.rpc.device.patrol.getTrendCountTypeByContainer({ createTime: [new Date('2017-02-01'), new Date(now)] }, date)
				}
				const ghosts = async () => {
					const data = await ght();
					const res = await ghost();
					const dataYarr = [], arr = [],datas=[];
					for (let i in data) {
						dataYarr.push({ name: data[i], type: 'bar', stack: '总量', label: { normal: { show: true, position: 'insideRight' } }, data: [] })
					}
					for (let i in res) {
						for (let j in data) {
							for (let z in res[i]) {
								if (z == j) arr.push({ name: i, value: res[i] })
								else arr.push({ name: "", value: { [j]: 0 } })
							}
						}

					}
					if (arr.length > 0) {
						arr.forEach((x, index) => {
							dataArr.forEach((y, i) => {
								if (dataArr[i] === arr[index].name) {
									for (let z in arr[index].value) {
										if (data[z] === dataYarr[index].name) {
											dataYarr[index].data.push(arr[index].value[z])
											datas.push(arr[index].value[z])
										} else {
											dataYarr[index].data.push(0)
											datas.push(0)
										}
									}
								} else {
									dataYarr[index].data.push(0);
									if(switcs !== index){
										flag = 1;
									}else{
										flag=0;
									}
									if(flag){
										datas.push(0)
									}
									switcs = index
								}
							})
						})
					} else {
						dataYarr.forEach((y, i) => {
							dataYarr[i].data = [0, 0, 0, 0, 0, 0, 0];
							datas.push(0)
						})
					}
					let num = 0;
					for (var i = 0; i < dataYarr.length; i++) {
						for (var j = 0; j < dataYarr[i].data.length; j++) {
							num += dataYarr[i].data[j];
						}
						number.push({ key: i, value: num, name: dataYarr[i].name })
						num = 0
					}
					this.patrolData = number
					let myChart = echarts.init(document.getElementById('DevicePatrolEcharts'));

					myChart.setOption({
						tooltip: {
							trigger: 'axis',
							axisPointer: {            // 坐标轴指示器，坐标轴触发有效
								type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
							}
						},
						legend: {
							data: dataYarr.map(x => x.name)
						},
						grid: {
							left: '3%',
							right: '4%',
							bottom: '3%',
							containLabel: true
						},
						xAxis: {
							type: 'value'
						},
						yAxis: {
							type: 'category',
							data: dataArr
						},
						series: dataYarr
					});
				}
				ghosts()
			}),
			search: action(function (obj,befor,after) {			
				let number = [];
				const time = () =>{
					const reducs = (new Date(after).getTime()-new Date(befor).getTime())/86400/1000;
					return reducs
				}
				const ght = () => {
					return window.rpc.alias.getValueByName('device.alarm.type')
				}
				const ghost = () => {
					return window.rpc.device.patrol.getTrendCountTypeByContainer(obj, 'data')
				}
				const ghosts = async () => {
					const reduces =await time();
					const data = await ght();
					const res = await ghost();
					let dataArr = [];
					for (let i = reduces; i >= 0; i--) {
						(function () {
							dataArr.push(`${new Date(after).getFullYear()}-${(new Date(after).getMonth() + 1).toString().length === 1 ? '0' + (new Date(after).getMonth() + 1) : (new Date(after).getMonth() + 1)}-${((new Date(after).getDate() - i).toString().length === 1 ? '0' + (new Date(after).getDate() - i) : (new Date(after).getDate() - i))}`)
						})(i)
					}
					let dataYarr = [], arr = [];
					for (let i in data) {
						dataYarr.push({ name: data[i], type: 'bar', stack: '总量', label: { normal: { show: true, position: 'insideRight' } }, data: [] })
					}
					for (let i in res) {
						for (let j in data) {
							for (let z in res[i]) {
								if (z == j) arr.push({ name: i, value: res[i] })
								else arr.push({ name: j, value: { [j]: 0 } })
							}
						}
					}

					if (arr.length > 0) {
						arr.forEach((x, index) => {
							dataArr.forEach((y, i) => {
								if (dataArr[i] === arr[index].name) {
									for (let z in arr[index].value) {
										if (data[z] === dataYarr[index].name) {
											dataYarr[index].data.push(arr[index].value[z])
										} else {
											dataYarr[index].data.push(0)
										}
									}
								} else {
									dataYarr[index].data.push(0);
								}
							})
						})
					} else {
						dataYarr.forEach((y, j) => {
							for (var i = 0 ;i<reduces;i++){
								dataYarr[j].data.push(0);
							}					
						})
					}
					let num = 0;
					for (var i = 0; i < dataYarr.length; i++) {
						for (var j = 0; j < dataYarr[i].data.length; j++) {
							num += dataYarr[i].data[j];
						}
						number.push({ key: i, value: num, name: dataYarr[i].name })
						num = 0
					}
					this.patrolData = number
					let myChart = echarts.init(document.getElementById('DevicePatrolEcharts'));

					myChart.setOption({
						tooltip: {
							trigger: 'axis',
							axisPointer: {            // 坐标轴指示器，坐标轴触发有效
								type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
							}
						},
						legend: {
							data: dataYarr.map(x => x.name)
						},
						grid: {
							left: '3%',
							right: '4%',
							bottom: '3%',
							containLabel: true
						},
						xAxis: {
							type: 'value'
						},
						yAxis: {
							type: 'category',
							data: dataArr
						},
						series: dataYarr
					});
				}
				ghosts()
			})
		})
	}
}


const PatrolSearchForm = Form.create()(React.createClass({
	getInitialState() {
		return {
			size: 'week'
		}
	},
	handleSearch(e) {
		e.preventDefault();
		let json,befor,after;
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const rangeValue = fieldsValue['field-5'];
				const values = {
					...fieldsValue,
					'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
				}
				json = { createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')),new Date(rangeValue[1].format('YYYY-MM-DD'))] }
				befor = rangeValue[0].format('YYYY-MM-DD');
				after = rangeValue[1].format('YYYY-MM-DD');			
			});
			setTimeout(()=>{this.props.deviceState.search(json,befor,after);},100)
			message.info('已更新');
		} catch (e) {
			console.log(e)
		}
		this.props.deviceState.addPatrol();
	},
	onChange(e) {
		this.props.deviceState.addPatrol(e.target.value);
		this.setState({ size: e.target.value });
	},
	render() {
		const { getFieldDecorator } = this.props.form;

		return (
			<Form layout="inline" style={{ margin: 12 }}>
				<Row>
					<Col style={{ float: "left", marginRight: 20 }} key={2}>
						<Radio.Group onChange={this.onChange} value={this.state.size}>
							<Radio.Button value="week">周</Radio.Button>
							<Radio.Button value="month">月</Radio.Button>
							<Radio.Button value="seacon">季</Radio.Button>
						</Radio.Group>
					</Col>
					<Col style={{ float: "left" }} key={5}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`field-5`)(
								<RangePicker style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col style={{ float: "left" }} key={6}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
              </Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}));

@observer
class DevicePatrolC extends Component {
	//const DevicePatrolC=observer(class DevicePatrolC extends React.Component {
	constructor() {
		super();

		this.state = {
			size: 'default'
		};
	}

	componentDidMount() {
		const before = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate() - 6);
		const now = moment(new Date()).format('YYYY-MM-DD')
		let number = [];
		const ght = () => {
			return window.rpc.alias.getValueByName('device.alarm.type')
		}
		const ghost = () => {
			return window.rpc.device.patrol.getTrendCountTypeByContainer({ createTime: [new Date('2017-02-01'), new Date(now)] }, 'data')
		}
		const ghosts = async () => {
			const data = await ght();
			const res = await ghost();
			const dataArr = [];
			for (let i = 6; i >= 0; i--) {
				(function () {
					dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}-${((new Date().getDate() - i).toString().length === 1 ? '0' + (new Date().getDate() - i) : (new Date().getDate() - i))}`)
				})(i)
			}
			const dataYarr = [], arr = [];
			for (let i in data) {
				dataYarr.push({ name: data[i], type: 'bar', stack: '总量', label: { normal: { show: true, position: 'insideRight' } }, data: [] })
			}
			for (let i in res) {
				for (let j in data) {
					for (let z in res[i]) {
						console.log(res[i][z] + '-' + j)
						if (z == j) arr.push({ name: i, value: res[i] })
						else arr.push({ name: j, value: { [j]: 0 } })
					}
				}

			}
			
			if (arr.length > 0) {
				arr.forEach((x, index) => {
					dataArr.forEach((y, i) => {
						if (dataArr[i] === arr[index].name) {
							for (let z in arr[index].value) {
								if (data[z] === dataYarr[index].name) {
									dataYarr[index].data.push(arr[index].value[z])
								} else {
									dataYarr[index].data.push(0)
								}
							}
						} else {
							dataYarr[index].data.push(0);
						}
					})
				})
			} else {
				dataYarr.forEach((y, i) => {
					dataYarr[i].data = [0, 0, 0, 0, 0, 0, 0];
				})
			}
			let num = 0;
			for (var i = 0; i < dataYarr.length; i++) {
				for (var j = 0; j < dataYarr[i].data.length; j++) {
					num += dataYarr[i].data[j];
				}
				number.push({ key: i, value: num, name: dataYarr[i].name })
				num = 0
			}
			this.props.deviceState.patrolData = number
			let myChart = echarts.init(document.getElementById('DevicePatrolEcharts'));

			myChart.setOption({
				tooltip: {
					trigger: 'axis',
					axisPointer: {            // 坐标轴指示器，坐标轴触发有效
						type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
					}
				},
				legend: {
					data: dataYarr.map(x => x.name)
				},
				grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				},
				xAxis: {
					type: 'value'
				},
				yAxis: {
					type: 'category',
					data: dataArr
				},
				series: dataYarr
			});
		}
		ghosts()
	}
	render() {
		return (
			<div className="DevicePatrol" style={{ padding: '5px' }}>
				<PatrolSearchForm deviceState={this.props.deviceState} />
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>巡查占比</p>
					<div id="DevicePatrolEcharts" style={{ height: '50vh', width: '100%',borderTop:"1px solid #ccc" }}></div>
				</Row>
				<Row>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>巡查占比</p>
					<Table dataSource={[...this.props.deviceState.patrolData]} bordered columns={columns} pagination={false} />
				</Row>
			</div>
		);
	}
}

class DevicePatrol extends Component {
	render() {
		return (
			<DevicePatrolC deviceState={new deviceState()} />
		)
	}
}

export default DevicePatrol;