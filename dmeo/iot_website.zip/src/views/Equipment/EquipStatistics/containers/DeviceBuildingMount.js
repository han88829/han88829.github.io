import React, { Component } from 'react';
import { Row, Col, Card, Table } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import echarts from 'echarts';

/*const { RangePicker } = DatePicker;*/

var schema = [
	{ name: 'date', index: 0, text: '日' },
];

var itemStyle = {
	normal: {
		opacity: 0.8,
		shadowBlur: 10,
		shadowOffsetX: 0,
		shadowOffsetY: 0,
		shadowColor: 'rgba(0, 0, 0, 0.5)',
	}
};

class buildingMountState {
	constructor() {
		extendObservable(this, {
			tableData: []
		})
	}
}

const locations = JSON.parse(sessionStorage.getItem('locations')) || [];

const columns = [{
	title: '所属建筑',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '设备数量',
	dataIndex: 'value',
	key: 'value',
}];

const DeviceBuildingMountC = observer(class buildingMountState extends React.Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			data: []
		};
	}

	onChangeDate(date, dateString) {

	}
	handleSizeChange = (e) => {
		this.setState({ size: e.target.value });
	}
	componentWillMount() {

	}

	componentDidMount() {
		function pushChildren(data) {
			let arr = [...data];
			let layer = arr.map(x => x.layer).sort((a, b) => b - a)[0];
			let layerNow = arr.filter(x => x.layer === layer);
			let layerUp = arr.filter(x => x.layer !== layer);
			for (let i = 0; i < layerUp.length; i++) {
				for (let j = 0; j < layerNow.length; j++) {
					if (layerNow[j].parentId === layerUp[i].id) {
						if (layerUp[i].children) {
							layerUp[i].value += layerNow[j].value
							layerUp[i].children.push({ ...layerNow[j], key: `${layerNow[j].id}-${layer}` });
						} else {
							layerUp[i].value += layerNow[j].value
							layerUp[i].children = [{ ...layerNow[j], key: `${layerNow[j].id}-${layer}` }];
						}
					}
				}
			}
			if (layer === 2) {
				return layerUp;
			} else {
				pushChildren(layerUp);
			}
		}
		window.rpc.area.getArray(0, 0).then(result => {
			return window.rpc.device.getCountFieldByContainer({}, 'location').then(data => ({ result, data }))
		}).then((rest) => {
			let tableDate = rest.result.map(x => ({ ...x, name: x.name || "无", key: x.id, value: rest.data[x.id] || 0 })).filter(x => x.id);
			pushChildren(tableDate);
			this.setState({
				data: tableDate
			})
			this.props.buildingMountState.tableDate = tableDate;
			const deviceArr = this.state.data.filter(x => x.parentId === 0).map((x, i) => ({
				...x, itemStyle, data: [[x.value, x.value]], type: 'scatter'
			}))
			let myChart = echarts.init(document.getElementById('DeviceBuildingMountEcharts'));

			myChart.setOption({
				backgroundColor: '#fff',
				color: [
					'#dd4444', '#fec42c', '#80F1BE'
				],
				legend: {
					y: 'top',
					data: this.state.data.filter(x => x.parentId === 0).map(x => x.name),
					textStyle: {
						color: '#555',
						fontSize: 16
					}
				},
				tooltip: {
					padding: 10,
					backgroundColor: '#222',
					borderColor: '#777',
					borderWidth: 1,
					formatter: function (obj) {
						var value = obj.value;
						return '<div style="border-bottom: 1px solid rgba(255,255,255,.3); font-size: 18px;padding-bottom: 7px;margin-bottom: 7px">'
							+ obj.seriesName + '：' + value[0]
							+ '</div>'

					}
				},
				xAxis: {
					type: 'value',
					name: '设备类型',
					nameLocation: 'end',
					nameGap: 16,
					nameTextStyle: {
						color: '#555',
						fontSize: 14
					},
					splitLine: {
						show: false
					},
					axisLine: {
						lineStyle: {
							color: '#00d8bf'
						}
					}
				},
				yAxis: {
					type: 'value',
					name: '设备数量',
					nameLocation: 'end',
					nameGap: 20,
					nameTextStyle: {
						color: '#555',
						fontSize: 16
					},
					axisLine: {
						lineStyle: {
							color: '#00d8bf'
						}
					},
					splitLine: {
						show: false
					}
				},
				series: deviceArr
			});
		}, (err) => {
			console.warn(err);
			 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
		});
	}

	render() {
		return (
			<div className="DeviceBuildingMount">
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>所属建筑占比</p>
					<div id="DeviceBuildingMountEcharts" style={{ height: '50vh', width: '100%', border: "1px solid #ccc" }}></div>
				</Row>
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>所属建筑占比</p>
					<Table dataSource={this.state.data.filter(x => x.parentId === 0)} bordered columns={columns} pagination={false} />
				</Row>
			</div>
		);
	}
})

class DeviceBuildingMount extends Component {
	render() {
		return (
			<DeviceBuildingMountC buildingMountState={new buildingMountState()} />
		)
	}
}

export default DeviceBuildingMount;