import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, DatePicker, Button, Radio, Card, Table, Form, message } from 'antd';
import moment from 'moment';
import echarts from 'echarts';
import './deivceWarnning.css'
const FormItem = Form.Item;

const { RangePicker } = DatePicker;

const columns = [{
	title: '报警类型',
	dataIndex: 'name',
	key: 'name',
}, {
	title: '报警数量',
	dataIndex: 'value',
	key: 'value',
}];
const color = ['red', 'green', 'yellow'];
class deviceState {
	constructor() {
		extendObservable(this, {
			patrolData: [],
			addPatrol: action(function (e) {
				let before, now, date, flag = 1, switcs = null,datenum;
				let dataArr = [];
				switch (e) {
					case 'week':
						date = 'date';
						before = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate() - 6);
						now = moment(new Date()).format('YYYY-MM-DD');
						datenum=7;
						for (let i = 6; i >= 0; i--) {
							(function () {
								dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}-${((new Date().getDate() - i).toString().length === 1 ? '0' + (new Date().getDate() - i) : (new Date().getDate() - i))}`)
							})(i)
						}
						break;
					case 'month':
						date = 'date';
						before = new Date().getFullYear() + '-' + (new Date().getMonth());
						now = moment(new Date()).format('YYYY-MM')
						datenum=1;
						dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}`)
						break;
					case 'seacon':
						date = 'month';
						before = new Date().getFullYear() + '-' + (new Date().getMonth() - 2);
						now = moment(new Date()).format('YYYY-MM')
						datenum=3;
						for (let i = 2; i >= 0; i--) {
							(function () {
								dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() - i).toString().length === 1 ? '0' + (new Date().getMonth() - i) : (new Date().getMonth() - i)}`)
							})(i)
						}
						break;
					default:
						break;
				}
				let number = [];
				window.rpc.alias.getValueByName('device.alarm.type').then(result => {
					return window.rpc.device.alarm.getTrendCountTypeByContainer({ createTime: [new Date(before), new Date(now)] }, date).then(data => { return { result, data } })
				}).then(ress => {
					const data = ress.result;
					const res = ress.data;
					const dataYarr = [], arr = [], nameArr = [], dates = [], tableDate = [],nameTable=[];
					for (let i in res) {
						nameArr.push(res[i])
					}

					for (let j in data) {
						nameTable.push(data[j])
						dataArr.forEach((x, i) => {
							dataYarr.push([x, data[j]]);
						})
					}
					for (let i in res) {
						for (let j in data) {
							for (let z in res[i]) {
								if (z == j) arr.push({ name: i, value: res[i] })
								else arr.push({ name: j, value: { [j]: 0 } })
								tableDate.push({ name: data[i], data: [] })
							}
						}
					}

					if (arr.length > 0) {
						arr.forEach((x, index) => {
							dataArr.forEach((y, i) => {
								if (dataArr[i] === arr[index].name) {
									for (let z in arr[index].value) {
										if (data[z] === tableDate[index].name) {
											tableDate[index].data.push(arr[index].value[z])
										} else {
											tableDate[index].data.push(0)
										}
									}
								} else {
									tableDate[index].data.push(0);
								}
							})
						})
					} else {
						tableDate.forEach((y, j) => {
							for (var i = 0; i < 7; i++) {
								tableDate[j].data.push(0);
							}
						})
					}
					if (arr.length > 0) {
						dataYarr.forEach((x, index) => {
							arr.forEach((y, i) => {
								if (y.name === x[0]) {
									for (let z in y.value) {
										if (data[z] === x[1]) {
											dataYarr[index].push(y.value[z])
											break;
										} else {
											dataYarr[index].push(0)
											break;
										}
									}
								} else {
									if (switcs !== index) {
										flag = 1;
										dataYarr[index].push(0);
									} else {
										flag = 0;
									}
									switcs = index;
								}
							})
						})
					} else {
						dataYarr.forEach((y, i) => {
							dataYarr[i].push(0);
						})
					}

					//时间组成方法
					let nDtate = [];

					dataYarr.forEach((x, i) => {
						if (x.length > 3) {
							if (x[2] > 0) {
								x.splice(3, 1)
							} else {
								x.splice(2, 1)
							}
						}
						var type = x[1];
						x[1] = x[2];
						x[2] = type;
						nDtate.push(x[1])
					})

					let num = 0, valuename = 0;

					for (var i = 0; i < nameTable.length; i++) {
						for (var j = valuename * datenum; j < nDtate.length; j++) {
							num += nDtate[j];
							if (j % datenum === 0 && j !== 0) {
								number.push({ key: i, value: num, name: nameTable[i] })
								num = 0;
								valuename++;
								break;
							} else if (j === (parseInt(nDtate.length) - 1)) {
								number.push({ key: i, value: num, name: nameTable[parseInt(nameTable.length) - 1] })
							}
						}
					}
					this.patrolData = number;

					let myChart = echarts.init(document.getElementById('DeviceWarningEcharts'));

					myChart.setOption({
						tooltip: {
							trigger: 'axis',
							axisPointer: {
								type: 'line',
								lineStyle: {
									color: 'rgba(0,0,0,0.2)',
									width: 1,
									type: 'solid'
								}
							}
						},

						legend: {
							data: nameArr
						},

						singleAxis: {
							top: 50,
							bottom: 50,
							axisTick: {},
							axisLabel: {},
							type: 'time',
							axisPointer: {
								animation: true,
								label: {
									show: true
								}
							},
							splitLine: {
								show: true,
								lineStyle: {
									type: 'dashed',
									opacity: 0.2
								}
							}
						},

						series: [
							{
								type: 'themeRiver',
								itemStyle: {
									emphasis: {
										shadowBlur: 20,
										shadowColor: 'rgba(0, 0, 0, 0.8)'
									}
								},
								data: dataYarr
							}
						]
					});
				})
			}),
			search: action(function (obj, befor, after) {
				let before, now, date, flag = 1, switcs = null,datenum;
				let dataArr = [];
				let number = [];
				window.rpc.alias.getValueByName('device.alarm.type').then(result => {
					return window.rpc.device.alarm.getTrendCountTypeByContainer({ createTime: [new Date(befor), new Date(after)] }, "date").then(data => { return { result, data } })
				}).then(ress => {
					const data = ress.result;
					const res = ress.data;
					const reduces = (new Date(after).getTime() - new Date(befor).getTime()) / 86400 / 1000;
					datenum=reduces;
					for (let i = reduces; i >= 0; i--) {
						(function () {
							dataArr.push(`${new Date(after).getFullYear()}-${(new Date(after).getMonth() + 1).toString().length === 1 ? '0' + (new Date(after).getMonth() + 1) : (new Date(after).getMonth() + 1)}-${((new Date(after).getDate() - i).toString().length === 1 ? '0' + (new Date(after).getDate() - i) : (new Date(after).getDate() - i))}`)
						})(i)
					}

					const dataYarr = [], arr = [], nameArr = [], dates = [], tableDate = [],nameTable=[];
					for (let i in res) {
						nameArr.push(res[i])
					}
					for (let j in data) {
						nameTable.push(data[j])
						dataArr.forEach((x, i) => {
							dataYarr.push([x, data[j]]);
						})
					}

					for (let i in data) {
						tableDate.push({ name: data[i], data: [] })
					}
					for (let i in res) {
						for (let j in data) {
							for (let z in res[i]) {
								if (z == j) arr.push({ name: i, value: res[i] })
								else arr.push({ name: j, value: { [j]: 0 } })
							}
						}
					}

					if (arr.length > 0) {
						arr.forEach((x, index) => {
							dataArr.forEach((y, i) => {
								if (dataArr[i] === arr[index].name) {
									for (let z in arr[index].value) {
										if (data[z] === tableDate[index].name) {
											tableDate[index].data.push(arr[index].value[z])
										} else {
											tableDate[index].data.push(0)
										}
									}
								} else {
									tableDate[index].data.push(0);
								}
							})
						})
					} else {
						tableDate.forEach((y, j) => {
							for (var i = 0; i < 7; i++) {
								tableDate[j].data.push(0);
							}
						})
					}

					if (arr.length > 0) {
						dataYarr.forEach((x, index) => {
							arr.forEach((y, i) => {
								if (y.name === x[0]) {
									for (let z in y.value) {
										if (data[z] === x[1]) {
											dataYarr[index].push(y.value[z])
											dates.push(y.value[z])
											break;
										} else {
											dataYarr[index].push(0)
											dates.push(0)
											break;
										}
									}
								} else {
									if (switcs !== index) {
										flag = 1;
									} else {
										flag = 0;
									}
									if (flag === 1) {
										dataYarr[index].push(0);
										dates.push(0)
									}
									switcs = index;
								}
							})
						})
					} else {
						dataYarr.forEach((y, i) => {
							dataYarr[i].push(0);
							dates.push(0)
						})
					}
					let nDtate = [];

					dataYarr.forEach((x, i) => {
						if (x.length > 3) {
							if (x[2] > 0) {
								x.splice(3, 1)
							} else {
								x.splice(2, 1)
							}
						}
						var type = x[1];
						x[1] = x[2];
						x[2] = type;
						nDtate.push(x[1])
					})

					let num = 0, valuename = 0;

					for (var i = 0; i < nameTable.length; i++) {
						for (var j = valuename * 7; j < nDtate.length; j++) {
							num += nDtate[j];
							if (j % 7 === 0 && j !== 0) {
								number.push({ key: i, value: num, name: nameTable[i] })
								num = 0;
								valuename++;
								break;
							} else if (j === (parseInt(nDtate.length) - 1)) {
								number.push({ key: i, value: num, name: nameTable[parseInt(nameTable.length) - 1] })
							}
						}
					}
					this.patrolData = number;
					let myChart = echarts.init(document.getElementById('DeviceWarningEcharts'));
					myChart.setOption({
						tooltip: {
							trigger: 'axis',
							axisPointer: {
								type: 'line',
								lineStyle: {
									color: 'rgba(0,0,0,0.2)',
									width: 1,
									type: 'solid'
								}
							}
						},

						legend: {
							data: nameArr
						},

						singleAxis: {
							top: 50,
							bottom: 50,
							axisTick: {},
							axisLabel: {},
							type: 'time',
							axisPointer: {
								animation: true,
								label: {
									show: true
								}
							},
							splitLine: {
								show: true,
								lineStyle: {
									type: 'dashed',
									opacity: 0.2
								}
							}
						},

						series: [
							{
								type: 'themeRiver',
								itemStyle: {
									emphasis: {
										shadowBlur: 20,
										shadowColor: 'rgba(0, 0, 0, 0.8)'
									}
								},
								data: dataYarr
							}
						]
					});
				})
			})
		})
	}
}



const WarningSearchForm = Form.create()(React.createClass({
	getInitialState() {
		return {
			size: "week"
		}
	},
	handleSearch(e) {
		e.preventDefault();
		let json, befor, after;
		try {
			this.props.form.validateFields((err, fieldsValue) => {
				const rangeValue = fieldsValue['field-5'];
				const values = {
					...fieldsValue,
					'field-5': [rangeValue[0].format('YYYY-MM-DD'), rangeValue[1].format('YYYY-MM-DD')]
				}
				json = { createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
				befor = rangeValue[0].format('YYYY-MM-DD');
				after = rangeValue[1].format('YYYY-MM-DD');
			});
			setTimeout(() => { this.props.deviceState.search(json, befor, after); }, 100)
			message.info('已更新');
		} catch (e) {
			console.log(e)
		}
	},
	onChange(e) {
		this.props.deviceState.addPatrol(e.target.value);
		this.setState({ size: e.target.value });
	},
	componentDidMount() {

	},
	render() {
		const { getFieldDecorator } = this.props.form;

		return (
			<Form layout="inline" style={{ margin: 10 }} className="deivceWarnning">
				<Row>
					<Col style={{ float: 'left', marginRight: 20 }} key={1}>
						<Radio.Group onChange={this.onChange} type="card" value={this.state.size}>
							<Radio.Button value="week">周</Radio.Button>
							<Radio.Button value="month">月</Radio.Button>
							<Radio.Button value="seacon">季</Radio.Button>
						</Radio.Group>

					</Col>
					<Col style={{ float: 'left' }} key={2}>
						<FormItem label={`时间`}>
							{getFieldDecorator(`field-5`)(
								<RangePicker style={{ width: 200 }} />
							)}
						</FormItem>
					</Col>
					<Col span={1} key={3} style={{ float: 'left' }}>
						<FormItem>
							<Button
								type="primary"
								onClick={this.handleSearch}
							>
								搜索
              				</Button>
						</FormItem>
					</Col>
				</Row>
			</Form>
		);
	}
}));

@observer
class DeviceWarningC extends Component {
	constructor() {
		super();
		this.state = {
			size: 'default',
			data: []
		};
	}
	componentWillMount() {

	}
	componentDidMount() {
		let flag = 1, switcs = null;
		const before = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate() - 6);
		const now = moment(new Date()).format('YYYY-MM-DD')
		let number = [];
		window.rpc.alias.getValueByName('device.alarm.type').then(result => {
			return window.rpc.device.alarm.getTrendCountTypeByContainer({ createTime: [new Date(before), new Date(now)] }, 'date').then(data => { return { result, data } })
		}).then(ress => {
			const data = ress.result;
			const res = ress.data;
			const dataYarr = [], arr = [], nameArr = [], dates = [], tableDate = [], dataArr = [], nameTable = [];
			for (let i in res) {
				nameArr.push(res[i])
			}

			for (let i = 6; i >= 0; i--) {
				(function () {
					dataArr.push(`${new Date().getFullYear()}-${(new Date().getMonth() + 1).toString().length === 1 ? '0' + (new Date().getMonth() + 1) : (new Date().getMonth() + 1)}-${((new Date().getDate() - i).toString().length === 1 ? '0' + (new Date().getDate() - i) : (new Date().getDate() - i))}`)
				})(i)
			}

			for (let j in data) {
				nameTable.push(data[j])
				dataArr.forEach((x, i) => {
					dataYarr.push([x, data[j]]);
				})
			}

			for (let i in res) {
				for (let j in data) {
					for (let z in res[i]) {
						if (z == j) arr.push({ name: i, value: res[i] })
						else arr.push({ name: j, value: { [j]: 0 } })
						tableDate.push({ name: data[i], data: [] })
					}
				}
			}

			if (arr.length > 0) {
				dataYarr.forEach((x, index) => {
					arr.forEach((y, i) => {
						if (y.name === x[0]) {
							for (let z in y.value) {
								if (data[z] === x[1]) {
									dataYarr[index].push(y.value[z])
									break;
								} else {
									dataYarr[index].push(0)
									break;
								}
							}
						} else {
							if (switcs !== index) {
								flag = 1;
								dataYarr[index].push(0);
							} else {
								flag = 0;
							}
							switcs = index;
						}
					})
				})
			} else {
				dataYarr.forEach((y, i) => {
					dataYarr[i].push(0);
				})
			}

			//时间组成方法
			let nDtate = [];

			dataYarr.forEach((x, i) => {
				if (x.length > 3) {
					if (x[2] > 0) {
						x.splice(3, 1)
					} else {
						x.splice(2, 1)
					}
				}
				var type = x[1];
				x[1] = x[2];
				x[2] = type;
				nDtate.push(x[1])
			})
			let num = 0, valuename = 0;

			for (var i = 0; i < nameTable.length; i++) {
				for (var j = valuename * 7; j < nDtate.length; j++) {
					num += nDtate[j];
					if (j % 7 === 0 && j !== 0) {
						number.push({ key: i, value: num, name: nameTable[i] })
						num = 0;
						valuename++;
						break;
					} else if (j === (parseInt(nDtate.length) - 1)) {
						number.push({ key: i, value: num, name: nameTable[parseInt(nameTable.length) - 1] })
					}
				}
			}
			this.props.deviceState.patrolData = number;

			let myChart = echarts.init(document.getElementById('DeviceWarningEcharts'));

			myChart.setOption({
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'line',
						lineStyle: {
							color: 'rgba(0,0,0,0.2)',
							width: 1,
							type: 'solid'
						}
					}
				},

				legend: {
					data: nameArr
				},

				singleAxis: {
					top: 50,
					bottom: 50,
					axisTick: {},
					axisLabel: {},
					type: 'time',
					axisPointer: {
						animation: true,
						label: {
							show: true
						}
					},
					splitLine: {
						show: true,
						lineStyle: {
							type: 'dashed',
							opacity: 0.2
						}
					}
				},

				series: [
					{
						type: 'themeRiver',
						itemStyle: {
							emphasis: {
								shadowBlur: 20,
								shadowColor: 'rgba(0, 0, 0, 0.8)'
							}
						},
						data: dataYarr
					}
				]
			});
		},err=>{
			 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
	})

	}

	render() {
		return (
			<div className="DeviceWarning" style={{ padding: '5px' }}>
				<WarningSearchForm deviceState={this.props.deviceState} />
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>报警统计占比</p>
					<div id="DeviceWarningEcharts" style={{ height: '50vh', width: '100%', borderTop: "1px solid #ccc" }}></div>
				</Row>
				<Row style={{ padding: '5px 0' }} gutter={16}>
					<p style={{ marginTop: 16, marginBottom: 10, fontSize: 12, color: "#111", fontFamily: "PingFang-SC-Medium" }}>报警统计占比</p>
					<Table bordered dataSource={[...this.props.deviceState.patrolData]} columns={columns} pagination={false} />
				</Row>
			</div>
		);
	}
}

class DeviceWarning extends Component {
	render() {
		return (
			<DeviceWarningC deviceState={new deviceState()} />
		)
	}
}

export default DeviceWarning;