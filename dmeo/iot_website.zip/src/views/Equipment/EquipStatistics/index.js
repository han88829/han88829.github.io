import React, { Component } from 'react';
import { Tabs, Icon } from 'antd';
import { Link, browserHistory } from 'react-router';
import DeviceBuildingMount from './containers/DeviceBuildingMount';
import DevicePatrol from './containers/DevicePatrol';
import DeviceStateMount from './containers/DeviceStateMount';
import DeviceTrend from './containers/DeviceTrend';
import DeviceTypeMount from './containers/DeviceTypeMount';
import DeviceWarning from './containers/DeviceWarning';
import './equipStatistics.css';

const { TabPane } = Tabs;

class EquipStatistics extends Component {
  render() {
    return (
      <div className="EquipStatistics" style={{ padding:'0 12px' }}>
        <Tabs defaultActiveKey="1"  style={{fontSize:'0.75em' }} className='infoTabOne'>
          <TabPane tab={<span><Icon type="info-circle-o" />数量统计</span>} key="1">
            <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/equip/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75em',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>设备统计</Link>
            </div>
            <Tabs tabPosition="top" type="card" className='infoTabTwo' >
              <TabPane tab="设备类型" key="1">
                <DeviceTypeMount />
              </TabPane>
              <TabPane tab="所属建筑" key="2">
                <DeviceBuildingMount />
              </TabPane>
              <TabPane tab="设备状态" key="3">
                <DeviceStateMount />
              </TabPane>
            </Tabs>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />报警统计</span>} key="2">
            <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/equip/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75em',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>设备统计</Link>
            </div>
            <DeviceWarning />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />趋势分析</span>} key="3">
            <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/equip/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75em',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>设备统计</Link>
            </div>
            <DeviceTrend />
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />巡查统计</span>} key="4">
            <div style={{position:'absolute',left:0,top:10,width:75,height:'32px',linHeight:'32px',zIndex:99,backgroundColor:'#fff'}}>
              <Link to='/equip/stati' style={{padding: '2px 12px 2px 10px', margin:'8px 0',fontSize:'0.75em',color:'#373e41',borderLeft:'2px solid #88b7e0'}}>设备统计</Link>
            </div>
            <DevicePatrol />
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

export default EquipStatistics;