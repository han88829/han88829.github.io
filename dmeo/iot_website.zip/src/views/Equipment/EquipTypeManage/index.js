/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:47 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:26:26
 */
import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable } from 'mobx';//, action 
import { observer } from 'mobx-react';
import { Table, Row, Col, Button } from 'antd';
import './equipTypeManage.css';

const columns = [
  { title: '序号', dataIndex: 'id', key: 'id' },
  { title: '类型名称', dataIndex: 'name', key: 'name' },
  {
    title: '操作', key: 'operation', render: (record) =>
      <div>
        <Link to={`/equip/type/${record.key}`} style={{ marginRight: "10px" }}>详情</Link>
        <Link to={`/equip/type/edit/${record.key}`}>编辑</Link>
      </div>
  },
];
class typeState {
  constructor() {
    extendObservable(this, {
      types: [],
    })
  }
}

const EquipTypeManageC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      types: [],
      dataList: [],
      loopList: [],
      data: []
    };
  }

  onSelect(info) {
  }

  onCheck(info) {
  }

  onSearch(info) {
    this.props.typeState.onSearch(info);
  }

  componentDidMount() {
    function pushChildren(data) {
      let arr = [...data];
      let layer = arr.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = arr.filter(x => x.layer === layer);
      let layerUp = arr.filter(x => x.layer !== layer);
      for (let i = 0; i < layerUp.length; i++) {
        for (let j = 0; j < layerNow.length; j++) {
          if (layerNow[j].parentId === layerUp[i].id) {
            if (layerUp[i].children) {
              layerUp[i].children.push({ ...layerNow[j] });
            } else {
              layerUp[i].children = [{ ...layerNow[j] }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        pushChildren(layerUp);
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let proper = '';
      res.forEach(function (value) {
        value.flags.forEach(function (x) {
          proper += `${x.name}${x.unit}`
        })
      })

      let tableDate = res.map(x => ({ ...x, key: x.id, flags: proper }));
      pushChildren(tableDate)
      this.setState({
        data: tableDate
      })
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })

  }

  render() {
    return (
      <div className="typeManage" style={{ padding: 0 }}>
        <div style={{ fontSize: '0.75rem', overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>类型管理</Link>
          </div>
          <div style={{ float: 'left', height: 32, marginRight: 4 }}>
            <Button type="" style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="/equip/type/new">新增类型</Link></Button>
          </div>
        </div>
        <Row>
          <Col span={24}>
            <Table
              columns={columns}
              dataSource={this.state.data.filter(x => x.layer === 1)}
            />
          </Col>
        </Row>
      </div>
    )
  }
})

class EquipTypeManage extends Component {
  render() {
    return (
      <EquipTypeManageC typeState={new typeState()} />
    )
  }
}

export default EquipTypeManage;