/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:17 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-06-13 13:28:04
 */
import React from 'react';
import { Input, Button, Form, TreeSelect, message, Row, Col, Table, Icon, Popconfirm, Checkbox } from 'antd';
import { Link } from 'react-router';

const FormItem = Form.Item;
class EditableCell extends React.Component {
  state = {
    value: this.props.value,
    editable: false,
  }
  handleChange = (e) => {
    const value = e.target.value;
    this.setState({ value });
  }
  check = () => {
    this.setState({ editable: false });
    if (this.props.onChange) {
      this.props.onChange(this.state.value);
    }
  }
  edit = () => {
    this.setState({ editable: true });
  }
  render() {
    const { value, editable } = this.state;
    return (
      <div className="editable-cell">
        {
          editable ?
            <div className="editable-cell-input-wrapper">
              <Input
                value={value}
                onChange={this.handleChange}
                onPressEnter={this.check}
              />
              <Icon
                type="check"
                className="editable-cell-icon-check"
                onClick={this.check}
              />
            </div>
            :
            <div className="editable-cell-text-wrapper">
              {value || ' '}
              <Icon
                type="edit"
                className="editable-cell-icon"
                onClick={this.edit}
              />
            </div>
        }
      </div>
    );
  }
}

class EditableTable extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [{
      title: '名称',
      dataIndex: 'name',
      width: '30%',
      render: (text, record, index) => (
        <EditableCell
          value={text}
          onChange={this.onCellChange(index, 'name')}
        />
      ),
    }, {
      title: '单位',
      dataIndex: 'unit',
      render: (text, record, index) => (
        <EditableCell
          value={text}
          onChange={this.onCellChange(index, 'unit')}
        />
      ),
    }, {
      title: '单值打勾,区域值不勾',
      dataIndex: 'single',
      render: (text, record, index) => (
        <Checkbox onChange={this.onCellChange(index, 'single')} style={{ marginLeft: "50%" }} checked={this.state.dataSource[index].single}></Checkbox>
      ),
    }, {
      title: '操作',
      dataIndex: 'operation',
      render: (text, record, index) => {
        return (
          this.state.dataSource.length > 0 ?
            (
              <Popconfirm title="Sure to delete?" onConfirm={() => this.onDelete(index)}>
                <a href="#">删除</a>
              </Popconfirm>
            ) : null
        );
      },
    }];

    this.state = {
      dataSource: [{
        single: ""
      }],
      count: 2,
    };
  }
  componentDidMount() {
    var str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = Number(str.substring(index + 1, str.length));
    window.rpc.device.types.getInfoExById(str).then((res) => {
      let sing = "";
      res.flags.forEach(function (value) {
        if (value.single === 1) {
          sing = 'checked';
        } else {
          sing = '';
        }
        value.single = sing;
        delete value.createTime
      })
      setTimeout(() => {
        let flags = res.flags.map(x => ({ ...x, key: x.id }))
        this.setState({
          dataSource: flags
        })
      }, 300)
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  onCellChange = (index, key) => {
    return (value) => {
      const dataSource = [...this.state.dataSource];
      let daChecked = "";
      dataSource[index][key] = value;
      if (key === 'single') {
        if (value.target.checked) {
          daChecked = 'checked'
        } else {
          daChecked = ''
        }
        dataSource[index][key] = daChecked;
      }
      this.setState({ dataSource });
      var newObj, sing = "";
      newObj = (JSON.parse(JSON.stringify(dataSource)) || {});
      for (var i = 0; i < newObj.length; i++) {
        if (newObj[i].single !== "1") {
          if (newObj[i].single === 'checked') {
            sing = 1;
          } else {
            sing = 0;
          }
        } else {
          sing = 0;
        }
        newObj[i].single = sing;
        delete newObj[i].key
      }
      setTimeout(() => {
        sessionStorage.setItem('datasource', JSON.stringify(newObj))
      }, 300)
    };
  }
  onDelete = (index) => {
    const dataSource = [...this.state.dataSource];
    dataSource.splice(index, 1);
    this.setState({ dataSource });
    var newObj, sing = "";
    newObj = (JSON.parse(JSON.stringify(dataSource)) || {});
    for (var i = 0; i < newObj.length; i++) {
      if (newObj[i].single !== "1") {
        if (newObj[i].single.target) {
          if (newObj[i].single.target.checked) {
            sing = 1;
          } else {
            sing = 0;
          }
        }
      } else {
        sing = 0;
      }

      newObj[i].single = sing;
      delete newObj[i].key;
    }
    setTimeout(() => {
      sessionStorage.setItem('datasource', JSON.stringify(newObj))
    }, 300)

  }
  handleAdd = () => {
    const { count, dataSource } = this.state;
    const newData = {
      key: count,
      name: "请输入名字",
      unit: "请输入单位",
      single: "1",
    };
    this.setState({
      dataSource: [...dataSource, newData],
      count: count + 1,
    });

  }
  render() {
    const { dataSource } = this.state;
    const columns = this.columns;
    return (
      <div>
        <Button className="editable-add-btn" onClick={this.handleAdd}>添加</Button>
        <Table bordered dataSource={dataSource} columns={columns} />
      </div>
    );
  }
}

const EditTypes = Form.create()(React.createClass({
  getInitialState() {
    return {
      value: undefined,
      types: [],
      mine: {},
      data: []
    };
  },
  componentDidMount() {
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];
      let layerNow = data.filter(x => x.layer === layer);
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId === layerUp[j].id) {
            if (layerUp[j].children) {
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
            } else {
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    const id = parseInt(this.props.params.id, 10);
    window.rpc.device.types.getInfoExById(id).then((res) => {
      for (var i = 0; i < res.flags.length; i++) {
        delete res.flags[i].createTime;
      }
      this.setState({
        mine: res
      })
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [{ key: 100, label: "无", value: 100, id: 100 }];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      let mine = res.filter(x => x.id === id)[0];
      loop(tableDate);
      window.rpc.device.types.getInfoExById(mine.parentId).then((result) => {
        this.props.form.setFieldsValue({
          name: mine.name,
          parentId: mine.parentId
        });
        this.setState({
          value: result.name
        })
      }, (err) => {
        console.warn(err);
      })
      this.setState({ types, data: tableDate });
    }, (err) => {

    })
  },
  handleSubmit(e) {
    this.props.form.setFieldsValue({
      flags: JSON.parse(sessionStorage.getItem('datasource')) || []
    })
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        let obj = { ...this.state.mine, name: values.name, flags: values.flags, parentId: parseInt(values.parentId, 10) }
        delete obj.createTime;
        window.rpc.device.types.setInfoById(this.state.mine.id, obj).then(() => {
          message.info('修改成功！')
          setTimeout(function () {
            window.location.href = '/equip/type/manage';
          }, 1000)
        }, (err) => {
          console.warn(err);
           function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){   message.info(`暂无权限!`);  }    } existError(err);
        })
      }
    });
  },
  onChange(value) {
    this.setState({ value });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 1 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    return (
      <div>
        <div style={{ fontSize: '0.75em', overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75em', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>类型编辑</Link>
          </div>
        </div>
        <Row>
          <Col span={2}></Col>
          <Col span={22}>
            <Form onSubmit={this.handleSubmit} className="NewTypes" style={{ padding: 24 }}>
              <FormItem
                {...formItemLayout}
                label="上级类型"
              >
                {getFieldDecorator('parentId', {
                  valuePropName: 'checked',
                  initialValue: undefined,
                  rules: [{ required: true, message: 'Please input your username!' }]
                })(
                  <TreeSelect
                    style={{ width: 300 }}
                    value={this.state.value}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.data.filter(x => x.layer === 1)}
                    placeholder="Please select"
                    treeDefaultExpandAll
                    onChange={this.onChange}
                  />
                  )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="名称"
              >
                {getFieldDecorator('name', {
                  rules: [{ required: true, message: 'Please input your username!' }],
                })(
                  <Input />
                  )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="属性"
              >
                {getFieldDecorator('flags', {
                  rules: [{ required: true, message: 'Please input your username!' }],
                })(
                  <EditableTable />
                  )}
              </FormItem>
              <FormItem
                {...tailFormItemLayout}
              >
              </FormItem>
              <Row style={{ marginTop: 400, marginLeft: 76 }}>
                <Button type="primary" htmlType="submit">保存</Button>
                <Button type="success" style={{ marginLeft: 10 }}><Link to="/equip/type/manage">返回</Link></Button>
              </Row>
            </Form>
          </Col>
        </Row>
      </div>
    );
  },
}));

export default EditTypes;
