/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:53:15 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:53:15 
 */

import React, { Component } from 'react';
import { Input, Button, Form, TreeSelect, Select, DatePicker,  Row, Col, InputNumber } from 'antd';
import { Link } from 'react-router';
const FormItem = Form.Item;
const RangePicker = DatePicker.RangePicker;
const Option = Select.Option;

const treeData = [{
  label: 'Node1',
  value: '0-0',
  key: '0-0',
  children: [{
    label: 'Child Node1',
    value: '0-0-0',
    key: '0-0-0',
  }],
}, {
  label: 'Node2',
  value: '0-1',
  key: '0-1',
  children: [{
    label: 'Child Node3',
    value: '0-1-0',
    key: '0-1-0',
  }, {
    label: 'Child Node4',
    value: '0-1-1',
    key: '0-1-1',
  }, {
    label: 'Child Node5',
    value: '0-1-2',
    key: '0-1-2',
    
  }],
}];


class EquipInspectTaskNew extends Component {
 
 

  render() {

    return (
      <div className="EquipInspectTaskNew">
            <InspectTaskNew  />
      </div>
    );
  }
}

const InspectTaskNew = Form.create()(React.createClass({
   getInitialState() {
    return {
    };
  },
  handleSubmit(e) {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
   const rangeConfig = {
      rules: [{ type: 'array', required: true, message: 'Please select time!' }],
    };
    return (
   <Form onSubmit={this.handleSubmit} style={{fontSize:'12px'}}>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
                label="周期计划标题"
                style={{fontSize:'16px',color:'#555'}}
            >
              {getFieldDecorator('fffff', {
                rules: [{ required: true, message: '请输入周期计划标题！' }],
              })(
                <Input type="textarea" size="large" defaultValue={`周期计划标题{item.id}`} style={{height:'40px'}}/>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
                 label="周期计划说明"
            >
              {getFieldDecorator('aaa', {
                 rules: [{ required: true, message: 'Please input the captcha you got!' }],
               })(
                <Input type="textarea"  size="large"  placeholder="请输入周期计划说明" autosize={{ minRows: 2, maxRows: 6 }} />
               )}
             </FormItem>
           </Col>
         </Row>
         <Row>
           <Col span={12}>
             <FormItem
               {...formItemLayout}
               label="审核方式"
              >
               {getFieldDecorator('mothod', {
                  rules: [{ required: true, message: '请输入审核方式!' }],
                  onChange: this.handleSelectChange,
               })(
                 <Select placeholder="请输入审核方式">
                   <Option value="系统">系统</Option>
                   <Option value="人工">人工</Option>
                 </Select>
               )}
             </FormItem>
           </Col>
         </Row>
         <Row>
           <Col span={12}>
             <FormItem
               {...formItemLayout}
               label="是否启用该计划"
             >
               {getFieldDecorator('yoro', {
                  rules: [{ required: true, message: '选择是否启用' }],
                  onChange: this.handleSelectChange,
               })(
                 <Select placeholder="">
                   <Option value="是">是</Option>
                   <Option value="否">否</Option>
                 </Select>
               )}
             </FormItem>
           </Col>
           <Col span={12}>
             <FormItem
               {...formItemLayout}
               label="巡检人选择方式"
              >
                {getFieldDecorator('checkMen', {
                  rules: [{ required: true, message: '请选择巡检人' }],
                  onChange: this.handleSelectChange,
                })(
                  <Select placeholder="请选择巡检人">
                    <Option value="自动分配">自动分配</Option>
                    <Option value="巡查员a">巡查员a</Option>
                    <Option value="巡查员b">巡查员b</Option>
                    <Option value="巡查员c">巡查员c</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12}>
              <FormItem
               {...formItemLayout}
               label="计划开始时间"
              >
                {getFieldDecorator('range-picker', rangeConfig)(
                  <RangePicker />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="计划结束时间"
              >
                {getFieldDecorator('range-picker-2', rangeConfig)(
                  <RangePicker />
                )}
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span={12} style={{textAlign:'center'}}>
              <Row>
                <Col span={8} style={{textAlign:'center'}}>  
                  <FormItem
                    {...formItemLayout}
                    label="巡检周期设定："
                    labelCol={{ span: 18 }}
                    wrapperCol={{ span: 2}}
                  >
                    {getFieldDecorator('bbb', {
                    rules: [{ required: true, message: 'Please input the captcha you got!' }],
                    })(
                     <InputNumber />
                    )}
                  </FormItem>
                </Col>
                <Col span={10}>  
                  <FormItem
                    {...formItemLayout}
                  >
                  {getFieldDecorator('timeType', {
                    rules: [{ required: true, message: '时间类型' }],
                    onChange: this.handleSelectChange,
                  })(
                    <Select placeholder="" style={{width:100}}>
                      <Option value="天">天</Option>
                      <Option value="周">周</Option>
                      <Option value="月">月</Option>
                      <Option value="年">年</Option>
                   </Select>
                 )}
               </FormItem>  
             </Col>
           </Row> 
         </Col>
         <Col span={12}>
           <FormItem
             {...formItemLayout}
             label="报表选择"
           >
             {getFieldDecorator('tableType', {
               rules: [{ required: true, message: 'Please select your table!' }],
               onChange: this.handleSelectChange,
             })(
              <Select placeholder="select table">
                <Option value="总表">总表</Option>
                <Option value="分表">分表</Option>
              </Select>
             )}
           </FormItem>
         </Col>
       </Row>
       <Row>
         <Col span={3} style={{textAlign:'right'}}>
           <span>巡检设备选择：</span>
        </Col>
        <Col span={21}  style={{textAlign:'left'}}>
          <Row>
            <Col span={20} style={{textAlign:'left'}}>
              <FormItem
                {...formItemLayout}
                label="类型选择"
                labelCol={{ span: 2 }}
                wrapperCol={{ span: 2}}
              >
              {getFieldDecorator('kindSelect', {
                valuePropName: 'checked',
                initialValue: undefined,
                rules: [{ required: true, message: '' }]
              })(
                <TreeSelect
                  treeData={treeData}
                  style={{ width: 300 }}
                 //value={this.state.value}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  placeholder="Please select"
                  treeDefaultExpandAll
                  onChange={this.onChange}
                  treeCheckable
                  multiple
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={20} style={{textAlign:'left'}}>
            <FormItem
              {...formItemLayout}
                label="建筑选择"
                labelCol={{ span: 2 }}
                wrapperCol={{ span: 2}}
            >
             {getFieldDecorator('buildingSelection', {
               valuePropName: 'checked',
               initialValue: undefined,
               rules: [{ required: true, message: '' }]
              })(
                <TreeSelect
                  treeData={treeData}
                  style={{ width: 300 }}
                  //value={this.state.value}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  placeholder="Please select"
                  treeDefaultExpandAll
                  onChange={this.onChange}
                  treeCheckable
                  multiple  
                 />
               )}
             </FormItem>
           </Col>
         </Row>
       </Col>
      </Row>
      <Row>
          <Col span={12}>
            <FormItem {...tailFormItemLayout}>
              <Button type="primary" htmlType="submit" size="large">新增</Button>
            </FormItem>
         </Col>
         <Col span={12}>
            <FormItem {...tailFormItemLayout}>
              <Button type="success"><Link to="/equipment/equiptask">返回</Link></Button>
            </FormItem>
         </Col>
        </Row>
    </Form>
   );
  },
}));


export default EquipInspectTaskNew;