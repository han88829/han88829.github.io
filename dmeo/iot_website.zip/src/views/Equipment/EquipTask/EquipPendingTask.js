/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:53:20 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:53:20 
 */

import React, { Component } from 'react';
import EquipTaskPendTr from './containers/EquipTaskPendTr.js';
import './containers/EquipTaskPend.css';


class EquipPendingTask extends Component {
  render() {
    return (
      <div className="EquipPendingTask">
          <EquipTaskPendTr/>
      </div>
    );
  }
}

export default EquipPendingTask;