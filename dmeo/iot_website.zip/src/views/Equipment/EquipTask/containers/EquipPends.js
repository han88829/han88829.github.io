/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:52:18 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:52:18 
 */

import React from 'react';
import { Radio } from 'antd';

const RadioGroup = Radio.Group;
let result=0;
const EquipPends = React.createClass({
  getInitialState() {
    return {
      value: result
    };
  },
  onChange(e) {
    var that=this;
    this.setState({
      value: e.target.value,
    },function(){
         result=that.state.value;
         return result
    })      
  },
  render() {
    return (
      <div className="ant-table">
        <div className="ant-inspect">
            <span className="inspect">审核</span>
            <span className="inspect">
            <RadioGroup onChange={this.onChange} value={this.state.value}>
                <Radio value={1}>通过</Radio>
                <Radio value={2}>不通过</Radio>
            </RadioGroup>
            </span>
        </div>
      </div>
    );
  },
});

export  {EquipPends,result};


