/*
 * @Author: lai.haibo 
 * @Date: 2017-03-17 15:53:27 
 * @Last Modified by:   lai.haibo 
 * @Last Modified time: 2017-03-17 15:53:27 
 */

import React from 'react';
import { Form, Input, Cascader, Select, DatePicker, Row, Col,Button } from 'antd';
import { Link } from 'react-router';
import moment from 'moment';

const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;
const equipTypes = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const builds = [{
  value: '选项一',
  label: '选项一',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    },{
      value: '选项二',
      label: '选项二',
    }],
  }],
}, {
  value: '选项二',
  label: '选项二',
  children: [{
    value: '选项一',
    label: '选项一',
    children: [{
      value: '选项一',
      label: '选项一',
    }],
  }],
}];

const EquipRandomTaskDetail = Form.create()(React.createClass({
 
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    // const config = {
    //   rules: [{ type: 'array', required: true, message: '请选择时间!' }],
    // };
    //const dateFormat = 'YYYY-MM-DD';

    return (
      <Form onSubmit={this.handleSubmit}>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务标题："
              hasFeedback
            >
              {getFieldDecorator('name', {
                initialValue: '标题',
                rules: [{ type: 'string',required: true, message: '请输入任务标题!' }],
              })(
                <Input disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检任务说明："
              hasFeedback
            >
              {getFieldDecorator('task', { 
                initialValue:  "第一次抽检",
                rules: [{ required: true, message: '请输入任务说明!' }],
              })(
                <Input type="textarea" rows={3} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
         <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="审核方式选择："
              hasFeedback
            >
              {getFieldDecorator('auditMethon', {
                initialValue:  "人工",
                rules: [
                  { type:'string', required: true, message: '请选择审核方式！' },
                ],
              })(
                <Select  disabled>
                  <Option value="1">系统</Option>
                  <Option value="2">人工</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="任务开始--截至时间："
            >
                <RangePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder={['开始时间', '截至时间']}
                  disabled
                  defaultValue={[moment('2015-09-26 08:50:08'), moment('2015-09-26 08:50:08')]}
                  /*onChange={onChange}*/
                />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="巡检人选择："
              hasFeedback
            >
              {getFieldDecorator('Inspectors', {
                initialValue:  "自动分配",
                rules: [
                  { type:'string', required: true, message: '请选择巡检人！' },
                ],
              })(
                <Select disabled>
                  <Option value="1">自动分配</Option>
                  <Option value="2">巡检员1</Option>
                  <Option value="3">巡检员2</Option>  
                  <Option value="4">巡检员3</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检报表选择"
              hasFeedback
            >
              {getFieldDecorator('report', {
                initialValue:  "总表",
                rules: [
                  { type:'string', required: true, message: '请选择报表方式！' },
                ],
              })(
                <Select disabled>
                  <Option value="1">总表</Option>
                  <Option value="2">分表</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备类型选择："
            >
              {getFieldDecorator('equipType', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{ type: 'array', required: true, message: '请选择类型!' }],
              })(
                <Cascader options={equipTypes} disabled />
              )}
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              {...formItemLayout}
              label="抽检设备建筑选择："
            >
              {getFieldDecorator('build', {
                initialValue: ['选项一', '选项一', '选项一'],
                rules: [{ type: 'array', required: true, message: '请选择建筑!' }],
              })(
                <Cascader options={builds} disabled />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span={12}>
            <FormItem {...tailFormItemLayout}>
              <Button type="primary" size="large"><Link to="/equipment/equiprandomtaskedit/:id">修改</Link></Button>
            </FormItem>
         </Col>
        <Col span={12}>
            <FormItem {...tailFormItemLayout}>
              <Button type="success"><Link to="/equipment/equiptask">返回</Link></Button>
            </FormItem>
         </Col>
        </Row>
      </Form>
    );
  },
}));

export default EquipRandomTaskDetail;