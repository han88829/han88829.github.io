/*
 * @Author: cai.jiadi 
 * @Date: 2017-03-17 15:53:49 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-08-01 14:58:05
 */

import React, { Component } from 'react';
import { Link } from 'react-router';
import { extendObservable, action } from 'mobx';
import { observer } from 'mobx-react';
import { Menu, Row, Col, Table, Button, Form, Input, Icon, DatePicker, Select, message, Dropdown } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;
class equipTaskState {
  constructor() {
    extendObservable(this, {
      tableData: []
    })
  }
}
class Drown extends React.Component {
  handleMenuClick(e) {
    message.info('Click on menu item.');
    console.log('click', e);
  }
  render() {
    const menu = (
      <Menu onClick={this.handleMenuClick}>
        <Menu.Item key="1">查看</Menu.Item>
        <Menu.Item key="2">编辑</Menu.Item>
        <Menu.Item key="3">停用</Menu.Item>
      </Menu>
    );
    return (
      <div style={{ marginBottom: 20,float:"left",width:"100%"}}>
        <div>共搜索到 922 条数据</div>
        <Button style={{float:"left",marginTop:10, marginLeft: 10}}>批量操作</Button>
        <Dropdown overlay={menu}>
          <Button style={{ marginLeft: 8 ,float:"left",marginTop:10}}>
            更多操作 <Icon type="down" />
          </Button>
        </Dropdown>
        <span style={{float:"right",marginRight:60,padding:"8px 12px",border:"1px solid #ccc",borderRadius:10}}>已经选择5项选择</span>
      </div>
    )
  }
}
class AdvancedSearchForm extends React.Component {
  componentDidMount() {
    // window.rpc.alias.getValueByName('device.rstate').then((res) => {
    //   console.log(res)
    //   for (let value in res) {
    //     rStateChildren.push(<Option key={`${value}`}>{res[value]}</Option>)
    //     rState[value] = res[value];
    //     rState[res[value]] = value;
    //   }
    // })
  }
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        const name = fieldsValue['name'];
        const dtype = fieldsValue['dtype'];
        const location = fieldsValue['location'];
        const dstate = fieldsValue['state'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        //设备类型
        if (dtype) {
          values = { ...values, dtype: fieldsValue['dtype'].map(x => parseInt(x, 10)) }
        }
        //运行状态
        if (dstate) {
          values = { ...values, dstate: fieldsValue['dstate'].map(x => parseInt(x, 10)) }
        }
        //所属建筑
        if (location) {
          values = { ...values, location: fieldsValue['location'].map(x => x) }
        }

        if (rangeValue) {
          values = { ...values, setupTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))] }
        }


        console.log('Received values of form: ', values);

        window.rpc.device.getArrayBriefByCondContainer({}, values, 0, 0).then((result) => {
          console.log(result);
          message.info(`共搜索到${result.length}条数据`);
          let devi = result.map((x) => ({ ...x, dtype: x.name, location: x.location, key: x.id, rstate: 1, setupTime: moment(x.setupTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
          // number = devi.length;
          this.props.appState.tableData = devi;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={4} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 200 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={4} key={2}>
            <FormItem label={`类型`}>
              {getFieldDecorator(`dtype`)(
                <Select multiple style={{ width: 200 }} placeholder="请选择">

                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={3}>
            <FormItem label={`状态`}>
              {getFieldDecorator(`dstate`)(
                <Select multiple style={{ width: 200 }} placeholder="请选择">

                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={4} key={4}>
            <FormItem label={`联系人`}>
              {getFieldDecorator(`location`)(
                <Select multiple style={{ width: 200 }} placeholder="请选择">

                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={6} key={5}>
            <FormItem label={`截止时间`}>
              {getFieldDecorator(`expireTime`)(
                <RangePicker style={{ width: 200 }} />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
class EquipList extends React.Component {
  expandedRowRender = () => {
    const columns = [{
      title: '名称',
      dataIndex: 'name',
    }, {
      title: '类型',
      dataIndex: 'type',
    }, {
      title: '安装日期',
      dataIndex: 'setupTime',
    }, {
      title: '安装位置',
      dataIndex: 'location',
    }, {
      title: '是否执行',
      dataIndex: 'execute',
    }
      , {
      title: '操作',
      dataIndex: 'operation',
    }
    ];

    const data = [];
    for (let i = 56; i < 80; i++) {
      data.push({
        key: i,
        name: `Edward King ${i}`,
        type: 32,
        setupTime: `London, Park Lane no. ${i}`,
        location: 213,
        execute: 213,
        operation: 123
      });
    }
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      selections: [{
        key: 'odd',
        text: 'Select Odd Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((key, index) => {
            if (index % 2 !== 0) {
              return false;
            }
            return true;
          });
          this.setState({ selectedRowKeys: newSelectedRowKeys });
        },
      }, {
        key: 'even',
        text: 'Select Even Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((key, index) => {
            if (index % 2 !== 0) {
              return true;
            }
            return false;
          });
          this.setState({ selectedRowKeys: newSelectedRowKeys });
        },
      }],
      onSelection: this.onSelection,
    };
    return (
      <Table rowSelection={rowSelection} columns={columns} dataSource={data} />
    );
  }
  state = {
    selectedRowKeys: [],  // Check here to configure the default column
  };
  componentWillMount() {

  }
  onSelectChange = (selectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    this.setState({ selectedRowKeys });
  }
  render() {
    const columns = [{
      title: '序号',
      dataIndex: 'id',
    }, {
      title: '名称',
      dataIndex: 'name',
    }, {
      title: '类型',
      dataIndex: 'type',
    }, {
      title: '创建日期',
      dataIndex: 'setupTime',
    }, {
      title: '截止日期',
      dataIndex: 'expireTime',
    }, {
      title: '状态',
      dataIndex: 'state',
    }, {
      title: '联系人',
      dataIndex: 'contact',
    }, {
      title: '操作',
      dataIndex: 'operation',
      render: (text, record) => (
        <span>
          <Link to='' style={{marginRight:10}}>查看</Link>
          <Link to='' style={{marginRight:10}}>编辑</Link>
          <Link to='' >停用</Link>
        </span>
      )
    }
    ];

    const data = [];
    for (let i = 0; i < 46; i++) {
      data.push({
        key: i,
        id: i,
        name: `Edward King ${i}`,
        type: 32,
        setupTime: `London, Park Lane no. ${i}`,
        expireTime: `London, Park Lane no. ${i}`,
        state: 213,
        contact: 213,
        operation: 123,
        children: [{
          id: i + 400,
          key: i + 400,
          name: `Edward King ${i}`,
          type: 32,
          setupTime: `London, Park Lane no. ${i}`,
          expireTime: `London, Park Lane no. ${i}`,
          state: 213,
          contact: 213,
          operation: 123,
        }]
      });
    }
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      selections: [{
        key: 'odd',
        text: 'Select Odd Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((key, index) => {
            if (index % 2 !== 0) {
              return false;
            }
            return true;
          });
          this.setState({ selectedRowKeys: newSelectedRowKeys });
        },
      }, {
        key: 'even',
        text: 'Select Even Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((key, index) => {
            if (index % 2 !== 0) {
              return true;
            }
            return false;
          });
          this.setState({ selectedRowKeys: newSelectedRowKeys });
        },
      }],
      onSelection: this.onSelection,
    };
    return (
      <div>
        <WrappedAdvancedSearchForm equipTaskState={this.props.equipTaskState} />
        <Drown equipTaskState={this.props.equipTaskState} />
        <Table rowSelection={rowSelection} columns={columns} dataSource={data} expandedRowRender={this.expandedRowRender} style={{float:"left",width:"100%"}}/>
      </div>
    );
  }
}


class EquipTask extends Component {
  render() {
    return (
      <EquipList equipTaskState={new equipTaskState()} />
    );
  }
}

export default EquipTask;