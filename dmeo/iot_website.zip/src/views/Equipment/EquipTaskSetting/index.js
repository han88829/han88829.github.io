/*
 * @Author: lai.haibo 
 * @Date: 2017-03-16 16:53:51 
 * @Last Modified by: lai.haibo
 * @Last Modified time: 2017-03-16 17:19:57
 */

import React, { Component } from 'react';
import {Link} from 'react-router';
import { Tabs ,Button,Table } from 'antd';

const TabPane = Tabs.TabPane;

class EquipTaskSetting extends Component {
  render() {
    return (
      <div className="EquipTaskSetting" style={{ padding: 24 }}>
        <Tabs defaultActiveKey="1">
          <TabPane tab="巡查任务设置" key="1">
            1
          </TabPane>
          <TabPane tab="抽检任务设置" key="2">
            1
          </TabPane>
        </Tabs>
      </div>
    )
  }
}

export default EquipTaskSetting;