/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:29 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-07-07 16:04:03
 */

import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { Link } from 'react-router';
import { observer } from 'mobx-react';
import { Tabs, Icon, Row, Col, DatePicker, Button, Form, Table, Card, message, Modal } from 'antd';
import './device.css';
import moment from 'moment';
import $ from 'jquery';
import star from '../../../assets/images/equipment/设备名称.png';
import er from '../../../assets/images/equipment/设备二维码.png';
import time from '../../../assets/images/equipment/安装时间.png';
import state from '../../../assets/images/equipment/布设状态.png';
import model from '../../../assets/images/equipment/采集模块.png';
import create from '../../../assets/images/equipment/创立时间.png';
import unit from '../../../assets/images/equipment/单位.png';
import address from '../../../assets/images/equipment/地址.png';
import type from '../../../assets/images/equipment/检测类型.png';
import dtype from '../../../assets/images/equipment/设备型号.png';
import shang from '../../../assets/images/equipment/生产厂家.png';
import area from '../../../assets/images/equipment/所属区域.png';
import net from '../../../assets/images/equipment/网关地址.png';

const { TabPane } = Tabs;
const { RangePicker } = DatePicker;
const FormItem = Form.Item;

let brand = new Map(), deviceType = new Map(), product = new Map(), networkMode = new Map(), locationMap = new Map(), brandMap = new Map(), netWd = new Map();

message.config({
  top: 216,
  duration: 2
})

class QrCode extends React.Component {
  state = {
    modal2Visible: false
  }
  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }
  preview = () => {
    let id = 'PrintContentDiv';
    var sprnhtml = document.getElementById(id).innerHTML;
    var selfhtml = window.document.body.innerHTML; //获取当前页的html
    window.document.body.innerHTML = sprnhtml;
    window.print();
    //window.document.body.innerHTML = selfhtml;//改变html内容，使react事件失效；$()事件应该有效，。。 影响范围
    //正确方案 新打开窗口，问题 图片加载循序问题
    window.location.href = "/equip/device/info/1";
    //         var newWin = window.open("",'newwindow',' height=700,width=750,top=100,left=200,toolbar=no,menubar=no,resizable=no,location=no, status=no');
    //   　　  newWin.document.write(sprnhtml);
    // 　    　newWin.print();
    // console.log(sprnhtml);//新打开的窗口无法显示二维码图片
    //window.document.body.innerHTML = selfhtml;
    //this.setState({modal2Visible:false});
    //var newWin = window.open("",'newwindow',' height=700,width=750,top=100,left=200,toolbar=no,menubar=no,resizable=no,location=no, status=no');
    //newWin.document.write(prnhtml);
    //　newWin.print();
  }
  render() {
    let ie = `http://qr.liantu.com/api.php?&bg=ffffff&text=http://xiot.lszpcn.com/SEquipment/${this.props.id}`
    return (
      <span className="QrCode">
        <Button type="primary" onClick={() => this.setModal2Visible(true)} style={{ borderColor: "#ccc", color: "#000", backgroundColor: "white" }}>点我查看二维码</Button>
        <Modal
          title="请扫以下二维码"
          wrapClassName="vertical-center-modal"
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          style={{ height: "400px" }}
          className="QrCode"
        >
          <Button name="print" onClick={this.preview} style={{ position: 'absolute', left: 12, bottom: 12, zIndex: 999 }}>打印</Button>
          <span id="PrintContentDiv">
            <img src={ie} alt="" style={{ position: 'absolute', left: '50%', top: '50%', marginLeft: '-150px', marginTop: '-150px' }} />
          </span>
        </Modal>
      </span>
    );
  }
}

class deviceState {
  constructor() {
    extendObservable(this, {
      runData: [],
      patrolData: [],
      maintainData: [],
      addRun: action(function () {
        this.runData.push({ key: 2, id: 2, state: '不合格', createTime: '2016-10-26 08:50:08' });
      }),
      runData: action(function () {
        let runData = [{ key: 1, id: 1, state: '合格', createTime: '2016-09-26 08:50:08' }];
      }),
      maintainData: action(function () {
        [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }];
      }),
      addPatrol: action(function () {
        this.patrolData.push({ key: 2, id: 2, userId: 2, type: '巡查', state: '正常', createTime: '2016-09-26 08:50:08', reportId: 2, remark: '2222' });
      }),
      addMaintain: action(function () {
        this.maintainData.push({ key: 2, id: 2, userId: 2, type: '巡查', state: '正常', createTime: '2016-09-26 08:50:08', reportId: 2, remark: '2222' });
      })
    })
  }
}

const RunSearchForm = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    let str = window.location.href;
    var index = str.lastIndexOf("\/");
    str = parseInt(str.substring(index + 1, str.length), 10);
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        let values = { id: str, type: 1 };
        values = {
          ...values,
          createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]
        }
      });
      message.info('共搜索到3条数据');
    } catch (e) {
      console.log(e)
    }
  },
  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form inline style={{ margin: 0, padding: '12px 0 15px' }}>
        <Row>
          <Col span={10} key={1}>
            <FormItem label={`运行时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={2} style={{ float: 'right', marginRight: 10 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}));

const PatrolSearchForm = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        let str = window.location.href;
        var index = str.lastIndexOf("\/");
        str = parseInt(str.substring(index + 1, str.length), 10);
        let values = { id: str, type: 1 };
        values = {
          ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]
        }
        window.rpc.alias.getValueByName('device.patrol.state').then(sres => {
          window.rpc.alias.getValueByName('device.patrol.type').then(tres => {
            window.rpc.device.patrol.getArrayExByContainer(values, 0, 0).then((res) => {
              message.info(`共搜索到${res.length}条数据`);
              let result = res.reverse();
              let alarm = result.map(x => ({ ...x, type: tres[x.type], state: sres[x.state], userName: x.userName, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
              let alarms = [];
              $.each(alarm, function (key, value) {
                value = { ...value, key: key + 1 };
                alarms.push(value);
              });
              this.props.deviceState.patrolData = alarms;
            })
          })
        })
      });
    } catch (e) {
      console.log(e)
    }
    this.props.deviceState.addPatrol();
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Form inline style={{ margin: 0, padding: '12px 0 15px' }}>
        <Row>
          <Col span={10} key={5}>
            <FormItem label={`巡查时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={6} style={{ float: 'right', marginRight: 10 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}));

const MaintainSearchForm = Form.create()(React.createClass({
  handleSearch(e) {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['field-5'];
        let str = window.location.href;
        var index = str.lastIndexOf("\/");
        str = parseInt(str.substring(index + 1, str.length), 10);
        let values = { id: str, type: 2 };
        values = {
          ...values, createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]
        }
        window.rpc.alias.getValueByName('device.patrol.state').then(sres => {
          window.rpc.alias.getValueByName('device.patrol.type').then(tres => {
            window.rpc.device.patrol.getArrayExByContainer(values, 0, 0).then((res) => {
              message.info(`共搜索到${res.length}条数据`);
              let result = res.reverse();
              let alarm = result.map(x => ({ ...x, type: tres[x.type], state: sres[x.state], userName: x.userName, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }));
              let alarms = [];
              $.each(alarm, function (key, value) {
                value = { ...value, key: key + 1 };
                alarms.push(value);
              });
              this.props.deviceState.maintainData = alarms;
            })
          })
        })
      });
    } catch (e) {
      console.log(e)
    }
    this.props.deviceState.addMaintain();
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Form inline style={{ margin: 0, padding: '12px 0 15px' }}>
        <Row>
          <Col span={10} key={1}>
            <FormItem label={`维护时间`}>
              {getFieldDecorator(`field-5`)(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={2} style={{ float: 'right', marginRight: 10 }}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}));

const DeviceC = observer(class appState extends React.Component {
  constructor() {
    super();
    this.state = {
      device: {
        name: '',
        location: '',
        setupTime: '',
        expiryTime: '',
        idQc: 123,
        param: '',
        tag: ''
      },
      devices: {}
    };
  }
  componentWillMount() {
    window.rpc.brand.getMapIdNameByContainer(null, 0, 0).then((res) => {
      brand = res;
    }, (err) => {
      console.warn(err);
    });
    window.rpc.device.types.getArray(0, 0).then((res) => {
      res.forEach(function (value, index) {
        deviceType[value.name] = value.id;
        deviceType[value.id] = value.name;
      })
    }, (err) => {
      console.warn(err);
    })
    window.rpc.product.getMapIdNameByContainer(null, 0, 0).then((res) => {
      product = res;
    }, (err) => {
      console.warn(err);
    })
    window.rpc.area.getArray(0, 0).then((res) => {
      res.forEach((x) => {
        locationMap[x.id] = x.name
        locationMap[x.name] = x.id
      })
    }, (err) => {
      console.warn(err);
    })
    const id = parseInt(this.props.params.id, 10);
    window.rpc.alias.getValueByName('device.patrol.state').then(result => {
      return window.rpc.device.run.getArray(id, 0, 0).then(data =>
      { return { data, result } })
    }).then(res => {
      var run = res.data.map((x, index) => ({ ...x, key: index, createTime: moment(x.createTime || new Date()).format('YYYY-MM-DD'), state: res.result[x.state], productId: product[x.productId] }))
      this.props.deviceState.runData = run;
    })
    window.rpc.alias.getValueByName('device.patrol.type').then(result => {
      return window.rpc.device.patrol.getArray(id, 0, 0).then(data =>
      { return { data, result } })
    }).then(date => {
      date.data.forEach((x, index) => {
        window.rpc.device.patrol.getArrayExByContainer({ userId: x.userId }, 0, 0).then(info => {
          if (x.type == 1) {
            var patrol = { ...x, key: index + 1, createTime: moment(x.createTime || new Date()).format('YYYY-MM-DD'), state: date.result[x.type], userId: info[0].userName }
            this.props.deviceState.patrolData.push(patrol)
          } else {
            var maintai = { ...x, key: index + 1, createTime: moment(x.createTime || new Date()).format('YYYY-MM-DD'), state: date.result[x.type], userId: info[0].userName }
            this.props.deviceState.maintainData.push(maintai)
          }
        }
        )
      }
      )
    })

    this.setState({
      idQc: id
    })
    window.rpc.device.getInfoById(id).then((result) => {
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.alias.getValueByName('device.networkmode').then(data=>{
        window.rpc.area.types.getMapIdNameByContainer(null, 0, 0).then(res => {
         setTimeout(() => {
           const device = { ...result,networkMode:data[result.networkMode],dtype:res[result.dtype], tag: result.tag, expiryTime: moment(result.expiryTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, location: locationMap[result.location], productId: product[result.productId], brandId: brand[result.param.brandId] };
           this.setState({ device });
         }, 300)
      },err=>{
       console.warn(err)     
      })
     },err=>{
       console.warn(err)     
     })
    

    }, (err) => {
      console.warn(err);
      function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
    })
  }

  onChangeDate(date, dateString) {
  }

  render() {
    function callback(key) {
    }
    const runColumns = [
      { title: '序号', dataIndex: 'key', key: 'key' },
      { title: '运行时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '运行状态', dataIndex: 'state', key: 'state' },
      {
        title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
            <Link to="">查看详情</Link>
          </span>
        )
      }
    ];

    const patrolColumns = [
      { title: '序号', dataIndex: 'key', key: 'key' },
      { title: '巡查时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '巡查结果', dataIndex: 'state', key: 'state' },
      { title: '巡查人', dataIndex: 'userId', key: 'userId' },
      {
        title: '巡查报表', dataIndex: '', key: 'x', render: (text, record) => (
          <span>
           <Link to="">查看报表</Link>
          </span>
        )
      },
      {
        title: '操作', dataIndex: '', key: 'y', render: (text, record) => (
          <span>
            <Link to="">查看</Link>
          </span>
        )
      }
    ];

    const maintainColumns = [
      { title: '序号', dataIndex: 'id', key: 'id' },
      { title: '维护时间', dataIndex: 'createTime', key: 'createTime' },
      { title: '维护类型', dataIndex: 'type', key: 'type' },
      { title: '维护结果', dataIndex: 'state', key: 'state' },
      { title: '维护说明', dataIndex: 'remark', key: 'remark' },
      { title: '巡查人', dataIndex: 'userId', key: 'userId' }
    ];

    const paginationr = {
      total: this.props.deviceState.runData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };
    const paginationp = {
      total: this.props.deviceState.patrolData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };
    const paginationm = {
      total: this.props.deviceState.runData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };
    return (
      <div className="Device OrgManage" >
        <Tabs defaultActiveKey="1" onChange={callback} className='infoTabOne' style={{ height: '100%', fontSize: '0.75rem' }}>
          <TabPane className="firstTabInfo" style={{ color: 'red' }} tab={<span><Icon type="info-circle-o" />基础信息</span>} key="1" style={{ padding: '5px' }}>
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备详情</Link>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备名称： {this.state.device.name}</div>
                  <div className="Row-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备二维码：<QrCode id={this.state.idQc} /> </div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px" }} />所属系统：</div>
                  <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />所在建筑： </div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px" }} />生产厂家： {this.state.device.brandId}</div>
                  <div className="Row-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px" }} />安装时间： {this.state.device.setupTime} </div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备型号： {this.state.device.productId}</div>
                  <div className="Row-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px" }} />有效期限： {this.state.device.expiryTime} </div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备类型：{this.state.device.dtype} </div>
                  <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />安装位置： {this.state.device.location} </div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                {/*<div className="Row-info">
                  <div className="Row-info-left"><img src={net} alt="" style={{ padding: " 0px 12px 0px 16px" }} />网关地址：{this.state.device.networkUrl}</div>
                  <div className="Row-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px" }} />网关序号：{this.state.device.networkId} </div>
                </div>*/}
                <div className="Row-info">
                  <div className="Row-info-left"><img src={net} alt="" style={{ padding: " 0px 12px 0px 16px" }} />相对坐标x：{this.state.device.mapX}</div>
                  <div className="Row-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px" }} />相对坐标y：{this.state.device.mapY} </div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                {/*<div className="Row-info">
                  <div className="Row-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px" }} />采集模块： {this.state.device.param.module}</div>
                  <div className="Row-info-left"><img src={create} alt="" style={{ padding: " 0px 12px 0px 16px" }} />监控类型： {this.state.device.networkNode}</div>
                </div>*/}
              </div>
            </div>
            {/*<div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备地址： {this.state.device.networkAddr}</div>
                  <div className="Row-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px" }} />监测类型： </div>
                </div>
              </div>
            </div>*/}
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px" }} />联网模式：{this.state.device.networkMode} </div>
                  <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />NFC： {this.state.device.tag}</div>
                </div>
              </div>
            </div>
            <Row style={{ padding: '10px 0 0px', marginTop: 80 }}>
              <Col span={9} style={{ textAlign: 'left' }}>
                <div className="new-button" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', fontFamily: '微软雅黑', width: 60, height: 32, borderRadius: 0 }}><Link to="/equip/manage">返回</Link></div>
              </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />运行记录</span>} key="2" style={{ padding: '5px' }}>
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备详情</Link>
            </div>
            <RunSearchForm deviceState={this.props.deviceState} />
            <Row style={{ padding: '0 0 5px' }}>
              <Col span={24}>
                <Table
                  //bordered
                  columns={runColumns}
                  dataSource={[...this.props.deviceState.runData]}
                  paginationr={{ ...paginationr, total: this.props.deviceState.runData.length }}
                />
              </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />巡查记录</span>} key="3" style={{ padding: '5px' }}>
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备详情</Link>
            </div>
            <PatrolSearchForm deviceState={this.props.deviceState} />
            <Row style={{ padding: '0 0 5px' }}>
              <Col span={24}>
                <Table
                  //bordered
                  columns={patrolColumns}
                  dataSource={[...this.props.deviceState.patrolData]}
                  pagination={{ ...paginationp, total: this.props.deviceState.patrolData.length }}
                />
              </Col>
            </Row>
          </TabPane>
          <TabPane tab={<span><Icon type="info-circle-o" />维护记录</span>} key="4" style={{ padding: '5px' }}>
            <div style={{ position: 'absolute', left: 0, top: 10, width: 75, height: '32px', linHeight: '32px', zIndex: 99, backgroundColor: '#fff' }}>
              <Link to='/org/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备详情</Link>
            </div>
            <MaintainSearchForm deviceState={this.props.deviceState} />
            <Row style={{ padding: '0 0 5px' }}>
              <Col span={24}>
                <Table
                  //bordered
                  columns={maintainColumns}
                  dataSource={[...this.props.deviceState.maintainData]}
                  pagination={{ ...paginationm, total: this.props.deviceState.maintainData.length }}
                />
              </Col>
            </Row>
          </TabPane>
        </Tabs>
        {/*<Row style={{ margin: '0', position: 'absolute', bottom: 70, left: '12px' }}>
          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 140, marginRight: 10, }}><Link to="/equip">返回</Link></Button>
        </Row>*/}
      </div>
    )
  }
})

class Device extends Component {
  render() {
    return (
      <DeviceC deviceState={new deviceState()} params={this.props.params} />
    )
  }
}

export default Device;