/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:37 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2017-08-07 16:13:34
 */
import React from 'react';
import { Form, Input, Select, Button, DatePicker, message, TreeSelect } from 'antd';
import { Link, browserHistory } from 'react-router';
import listStore from '../listStore';
import moment from 'moment';
import star from '../../../assets/images/equipment/设备名称.png';
import time from '../../../assets/images/equipment/安装时间.png';
import models from '../../../assets/images/equipment/采集模块.png';
import address from '../../../assets/images/equipment/地址.png';
import type from '../../../assets/images/equipment/检测类型.png';
import dtype from '../../../assets/images/equipment/设备型号.png';
import net from '../../../assets/images/equipment/网关地址.png';
import setLocation from '../../../assets/images/equipment/坐标.png';

import './newDevices.css';

const FormItem = Form.Item;
const Option = Select.Option;
const dateFormat = 'YYYY-MM-DD';
import './device.css';
var model = [], provinceData = [], dtypescon = [];
var brand = new Map(), deviceType = new Map(), product = new Map(), networkMode = new Map(), locationMap = new Map(), brandMap = new Map(), netWd = new Map(), local = "", flag = 0;
// 结构出参量表
//const { networkModeList } = listStore;

const EditDevice = Form.create()(React.createClass({
  getInitialState() {
    return {
      passwordDirty: false,
      networkMode: true,
      disabled: true,
      data: [],
      model: [],
      locations: [],
      setPingmiantu_visiable: false,
      pingmiantu_url: '',
      findData: [],
      newPointX: 0,
      newPointY: 0,
      extend: {},
      typeData: [],
      networkModeList:[]
    };
  },
  componentDidMount() {
    window.rpc.brand.getMapIdNameByContainer(null, 0, 0).then((res) => {
      for (let value in res) {
        provinceData.push(<Option key={value} data-key={value}>{res[value]}</Option>)
        brand[res[value]] = value;
        brand[value] = res[value];
      }
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.types.getArray(0, 0).then((res) => {
      res.forEach(function (value, index) {
        dtypescon.push(<Option key={value.id}>{value.name}</Option>)
        deviceType[value.name] = value.id;
        deviceType[value.id] = value.name;
      })
    }, (err) => {
      console.warn(err);
    });
  },
  componentWillMount() {
    window.rpc.product.getArray(0, 0).then((res) => {
      res.forEach((x) => {
        product[x.id] = x.number;
        product[x.number] = x.id;
      })
    }, (err) => {
      console.warn(err);
    })
      window.rpc.alias.getValueByName('device.networkmode').then(data=>{
        let arrWatch = ['/'];
        for (let key in data) {
          let values = `${data[key]}`
          arrWatch.push(values);
        }
        let  networkModeList= arrWatch;
        this.setState({
          networkModeList
        });
      },err=>{
        console.warn(err)
      })

    const id = parseInt(this.props.params.id, 10);
    let brandContent = '';
    window.rpc.brand.getMapIdNameByContainer(null, 0, 0).then((res) => {
      brandContent = res[id]
    })
    window.rpc.product.getArrayIdNumberByContainer({ brandId: id }, 0, 0, console.log, console.error).then((info) => {
    }, (err) => {
      console.warn(err);
    })
    function loop(data) {
      let layer = data.map(x => x.layer).sort((a, b) => b - a)[0];//得到layer最大值
      let layerNow = data.filter(x => x.layer === layer);//得到layer为2的元素组成数组
      let layerUp = data.filter(x => x.layer !== layer);
      for (var i = 0; i < layerNow.length; i++) {
        for (var j = 0; j < layerUp.length; j++) {
          if (layerNow[i].parentId == layerUp[j].id) {
            if (layerUp[j].children) {
              //在对象中children字段对应数组中push新对象
              layerUp[j].children.push({ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` })
              locationMap[layerNow[i].id] = layerNow[i].name
              locationMap[layerNow[i].name] = layerNow[i].id
            } else {
              //在对象中新增children字段
              layerUp[j].children = [{ ...layerNow[i], label: layerNow[i].name, value: `${layerNow[i].id}` }];
              locationMap[layerNow[i].id] = layerNow[i].name
              locationMap[layerNow[i].name] = layerNow[i].id
            }
          }
        }
      }
      if (layer === 2) {
        return layerUp;
      } else {
        loop(layerUp)
      }
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = res.filter(x => x.layer === 1).map(x => ({ ...x, key: x.id, label: x.name, value: `${x.id}` }));
      let tableDate = [];
      res.forEach(function (x) {
        tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
      })
      tableDate.unshift({ key: 0, label: "无", value: 0 })
      let date = loop(tableDate);
      this.setState({ typeData: tableDate });
    })
    window.rpc.area.getArray(0, 0).then((res) => {
      let tableDate = [];
      res.forEach(function (x) {
        if (x.name != "") {
          tableDate.push({ ...x, key: x.id, label: x.name, value: `${x.id}` })
        }
      })
      loop(tableDate)
      res.filter(x => x.layer == 1).forEach((x) => {
        locationMap[x.id] = x.name
        locationMap[x.name] = x.id
      })
      this.setState({
        data: tableDate,
        findData: res
      })
      let me = parseInt(this.props.params.id, 10);
      let meobj = res.filter(x => x.id === me)[0];
      if (meobj.mapUrl) {
        this.setState({ pingmiantu_url: meobj.mapUrl });
      } else {
        let parentId = meobj.parentId;
        let parentobj = res.filter(x => x.id === parentId)[0];
        this.setState({ pingmiantu_url: parentobj.mapUrl });
      }
    }, (err) => {
      console.warn(err);
    })
    window.rpc.brand.getMapIdNameByContainer(null, 0, 0).then((res) => {
      for (var i in res) {
        brandMap[res[i]] = i;
        brandMap[i] = res[i];
      }
    }, (err) => {
      console.warn(err);
    })
    window.rpc.device.getInfoById(id).then((result) => {
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY-MM-DD")
      } else {
        time = moment(result.setupTime).format("YYYY-MM-DD")
      }
      const device = { ...result, key: result.id, expiryTime: moment(result.expiryTime).format("YYYY-MM-DD"), setupTime: time };
      setTimeout(() => {
        this.props.form.setFieldsValue({
          name: result.name,
          networkUrl: result.networkUrl,
          dtype: deviceType[result.dtype],
          networkMode: networkMode[result.networkMode],
          brandId: brandMap[result.param.brandId],
          productId: product[result.productId],
          networkAddr: result.networkAddr,
          networkNode: result.networkNode,
          expiryTime: moment(result.expiryTime, dateFormat),
          setupTime: moment(time, dateFormat),
          unit: result.param.unit,
          scope: result.param.scope,
          survey: result.param.survey,
          location: locationMap[result.location],
          module: result.param.module,
          mapX: `${result.mapX},${result.mapY}`,
          tag: result.tag,
        });
      }, 300)

      this.setState({ device });
    }, (err) => {
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  },
  handleSubmit(e) {
    e.preventDefault();
    const id = parseInt(this.props.params.id, 10);
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        if (flag) {
          local = values.location;
        } else {
          local = locationMap[values.location];
        }
        setTimeout(() => {
          let { name, tag, setupTime, expiryTime, networkAddr, networkId, networkMode, networkUrl, networkNode, location, brandId, productId, dtype } = values;
          if (isNaN(networkMode)) {
            networkMode = parseInt(netWd[values.networkMode], 10);
          } else {
            networkMode = parseInt(networkMode, 10)
          }
          if (isNaN(dtype)) {
            dtype = parseInt(deviceType[values.dtype], 10);
          } else {
            dtype = parseInt(dtype, 10)
          }
          let mappoint = values.mapX;
          let mapX = mappoint.split(',')[0];
          let mapY = mappoint.split(',')[1];
          let extend = this.state.extend;

          let obj = { name, tag, mapX, mapY, extend, setupTime: new Date(setupTime.format('YYYY-MM-DD')), expiryTime: new Date(expiryTime.format('YYYY-MM-DD')), networkAddr, networkMode: networkMode, networkNode, networkId, networkUrl, location: parseInt(local, 10), productId: product[productId], dtype: dtype, param: { brandId: brand[brandId], module: values.module } };

          if (networkAddr) {
            obj = { ...obj, networkAddr };
          }
          if (networkId) {
            obj = { ...obj, networkId };
          }
          window.rpc.device.setInfoById(id, obj).then((x) => {
            message.info('修改成功！');
            browserHistory.push('/equip');
          }, (err) => {
            console.warn(err);
             function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
          })
        }, 300)
      }
    });
  },
  changeType(e) {
    window.rpc.product.getArrayIdNumberByContainer({ brandId: e }, 0, 0).then((info) => {
      for (let value of info) {
        if (value && value.id) {
          model.push(<Option key={`${value.number}`}>{value.number}</Option>)
          product[value.number] = value.id;
        }
      }
      this.setState({ model })
    }, (err) => {
      console.warn(err);
    })
    this.setState({
      disabled: false
    })
  },
  handlePasswordBlur(e) {
    const value = e.target.value;
    this.setState({ passwordDirty: this.state.passwordDirty || !!value });
  },
  checkPassword(rule, value, callback) {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  },
  checkConfirm(rule, value, callback) {
    const form = this.props.form;
    if (value && this.state.passwordDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  },
  changeTwoDecimal(x) {
    var f_x = parseFloat(x);
    if (isNaN(f_x)) {
      alert('function:changeTwoDecimal->parameter error');
      return false;
    }
    var f_x = Math.round(x * 100) / 100;

    return f_x;
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 3 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };

    const config = {
      rules: [{ type: 'object', required: true, message: 'Please select time!' }],
    };

    function isNetworkModeEqualOne(value) {
      return value !== '1';
    }

    let dtypes = JSON.parse(sessionStorage.getItem('dtypes')) || [];
    let locations = JSON.parse(sessionStorage.getItem('locations')) || [];
    let products = JSON.parse(sessionStorage.getItem('products')) || [];
    let networkModeList=this.state.networkModeList||[];
    let dtypeChildren = [];
    let locationChildren = [];
    let productChildren = [];
    let networkModeChildren = [];
   
    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    for (let value of locations) {
      if (value && value.id) {
        locationChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    for (let value of products) {
      if (value && value.id) {
        productChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }

    for (let i = 1; i < networkModeList.length; i++) {
      networkModeChildren.push(<Option key={`${i}`}>{networkModeList[i]}</Option>)
      networkMode[i] = networkModeList[i]
      netWd[i] = networkModeList[i];
      netWd[networkModeList[i]] = i;
    }
      
    return (
      <div>
        <div style={{ overflow: 'hidden', paddingBottom: '1.125em', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid' }}>
          <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
            <Link to='/equip/manage' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>设备管理</Link>
          </div>
          <div style={{ float: 'left', width: 80, height: 32, marginRight: 4 }}>
            <Button style={{ background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }} ><Link to="">编辑设备</Link></Button>
          </div>
        </div>
        <Form className="EditDevice" style={{ marginTop: -4, paddingTop: 30, height: 700, overflow: 'auto' }} >
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>设备名称&nbsp;</span>
              </div>
              <FormItem
                {...formItemLayout}
                style={{ float: 'left' }}
                hasFeedback
              >
                {getFieldDecorator('name', {
                  rules: [{ required: true, message: '请输入设备名称!' }],
                })(
                  <Input placeholder="请输入设备名称" style={{ width: 320 }} />
                 )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={time} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>过期时间：</span>
              </div>
              <FormItem
                style={{ float: 'left' }}
              >
                {getFieldDecorator('expiryTime', config)(
                  <DatePicker format={dateFormat} />
                )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={time} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>安装时间：</span>
              </div>
              <FormItem
                style={{ float: 'left' }}
              >
                {getFieldDecorator('setupTime', config)(
                  <DatePicker style={{ width: 180 }} format={dateFormat} />
                )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>品牌：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('brandId', {
                  rules: [{ required: true, message: '请选择品牌!' }],
                })(
                  <Select placeholder='请选择品牌' style={{ width: 180 }} onChange={this.changeType}>
                    {provinceData}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>安装位置：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('location', {
                  rules: [{ type: 'string', required: true, message: '请选择安装位置!' }],
                })(
                  <TreeSelect
                    style={{ width: 300 }}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.data.filter(x => x.layer == 1)}
                    placeholder="请选择安装位置"
                    onChange={(value) => {
                      flag = 1;
                      let me = parseInt(value, 10);
                      //console.log(me);
                      let sources = this.state.findData;
                      let meobj = sources.filter(x => x.id === me)[0];
                      if (meobj.mapUrl) {
                        this.setState({ pingmiantu_url: meobj.mapUrl });
                      } else {
                        let parentId = meobj.parentId;
                        let parentobj = sources.filter(x => x.id === parentId)[0];
                        this.setState({ pingmiantu_url: parentobj.mapUrl });
                      }
                    }}
                  />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={type} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>型号：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('productId', {
                  rules: [{ required: false, message: '请选择型号!' }],
                })(
                  <Select placeholder='请先选择品牌' disabled={this.state.disabled} style={{ width: 180 }} >
                    {model}
                  </Select>
                  )}
              </FormItem>
            </div>
          </div>
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={dtype} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>设备类型：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('dtype', {
                  rules: [{ type: 'string', required: true, message: '请选择设备类型!' }],
                })(
                  <TreeSelect
                    style={{ width: 170 }}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.typeData.filter(x => x.layer === 1)}
                    placeholder="请选择类型"
                    treeDefaultExpandAll
                  />
                  )}
              </FormItem>
            </div>
          {/*</div>
          <div className="Row-info">*/}
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={net} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>联网模式：</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              >
                {getFieldDecorator('networkMode', {
                  rules: [
                    { required: true, message: '请选择联网模式!' },
                  ],
                  onChange: this.handleNetWorkModel
                })(
                  <Select placeholder='请先选择联网模式' style={{ width: 180 }} >
                    {networkModeChildren}
                  </Select>
                  )}
              </FormItem>
            </div>
            {/*<div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>网关地址：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('networkAddr', {
                  rules: [{ message: '请输入网关地址!' }],
                })(
                  <Input disabled={isNetworkModeEqualOne(this.props.form.getFieldValue('networkMode'))} size="large" />
                  )}
              </FormItem>
            </div>*/}
          </div>
          {/*<div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={star} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>网关序号：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('networkId', {
                  rules: [{ message: '请输入网关序号!' }],
                })(
                  <Input disabled={isNetworkModeEqualOne(this.props.form.getFieldValue('networkMode'))} size="large" />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={models} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>采集模块：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('module', {
                  rules: [{ required: true, message: '请输入采集模块!' }],
                })(
                  <Input size="large" />
                  )}
              </FormItem>
            </div>
          </div>*/}
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={net} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>相对坐标：</span>
              </div>
              <FormItem
                {...formItemLayout}
                hasFeedback
              //float
              >
                {getFieldDecorator('mapX', {
                  rules: [
                    { required: true, message: '请输入设备相对坐标!' },
                  ]
                })(
                  <Input size="large" />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" style={{ height: 40, lineHeight: '40px', backgroundColor: '#fff' }}>
              <Button className="caiji_btn" style={{ display: 'inline-flex', alignItems: 'center' }} onClick={() => this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }))}><img src={setLocation} style={{ padding: '0 15px 0 12px' }} alt="" /><span>采集坐标</span></Button>
              <div className="shebei_pmt" style={{ display: this.state.setPingmiantu_visiable ? 'block' : 'none' }}>
                <div className="shebei_pmt_head">
                  <span>采集坐标</span>
                  <span style={{ cursor: 'pointer' }} onClick={() => this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }))}>X</span>
                </div>
                <div className="shebei_pmt_body">
                  <img src={this.state.pingmiantu_url} onMouseDown={(event) => {
                    event.persist();
                    let body = document.body;
                    let newPointX = event.clientX - event.target.offsetLeft - (body.clientWidth - event.target.offsetParent.offsetWidth) / 2;
                    let newPointY = event.clientY - event.target.offsetTop - (body.clientHeight - event.target.offsetParent.offsetHeight) / 2;
                    let zoom = event.target.height / event.target.naturalHeight;
                    let extend = { offsetHeight: event.target.offsetHeight, offsetWidth: event.target.offsetWidth, zoom };
                    let x = ((newPointX / event.target.offsetWidth) * 100).toFixed(2);
                    let y = ((newPointY / event.target.offsetHeight) * 100).toFixed(2);
                    this.setState({ newPointX: x, newPointY: y, extend });
                  }} alt="pingmiantu" />
                </div>
                <div className="shebei_pmt_footer">
                  <div>
                    <span>当前位置点如下：</span>
                    <Input value={`${this.state.newPointX}, ${this.state.newPointY}`} style={{ width: 150 }} />
                  </div>
                  <div>
                    <Button style={{ backgroundColor: '#00c2de', borderColor: '#00c2de', color: '#fff', marginRight: 8 }} onClick={() => {
                      this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }));
                      this.props.form.setFieldsValue({
                        mapX: `${this.state.newPointX},${this.state.newPointY}`,
                      });
                    }}>确定</Button>
                    <Button onClick={() => this.setState((prevState) => ({ setPingmiantu_visiable: !prevState.setPingmiantu_visiable }))}>取消</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/*<div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={type} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>监控类型：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('networkNode', {
                  rules: [{ required: true, message: '请输入监控类型!' }],
                })(
                  <Input size="large" style={{ width: '400px' }} />
                  )}
              </FormItem>
            </div>
            <div className="Row-info-right clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={address} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>设备地址：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('networkUrl', {
                  rules: [{ required: true, message: '请输入设备地址' }],
                })(
                  <Input size="large" />
                  )}
              </FormItem>
            </div>
          </div>*/}
          <div className="Row-info">
            <div className="Row-info-left clearfix" >
              <div style={{ float: 'left', marginRight: 12, height: 32, lineHeight: '32px' }}>
                <img src={type} style={{ padding: '0 15px 0 12px' }} alt="" />
                <span>NFC：</span>
              </div>
              <FormItem
                {...formItemLayout}
              >
                {getFieldDecorator('tag', {
                  rules: [{ required: false, message: '请输入NFCID!' }],
                })(
                  <Input size="large" style={{ width: '400px', marginLeft: 23 }} />
                  )}
              </FormItem>
            </div>
          </div>
          <div style={{ position: 'absolute', bottom: 60 }} className="search-btn">
            <FormItem >
              <Button htmlType="submit" onClick={this.handleSubmit}> 保存</Button>
              <div className="new-button" style={{ display: `inline-block`, backgroundColor: '#ccc', color: '#fff', fontSize: '0.875rem', marginLeft: 10, fontFamily: '微软雅黑', width: 60, height: 32, borderRadius: 0 }}><Link to="/equip/manage">返回</Link></div>
            </FormItem>
          </div>
        </Form>
      </div >
    );
  },
}));

export default EditDevice;