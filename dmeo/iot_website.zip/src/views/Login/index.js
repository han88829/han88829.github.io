import React, { Component } from 'react';
//import ReactDOM from 'react-dom';
import { browserHistory } from 'react-router';
import { Form, Icon, Input, Button, Checkbox, message } from 'antd';
import './login.css';
import $ from 'jquery';
import title_pic from '../../assets/images/login/logo-title.png';

const FormItem = Form.Item;
// message.config({
//   top: 100,
//   width:600,
//   duration: 10,
// });
// function error() {
//   message.error('rpc加载失败，请稍后重试或联系管理员',10);
// }

const LoginForm = Form.create()(React.createClass({
  getInitialState() {
    return {
     text:''
    };
  },
  componentDidMount() {
    
  },
  handleLoginSubmit(e) {
    e.preventDefault();
    if(!window.rpc) {
     // error()

       this.setState({
           text:'rpc加载失败，请稍后重试或联系管理员'
       });
        $('.message').css({
              display:'block',
              transition:'2s',
              opacity:1
            })
            setTimeout(function(){
              $('.message').css({
                  display:'none',
                   transition:'2s',
                   opacity:0
               })
            },5000)
    }
    this.props.form.validateFields((err, values) => {
      if (!err) {
        if(!window.rpc){
          this.setState({
            text:'rpc加载失败，请稍后重试或联系管理员'
          });
          $('.message').css({
            display:'block',
            transition:'2s',
            opacity:1
          });
          setTimeout(function(){
            $('.message').css({
               display:'none',
               transition:'2s',
               opacity:0
            });
          },5000);
        };
        window.rpc.public.user.login(values.userName, values.password).then((res) => {
          // 存储 token
          window.rpc.setToken(res);
          
          // 进行跳转
          // window.location.href = '/back';
          if(res){
              browserHistory.push('/safecenter');   
          }else{
           //message.error("登录失败，请重新输入用户名密码",10);    
           this.setState({
              text:'登录失败，请重新输入用户名密码'
            });
            $('.message').css({
              display:'block',
              opacity:1,
              transition:'2s'
            });
            setTimeout(function(){
              $('.message').css({
                  display:'none',
                  transition:'2s',
                  opacity:0
               });
            },5000);
          };
         
        }, (err) => {
          console.log(err);
           if(err.message=="timeout"){
             // console.log("时间延时");
            // message.info("时间延时",10)
            this.setState({
              text:'时间延时'
            });
             $('.message').css({
              display:'block',
              opacity:1,
              transition:'2s'
            });
            setTimeout(function(){
              $('.message').css({
                  display:'none',
                  transition:'2s',
                  opacity:0
               });
            },5000);
           }else{
             //console.log("请求数据失败，刷新无效请联系程序小哥")
             this.setState({
              text:'请求数据失败，刷新无效请联系程序小哥'
            });
             $('.message').css({
              display:'block',
              opacity:1,
              transition:'2s'
            });
            setTimeout(function(){
              $('.message').css({
                  display:'none',
                  transition:'2s',
                  opacity:0
               });
            },5000);
           };
        });
      };
    });
  },
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
    <div>
      <div className="message" style={{position:'absolute',display:'none',opacity:0,top: '93px',left: '40px', background: '#ffd0d0',color: '#d34e4e',width: '330px',height: '28px',lineHeight: '28px'}}>
        <Icon type="close-circle" style={{padding:'0 8px',}} /><span className="messageText" style={{fontSize:'12px'}}>{this.state.text}</span>
      </div>
      <Form  className="login-form" style={{margin:'50px 20px'}}>
        <FormItem>
          {getFieldDecorator('userName', {
            rules: [{ required: true, message: '请输入用户名!' }],
          })(
            <Input addonBefore={<Icon type="user" />} placeholder="请输入用户名" />
          )}
        </FormItem>
        <FormItem>
          {getFieldDecorator('password', {
            rules: [{ required: true, message: '请输入密码!' }],
          })(
            <Input addonBefore={<Icon type="lock" />} type="password" placeholder="请输入密码" />
          )}
        </FormItem>
        <FormItem>
           {getFieldDecorator('remember', {
            valuePropName: 'checked',
            initialValue: true,
          })(
              <Checkbox className="remember-me" style={{marginLeft:20}} >记住密码</Checkbox>
          )}
          <Button type="primary" onClick={this.handleLoginSubmit} htmlType="submit" className="login-form-button" style={{width:120,height:40}} >
            登录
          </Button>
        </FormItem>
      </Form>
    </div>  
    );
  },
}));

class Login extends Component {
  render() {
    return (
      <div className="Login">
        <div className="LoginPosition">
          <div className="logo"><p ><img src={title_pic} alt="图标"/></p></div>
          <div>
            <LoginForm />
          </div>
        </div>
          <div className="footer">
            <p><span>建议使用1024*768 分辨率 </span>&nbsp;<span>技术支持：宁波蓝晟智品信息科技发展有限公司 </span></p>
            <p><span style={{marginRight:10}}>技术支持电话 ：0574-86663183</span><span>传真 ：0574-86663183</span></p>
        </div>
      </div>  
    );
  }
}

export default Login;