/*
 * @Author: lai.haibo 
 * @Date: 2017-04-22 14:06:29 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-07 16:59:53
 */

import React, { Component } from 'react';
import { notification, Icon, Button, Dropdown, Menu, Modal, Select, Input, message, Tabs, Progress, Cascader } from 'antd';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { browserHistory } from 'react-router';
import moment from 'moment';
import EquipRight from './EquipCenter/EquipRight';
import AlarmLeft from './EquipCenter/AlarmLeft';
import NewPingmiantu from './PointImg';
import AreaInfoClick from './AlarmSix/InfoDisplay/AreaInfoClick';
import AlarmConcenBasicMes from './AlarmSix/AlarmConcenBasicMes';
import AlarmConcenRoute from './AlarmSix/AlarmConcenRoute';
import AlarmConcenResources from './AlarmSix/AlarmConcenResources';
import AlarmRealTimeMonitor from './AlarmSix/AlarmRealTimeMonitor';
import AlarmConcenEquipment from './AlarmSix/AlarmConcenEquipment';
import AlarmConcenFloor from './AlarmSix/AlarmConcenFloor';
import listStore from './AlarmSix/listStore';
import $ from 'jquery';
import './equipDefault.css';
import './modal.css';

import UnAlarm from '../../../assets/images/apply/green.png';
import yellow from '../../../assets/images/apply/yellow.png';
import Alarm from '../../../assets/images/apply/red.png';
import textbox from '../../../assets/images/apply/textbox.png';
import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
import buildingImg from '../../../assets/images/application/建筑分类.png';
import riverImg from '../../../assets/images/application/TZD河流.png';
import otherwaterImg from '../../../assets/images/application/其他水源.png';
import poorImg from '../../../assets/images/application/水池.png';
import firecarImg from '../../../assets/images/application/消防.png';
import xfsImg from '../../../assets/images/application/消防水栓.png';
import zheng from '../../../assets/images/apply/正常.png';
import yi from '../../../assets/images/apply/异常.png';

const Option = Select.Option;
const Search = Input.Search;
const TabPane = Tabs.TabPane;

// 结构出参量表
const { armtypeList, ResultState, dStateList } = listStore;

//取出户籍类型
let Orgtypes = JSON.parse(sessionStorage.getItem('Orgtypes')) || [];
let wateO = 0, wateT = 0, wateS = 0;
var audio;
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
    placement: 'bottomRight',
    duration: 30,
    onClose: function () {
      audio.pause();
    }
  });
};
class EquipDefaultState {
  constructor() {
    extendObservable(this, {
      buildId: [],
      idbul: 1,
      sixAlarm: {},
      building: {},
      mes_recever: '',
      mes_info: '',
      mes_array: [],
      warn_recever: '',
      warn_info: '',
      choice_array: [],
      choice_string: '',
      water: 0,
    })
  }
}

const EquipDefaultC = observer(class EquipDefaultState extends React.Component {

  state = {
    id: null,
    buildingInfoId: null,
    display: "none",
    SixD: "none",
    sixId: null,
    markerId: null,
    allDeviceCount: 0,
    commonDeviceCount: 0,
    erroeDeviceCount: 0,
    alarmCount: {
      1: 0,
      2: 0,
      3: 0
    },
    patrolCount: {
      1: 0,
      2: 0,
      3: 0
    },
    mapPoints: [],
    mapPointsIcon: [],
    types: [],
    building: {
      name: '',
      buildTime: '',
      createTime: '',
      fireDanger: '',
      fireLevel: '',
      galleryful: '',
      mapUrl: '',
      extend: {
        height: '',
        overgroundarea: '',
        overgroundfloor: '',
        rangebase: '',
        rangebuild: '',
        refugestoreyarea: '',
        refugestoreyfloor: '',
        subtype: '',
        undergroundarea: '',
        undergroundfloor: '',
        usetype: ''
      }
    },
    new_pingmiantu: false,
    storeys: [],
    storey: {
      name: '',
      buildTime: '',
      createTime: '',
      fireDanger: '',
      fireLevel: '',
      galleryful: '',
      mapUrl: '',
      extend: {
        height: '',
        overgroundarea: '',
        overgroundfloor: '',
        rangebase: '',
        rangebuild: '',
        refugestoreyarea: '',
        refugestoreyfloor: '',
        subtype: '',
        undergroundarea: '',
        undergroundfloor: '',
        usetype: ''
      }
    },
    storeyShow: false,
    offer: true,
    widthA: "29%",
    widthB: "29%",
    heightA: "29%",
    heightB: "29%",
    heightC: "29%",
    heightD: "29%",
    heightE: "29%",
    heightF: "29%",
    heightTotal: "92.5%",
    topA: "7.5%",
    alarmSix: {
      rdata: {},
      device: {},
      area: {},
      owner: {},
    },
    mes_loading: false,
    mes_visible: false,
    warn_loading: false,
    warn_visible: false,
    mes_recever: '',
    mes_info: '', mapBuild: null,
    mapState: null,
    mapType: false,//2 卫星
    mapLine: null,//2 虚线
    mapCenter: { x: 121.618835, y: 29.920698 },
    mapLevel: 18,
    water: 0,
    routId: 0,
    wateO: 0,
    wateT: 0,
    wateS: 0,
    displayTu: "none",
    Toffer: 0
  }

  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
  }

  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    loadJScript();
  }

  componentDidMount() {
    let that = this;
    let paramState = this.props.params.dstate;
    const getAllDeviceCount = () => {
      return window.rpc.device.getCount();
    }

    const getCommonDeviceCount = () => {
      return window.rpc.device.getCountByCond({ rstate: 1 });
    }

    const getErroeDeviceCount = () => {
      return window.rpc.device.getCountByCond({ rstate: 2 });
    }

    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = {};
      for (let value of res) {
        types[value.id] = value.name
      }
      this.setState({ types });
    });

    const getAlarm = () => {
      return window.rpc.device.alarm.getCountFieldByContainer(null, 'type');
    }

    const getPatrol = () => {
      return window.rpc.device.patrol.getCountFieldByContainer(null, 'type');
    }

    const initC = async () => {
      try {
        const commonDeviceCount = await getCommonDeviceCount();
        const allDeviceCount = await getAllDeviceCount();
        const erroeDeviceCount = await getErroeDeviceCount();
        const alarmCount = await getAlarm();
        const patrolCount = await getPatrol();

        this.setState({ allDeviceCount, commonDeviceCount, erroeDeviceCount });
        this.setState({ alarmCount });
        this.setState({ patrolCount });
      } catch (err) {
        console.log(err);
      }
    }

    initC();

    let setSSSSS = (obj) => {
      let building = { ...obj, buildTime: moment(obj.buildTime).format("YYYY年MM月DD日") };
      this.setState({ building });
    }

    function init() {
      let newId = [], param = '';
      function callBack(data) {
        sessionStorage.setItem('flag', 1)
        newId = [];
        window.rpc.area.getArrayDeviceCountExByContainer({ deep: 3 }, 0, 0).then((res) => {
          res.forEach(function (value) {
            data.forEach(function (x) {
              if (value.id === x.floor) {
                openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                alarm(Alarm);
                mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
                var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), value.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  id: newId
                };
                if (paramState !== '1') {
                  map.addOverlay(maker)// 将标注添加到地图中
                }
                addClickHandler(content, param, newId, obj, maker);
              }
            })
          })
        }, (err) => {
          console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
        })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);

      var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      var point = new window.BMap.Point(121.618835,
        29.920698);

      map.centerAndZoom(new window.BMap.Point(116.3964, 39.9094), 12);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      map.centerAndZoom(point, 12);
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 12);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      // map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);
      function G(id) {
        return document.getElementById(id);
      }
      map.centerAndZoom(point, 18);                   // 初始化地图,设置城市和地图级别。
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
      map.addEventListener("maptypechange", function show() {
        let mapType = !that.state.mapType;
        that.setState({ mapType: mapType })
      });
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      var opts = {
        width: 100,     // 信息窗口宽度
        height: 50,     // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true//设置允许信息窗发送短息
      };
      function alarm(src, buildId, level, nature) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
          li2.appendChild(document.createTextNode("消防等级：" + level));
          li3.appendChild(document.createTextNode("使用性质：" + nature));
          var a = this._a = document.createElement("a");

          //a.setAttribute("href", "/org/floor/" + buildId + "");
          a.setAttribute("href", "javascript:;");
          a.setAttribute("id", "buildAreaMap" + buildId + "");
          a.appendChild(document.createTextNode("查看详情"));
          a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          div.appendChild(ul);
          var a2 = this._a2 = document.createElement("span");
          a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
          li4.appendChild(a2);
          li4.appendChild(a);
          a2.setAttribute("href", "javascript:;");
          a2.setAttribute("id", "buildImgMap" + buildId + "");
          a2.appendChild(document.createTextNode("平面图"));
          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.setAttribute("class", "buildImgFix" + buildId + "");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              let id = Id[0];
              that.setState({ buildingInfoId: id });
            })
            a2.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                that.setState({ mapPoints, mapPointsIcon });
              });
              window.rpc.area.getInfoById(Id[0]).then((res) => {
                let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                that.setState({ building });
                that.setState({ markerId: Id, new_pingmiantu: true });
              })
              window.rpc.area.getArrayByContainer({ parentId: Id[0] }, 0, 0).then((res) => {
                let storeys = res.map(x => ({ ...x, id: x.id, value: `${x.id}`, label: x.name, mapUrl: x.mapUrl ? x.mapUrl : '', buildTime: moment(res.buildTime).format("YYYY年MM月DD日") }));
                console.log(storeys);
                that.setState({ storeys });
              })
            })
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];
            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }
            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {
        res.map((x) => {

          let points = point.split(';');
          let len = points.length;
          if (len > 0) {
            points[len - 1] = points[0]
          };
          let pointsMap = [];
          points.map(xy => {
            let mapXy = xy.replace('"', '');
            let pointa = mapXy.split(',');
            let objb = { x: pointa[0], y: pointa[1] };
            pointsMap.push(objb);
          });
          let arr = [];
          pointsMap.map(x => {
            let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
            arr.push(a);
          });
          var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5 });   //创建折线
          map.addOverlay(polyline);   //增加折线
        })
      })
      window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

        newId = '';
        res.map((x) => {
          let buildId = x.id;
          let level = "一级";
          let nature = "0";

          alarm(UnAlarm, buildId, level, nature);
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          if (paramState !== '2') {
            map.addOverlay(maker)// 将标注添加到地图中
          }
          addClickHandler(content, param, newId, obj, maker);

        })
        window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: 2 } }, 0, 0).then((res) => {

          newId = '';
          res.map((x) => {
            let buildId = x.id;
            let level = "一级";
            let nature = x.extend.nature;
            alarm(yellow, buildId, level, nature);
            mouseoverTxt = x.name;
            var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = { 'floor': newId };
            if (paramState !== '2') {
              map.addOverlay(maker)// 将标注添加到地图中
            }
            addClickHandler(content, param, newId, obj, maker);

          })
          window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: 3 } }, 0, 0).then((result) => {

            result.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = x.extend.nature;
              alarm(Alarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = { 'floor': newId };
              if (paramState !== '1') {
                map.addOverlay(maker)// 将标注添加到地图中
              }
              addClickHandler(content, param, newId, obj, maker);
            })
          }, (err) => {
            console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
          });

        }, (err) => {
          console.warn(err);
        });
      }, (err) => {
        console.warn(err);
      });

      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }

      function addClickHandler(content, param, newId, obj, marker) {
        marker._img.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        });
        marker._span.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);

          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        })
      }
    }

    setTimeout(() => {
      init();
    }, 1000)
  }

  setSSSSS = (obj) => {
    let building = { ...obj, buildTime: moment(obj.buildTime).format("YYYY年MM月DD日") };
    this.setState({ building });
  }

  init = (areaId) => {
    let that = this;
    let newId = [], param = '';
    if (that.state.mapType == false) {
      var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
    } else {
      var map = new window.BMap.Map("equipDefaultMap");
    }
    map.addEventListener("maptypechange", function show() {
      let mapType = !that.state.mapType;
      that.setState({ mapType: mapType })
    });
    window.rpc.area.getInfoById(areaId).then((res) => {
      that.setState({ mapCenter: { x: res.x, y: res.y } });
    });
    var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
    map.centerAndZoom(point, that.state.mapLevel);
    map.addEventListener("dragend", function () {
      var center = map.getCenter();
      that.setState({ mapCenter: { x: center.lng, y: center.lat } });
    });
    map.addEventListener("zoomend", function () {
      let zoomLevel = this.getZoom();
      that.setState({ mapLevel: zoomLevel });
    });
    map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));


    map.enableScrollWheelZoom();
    // 复杂的自定义覆盖物
    function ComplexCustomOverlay(point, text, mouseoverText) {
      this._point = point;
      this._text = text;
      this._overText = mouseoverText;
    }
    ComplexCustomOverlay.prototype = new window.BMap.Overlay();
    ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
      this._div['on' + event] = fun;
    }
    ComplexCustomOverlay.prototype.draw = function () {
      var map = this._map;
      var pixel = map.pointToOverlayPixel(this._point);
      this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
      this._div.style.top = pixel.y - 30 + "px";
    }
    var mouseoverTxt = '';
    map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
    map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
    // 编写自定义函数,创建标注
    //map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
    // 添加带有定位的导航控件
    var navigationControl = new window.BMap.NavigationControl({
      // 靠左上角位置
      // anchor: window.BMAP_ANCHOR_TOP_LEFT,
      // LARGE类型
      type: window.BMAP_NAVIGATION_CONTROL_LARGE,
      // 启用显示定位
      enableGeolocation: true
    });
    // map.addControl(navigationControl);
    // 添加定位控件
    var geolocationControl = new window.BMap.GeolocationControl();
    geolocationControl.addEventListener("locationSuccess", function (e) {
      // 定位成功事件
      var address = '';
      address += e.addressComponent.province;
      address += e.addressComponent.city;
      address += e.addressComponent.district;
      address += e.addressComponent.street;
      address += e.addressComponent.streetNumber;
    });
    geolocationControl.addEventListener("locationError", function (e) {
      // 定位失败事件
      alert(e.message);
    });
    map.addControl(geolocationControl);
    function G(id) {
      return document.getElementById(id);
    }
    //map.centerAndZoom("宁波", 12);                   // 初始化地图,设置城市和地图级别。
    var ac = new window.BMap.Autocomplete(    //建立一个自动完成的对象
      {
        "input": "suggestId"
        , "location": map
      });

    ac.addEventListener("onhighlight", function (e) {  //鼠标放在下拉列表上的事件
      var str = "";
      var _value = e.fromitem.value;
      var value = "";
      if (e.fromitem.index > -1) {
        value = _value.province + _value.city + _value.district + _value.street + _value.business;
      }
      str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;

      value = "";
      if (e.toitem.index > -1) {
        _value = e.toitem.value;
        value = _value.province + _value.city + _value.district + _value.street + _value.business;
      }
      str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
      G("searchResultPanel").innerHTML = str;
    });

    map.centerAndZoom(new window.BMap.Point(121.618835, 29.920702), 18);
    map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
    var data_info = [[116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
    [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
    [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
    ];
    var opts = {
      width: 100,     // 信息窗口宽度
      height: 50,     // 信息窗口高度
      title: "", // 信息窗口标题
      enableMessage: true//设置允许信息窗发送短息
    };
    function alarm(src, buildId, level, nature) {
      ComplexCustomOverlay.prototype.initialize = function (map) {
        this._map = map;
        var div = this._div = document.createElement("div");
        div.style.position = "absolute";
        div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
        div.style.color = "white";
        div.style.width = "24px";
        div.style.height = "33px";
        div.style.padding = "2px";
        div.style.textAlign = "center";
        div.style.lineHeight = "18px";
        div.style.whiteSpace = "nowrap";
        div.style.MozUserSelect = "none";
        div.style.fontSize = "12px";
        var span = this._span = document.createElement("span");
        span.style.position = 'absolute';
        span.style.width = "24px";
        div.style.height = "33px";
        span.style.left = "3px";
        span.style.top = "5px";
        span.style.textAlign = "center";
        var img = this._img = document.createElement("img");
        img.src = src;
        img.style.width = "24px";
        img.style.height = "33px";
        img.style.float = 'left';
        div.appendChild(img);
        div.appendChild(span);
        var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
        ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
        var li1 = this._li1 = document.createElement("li");
        var li1 = this._li1 = document.createElement("li");
        var li2 = this._li2 = document.createElement("li");
        var li3 = this._li3 = document.createElement("li");
        var li4 = this._li4 = document.createElement("li");
        li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
        li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
        li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
        li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
        div.appendChild(ul);
        ul.appendChild(li1);
        ul.appendChild(li2);
        ul.appendChild(li3);
        ul.appendChild(li4);
        li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
        li2.appendChild(document.createTextNode("消防等级：" + level));
        li3.appendChild(document.createTextNode("使用性质：" + nature));
        var a = this._a = document.createElement("a");

        a.setAttribute("href", "javascript:;");
        a.setAttribute("id", "buildImgMap" + buildId + "");
        a.appendChild(document.createTextNode("查看详情"));
        a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
        div.appendChild(ul);
        var a2 = this._a2 = document.createElement("span");
        a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
        li4.appendChild(a2);
        li4.appendChild(a);
        a2.setAttribute("href", "javascript:;");
        a2.setAttribute("id", "buildImgMap" + buildId + "");
        a2.appendChild(document.createTextNode("平面图"));
        var a3 = this._a3 = document.createElement("span");
        a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
        li4.appendChild(a3);
        a3.setAttribute("href", "javascript:;");
        a3.setAttribute("class", "buildImgFix" + buildId + "");
        a3.appendChild(document.createTextNode("关闭"));
        if (src !== UnAlarm) {
          span.appendChild(document.createTextNode(this._text));
        }
        var arrow = this._arrow = document.createElement("div");
        arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
        arrow.style.position = "absolute";
        arrow.style.height = "25px";
        arrow.style.top = "22px";
        arrow.style.left = "10px";
        arrow.style.overflow = "hidden";
        arrow.style.backgroundPosition = "0px 0px";
        div.appendChild(arrow);
        let display = false;
        div.onmouseenter = function () {
          display = true;
          let thatDiv = this;
          this.getElementsByTagName("ul")[0].style.display = 'block';
          arrow.style.backgroundPosition = "0px -20px";
          a.addEventListener("click", function (e) {
            var reg = /\d+/g;
            var str = this.id;
            var Id = str.match(reg);
            let id = Id[0];
            that.setState({ buildingInfoId: id });
          })
          a2.addEventListener("click", function (e) {
            var reg = /\d+/g;
            var str = this.id;
            var Id = str.match(reg);
            window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
              let mapPoints = res.filter(point => point.mapX);
              let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
              that.setState({ mapPoints, mapPointsIcon });
            });
            window.rpc.area.getInfoById(Id[0]).then((res) => {
              let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
              that.setState({ building });
              that.setState({ markerId: Id, new_pingmiantu: true });
            })
          })
          a3.addEventListener("click", function (e) {
            thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
          })
        }
        div.onmouseleave = function () {
          display = false;
          let ul = this.getElementsByTagName("ul")[0];
          setTimeout(function () {
            if (display == false) {
              ul.style.display = 'none';
            }
          }, 800)
          arrow.style.backgroundPosition = "0px 0px";
        }
        map.getPanes().labelPane.appendChild(div);
        return div;
      }
    }
    window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {
      let idState3 = res.map(x => x.id);
      newId = '';
      res.map((x) => {
        let buildId = x.id;
        let level = "一级";
        let nature = "办公";
        alarm(UnAlarm, buildId, level, nature);
        mouseoverTxt = x.name;
        var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
        var content = x.name;
        var obj = x;
        newId = x.id;
        param = { 'floor': newId };
        map.addOverlay(maker)// 将标注添加到地图中
        addClickHandler(content, param, newId, obj, maker);
      })
      window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 2 }, deep: 3 }, 0, 0).then((res) => {

        newId = '';
        res.map((x) => {
          let buildId = x.id;
          let level = "一级";
          let nature = "办公";
          alarm(UnAlarm, buildId, level, nature);
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);
        })
        window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 3 }, deep: 3 }, 0, 0).then((result) => {

          result.map((x) => {
            let buildId = x.id;
            let level = "一级";
            let nature = "办公";
            alarm(Alarm, buildId, level, nature);
            mouseoverTxt = x.name;
            var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = { 'floor': newId };
            map.addOverlay(maker)// 将标注添加到地图中
            addClickHandler(content, param, newId, obj, maker);
          })
        }, (err) => {
          console.warn(err);
        });

      }, (err) => {
        console.warn(err);
      });
    }, (err) => {
      console.warn(err);
    });

    const getBuilding = (newId) => {
      return window.rpc.area.getInfoById(newId);
    }

    const buildingInfo = async (newId) => {
      const building = await getBuilding(newId);
      this.setSSSSS(building);
    }

    function addClickHandler(content, param, newId, obj, marker) {
      marker.addEventListener("click", function (e) {
        sessionStorage.setItem('newId', newId);
        buildingInfo(newId);
        this.setState({
          id: newId
        })
        window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
          sessionStorage.setItem('equipment', JSON.stringify(res))
          sessionStorage.setItem('number', obj.count)
          this.setState({
            id: newId
          })
        }, (err) => {
          console.warn(err);
        })
      }
      );
    }
  }

  inita = (alarmId) => {
    let that = this;
    let newId = [], param = '';

    if (that.state.mapType == false) {
      var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
    } else {
      var map = new window.BMap.Map("equipDefaultMap");
    }
    map.addEventListener("maptypechange", function show() {
      let mapType = !that.state.mapType;
      that.setState({ mapType: mapType })
    });
    window.rpc.area.getInfoById(alarmId).then((res) => {
      that.setState({ mapCenter: { x: res.x, y: res.y } });
    });
    var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
    map.centerAndZoom(point, that.state.mapLevel);
    map.addEventListener("dragend", function () {
      var center = map.getCenter();
      that.setState({ mapCenter: { x: center.lng, y: center.lat } });
    });
    map.addEventListener("zoomend", function () {
      let zoomLevel = this.getZoom();
      that.setState({ mapLevel: zoomLevel });
    });
    map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));


    map.enableScrollWheelZoom();
    // 复杂的自定义覆盖物
    function ComplexCustomOverlay(point, text, mouseoverText) {
      this._point = point;
      this._text = text;
      this._overText = mouseoverText;
    }
    ComplexCustomOverlay.prototype = new window.BMap.Overlay();
    ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
      this._div['on' + event] = fun;
    }
    ComplexCustomOverlay.prototype.draw = function () {
      var map = this._map;
      var pixel = map.pointToOverlayPixel(this._point);
      this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
      this._div.style.top = pixel.y - 30 + "px";
    }
    var mouseoverTxt = '';
    map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
    map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
    // 编写自定义函数,创建标注
    //map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
    // 添加带有定位的导航控件
    var navigationControl = new window.BMap.NavigationControl({
      type: window.BMAP_NAVIGATION_CONTROL_LARGE,
      // 启用显示定位
      enableGeolocation: true
    });
    // map.addControl(navigationControl);
    // 添加定位控件
    var geolocationControl = new window.BMap.GeolocationControl();
    geolocationControl.addEventListener("locationSuccess", function (e) {
      // 定位成功事件
      var address = '';
      address += e.addressComponent.province;
      address += e.addressComponent.city;
      address += e.addressComponent.district;
      address += e.addressComponent.street;
      address += e.addressComponent.streetNumber;
    });
    geolocationControl.addEventListener("locationError", function (e) {
      // 定位失败事件
      alert(e.message);
    });
    map.addControl(geolocationControl);
    function G(id) {
      return document.getElementById(id);
    }
    //map.centerAndZoom("宁波", 12);                   // 初始化地图,设置城市和地图级别。
    var ac = new window.BMap.Autocomplete(    //建立一个自动完成的对象
      {
        "input": "suggestId"
        , "location": map
      });

    ac.addEventListener("onhighlight", function (e) {  //鼠标放在下拉列表上的事件
      var str = "";
      var _value = e.fromitem.value;
      var value = "";
      if (e.fromitem.index > -1) {
        value = _value.province + _value.city + _value.district + _value.street + _value.business;
      }
      str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;

      value = "";
      if (e.toitem.index > -1) {
        _value = e.toitem.value;
        value = _value.province + _value.city + _value.district + _value.street + _value.business;
      }
      str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
      G("searchResultPanel").innerHTML = str;
    });

    map.centerAndZoom(new window.BMap.Point(121.618835, 29.920702), 18);
    var data_info = [[116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
    [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
    [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
    ];
    var opts = {
      width: 100,     // 信息窗口宽度
      height: 50,     // 信息窗口高度
      title: "", // 信息窗口标题
      enableMessage: true//设置允许信息窗发送短息
    };
    function alarm(src, buildId, level, nature) {
      ComplexCustomOverlay.prototype.initialize = function (map) {
        this._map = map;
        var div = this._div = document.createElement("div");
        div.style.position = "absolute";
        div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
        div.style.color = "white";
        div.style.width = "24px";
        div.style.height = "33px";
        div.style.padding = "2px";
        div.style.textAlign = "center";
        div.style.lineHeight = "18px";
        div.style.whiteSpace = "nowrap";
        div.style.MozUserSelect = "none";
        div.style.fontSize = "12px";
        var span = this._span = document.createElement("span");
        span.style.position = 'absolute';
        span.style.width = "24px";
        div.style.height = "33px";
        span.style.left = "3px";
        span.style.top = "5px";
        span.style.textAlign = "center";
        var img = this._img = document.createElement("img");
        img.src = src;
        img.style.width = "24px";
        img.style.height = "33px";
        img.style.float = 'left';
        div.appendChild(img);
        div.appendChild(span);
        var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
        ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
        var li1 = this._li1 = document.createElement("li");
        var li1 = this._li1 = document.createElement("li");
        var li2 = this._li2 = document.createElement("li");
        var li3 = this._li3 = document.createElement("li");
        var li4 = this._li4 = document.createElement("li");
        li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
        li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
        li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
        li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
        div.appendChild(ul);
        ul.appendChild(li1);
        ul.appendChild(li2);
        ul.appendChild(li3);
        ul.appendChild(li4);
        li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
        li2.appendChild(document.createTextNode("消防等级：" + level));
        li3.appendChild(document.createTextNode("使用性质：" + nature));
        var a = this._a = document.createElement("a");

        a.setAttribute("href", "javascript:;");
        a.setAttribute("id", "buildImgMap" + buildId + "");
        a.appendChild(document.createTextNode("查看详情"));
        a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
        div.appendChild(ul);
        var a2 = this._a2 = document.createElement("span");
        a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
        li4.appendChild(a2);
        li4.appendChild(a);
        a2.setAttribute("href", "javascript:;");
        a2.setAttribute("id", "buildImgMap" + buildId + "");
        a2.appendChild(document.createTextNode("平面图"));
        var a3 = this._a3 = document.createElement("span");
        a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
        li4.appendChild(a3);
        a3.setAttribute("href", "javascript:;");
        a3.setAttribute("class", "buildImgFix" + buildId + "");
        a3.appendChild(document.createTextNode("关闭"));
        if (src !== UnAlarm) {
          span.appendChild(document.createTextNode(this._text));
        }
        var arrow = this._arrow = document.createElement("div");
        arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
        arrow.style.position = "absolute";
        arrow.style.height = "25px";
        arrow.style.top = "22px";
        arrow.style.left = "10px";
        arrow.style.overflow = "hidden";
        arrow.style.backgroundPosition = "0px 0px";
        div.appendChild(arrow);
        let display = false;
        div.onmouseenter = function () {
          display = true;
          let thatDiv = this;
          this.getElementsByTagName("ul")[0].style.display = 'block';
          arrow.style.backgroundPosition = "0px -20px";
          a.addEventListener("click", function (e) {
            var reg = /\d+/g;
            var str = this.id;
            var Id = str.match(reg);
            let id = Id[0];
            that.setState({ buildingInfoId: id });
          });
          a2.addEventListener("click", function (e) {
            var reg = /\d+/g;
            var str = this.id;
            var Id = str.match(reg);
            window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
              let mapPoints = res.filter(point => point.mapX);
              let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
              that.setState({ mapPoints, mapPointsIcon });
            });
            window.rpc.area.getInfoById(Id[0]).then((res) => {
              let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
              that.setState({ building });
              that.setState({ markerId: Id, new_pingmiantu: true });
            })
          })
          a3.addEventListener("click", function (e) {
            thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
          })
        }
        div.onmouseleave = function () {
          display = false;
          let ul = this.getElementsByTagName("ul")[0];
          setTimeout(function () {
            if (display == false) {
              ul.style.display = 'none';
            }
          }, 800)
          arrow.style.backgroundPosition = "0px 0px";
        }
        map.getPanes().labelPane.appendChild(div);
        return div;
      }
    }
    window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

      newId = '';
      res.map((x) => {
        let buildId = x.id;
        let level = "一级";
        let nature = "办公";
        alarm(UnAlarm, buildId, level, nature);
        mouseoverTxt = x.name;
        var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
        var content = x.name;
        var obj = x;
        newId = x.id;
        param = { 'floor': newId };
        map.addOverlay(maker)// 将标注添加到地图中
        addClickHandler(content, param, newId, obj, maker);
      })
      window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 2 }, deep: 3 }, 0, 0).then((res) => {

        newId = '';
        res.map((x) => {
          let buildId = x.id;
          let level = "一级";
          let nature = "办公";
          alarm(yellow, buildId, level, nature);
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);

        })
        window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 3 }, deep: 3 }, 0, 0).then((result) => {

          result.map((x) => {
            if (x.id != alarmId) {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(Alarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = { 'floor': newId };
              map.addOverlay(maker)// 将标注添加到地图中
              addClickHandler(content, param, newId, obj, maker);
            } else {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              newId = x.id;
              param = { 'floor': newId };
              map.addOverlay(maker)// 将标注添加到地图中
              addClickHandler(content, param, newId, obj, maker);
            }
          })
        }, (err) => {
          console.warn(err);
        });

      }, (err) => {
        console.warn(err);
      });
    }, (err) => {
      console.warn(err);
    });

    const getBuilding = (newId) => {
      return window.rpc.area.getInfoById(newId);
    }

    const buildingInfo = async (newId) => {
      const building = await getBuilding(newId);
      this.setSSSSS(building);
    }

    function addClickHandler(content, param, newId, obj, marker) {
      marker.addEventListener("click", function (e) {
        sessionStorage.setItem('newId', newId);
        buildingInfo(newId);
        this.setState({
          id: newId
        })
        window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
          sessionStorage.setItem('equipment', JSON.stringify(res))
          sessionStorage.setItem('number', obj.count)
          this.setState({
            id: newId
          })
        }, (err) => {
          console.warn(err);
        })
      }
      );
    }
  }

  handleK = () => {
    if (this.state.display === "block") {
      this.setState({ display: "none" });
    } else {
      this.setState({ display: "block" });
      $("#searchCase").css({ display: 'none' });
    }
  }

  //关闭辅助
  handleCan = () => {
    this.setState({ SixD: "none", routId: 0, });
    //关闭辅助后，去掉圆圈、资源分布图标
    let that = this;
    let paramState = this.props.params.dstate;
    const getAllDeviceCount = () => {
      return window.rpc.device.getCount();
    }

    const getCommonDeviceCount = () => {
      return window.rpc.device.getCountByCond({ rstate: 1 });
    }

    const getErroeDeviceCount = () => {
      return window.rpc.device.getCountByCond({ rstate: 2 });
    }
    window.rpc.device.types.getArray(0, 0).then((res) => {
      let types = {};
      for (let value of res) {
        types[value.id] = value.name
      }
      this.setState({ types });
    });

    const getAlarm = () => {
      return window.rpc.device.alarm.getCountFieldByContainer(null, 'type');
    }

    const getPatrol = () => {
      return window.rpc.device.patrol.getCountFieldByContainer(null, 'type');
    }

    const initC = async () => {
      try {
        const commonDeviceCount = await getCommonDeviceCount();
        const allDeviceCount = await getAllDeviceCount();
        const erroeDeviceCount = await getErroeDeviceCount();

        const alarmCount = await getAlarm();
        const patrolCount = await getPatrol();

        this.setState({ allDeviceCount, commonDeviceCount, erroeDeviceCount });
        this.setState({ alarmCount });
        this.setState({ patrolCount });
      } catch (err) {
        console.log(err);
      }
    }

    initC();

    let setSSSSS = (obj) => {
      let building = { ...obj, buildTime: moment(obj.buildTime).format("YYYY年MM月DD日") };
      this.setState({ building });
    }

    function init() {
      let newId = [], param = '';
      function callBack(data) {
        sessionStorage.setItem('flag', 1)
        newId = [];
        window.rpc.area.getArrayDeviceCountExByContainer({ deep: 3 }, 0, 0).then((res) => {
          res.forEach(function (value) {
            data.forEach(function (x) {
              if (value.id === x.floor) {
                openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                alarm(Alarm);
                mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
                var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), value.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  id: newId
                };
                if (paramState !== '1') {
                  map.addOverlay(maker)// 将标注添加到地图中
                }
                addClickHandler(content, param, newId, obj, maker);
              }
            })
          })
        }, (err) => {
          console.warn(err);
        })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);
      var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      var point = new window.BMap.Point(121.618835,
        29.920698);

      map.centerAndZoom(new window.BMap.Point(116.3964, 39.9094), 12);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      map.centerAndZoom(point, 12);
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 12);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      // map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);
      function G(id) {
        return document.getElementById(id);
      }
      map.centerAndZoom(point, 18);                   // 初始化地图,设置城市和地图级别。
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
      map.addEventListener("maptypechange", function show() {
        let mapType = !that.state.mapType;
        this.setState({ mapType: mapType })
      });
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      var opts = {
        width: 100,     // 信息窗口宽度
        height: 50,     // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true//设置允许信息窗发送短息
      };
      function alarm(src, buildId, level, nature) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
          li2.appendChild(document.createTextNode("消防等级：" + level));
          li3.appendChild(document.createTextNode("使用性质：" + nature));
          var a = this._a = document.createElement("a");

          //a.setAttribute("href", "/org/floor/" + buildId + "");
          a.setAttribute("href", "javascript:;");
          a.setAttribute("id", "buildAreaMap" + buildId + "");
          a.appendChild(document.createTextNode("查看详情"));
          a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          div.appendChild(ul);
          var a2 = this._a2 = document.createElement("span");
          a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
          li4.appendChild(a2);
          li4.appendChild(a);
          a2.setAttribute("href", "javascript:;");
          a2.setAttribute("id", "buildImgMap" + buildId + "");
          a2.appendChild(document.createTextNode("平面图"));
          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.setAttribute("class", "buildImgFix" + buildId + "");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              let id = Id[0];
              that.setState({ buildingInfoId: id });
            })
            a2.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                that.setState({ mapPoints, mapPointsIcon });
              });
              window.rpc.area.getInfoById(Id[0]).then((res) => {
                let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                that.setState({ building });
                that.setState({ markerId: Id, new_pingmiantu: true });
              })
            })
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];
            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }
            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {
        res.map((x) => {
          let points = point.split(';');
          let len = points.length;
          if (len > 0) {
            points[len - 1] = points[0]
          };
          let pointsMap = [];
          points.map(xy => {
            let mapXy = xy.replace('"', '');
            let pointa = mapXy.split(',');
            let objb = { x: pointa[0], y: pointa[1] };
            pointsMap.push(objb);
          });
          let arr = [];
          pointsMap.map(x => {
            let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
            arr.push(a);
          });
          var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5 });   //创建折线
          map.addOverlay(polyline);   //增加折线
        })
      })
      window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

        newId = '';
        res.map((x) => {
          let buildId = x.id;
          let level = "一级";
          let nature = "0";

          alarm(UnAlarm, buildId, level, nature);
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          if (paramState !== '2') {
            map.addOverlay(maker)// 将标注添加到地图中
          }
          addClickHandler(content, param, newId, obj, maker);

        })
        window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 2 }, deep: 3 }, 0, 0).then((res) => {

          newId = '';
          res.map((x) => {
            let buildId = x.id;
            let level = "一级";
            let nature = "办公";
            alarm(yellow, buildId, level, nature);
            mouseoverTxt = x.name;
            var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = { 'floor': newId };
            if (paramState !== '2') {
              map.addOverlay(maker)// 将标注添加到地图中
            }
            addClickHandler(content, param, newId, obj, maker);

          })
          window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 3 }, deep: 3 }, 0, 0).then((result) => {

            result.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(Alarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = { 'floor': newId };
              if (paramState !== '1') {
                map.addOverlay(maker)// 将标注添加到地图中
              }
              addClickHandler(content, param, newId, obj, maker);
            })
          }, (err) => {
            console.warn(err);
          });

        }, (err) => {
          console.warn(err);
        });
      }, (err) => {
        console.warn(err);
      });

      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }

      function addClickHandler(content, param, newId, obj, marker) {
        marker._img.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        });
        marker._span.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        })
      }
      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts);  // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }
    }

    setTimeout(() => {
      init();
    }, 100)
  }

  //刷新地图
  onChangeState = (stateName) => {
    this.setState(stateName)
    this.setState({ id: stateName.sixId, routId: 1 });
    let id = stateName.sixId;
    window.rpc.device.getInfoById(id).then((result) => {
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.area.getLocationName(result.location).then((res) => {
        const device = { ...result, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, location: res, };
        this.setState({ alarmSix: { device: device } });
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    })
    //建筑
    window.rpc.area.getInfoById(id).then((result) => {
      let area = { ...result, name: result.name, layer: result.layer, galleryful: result.galleryful, face: result.face, hight: result.hight, };
      this.setState({ alarmSix: { area: area }, display: 'none' });
    }, (err) => {
      console.warn(err);
    })
    //户籍
    window.rpc.owner.getInfoById(id).then((result) => {
      let owner = { ...result, type: Orgtypes[result.type]['name'], state: dStateList[result.state], name: result.name, asset: result.asset, face: result.face, address: result.address, peopleScale: result.peopleScale, registerTime: moment(result.registerTime).format("YYYY年MM月DD日") || new Date().toLocaleString, };
      this.setState({ alarmSix: { owner: owner } });
    }, (err) => {
      console.warn(err);
    })
    //处理结果详情数据
    window.rpc.device.alarm.getInfoById(id).then((result) => {
      window.rpc.user.getArray(0, 0).then((res) => {
        const rData = { ...result, type: armtypeList[result.type], userId: res[result.userId]["name"], state: ResultState[result.state], createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };
        this.setState({ alarmSix: { rData: rData } });
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    })

    let areaId = stateName.areaId || null;
    let alarmId = stateName.alarmId || null;

    if (areaId) {
      this.init(areaId);
    }
    if (alarmId) {
      this.inita(alarmId);
    }

    let jingdu = 0.005855;
    let weidu = 0.004505;

    const getBuilding = () => {
      return window.rpc.area.getArrayByContainer({ id: stateName.sixId }, 0, 0);
    }

    const getResources = (building) => {
      return window.rpc.resource.getArrayByContainer({ x: [building.x - jingdu, building.x + jingdu], y: [building.y - weidu, building.y + weidu] }, 0, 0);
    }

    const draw = async () => {
      try {
        let building = await getBuilding();
        let resources = await getResources(building[0]);

        var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
        var point = new window.BMap.Point(building[0].x, building[0].y);
        map.centerAndZoom(point, 17);
        map.enableScrollWheelZoom(true);
        map.enableContinuousZoom();
        var circle = new window.BMap.Circle(point, 500, { strokeColor: "#c8efe6", strokeWeight: 2, strokeOpacity: 0.5, fillColor: '#c8efe6' });
        map.addOverlay(circle);

        var buildingIcon = new window.BMap.Icon(buildingImg, new window.BMap.Size(56, 56));
        var riverIcon = new window.BMap.Icon(riverImg, new window.BMap.Size(32, 32));
        var otherwaterIcon = new window.BMap.Icon(otherwaterImg, new window.BMap.Size(32, 32));
        var poorIcon = new window.BMap.Icon(poorImg, new window.BMap.Size(32, 32));
        var firecarIcon = new window.BMap.Icon(firecarImg, new window.BMap.Size(32, 32));
        var xfsIcon = new window.BMap.Icon(xfsImg, new window.BMap.Size(32, 32));
        var buildingMarker = new window.BMap.Marker(point, { icon: buildingIcon });
        map.addOverlay(buildingMarker);

        function addMarker(x) {
          let point = new window.BMap.Point(x.x, x.y);
          let icon = { icon: otherwaterIcon };
          switch (x.type) {
            case 1:
              icon = { icon: riverIcon };
              break;
            case 3:
              icon = { icon: poorIcon };
              break;
            case 2:
              icon = { icon: xfsIcon };
              break;
            default:
              icon = { icon: otherwaterIcon };
              break;
          }
          var marker = new window.BMap.Marker(point, icon);
          map.addOverlay(marker);
        }
        resources.map(x => {
          addMarker(x);
        })
      } catch (error) {
        console.log(error)
      }
    }

    draw();
    document.addEventListener('mousewheel', () => {
      // console.log("测试成功！")
    })
  }

  // 六屏
  handleA = () => {
    this.setState({ heightTotal: "100%", topA: 0, offer: false, widthA: "100%", widthB: 0, heightA: "100%", heightB: 0, heightC: 0, heightD: 0, heightE: 0, heightF: 0, });
  }
  handleB = () => {
    this.setState({ Toffer: 1, heightTotal: "100%", topA: 0, offer: false, widthA: "100%", widthB: 0, heightA: 0, heightB: "95%", heightC: 0, heightD: 0, heightE: 0, heightF: 0, });
  }
  handleC = () => {
    this.setState({ Toffer: 1, heightTotal: "100%", topA: 0, offer: false, widthA: "100%", widthB: 0, heightA: 0, heightB: 0, heightC: "95%", heightD: 0, heightE: 0, heightF: 0, });
  }
  handleD = () => {
    this.setState({ heightTotal: "100%", topA: 0, offer: false, widthA: 0, widthB: "100%", heightA: 0, heightB: 0, heightC: 0, heightD: "95%", heightE: 0, heightF: 0, });
  }
  handleE = () => {
    this.setState({ heightTotal: "100%", topA: 0, offer: false, widthA: 0, widthB: "100%", heightA: 0, heightB: 0, heightC: 0, heightD: 0, heightE: "95%", heightF: 0, });
  }
  handleF = () => {
    this.setState({ heightTotal: "100%", topA: 0, offer: false, widthA: 0, widthB: "100%", heightA: 0, heightB: 0, heightC: 0, heightD: 0, heightE: 0, heightF: "95%", });
  }
  handleTrue = () => {
    this.setState({
      Toffer: 1, offer: true, widthA: "30%", widthB: "30%", heightA: "30%", heightB: "29%", heightC: "29%",
      heightD: "29%", heightE: "29%", heightF: "29%", heightTotal: "92.5%", topA: "7.5%",
    });
    setTimeout(() => {
      this.setState({
        Toffer: 0,
      });
    }, 1000)
  }

  // 发送短信
  showMesModal = () => {
    window.rpc.user.getArray(0, 0).then((res) => {
      let user = res.map(x => ({ id: x.id, name: x.name, mobile: x.mobile || '' }))
      this.props.EquipDefaultState.mes_array = user;
    })
    this.setState({
      mes_visible: true,
    });
  }
  handleMesOk = () => {
    this.setState({ mes_loading: true });
    setTimeout(() => {
      this.setState({ mes_loading: false, mes_visible: false });
    }, 3000);
  }
  handleMesCancel = () => {
    this.setState({ mes_visible: false });
  }

  showWarnModal = () => {
    window.rpc.user.getArray(0, 0).then((res) => {
      let user = res.map(x => ({ id: x.id, name: x.name }))
      this.props.EquipDefaultState.mes_array = user;
    })
    this.setState({
      warn_visible: true,
    });
  }
  handleWarnOk = () => {
    this.setState({ warn_loading: true });
    setTimeout(() => {
      this.setState({ warn_loading: false, warn_visible: false });
    }, 3000);
  }
  handleWarnCancel = () => {
    this.setState({ warn_visible: false });
  }
  handleMouseOver = (e) => {

  }
  handleSeach = (e) => {
    $("#searchCase").css({ display: 'none' });
  }

  handleSeachTongxunlu(value) {
    window.rpc.user.getArrayByCond({ name: value }, 0, 0).then((res) => {
      let user = res.map(x => ({ id: x.id, name: x.name, mobile: x.mobile || '' }))
      this.props.EquipDefaultState.mes_array = user;
    })
  }
  onFloorChange = (value) => {
    let that = this;


    let storey = parseInt(value[0], 10);
    console.log(storey);
    // console.log(this.state.storeys)
    window.rpc.area.getInfoById(storey).then((res) => {
      console.log(res)
      let storey = res.map(x => ({ ...x, mapUrl: x.mapUrl ? x.mapUrl : '', buildTime: moment(res.buildTime).format("YYYY年MM月DD日") }));
      console.log(storey);
      that.setState({ storey });
      that.setState({ storeyShow: true });

    }, err => {
      console.warn(err)
    })

    //this.set
  }
  render() {
    let that = this;

    $('.hoverSearch').mouseenter((e) => {
      e.stopPropagation();
      $("#searchCase").css({ display: 'block' });
    });

    function handleMenuClick(e) {
      that.setState({ mapState: e.key });
      that.setState({ mapBuild: '' });
      wateO = 0; wateT = 0; wateS = 0;
      if (that.state.mapType == false) {
        var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
      } else {
        var map = new window.BMap.Map("equipDefaultMap");
      }
      map.addEventListener("maptypechange", function show() {
        let mapType = !that.state.mapType;
        that.setState({ mapType: mapType })
      });
      var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
      map.centerAndZoom(point, that.state.mapLevel);
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));

      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用

      // 编写自定义函数,创建标注
      function addMarker(point, label) {
        var marker = new window.BMap.Marker(point);
        map.addOverlay(marker);
        marker.setLabel(label);
      }
      var marker = new window.BMap.Marker(new window.BMap.Point(121.618835, 29.920698)); // 创建点

      let newId = [], param = '';
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      function alarm(src, buildId, level, nature) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
          li2.appendChild(document.createTextNode("消防等级：" + level));
          li3.appendChild(document.createTextNode("使用性质：" + nature));
          var a = this._a = document.createElement("a");

          //a.setAttribute("href", "/org/floor/" + buildId + "");
          a.setAttribute("href", "javascript:;");
          a.setAttribute("id", "buildAreaMap" + buildId + "");
          a.appendChild(document.createTextNode("查看详情"));
          a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          div.appendChild(ul);
          var a2 = this._a2 = document.createElement("span");
          a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
          li4.appendChild(a2);
          li4.appendChild(a);
          a2.setAttribute("href", "javascript:;");
          a2.setAttribute("id", "buildImgMap" + buildId + "");
          a2.appendChild(document.createTextNode("平面图"));
          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.setAttribute("class", "buildImgFix" + buildId + "");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              let id = Id[0];
              that.setState({ buildingInfoId: id });
            })
            a2.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                that.setState({ mapPoints, mapPointsIcon });
              });
              window.rpc.area.getInfoById(Id[0]).then((res) => {
                let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                that.setState({ building });
                that.setState({ markerId: Id, new_pingmiantu: true });
              })
            })
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];
            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }
            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      if (e.key == 1) {
        map.clearOverlays();
        window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 1 }, deep: 3, type: 50 }, 0, 0).then((res) => {

          newId = '';
          res.map((x) => {
            let buildId = x.id;
            let level = "一级";
            let nature = "0";
            alarm(UnAlarm, buildId, level, nature);
            mouseoverTxt = x.name;
            var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = {
              'floor': newId
            };
            map.clearOverlays();
            map.addOverlay(maker2) // 将标注添加到地图中
            addClickHandler(content, param, newId, obj, maker2);
          })
        }, (err) => {
          console.warn(err);
        });
      } else if (e.key == 2) {
        map.clearOverlays();
        window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 3 }, deep: 3, type: 50 }, 0, 0).then((result) => {

          result.map((x) => {
            let buildId = x.id;
            let level = "一级";
            let nature = "办公";
            alarm(Alarm, buildId, level, nature);
            mouseoverTxt = x.name;
            var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = {
              'floor': newId
            };
            map.clearOverlays();
            map.addOverlay(maker3) // 将标注添加到地图中
            addClickHandler(content, param, newId, obj, maker3);
          })
        }, (err) => {
          console.warn(err);
        });
      } else if (e.key == 3) {
        map.clearOverlays();
        window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

          newId = '';
          res.map((x) => {
            let buildId = x.id;
            let level = "一级";
            let nature = "0";

            alarm(UnAlarm, buildId, level, nature);
            mouseoverTxt = x.name;
            var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
            var content = x.name;
            var obj = x;
            newId = x.id;
            param = {
              'floor': newId
            };
            map.addOverlay(maker1) // 将标注添加到地图中
            addClickHandler(content, param, newId, obj, maker1);
          })
          window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 2 }, deep: 3 }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "0";
              alarm(yellow, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.addOverlay(maker2) // 将标注添加到地图中
              addClickHandler(content, param, newId, obj, maker2);
            })
            window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 3 }, deep: 3 }, 0, 0).then((result) => {
              let idState2 = result.map(x => x.id);
              result.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "0";
                alarm(Alarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.addOverlay(maker3) // 将标注添加到地图中
                addClickHandler(content, param, newId, obj, maker3);
              })
            }, (err) => {
              console.warn(err);
            });

          }, (err) => {
            console.warn(err);
          });
        }, (err) => {
          console.warn(err);
        });
      }
      function addClickHandler(content, param, newId, obj, marker) {
        marker._img.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          this.setState({
            id: newId
          })
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        });
        marker._span.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          this.setState({
            id: newId
          })
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        });
      }
      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }

    }

    function handleSeach(e) {
      if (e) {
        that.setState({ mapBuild: e });
        that.setState({ mapState: null });
        search(e)
      } else {
        message.info("请输入建筑名称");
      }
      function search(e) {
        $("#searchCase").css({ display: 'none' });
        $("#searchCase input").val("");
        if (that.state.mapType == false) {
          var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
        } else {
          var map = new window.BMap.Map("equipDefaultMap");
        }
        map.addEventListener("maptypechange", function show() {
          let mapType = !that.state.mapType;
          that.setState({ mapType: mapType })
        });
        var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
        map.centerAndZoom(point, that.state.mapLevel);
        map.addEventListener("dragend", function () {
          var center = map.getCenter();
          that.setState({ mapCenter: { x: center.lng, y: center.lat } });
        });
        map.addEventListener("zoomend", function () {
          let zoomLevel = this.getZoom();
          that.setState({ mapLevel: zoomLevel });
        });
        map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
        map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
        map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用

        // 编写自定义函数,创建标注
        function addMarker(point, label) {
          var marker = new window.BMap.Marker(point);
          map.addOverlay(marker);
          marker.setLabel(label);
        }
        var marker = new window.BMap.Marker(new window.BMap.Point(121.618835, 29.920698)); // 创建点
        let newId = [], param = '';
        function ComplexCustomOverlay(point, text, mouseoverText) {
          this._point = point;
          this._text = text;
          this._overText = mouseoverText;
        }
        ComplexCustomOverlay.prototype = new window.BMap.Overlay();
        ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
          this._div['on' + event] = fun;
        }
        ComplexCustomOverlay.prototype.draw = function () {
          var map = this._map;
          var pixel = map.pointToOverlayPixel(this._point);
          this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
          this._div.style.top = pixel.y - 30 + "px";
        }
        var mouseoverTxt = '';
        function alarm(src, buildId, level, nature) {
          ComplexCustomOverlay.prototype.initialize = function (map) {
            this._map = map;
            var div = this._div = document.createElement("div");
            div.style.position = "absolute";
            div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
            div.style.color = "white";
            div.style.width = "24px";
            div.style.height = "33px";
            div.style.padding = "2px";
            div.style.textAlign = "center";
            div.style.lineHeight = "18px";
            div.style.whiteSpace = "nowrap";
            div.style.MozUserSelect = "none";
            div.style.fontSize = "12px";
            var span = this._span = document.createElement("span");
            span.style.position = 'absolute';
            span.style.width = "24px";
            div.style.height = "33px";
            span.style.left = "3px";
            span.style.top = "5px";
            span.style.textAlign = "center";
            var img = this._img = document.createElement("img");
            img.src = src;
            img.style.width = "24px";
            img.style.height = "33px";
            img.style.float = 'left';
            div.appendChild(img);
            div.appendChild(span);
            var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
            ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
            var li1 = this._li1 = document.createElement("li");
            var li1 = this._li1 = document.createElement("li");
            var li2 = this._li2 = document.createElement("li");
            var li3 = this._li3 = document.createElement("li");
            var li4 = this._li4 = document.createElement("li");
            li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
            li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
            li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
            li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
            div.appendChild(ul);
            ul.appendChild(li1);
            ul.appendChild(li2);
            ul.appendChild(li3);
            ul.appendChild(li4);
            li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
            li2.appendChild(document.createTextNode("消防等级：" + level));
            li3.appendChild(document.createTextNode("使用性质：" + nature));
            var a = this._a = document.createElement("a");

            a.setAttribute("href", "javascript:;");
            a.setAttribute("id", "buildImgMap" + buildId + "");
            a.appendChild(document.createTextNode("查看详情"));
            a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
            div.appendChild(ul);
            var a2 = this._a2 = document.createElement("span");
            a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
            li4.appendChild(a2);
            li4.appendChild(a);
            a2.setAttribute("href", "javascript:;");
            a2.setAttribute("id", "buildImgMap" + buildId + "");
            a2.appendChild(document.createTextNode("平面图"));
            var a3 = this._a3 = document.createElement("span");
            a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
            li4.appendChild(a3);
            a3.setAttribute("href", "javascript:;");
            a3.setAttribute("class", "buildImgFix" + buildId + "");
            a3.appendChild(document.createTextNode("关闭"));
            if (src !== UnAlarm) {
              span.appendChild(document.createTextNode(this._text));
            }
            var arrow = this._arrow = document.createElement("div");
            arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
            arrow.style.position = "absolute";
            arrow.style.height = "25px";
            arrow.style.top = "22px";
            arrow.style.left = "10px";
            arrow.style.overflow = "hidden";
            arrow.style.backgroundPosition = "0px 0px";
            div.appendChild(arrow);
            let display = false;
            div.onmouseenter = function () {
              display = true;
              let thatDiv = this;
              this.getElementsByTagName("ul")[0].style.display = 'block';
              arrow.style.backgroundPosition = "0px -20px";
              a.addEventListener("click", function (e) {
                var reg = /\d+/g;
                var str = this.id;
                var Id = str.match(reg);
                let id = Id[0];
                that.setState({ buildingInfoId: id });
              })
              a2.addEventListener("click", function (e) {
                var reg = /\d+/g;
                var str = this.id;
                var Id = str.match(reg);
                window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                  let mapPoints = res.filter(point => point.mapX);
                  let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                  that.setState({ mapPoints, mapPointsIcon });
                });
                window.rpc.area.getInfoById(Id[0]).then((res) => {
                  let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                  that.setState({ building });
                  that.setState({ markerId: Id, new_pingmiantu: true });
                })
              })
              a3.addEventListener("click", function (e) {
                thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
              })
            }
            div.onmouseleave = function () {
              display = false;
              let ul = this.getElementsByTagName("ul")[0];
              setTimeout(function () {
                if (display == false) {
                  ul.style.display = 'none';
                }
              }, 800)
              arrow.style.backgroundPosition = "0px 0px";
            }
            map.getPanes().labelPane.appendChild(div);
            return div;
          }
        }

        if (e) {
          map.clearOverlays();
          window.rpc.area.getArrayDeviceCountExByContainer({ name: e, deep: 3, type: 50 }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.clearOverlays();
              map.addOverlay(maker2) // 将标注添加到地图中
              addClickHandler(content, param, newId, obj, maker2);
            })
          }, (err) => {
            console.warn(err);
          });
        }
        function addClickHandler(content, param, newId, obj, marker) {
          marker._img.addEventListener("click", function (e) {
            sessionStorage.setItem('newId', newId);
            buildingInfo(newId);
            this.setState({
              id: newId
            })
            window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
              sessionStorage.setItem('equipment', JSON.stringify(res))
              sessionStorage.setItem('number', obj.count)
              this.setState({
                id: newId
              })
            }, (err) => {
              console.warn(err);
            })
          });
          marker._span.addEventListener("click", function (e) {
            sessionStorage.setItem('newId', newId);
            buildingInfo(newId);
            this.setState({
              id: newId
            })
            window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
              sessionStorage.setItem('equipment', JSON.stringify(res))
              sessionStorage.setItem('number', obj.count)
              this.setState({
                id: newId
              })
            }, (err) => {
              console.warn(err);
            })
          });
        }
      }
      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }


    };

    function handleStrokeMenuClick(e) {
      that.setState({ mapLine: e.key });
      wateO = 0; wateT = 0; wateS = 0;
      if (that.state.mapType == false) {
        var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
      } else {
        var map = new window.BMap.Map("equipDefaultMap");
      }
      map.addEventListener("maptypechange", function show() {

        let mapType = !that.state.mapType;
        that.setState({ mapType: mapType })
      });

      var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
      map.centerAndZoom(point, that.state.mapLevel);
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      map.enableScrollWheelZoom();
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用

      // 编写自定义函数,创建标注
      function addMarker(point, label) {
        var marker = new window.BMap.Marker(point);
        map.addOverlay(marker);
        marker.setLabel(label);
      }
      var marker = new window.BMap.Marker(new window.BMap.Point(121.618835, 29.920698)); // 创建点
      // 随机向地图添加25个标注
      let newId = [], param = '';
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      function alarm(src, buildId, level, nature) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
          li2.appendChild(document.createTextNode("消防等级：" + level));
          li3.appendChild(document.createTextNode("使用性质：" + nature));
          var a = this._a = document.createElement("a");

          a.setAttribute("href", "javascript:;");
          a.setAttribute("id", "buildImgMap" + buildId + "");
          a.appendChild(document.createTextNode("查看详情"));
          a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          div.appendChild(ul);
          var a2 = this._a2 = document.createElement("span");
          a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
          li4.appendChild(a2);
          li4.appendChild(a);
          a2.setAttribute("href", "javascript:;");
          a2.setAttribute("id", "buildImgMap" + buildId + "");
          a2.appendChild(document.createTextNode("平面图"));
          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.setAttribute("class", "buildImgFix" + buildId + "");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }
          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              let id = Id[0];
              that.setState({ buildingInfoId: id });
            })
            a2.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                that.setState({ mapPoints, mapPointsIcon });
              });
              window.rpc.area.getInfoById(Id[0]).then((res) => {
                let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                that.setState({ building });
                that.setState({ markerId: Id, new_pingmiantu: true });
              })
            })
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];
            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }
            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }

      if (e.key) {
        map.clearOverlays();
        if (that.state.mapBuild) {
          window.rpc.area.getArrayDeviceCountExByContainer({ name: that.state.mapBuild, deep: 3 }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.clearOverlays();
              map.addOverlay(maker2) // 将标注添加到地图中
              //拆分建筑物边界坐标   
              let points = x.point.split(';');
              let len = points.length;
              if (len > 0) {
                points[len - 1] = points[0]
              };
              let pointsMap = [];
              points.map(xy => {
                let mapXy = xy.replace('"', '');
                let pointa = mapXy.split(',');
                let objb = { x: pointa[0], y: pointa[1] };
                pointsMap.push(objb);
              });
              let arr = [];
              pointsMap.map(x => {
                let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));

                arr.push(a);
              });
              if (e.key == 1) {

                var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });   //创建折线
                map.addOverlay(polyline);   //增加折线
              } else if (e.key == 2) {

                var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5, strokeStyle: 'dashed' });   //创建折线
                map.addOverlay(polyline);   //增加折线
              } else if (e.key == 3) {

                var polygon = new window.BMap.Polygon(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });  //创建多边形
                map.addOverlay(polygon);   //增加多边形
              }
              addClickHandler(content, param, newId, obj, maker2);
            })
          }, (err) => {
            console.warn(err);
          });
        } else if (that.state.mapState) {
          if (that.state.mapState == 1) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 1 }, deep: 3 }, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.clearOverlays();

                map.addOverlay(maker2);// 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });
                if (e.key == 1) {
                  var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });   //创建折线
                  map.addOverlay(polyline);   //增加折线
                } else if (e.key == 2) {
                  var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeStyle: 'dashed' });   //创建折线
                  map.addOverlay(polyline);   //增加折线
                } else if (e.key == 3) {
                  var polygon = new window.BMap.Polygon(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });  //创建多边形
                  map.addOverlay(polygon);   //增加多边形
                }
                addClickHandler(content, param, newId, obj, maker2);
              })
            }, (err) => {
              console.warn(err);
            });
          } else if (that.state.mapState == 2) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 3 }, deep: 3 }, 0, 0).then((result) => {
              let idState2 = result.map(x => x.id);
              result.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(Alarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.clearOverlays();
                map.addOverlay(maker3) // 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });
                if (e.key == 1) {
                  var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });   //创建折线
                  map.addOverlay(polyline);   //增加折线
                } else if (e.key == 2) {

                  var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5, strokeStyle: 'dashed' });   //创建折线
                  map.addOverlay(polyline);   //增加折线
                } else if (e.key == 3) {

                  var polygon = new window.BMap.Polygon(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });  //创建多边形
                  map.addOverlay(polygon);   //增加多边形
                }
                addClickHandler(content, param, newId, obj, maker3);
              })
            }, (err) => {
              console.warn(err);
            });
          } else if (that.state.mapState == 3) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = x.extend.usetype;
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.addOverlay(maker1) // 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });
                if (e.key == 1) {
                  var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });   //创建折线
                  map.addOverlay(polyline);   //增加折线
                } else if (e.key == 2) {
                  var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5, strokeStyle: 'dashed' });   //创建折线
                  map.addOverlay(polyline);   //增加折线
                } else if (e.key == 3) {
                  var polygon = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeOpacity: 0.5 });  //创建多边形
                  map.addOverlay(polygon);   //增加多边形
                }

                addClickHandler(content, param, newId, obj, maker1);
              })
              window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 2 }, deep: 3, type: 50 }, 0, 0).then((res) => {

                newId = '';
                res.map((x) => {
                  let buildId = x.id;
                  let level = "一级";
                  let nature = x.extend.usetype;
                  alarm(yellow, buildId, level, nature);
                  mouseoverTxt = x.name;
                  var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                  var content = x.name;
                  var obj = x;
                  newId = x.id;
                  param = {
                    'floor': newId
                  };
                  map.addOverlay(maker2) // 将标注添加到地图中
                  addClickHandler(content, param, newId, obj, maker2);
                })
                window.rpc.area.getArrayDeviceCountExByContainer({ deep: 3, device: { dstate: 3 }, type: 50 }, 0, 0).then((result) => {

                  result.map((x) => {
                    //测试
                    let buildId = x.id;
                    let level = "一级";
                    let nature = x.extend.usetype;
                    alarm(Alarm, buildId, level, nature);
                    mouseoverTxt = x.name;
                    var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                    var content = x.name;
                    var obj = x;
                    newId = x.id;
                    param = {
                      'floor': newId
                    };
                    map.addOverlay(maker3) // 将标注添加到地图中
                    addClickHandler(content, param, newId, obj, maker3);
                  })
                }, (err) => {
                  console.warn(err);
                });

              }, (err) => {
                console.warn(err);
              });
            }, (err) => {
              console.warn(err);
            });
          }
        } else {

          map.clearOverlays();
          window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "0";

              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = { 'floor': newId };
              //if (paramState !== '2') {
              map.addOverlay(maker2)// 将标注添加到地图中
              //}
              let points = x.point.split(';');
              let len = points.length;
              if (len > 0) {
                points[len - 1] = points[0]
              };
              let pointsMap = [];
              points.map(xy => {
                let mapXy = xy.replace('"', '');
                let pointa = mapXy.split(',');
                let objb = { x: pointa[0], y: pointa[1] };
                pointsMap.push(objb);
              });
              let arr = [];
              pointsMap.map(x => {
                let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                arr.push(a);
              });
              if (e.key == 1) {
                var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5 });   //创建折线
                map.addOverlay(polyline);   //增加折线
              } else if (e.key == 2) {
                var polyline = new window.BMap.Polyline(arr, { strokeColor: "#e4db47", strokeWeight: 5, strokeStyle: 'dashed' });   //创建折线
                map.addOverlay(polyline);   //增加折线
              } else if (e.key == 3) {
                var polygon = new window.BMap.Polygon(arr, { strokeColor: "#e4db47", strokeWeight: 5 });  //创建多边形
                map.addOverlay(polygon);   //增加多边形
              }
              addClickHandler(content, param, newId, obj, maker2);

            })
            window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: 2 } }, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(yellow, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = { 'floor': newId };
                //if (paramState !== '2') {
                map.addOverlay(maker1)// 将标注添加到地图中
                //}
                addClickHandler(content, param, newId, obj, maker1);

              })
              window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: 3 } }, 0, 0).then((result) => {

                result.map((x) => {
                  let buildId = x.id;
                  let level = "一级";
                  let nature = "办公";
                  alarm(Alarm, buildId, level, nature);
                  mouseoverTxt = x.name;
                  var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                  var content = x.name;
                  var obj = x;
                  newId = x.id;
                  param = { 'floor': newId };
                  map.addOverlay(maker)// 将标注添加到地图中
                  addClickHandler(content, param, newId, obj, maker);
                })
              }, (err) => {
                console.warn(err);
              });

            }, (err) => {
              console.warn(err);
            });
          }, (err) => {
            console.warn(err);
          });
        }
      }

      function addClickHandler(content, param, newId, obj, marker) {
        marker.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        }
        );
      }
      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }
    };

    //资源分布
    function handleWarteClick(e) {

      that.setState({ mapLine: e.key });
      if (that.state.mapType == false) {
        var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
      } else {
        var map = new window.BMap.Map("equipDefaultMap");
      }
      map.addEventListener("maptypechange", function show() {

        let mapType = !that.state.mapType;
        that.setState({ mapType: mapType })
      });

      var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
      map.centerAndZoom(point, that.state.mapLevel);
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      map.enableScrollWheelZoom();
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用

      // 随机向地图添加25个标注
      let newId = [], param = '';
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      function alarm(src, buildId, level, nature) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
          li2.appendChild(document.createTextNode("消防等级：" + level));
          li3.appendChild(document.createTextNode("使用性质：" + nature));
          var a = this._a = document.createElement("a");

          a.setAttribute("href", "javascript:;");
          a.setAttribute("id", "buildImgMap" + buildId + "");
          a.appendChild(document.createTextNode("查看详情"));
          a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          div.appendChild(ul);
          var a2 = this._a2 = document.createElement("span");
          a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
          li4.appendChild(a2);
          li4.appendChild(a);
          a2.setAttribute("href", "javascript:;");
          a2.setAttribute("id", "buildImgMap" + buildId + "");
          a2.appendChild(document.createTextNode("平面图"));
          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.setAttribute("class", "buildImgFix" + buildId + "");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }
          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              let id = Id[0];
              that.setState({ buildingInfoId: id });
            });
            a2.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                that.setState({ mapPoints, mapPointsIcon });
              });
              window.rpc.area.getInfoById(Id[0]).then((res) => {
                let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                that.setState({ building });
                that.setState({ markerId: Id, new_pingmiantu: true });
              })
            })
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];

            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }

            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);
          return div;
        }
      }
      function alarmWarte(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "35px";
          img.style.height = "40px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          span.appendChild(document.createTextNode(this._text));
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }

      if (e.key) {
        map.clearOverlays();
        if (that.state.mapBuild) {
          window.rpc.area.getArrayDeviceCountExByContainer({ name: that.state.mapBuild }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.clearOverlays();
              map.addOverlay(maker2) // 将标注添加到地图中
              //拆分建筑物边界坐标    
              let points = x.point.split(';');
              let len = points.length;
              if (len > 0) {
                points[len - 1] = points[0]
              };
              let pointsMap = [];
              points.map(xy => {
                let mapXy = xy.replace('"', '');
                let pointa = mapXy.split(',');
                let objb = { x: pointa[0], y: pointa[1] };
                pointsMap.push(objb);
              });
              let arr = [];
              pointsMap.map(x => {
                let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));

                arr.push(a);
              });
              if (e.key == 1) {
                window.rpc.resource.getArrayByContainer({ type: 1 }, 0, 0).then((w) => {
                  let newId = '';
                  w.map((x) => {
                    alarmWarte(riverImg);
                    mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                    newId = x.id;
                    param = { 'floor': newId };
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              } else if (e.key == 2) {
                window.rpc.resource.getArrayByContainer({ type: 2 }, 0, 0).then((w) => {
                  let newId = '';
                  w.map((x) => {
                    alarmWarte(xfsImg);
                    mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                    newId = x.id;
                    param = { 'floor': newId };
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              } else if (e.key == 3) {
                window.rpc.resource.getArrayByContainer({ type: 3 }, 0, 0).then((w) => {
                  let newId = '';
                  w.map((x) => {
                    alarmWarte(poorImg);
                    mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                    newId = x.id;
                    param = { 'floor': newId };
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              }
              addClickHandler(content, param, newId, obj, maker2);
            })
          }, (err) => {
            console.warn(err);
          });
        } else if (that.state.mapState) {
          if (that.state.mapState == 1) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 1 } }, 0, 0).then((res) => {

              newId = '';

              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.clearOverlays();

                map.addOverlay(maker2);// 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });
                if (e.key == 1) {
                  window.rpc.resource.getArrayByContainer({ type: 1 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(riverImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else if (e.key == 2) {
                  window.rpc.resource.getArrayByContainer({ type: 2 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(xfsImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else if (e.key == 3) {
                  window.rpc.resource.getArrayByContainer({ type: 3 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(poorImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                }
                addClickHandler(content, param, newId, obj, maker2);
              })
            }, (err) => {
              console.warn(err);
            });
          } else if (that.state.mapState == 2) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 3 } }, 0, 0).then((result) => {

              result.map((x) => {
                //测试
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(Alarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.clearOverlays();
                map.addOverlay(maker3) // 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });
                if (e.key == 1) {
                  window.rpc.resource.getArrayByContainer({ type: 1 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(riverImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else if (e.key == 2) {
                  window.rpc.resource.getArrayByContainer({ type: 2 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(xfsImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else if (e.key == 3) {
                  window.rpc.resource.getArrayByContainer({ type: 3 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(poorImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);

                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                }
                addClickHandler(content, param, newId, obj, maker3);
              })
            }, (err) => {
              console.warn(err);
            });
          } else if (that.state.mapState == 3) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({}, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = x.extend.usetype;
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.addOverlay(maker1) // 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });
                if (e.key == 1) {
                  window.rpc.resource.getArrayByContainer({ type: 1 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(riverImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else if (e.key == 2) {
                  window.rpc.resource.getArrayByContainer({ type: 2 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(xfsImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else if (e.key == 3) {
                  window.rpc.resource.getArrayByContainer({ type: 3 }, 0, 0).then((w) => {
                    let newId = '';
                    w.map((x) => {
                      alarmWarte(poorImg);
                      mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      newId = x.id;
                      param = { 'floor': newId };
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                }
                addClickHandler(content, param, newId, obj, maker1);
              })
              window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 2 } }, 0, 0).then((res) => {
                newId = '';
                res.map((x) => {
                  let buildId = x.id;
                  let level = "一级";
                  let nature = x.extend.usetype;;
                  alarm(yellow, buildId, level, nature);
                  mouseoverTxt = x.name;
                  var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                  var content = x.name;
                  var obj = x;
                  newId = x.id;
                  param = {
                    'floor': newId
                  };
                  map.addOverlay(maker2) // 将标注添加到地图中
                  addClickHandler(content, param, newId, obj, maker2);
                })
                window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 3 } }, 0, 0).then((result) => {
                  result.map((x) => {
                    //测试
                    let buildId = x.id;
                    let level = "一级";
                    let nature = x.extend.usetype;;
                    alarm(Alarm, buildId, level, nature);
                    mouseoverTxt = x.name;
                    var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                    var content = x.name;
                    var obj = x;
                    newId = x.id;
                    param = {
                      'floor': newId
                    };
                    map.addOverlay(maker3) // 将标注添加到地图中
                    addClickHandler(content, param, newId, obj, maker3);
                  })
                }, (err) => {
                  console.warn(err);
                });

              }, (err) => {
                console.warn(err);
              });
            }, (err) => {
              console.warn(err);
            });
          }
        } else {
          window.rpc.area.getArrayDeviceCountExByContainer({ type: 50 }, 0, 0).then((res) => {
            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = x.extend.usetype;
              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.addOverlay(maker1) // 将标注添加到地图中
              let points = x.point.split(';');
              let len = points.length;
              if (len > 0) {
                points[len - 1] = points[0]
              };
              let pointsMap = [];
              points.map(xy => {
                let mapXy = xy.replace('"', '');
                let pointa = mapXy.split(',');
                let objb = { x: pointa[0], y: pointa[1] };
                pointsMap.push(objb);
              });
              let arr = [];
              pointsMap.map(x => {
                let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                arr.push(a);
              });
              if (e.key == 1) {
                window.rpc.resource.getArrayByContainer({ type: 1 }, 0, 0).then((w) => {
                  let newId = '';
                  w.map((x) => {
                    alarmWarte(riverImg);
                    mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    newId = x.id;
                    param = { 'floor': newId };
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              } else if (e.key == 2) {
                window.rpc.resource.getArrayByContainer({ type: 2 }, 0, 0).then((w) => {
                  let newId = '';
                  w.map((x) => {
                    alarmWarte(xfsImg);
                    mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    newId = x.id;
                    param = { 'floor': newId };
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              } else if (e.key == 3) {
                window.rpc.resource.getArrayByContainer({ type: 3 }, 0, 0).then((w) => {
                  let newId = '';
                  w.map((x) => {
                    alarmWarte(poorImg);
                    mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    newId = x.id;
                    param = { 'floor': newId };
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              }
              addClickHandler(content, param, newId, obj, maker1);
            });

            window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 2 } }, 0, 0).then((res) => {
              newId = '';
              res.map((x) => {
                alarm(Alarm)
                mouseoverTxt = x.name;
                var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.addOverlay(maker2) // 将标注添加到地图中
                addClickHandler(content, param, newId, obj, maker2);
              })
              window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, device: { dstate: 3 } }, 0, 0).then((result) => {
                result.map((x) => {
                  //测试
                  let buildId = x.id;
                  let level = "一级";
                  let nature = x.extend.usetype;
                  alarm(Alarm, buildId, level, nature);
                  mouseoverTxt = x.name;
                  var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                  var content = x.name;
                  var obj = x;
                  newId = x.id;
                  param = {
                    'floor': newId
                  };
                  map.addOverlay(maker3) // 将标注添加到地图中
                  addClickHandler(content, param, newId, obj, maker3);
                })
              }, (err) => {
                console.warn(err);
              });

            }, (err) => {
              console.warn(err);
            });

          }, (err) => {
            console.warn(err);
          });
        }
      }

      function addClickHandler(content, param, newId, obj, marker) {
        marker.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          this.setState({
            id: newId
          })
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        }
        );
      }
      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }
    };

    // 资源新
    function handleWarteNewClick(e) {
      let type = [];
      if (e.key == 1) {
        if (wateO) {
          wateO = 0;
        } else {
          wateO = 1;
        }
      } else if (e.key == 2) {
        if (wateT) {
          wateT = 0;
        } else {
          wateT = 1;
        }
      } else if (e.key == 3) {
        if (wateS) {
          wateS = 0;
        } else {
          wateS = 1;
        }
      }
      if (wateO) {
        type.push(1)
      }
      if (wateT) {
        type.push(2)
      }
      if (wateS) {
        type.push(3)
      }
      that.setState({ mapLine: e.key });
      if (that.state.mapType == false) {
        var map = new window.BMap.Map("equipDefaultMap", { mapType: window.BMAP_HYBRID_MAP });
      } else {
        var map = new window.BMap.Map("equipDefaultMap");
      }
      map.addEventListener("maptypechange", function show() {

        let mapType = !that.state.mapType;
        that.setState({ mapType: mapType })
      });

      var point = new window.BMap.Point(that.state.mapCenter.x, that.state.mapCenter.y);
      map.centerAndZoom(point, that.state.mapLevel);
      map.addEventListener("dragend", function () {
        var center = map.getCenter();
        that.setState({ mapCenter: { x: center.lng, y: center.lat } });
      });
      map.addEventListener("zoomend", function () {
        let zoomLevel = this.getZoom();
        that.setState({ mapLevel: zoomLevel });
      });
      map.enableScrollWheelZoom();
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用


      // 随机向地图添加25个标注
      let newId = [], param = '';
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left, 10) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';
      function alarm(src, buildId, level, nature) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;cursor:pointer;padding:5px 0;';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("建筑物名称：" + this._overText));
          li2.appendChild(document.createTextNode("消防等级：" + level));
          li3.appendChild(document.createTextNode("使用性质：" + nature));
          var a = this._a = document.createElement("a");

          //a.setAttribute("href", "/org/floor/" + buildId + "");
          a.setAttribute("href", "javascript:;");
          a.setAttribute("id", "buildAreaMap" + buildId + "");
          a.appendChild(document.createTextNode("查看详情"));
          a.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;text-align:center;width:60px;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          div.appendChild(ul);
          var a2 = this._a2 = document.createElement("span");
          a2.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding: 5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:50px';
          li4.appendChild(a2);
          li4.appendChild(a);
          a2.setAttribute("href", "javascript:;");
          a2.setAttribute("id", "buildImgMap" + buildId + "");
          a2.appendChild(document.createTextNode("平面图"));
          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:right;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.setAttribute("class", "buildImgFix" + buildId + "");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          //  div.onmouseover = function () {
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              let id = Id[0];
              that.setState({ buildingInfoId: id });
            })
            a2.addEventListener("click", function (e) {
              var reg = /\d+/g;
              var str = this.id;
              var Id = str.match(reg);
              window.rpc.device.getArrayByCond({ floor: Id[0] }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
                that.setState({ mapPoints, mapPointsIcon });
              });
              window.rpc.area.getInfoById(Id[0]).then((res) => {
                let building = { ...res, buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
                that.setState({ building });
                that.setState({ markerId: Id, new_pingmiantu: true });
              })
            })
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];
            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }
            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }

      function alarmWarte(src, Tname, Ttype, Tstate) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          var ul = this._ul = document.createElement("ul");//rgb(250, 250, 250)box-shadow:0 0 3px #666;
          ul.style.cssText = 'position:absolute;left:-90px;top:-150px;font-size:14px;height:150px;line-height:14px;display:none;width:270px;text-align:left;color:#666;background: url(' + textbox + ')';
          var li1 = this._li1 = document.createElement("li");
          var li2 = this._li2 = document.createElement("li");
          var li3 = this._li3 = document.createElement("li");
          var li4 = this._li4 = document.createElement("li");
          li1.style.cssText = 'margin-left:4px;padding: 16px 0px 5px 16px;background:#f9f9f9;border-top: 1px solid #ddddd1;';
          li2.style.cssText = 'margin-left:4px;padding: 5px 0px 5px 16px;background:#f9f9f9;';
          li3.style.cssText = 'margin-left:4px;padding:5px 0px 8px 16px;background:#f9f9f9;';//background:#fff;
          li4.style.cssText = 'border-top:1px #ddddd1 solid;text-align:center;cursor:pointer;padding:5px 0;padding-left:40%';
          div.appendChild(ul);
          ul.appendChild(li1);
          ul.appendChild(li2);
          ul.appendChild(li3);
          ul.appendChild(li4);
          li1.appendChild(document.createTextNode("资源名称：" + Tname));
          li2.appendChild(document.createTextNode("资源类型：" + Ttype));
          li3.appendChild(document.createTextNode("状态：" + Tstate));

          var a3 = this._a3 = document.createElement("span");
          a3.style.cssText = 'font-size:12px;border:1px #ddddd1 solid;width:50px;text-align:center;display:inline-block;padding:5px 0;background:#f6f6f6;color:#010101;float:left;margin-left:6px';
          li4.appendChild(a3);
          a3.setAttribute("href", "javascript:;");
          a3.appendChild(document.createTextNode("关闭"));
          if (src !== UnAlarm) {
            span.appendChild(document.createTextNode(this._text));
          }

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          arrow.style.backgroundPosition = "0px 0px";
          div.appendChild(arrow);
          let display = false;
          div.onmouseenter = function () {
            display = true;
            let thatDiv = this;
            this.getElementsByTagName("ul")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
            a3.addEventListener("click", function (e) {
              thatDiv.getElementsByTagName("ul")[0].style.display = 'none';
            })
          }

          div.onmouseleave = function () {
            display = false;
            let ul = this.getElementsByTagName("ul")[0];
            setTimeout(function () {
              if (display == false) {
                ul.style.display = 'none';
              }
            }, 800)
            arrow.style.backgroundPosition = "0px 0px";
          }
          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      if (e.key) {
        map.clearOverlays();
        if (that.state.mapBuild) {
          window.rpc.area.getArrayDeviceCountExByContainer({ name: that.state.mapBuild, deep: 3 }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "办公";
              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = {
                'floor': newId
              };
              map.clearOverlays();
              map.addOverlay(maker2) // 将标注添加到地图中
              //拆分建筑物边界坐标   
              let points = x.point.split(';');
              let len = points.length;
              if (len > 0) {
                points[len - 1] = points[0]
              };
              let pointsMap = [];
              points.map(xy => {
                let mapXy = xy.replace('"', '');
                let pointa = mapXy.split(',');
                let objb = { x: pointa[0], y: pointa[1] };
                pointsMap.push(objb);
              });
              let arr = [];
              pointsMap.map(x => {
                let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));

                arr.push(a);
              });

              if (type.length > 0) {
                window.rpc.resource.getArrayByContainer({ type: type }, 0, 0).then((w) => {
                  w.map((x) => {
                    if (x.type === 1) {
                      alarmWarte(riverImg, x.name, "河流", x.state === 1 ? "正常" : "异常");
                    } else if (x.type === 2) {
                      alarmWarte(xfsImg, x.name, "消防栓", x.state === 1 ? "正常" : "异常");
                    } else {
                      alarmWarte(poorImg, x.name, "水池", x.state === 1 ? "正常" : "异常");
                    }
                    // mouseoverTxt = x.name;
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              } else {
                window.rpc.resource.getArrayByContainer({ type: 888 }, 0, 0).then((w) => {
                  w.map((x) => {
                    if (x.type === 1) {
                      alarmWarte(riverImg, x.name, x.type, x.state === 1 ? "正常" : "异常");
                    } else if (x.type === 2) {
                      alarmWarte(xfsImg, x.name, x.type, x.state === 1 ? "正常" : "异常");
                    } else {
                      alarmWarte(poorImg, x.name, x.type, x.state === 1 ? "正常" : "异常");
                    }
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              }
              addClickHandler(content, param, newId, obj, maker2);
            })
          }, (err) => {
            console.warn(err);
          });
        } else if (that.state.mapState) {
          if (that.state.mapState == 1) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 1 }, deep: 3 }, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.clearOverlays();

                map.addOverlay(maker2);// 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });

                if (type.length > 0) {
                  window.rpc.resource.getArrayByContainer({ type: type }, 0, 0).then((w) => {
                    w.map((x) => {
                      if (x.type === 1) {
                        alarmWarte(riverImg, x.name, "河流", x.state === 1 ? "正常" : "异常");
                      } else if (x.type === 2) {
                        alarmWarte(xfsImg, x.name, "消防栓", x.state === 1 ? "正常" : "异常");
                      } else {
                        alarmWarte(poorImg, x.name, "水池", x.state === 1 ? "正常" : "异常");
                      }
                      // mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else {
                  window.rpc.resource.getArrayByContainer({ type: 888 }, 0, 0).then((w) => {
                    w.map((x) => {
                      if (x.type === 1) {
                        alarmWarte(riverImg, x.name, x.type, x.state);
                      } else if (x.type === 2) {
                        alarmWarte(xfsImg, x.name, x.type, x.state);
                      } else {
                        alarmWarte(poorImg, x.name, x.type, x.state);
                      }
                      // mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                }
                addClickHandler(content, param, newId, obj, maker2);
              })
            }, (err) => {
              console.warn(err);
            });
          } else if (that.state.mapState == 2) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 3 }, deep: 3 }, 0, 0).then((result) => {
              result.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(Alarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.clearOverlays();
                map.addOverlay(maker3) // 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });

                if (type.length > 0) {
                  window.rpc.resource.getArrayByContainer({ type: type }, 0, 0).then((w) => {
                    w.map((x) => {
                      if (x.type === 1) {
                        alarmWarte(riverImg, x.name, "河流", x.state === 1 ? "正常" : "异常");
                      } else if (x.type === 2) {
                        alarmWarte(xfsImg, x.name, "消防栓", x.state === 1 ? "正常" : "异常");
                      } else {
                        alarmWarte(poorImg, x.name, "水池", x.state === 1 ? "正常" : "异常");
                      }
                      // mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else {
                  window.rpc.resource.getArrayByContainer({ type: 888 }, 0, 0).then((w) => {
                    w.map((x) => {
                      if (x.type === 1) {
                        alarmWarte(riverImg, x.name, x.type, x.state);
                      } else if (x.type === 2) {
                        alarmWarte(xfsImg, x.name, x.type, x.state);
                      } else {
                        alarmWarte(poorImg, x.name, x.type, x.state);
                      }
                      // mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                }
                addClickHandler(content, param, newId, obj, maker3);
              })
            }, (err) => {
              console.warn(err);
            });
          } else if (that.state.mapState == 3) {
            map.clearOverlays();
            window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = x.extend.usetype;
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  'floor': newId
                };
                map.addOverlay(maker1) // 将标注添加到地图中
                //拆分建筑物边界坐标   
                let points = x.point.split(';');
                let len = points.length;
                if (len > 0) {
                  points[len - 1] = points[0]
                };
                let pointsMap = [];
                points.map(xy => {
                  let mapXy = xy.replace('"', '');
                  let pointa = mapXy.split(',');
                  let objb = { x: pointa[0], y: pointa[1] };
                  pointsMap.push(objb);
                });
                let arr = [];
                pointsMap.map(x => {
                  let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                  arr.push(a);
                });

                if (type.length > 0) {
                  window.rpc.resource.getArrayByContainer({ type: type }, 0, 0).then((w) => {
                    w.map((x) => {
                      if (x.type === 1) {
                        alarmWarte(riverImg, x.name, "河流", x.state === 1 ? "正常" : "异常");
                      } else if (x.type === 2) {
                        alarmWarte(xfsImg, x.name, "消防栓", x.state === 1 ? "正常" : "异常");
                      } else {
                        alarmWarte(poorImg, x.name, "水池", x.state === 1 ? "正常" : "异常");
                      }
                      // mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                } else {
                  window.rpc.resource.getArrayByContainer({ type: 888 }, 0, 0).then((w) => {
                    w.map((x) => {
                      if (x.type === 1) {
                        alarmWarte(riverImg, x.name, x.type, x.state);
                      } else if (x.type === 2) {
                        alarmWarte(xfsImg, x.name, x.type, x.state);
                      } else {
                        alarmWarte(poorImg, x.name, x.type, x.state);
                      }
                      // mouseoverTxt = x.name;
                      var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                      map.addOverlay(maker)// 将标注添加到地图中
                    })
                  })
                }
                addClickHandler(content, param, newId, obj, maker1);
              })
              window.rpc.area.getArrayDeviceCountExByContainer({ device: { dstate: 2 }, deep: 3, type: 50 }, 0, 0).then((res) => {

                newId = '';
                res.map((x) => {
                  let buildId = x.id;
                  let level = "一级";
                  let nature = x.extend.usetype;
                  alarm(UnAlarm, buildId, level, nature);
                  mouseoverTxt = x.name;
                  var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                  var content = x.name;
                  var obj = x;
                  newId = x.id;
                  param = {
                    'floor': newId
                  };
                  map.addOverlay(maker2) // 将标注添加到地图中
                  addClickHandler(content, param, newId, obj, maker2);
                })
                window.rpc.area.getArrayDeviceCountExByContainer({ deep: 3, device: { dstate: 3 }, type: 50 }, 0, 0).then((result) => {

                  result.map((x) => {
                    //测试
                    let buildId = x.id;
                    let level = "一级";
                    let nature = x.extend.usetype;
                    alarm(Alarm, buildId, level, nature);
                    mouseoverTxt = x.name;
                    var maker3 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                    var content = x.name;
                    var obj = x;
                    newId = x.id;
                    param = {
                      'floor': newId
                    };
                    map.addOverlay(maker3) // 将标注添加到地图中
                    addClickHandler(content, param, newId, obj, maker3);
                  })
                }, (err) => {
                  console.warn(err);
                });

              }, (err) => {
                console.warn(err);
              });
            }, (err) => {
              console.warn(err);
            });
          }
        } else {

          map.clearOverlays();
          window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: [1, 2, 3] } }, 0, 0).then((res) => {

            newId = '';
            res.map((x) => {
              let buildId = x.id;
              let level = "一级";
              let nature = "0";

              alarm(UnAlarm, buildId, level, nature);
              mouseoverTxt = x.name;
              var maker2 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
              var content = x.name;
              var obj = x;
              newId = x.id;
              param = { 'floor': newId };
              map.addOverlay(maker2)// 将标注添加到地图中
              let points = x.point.split(';');
              let len = points.length;
              if (len > 0) {
                points[len - 1] = points[0]
              };
              let pointsMap = [];
              points.map(xy => {
                let mapXy = xy.replace('"', '');
                let pointa = mapXy.split(',');
                let objb = { x: pointa[0], y: pointa[1] };
                pointsMap.push(objb);
              });
              let arr = [];
              pointsMap.map(x => {
                let a = new window.BMap.Point(parseFloat(x.x, 10), parseFloat(x.y, 10));
                arr.push(a);
              });

              if (type.length > 0) {
                window.rpc.resource.getArrayByContainer({ type: type }, 0, 0).then((w) => {
                  w.map((x) => {
                    if (x.type === 1) {
                      alarmWarte(riverImg, x.name, "河流", x.state === 1 ? "正常" : "异常");
                    } else if (x.type === 2) {
                      alarmWarte(xfsImg, x.name, "消防栓", x.state === 1 ? "正常" : "异常");
                    } else {
                      alarmWarte(poorImg, x.name, "水池", x.state === 1 ? "正常" : "异常");
                    }
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              } else {
                window.rpc.resource.getArrayByContainer({ type: 888 }, 0, 0).then((w) => {
                  w.map((x) => {
                    if (x.type === 1) {
                      alarmWarte(riverImg, x.name, x.type, x.state);
                    } else if (x.type === 2) {
                      alarmWarte(xfsImg, x.name, x.type, x.state);
                    } else {
                      alarmWarte(poorImg, x.name, x.type, x.state);
                    }
                    var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                    map.addOverlay(maker)// 将标注添加到地图中
                  })
                })
              }
              addClickHandler(content, param, newId, obj, maker2);

            })
            window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: 2 } }, 0, 0).then((res) => {

              newId = '';
              res.map((x) => {
                let buildId = x.id;
                let level = "一级";
                let nature = "办公";
                alarm(UnAlarm, buildId, level, nature);
                mouseoverTxt = x.name;
                var maker1 = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = { 'floor': newId };
                map.addOverlay(maker1)// 将标注添加到地图中
                addClickHandler(content, param, newId, obj, maker1);

              })
              window.rpc.area.getArrayDeviceCountExByContainer({ type: 50, deep: 3, device: { dstate: 3 } }, 0, 0).then((result) => {

                result.map((x) => {
                  let buildId = x.id;
                  let level = "一级";
                  let nature = "办公";
                  alarm(Alarm, buildId, level, nature);
                  mouseoverTxt = x.name;
                  var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
                  var content = x.name;
                  var obj = x;
                  newId = x.id;
                  param = { 'floor': newId };
                  map.addOverlay(maker)// 将标注添加到地图中
                  addClickHandler(content, param, newId, obj, maker);
                })
              }, (err) => {
                console.warn(err);
              });

            }, (err) => {
              console.warn(err);
            });
          }, (err) => {
            console.warn(err);
          });
        }
      }

      function addClickHandler(content, param, newId, obj, marker) {
        marker.addEventListener("click", function (e) {
          sessionStorage.setItem('newId', newId);
          buildingInfo(newId);
          window.rpc.device.getArrayBriefByCondContainer(null, param, 0, 10, console.log, console.error).then((res) => {
            sessionStorage.setItem('equipment', JSON.stringify(res))
            sessionStorage.setItem('number', obj.count)
            this.setState({
              id: newId
            })
          }, (err) => {
            console.warn(err);
          })
        }
        );
      }
      const getBuilding = (newId) => {
        return window.rpc.area.getInfoById(newId);
      }

      const buildingInfo = async (newId) => {
        const building = await getBuilding(newId);
        setSSSSS(building);
      }
    };

    function setSSSSS(obj) {
      let building = { ...obj, buildTime: moment(obj.buildTime).format("YYYY年MM月DD日") };
      that.setState({ building });
    }

    function handleOneClick(e) {
      if (e.key === "1") {
        browserHistory.push("/safecenter");
      } else {
        browserHistory.push("/back");
      }
    }

    const menu = (
      <Menu onClick={handleMenuClick.bind(this)} className="menuStyleEquip">
        <Menu.Item key="1">正常</Menu.Item>
        <Menu.Item key="2">异常</Menu.Item>
        <Menu.Item key="3">全部</Menu.Item>
      </Menu>
    );

    const strokeMenu = (
      <Menu onClick={handleStrokeMenuClick.bind(this)} className="xianStyleImg">
        <Menu.Item key="1">实线</Menu.Item>
        <Menu.Item key="2">虚线</Menu.Item>
        <Menu.Item key="3">实心</Menu.Item>
      </Menu>
    );

    const water = (
      <Menu className="WaterStyleImg" onClick={handleWarteNewClick.bind(this)}>
        <Menu.Item key="1">河流</Menu.Item>
        <Menu.Item key="2">消防栓</Menu.Item>
        <Menu.Item key="3">消防水池</Menu.Item>
      </Menu>
    );

    const menuOne = (
      <Menu style={{ top: "-3px", left: 0 }} className="menuStyleImg" onClick={handleOneClick.bind(this)}>
        <Menu.Item key="1">安全云中心</Menu.Item>
        <Menu.Item key="2">数据中心</Menu.Item>
      </Menu>
    );

    let types = this.state.types;

    return (
      <div className="EquipDefault">
        <div id="equipDefaultMap" style={{ height: '100vh', borderTop: '5px solid #32517d ' }}></div>
        <div style={{ display: this.state.new_pingmiantu ? 'flex' : 'none', position: 'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff' }}>
          <div className="pingmiantu-top" style={{ position: 'absolute', top: 0, right: 2 }}>
            <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <NewPingmiantu id={this.state.markerId} />
        </div>
        {/*<div className="new_pingmiantu" style={{ display: this.state.new_pingmiantu ? 'flex' : 'none', position: 'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff' }}>
          <div className="pingmiantu-top">
            <Button style={{ background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))}><img src={QuitScreen} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>退出全屏</span></Button>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState((prevState) => ({ new_pingmiantu: !prevState.new_pingmiantu }))}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <div> 
             <div className="pmt_select">
                <span style={{ margin: '0 12px 0 25px', fontSize: '0.75rem' }}>楼层选择：</span>
                <Cascader options={this.state.storeys} onChange={this.onFloorChange.bind(this)} placeholder="请选择" />
              </div>
          </div>
      
          <div className="pingmiantu-left" >
            
            <img id="img2" src={this.state.storey.mapUrl} alt="right-pic" />
            {this.state.mapPoints.map((point, index) => (
              <div key={index} className={`map-point map-point-${point.dtype}`} style={{ position: 'absolute', height: 20, width: 20, top: `${point.mapY}%`, left: `${point.mapX}%` }}></div>
            ))}
          </div>
          <div className="pingmiantu-right">
            <div className="pingmiantu-oprate" title="正常" onClick={() => {
              window.rpc.device.getArrayByCond({ storey: this.state.storey.id, rstate: 1 }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                this.setState({ mapPoints });
              });
            }}><i className="iconfont-lszp">&#xe62a;</i></div>
            <div className="pingmiantu-oprate" title="异常" onClick={() => {
              window.rpc.device.getArrayByCond({ storey: this.state.storey.id, rstate: 2 }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                this.setState({ mapPoints });
              });
            }}><i className="iconfont-lszp">&#xe7e6;</i></div>
            <div className="pingmiantu-oprate" title="离线" onClick={() => {
              window.rpc.device.getArrayByCond({ storey: this.state.storey.id, rstate: 3 }, 0, 0).then((res) => {
                let mapPoints = res.filter(point => point.mapX);
                this.setState({ mapPoints });
              });
            }}><i className="iconfont-lszp">&#xe613;</i></div>
            {this.state.mapPointsIcon.map((point, index) => (
              <div key={index} className={`pingmiantu-oprate pingmiantu-oprate-${point}`} title={types[point]} onClick={() => {
                window.rpc.device.getArrayByCond({storey: this.state.storey.id, dtype: point }, 0, 0).then((res) => {
                  let mapPoints = res.filter(point => point.mapX);
                  this.setState({ mapPoints });
                });
              }}></div>
            ))}
          </div>
   
        </div>*/}
        <div className="banner">
          <div className="banner-left">
            <Button.Group style={{ width: 520 }}>
              <Dropdown overlay={menuOne} className="centerY" >
                <Button>
                  首页 <Icon type="down" />
                </Button>
              </Dropdown>
              <Dropdown overlay={menu} getPopupContainer={() => document.querySelector('.EquipDefault')} className="shebeizhuangtai">
                <Button>
                  设备状态 <Icon type="down" />
                </Button>
              </Dropdown>
              <Dropdown overlay={strokeMenu} className="imgStyle">
                <Button>
                  图层样式<Icon type="down" />
                </Button>
              </Dropdown>
              <Dropdown overlay={water} className="imgStyle">
                <Button>
                  资源分布<Icon type="down" />
                </Button>
              </Dropdown>
            </Button.Group>
            <AlarmLeft onClicked={this.onChangeState.bind(this)} />
          </div>
          <div className="banner-middle"><span>消防设备应急中心</span></div>
          <div className="banner-right">
            <Button.Group size="large" style={{ display: 'flex', alignItems: 'center' }}>
              <Button
                type="primary"
                className="tubiaos"
                style={{ width: 140, position: "relative" }}
                onMouseOver={() => {
                  this.setState({ displayTu: '' });
                  $("#searchCase").css({ display: 'none' });
                }}
                onMouseOut={() => {
                  this.setState({ displayTu: 'none' });
                }}
              >
                <span>图标说明</span>
                <div
                  style={{ display: this.state.displayTu, fontSize: '1rem', position: "absolute", top: 42, left: 0, width: 300, height: 300, backgroundColor: "white", color: "black" }}
                >
                  <div style={{ width: "100%", padding: "10px 25px ", heigth: '10%', textAlign: "left", lineHeight: "30px", position: "relative" }}>
                    <img src={UnAlarm} alt="图标" style={{ height: 20, width: 15, position: "absolute", top: 13 }} />
                    <span style={{ marginLeft: 25 }}>正常设备</span>
                    <img src={Alarm} alt="图标" style={{ height: 20, width: 15, position: "absolute", top: 13, marginLeft: '15%' }} />
                    <span style={{ marginLeft: '28%' }}>异常设备</span>
                  </div>
                  <div style={{ width: "100%", padding: "10px 25px ", heigth: '10%', textAlign: "left", lineHeight: "30px", position: "relative" }}>
                    <img src={poorImg} alt="图标" style={{ height: 20, width: 15, position: "absolute", top: 13 }} />
                    <span style={{ marginLeft: 25 }}>正常水池</span>
                    <img src={riverImg} alt="图标" style={{ height: 20, width: 15, position: "absolute", top: 13, marginLeft: '15%' }} />
                    <span style={{ marginLeft: '28%' }}>正常河流</span>
                  </div>
                  <div style={{ width: "100%", padding: "10px 25px ", heigth: '10%', textAlign: "left", lineHeight: "30px", position: "relative" }}>
                    <img src={xfsImg} alt="图标" style={{ height: 20, width: 15, position: "absolute", top: 13 }} />
                    <span style={{ marginLeft: 25 }}>正常消防栓</span>
                    {/*<img src={Alarm} alt="图标" style={{ height: 20, width: 15, position: "absolute", top: 13, marginLeft: '10%' }} />
                    <span style={{ marginLeft: '22%' }}>异常设备</span>*/}
                  </div>
                  {/*<div style={{ width: "100%", padding: "10px 25px ", heigth: '10%', textAlign: "left", lineHeight: "30px", position: "relative" }}>
                    <img src={zheng} alt="图标" style={{ height: 15, width: 15, position: "absolute", top: 13 }} />
                    <span style={{ marginLeft: 25 }}>正常状态</span>
                    <img src={yi} alt="图标" style={{ height: 15, width: 15, position: "absolute", top: 13, marginLeft: '15%' }} />
                    <span style={{ marginLeft: '28%' }}>异常状态</span>
                  </div>*/}
                </div>
              </Button>
              <Button type="primary" className="yijianbaojing" style={{ width: 140, paddingLeft: 40 }} onClick={this.showWarnModal}>
                一键报警
              </Button>
              <Button type="primary" className="duanxintongzhi" style={{ width: 140 }} onClick={this.showMesModal}>
                短信通知
              </Button>
              <Button type="primary" onClick={this.handleK} className="shebeitongji" style={{ width: 140 }}>
                设备统计
              </Button>
              <Button
                type="primary"
                className="hoverSearch"
                style={{ width: 80 }}
              >
                <Icon type="search" />搜索
              </Button>
              <span className="searchCase" id="searchCase" style={{ display: 'none' }}>
                <Search
                  placeholder="请输入建筑名称"
                  style={{ width: 510, position: 'fixed', right: 30, top: 60, zIndex: 999 }}
                  onSearch={handleSeach.bind(this)}
                />
              </span>
            </Button.Group>
            <Modal
              visible={this.state.warn_visible}
              className="lsyijianbaojing-modal"
              title="蓝晟管控中心一键报警界面"
              onOk={this.handleWarnOk}
              onCancel={this.handleWarnCancel}
              style={{ width: 786, height: 540 }}
              width={786}
              footer={[
                <Button key="submit" type="primary" size="large" loading={this.state.warn_loading} onClick={this.handleWarnOk}>
                  一键报警
                </Button>,
              ]}
            >
              <span className="shoujianren">收件人：</span>
              <Select
                showSearch
                style={{ width: 551 }}
                placeholder="请选择收信人"
                optionFilterProp="children"
                onChange={(value) => this.props.EquipDefaultState.warn_recever = value}
                filterOption={(input, option) => option.props.value.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                {this.props.EquipDefaultState.mes_array.map(x => (<Option value={`${x.id}`} key={`${x.id}`}>{x.name}</Option>))}
              </Select>
              <br />
              <span className="xinxi">信息：</span>
              <Input type="textarea" rows={4} onChange={(e) => { this.props.EquipDefaultState.warn_info = e.target.value }} placeholder="请输入信息" />
            </Modal>
            <Modal
              visible={this.state.mes_visible}
              className="lsduanxintongzhi-modal"
              title="蓝晟管控中心短信通知界面"
              onOk={this.handleMesOk}
              onCancel={this.handleMesCancel}
              style={{ width: 1200, height: 610 }}
              width={1200}
              footer={null}
            >
              <div className="duanxin-left">
                <div className="tongxunlu">
                  通讯录
                </div>
                <div className="sousuolianxiren">
                  <Search
                    placeholder="搜索联系人"
                    onSearch={(value) => this.handleSeachTongxunlu(value)}
                  />
                </div>
                <div className="xingminghaoma">
                  <span>姓名</span>
                  <span>手机号码</span>
                </div>
                <div className="xinghaolist">
                  {this.props.EquipDefaultState.mes_array.map(x =>
                    <div onClick={() => this.props.EquipDefaultState.choice_string += `${x.mobile}; `}><span>{x.name}</span><span>{x.mobile}</span></div>
                  )}
                </div>
              </div>
              <div className="duanxin-right">
                <div className="duanxin-r-main">
                  <div className="duanxin-r-up">
                    <span className="shoujianren">收件人：</span>
                    <Input value={this.props.EquipDefaultState.choice_string} onChange={(e) => { this.props.EquipDefaultState.choice_string = e.target.value; console.log(this.props.EquipDefaultState.choice_string) }} />
                    <span className="xinxi">信息：</span>
                    <Input type="textarea" rows={20} onChange={(e) => { this.props.EquipDefaultState.mes_info = e.target.value }} placeholder="" />
                    <div className="fasonglv">
                      <span>信息发送中：</span>
                      <Progress percent={0} status="active" />
                    </div>
                  </div>
                  <div className="duanxin-r-right">
                    <Tabs type="card">
                      <TabPane tab="历史消息" key="1">
                        <div className="mes_list">
                          <div></div>
                          <div></div>
                          <div></div>
                          <div></div>
                        </div>
                        <div className="mes_bot">
                          <span>选择：</span>
                          <span>全选</span>
                          <span>{' - '}</span>
                          <span>无</span>
                          <Button>删除</Button>
                        </div>
                      </TabPane>
                      <TabPane tab="消息模板" key="2">
                        <div className="mes_list">
                          <div></div>
                          <div></div>
                          <div></div>
                          <div></div>
                        </div>
                        <div className="mes_bot">
                          <span>选择：</span>
                          <span>全选</span>
                          <span>{' - '}</span>
                          <span>无</span>
                          <Button>删除</Button>
                        </div>
                      </TabPane>
                    </Tabs>
                  </div>
                </div>
                <div className="duanxin-r-down">
                  <Button onClick={this.handleMesOk.bind(this)}>发送</Button>
                  <Button>取消</Button>
                  <Button onClick={this.handleMesCancel.bind(this)}>关闭</Button>
                </div>
              </div>
            </Modal>
          </div>
        </div>

        <div className="" style={{ overflowY: "auto", display: this.state.display }}>
          <EquipRight id={this.state.id} building={this.state.building} className={`{this.state.id}`} />
        </div>

        <div style={{ background: "rgba(255,255,255,0)", display: this.state.SixD, width: this.state.widthA, height: this.state.heightTotal, position: "absolute", top: this.state.topA, left: 0, zIndex: 99, }}>
          <div style={{ position: "relative", height: "100%" }} className="Alarm-border">
            <div style={{ background: "rgba(255,255,255,1)", height: this.state.heightA, width: "100%", overflow: "hidden", position: 'relative', boxShadow: "0 0 10px #00c1de" }} className="Alarm-border-hover">
              <span onClick={this.state.offer ? this.handleA : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer', textAlign: "center", lineHeight: "15px" }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenBasicMes id={this.state.id} alarmSix={this.state.alarmSix} />
            </div>
            <div style={{ background: "rgba(255,255,255,1)", height: this.state.heightB, width: "100%", marginTop: 25, overflow: "hidden", position: 'relative', boxShadow: "0 0 10px #00c1de" }} className="Alarm-border-hover">
              <span onClick={this.state.offer ? this.handleB : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer', textAlign: "center", lineHeight: "15px" }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenRoute mesid={this.state.id} id={this.state.routId} offer={this.state.Toffer} />
            </div>
            <div style={{ background: "rgba(255,255,255,1)", height: this.state.heightC, width: "100%", marginTop: 25, overflow: "hidden", position: 'relative', boxShadow: "0 0 10px #00c1de" }} className="Alarm-border-hover">
              <span onClick={this.state.offer ? this.handleC : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer', textAlign: "center", lineHeight: "15px" }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenResources mesid={this.state.id} offer={this.state.Toffer} id={this.state.routId} />
            </div>
            <div className="sixAlarm" style={{ position: "absolute", bottom: 10, right: 10, display: this.state.offer ? "block" : "none" }} onClick={this.handleCan}>关闭辅助</div>
          </div>
        </div>

        <div style={{ background: "rgba(255,255,255,0)", display: this.state.SixD, width: this.state.widthB, height: this.state.heightTotal, position: "absolute", top: this.state.topA, right: 0, zIndex: 99 }}>
          <div style={{ position: "relative", height: "100%" }} className="Alarm-border">
            <div style={{ background: "rgba(255,255,255,1)", height: this.state.heightD, width: "100%", overflow: "hidden", position: 'relative', boxShadow: "0 0 10px #00c1de" }} className="Alarm-border-hover">
              <span onClick={this.state.offer ? this.handleD : this.handleTrue} style={{ zIndex: 9999999999999999999, background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer', textAlign: "center", lineHeight: "15px" }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmRealTimeMonitor mesid={this.state.id} offer={this.state.Toffer} />
            </div>
            <div style={{ background: "rgba(255,255,255,1)", height: this.state.heightE, width: "100%", marginTop: 25, overflow: "hidden", position: 'relative', boxShadow: "0 0 10px #00c1de" }} className="Alarm-border-hover">
              <span onClick={this.state.offer ? this.handleE : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer', textAlign: "center", lineHeight: "15px" }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenFloor mesid={this.state.id} />
            </div>
            <div style={{ background: "rgba(255,255,255,1)", height: this.state.heightF, width: "100%", marginTop: 25, overflow: "hidden", position: 'relative', boxShadow: "0 0 10px #00c1de" }} className="Alarm-border-hover">
              <span onClick={this.state.offer ? this.handleF : this.handleTrue} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium', paddingTop: 2, cursor: 'pointer', textAlign: "center", lineHeight: "15px" }}>{this.state.offer ? "点击全屏" : "点击关闭"}</span>
              <AlarmConcenEquipment mesid={this.state.id} />
            </div>
            <div className="sixAlarm" style={{ position: "absolute", bottom: 10, right: 10, display: this.state.offer ? "block" : "none" }} onClick={this.handleCan}>关闭辅助</div>
          </div>
        </div>

        <div style={{ display: this.state.buildingInfoId ? 'block' : 'none', position: 'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff' }}>
          <div className="pingmiantu-top" style={{ float: 'right' }}>
            <Button style={{ background: 'rgba(55, 61, 65,.8)', overflow: 'hidden' }} onClick={() => this.setState({ buildingInfoId: null })}><img src={Close} alt="" style={{ marginTop: 2, marginRight: 2, float: 'left' }} /><span style={{ color: '#fff' }}>关闭</span></Button>
          </div>
          <AreaInfoClick mesid={this.state.buildingInfoId} />
        </div>

      </div>
    )
  }
})

class EquipDefault extends Component {
  render() {
    return (
      <EquipDefaultC EquipDefaultState={new EquipDefaultState()} params={this.props.params} />
    )
  }
}

export default EquipDefault;