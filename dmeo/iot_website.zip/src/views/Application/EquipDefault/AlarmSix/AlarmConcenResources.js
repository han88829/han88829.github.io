/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-07 17:02:22
 */

import React, { Component } from 'react';
import { Input, Row, Col, Button } from 'antd';
import { Link } from 'react-router';

import UnAlarm from '../../../../assets/images/equipment/unalarm.png';
import Alarm from '../../../../assets/images/equipment/1.png';
import Water from '../../../../assets/images/concentrate/water.png';
import xiaofang from '../../../../assets/images/application/消防水栓.png';
import shuichi from '../../../../assets/images/application/水池.png';
import TZD from '../../../../assets/images/application/TZD河流.png';

let time = 0;
class AlarmConcenResources extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'none'
    };
  }

  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    loadJScript();
  }
  // shouldComponentUpdate(nextProps, nextState) {
  //   return nextProps.offer ? true : false;
  // }


  componentWillReceiveProps(nextProps) {
    // console.log("开关 ：" + nextProps.offer)
    if ((nextProps.mesid && time < 2) || nextProps.offer) {
      time++;
      // 定义组件内的变量
      let newId = [], param = '', mountText = '', mouseoverTxt = '';
      // 初始化地图
      var map = new window.BMap.Map("resourcesMap");
      var point = new window.BMap.Point(121.618835, 29.920698);
      map.centerAndZoom(point, 16);
      map.addControl(new window.BMap.MapTypeControl({ mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP] }));

      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用

      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);

      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }

      //报警功能
      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var span = this._span = document.createElement("span");
          span.style.position = 'absolute';
          span.style.width = "24px";
          div.style.height = "33px";
          span.style.left = "3px";
          span.style.top = "5px";
          span.style.textAlign = "center";
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "20px";
          img.style.height = "23px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(span);
          div.appendChild(p);
          span.appendChild(document.createTextNode(this._text));
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }

      //添加地点
      window.rpc.resource.getArray(0, 0).then((res) => {
        newId = '';
        res.map((x, index) => {
          if (x.type === 1) {
            alarm(TZD)
          } else if (x.type === 2) {
            alarm(xiaofang)
          } else {
            alarm(shuichi)
          }
          mouseoverTxt = x.name;
          let pointO = new window.BMap.Point(x.x, x.y);
          let maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), '', mouseoverTxt);
          let content = x.name;
          let obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          map.centerAndZoom(pointO, 16);
        })
      }, (err) => {
        console.warn(err);
      })
    }
    if (!this.props.id) {
      time = 0;
    }

  }
  render() {
    let mesid = parseInt(this.props.mesid, 10) || 1;
    let backTo = '/apply/equip/six/alarm/' + mesid;

    return (
      <div className="AlarmConcenResources " style={{ fontSize: 14, fontFamily: '苹方中等', padding: '12px', height: '100%', boxShadow: '0 0 20px rgb(0, 193, 222)' }}>
        <div style={{ width: "100%", marginBottom: 12, overflow: 'hidden' }}>
          <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
          <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>资源分布</span>
        </div>
        <div id="resourcesMap" style={{ height: '90%', width: '100%' }}></div>
      </div>
    );
  }
}

export default AlarmConcenResources;