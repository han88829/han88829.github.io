/*
 * @Author: 蔡嘉迪 
 * @Date: 2017-03-21 15:27:29 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-04 10:21:56
 */

import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { Link } from 'react-router';
import { observer } from 'mobx-react';
import { Tabs, Icon, Row, Col, DatePicker, Button, Form, Table, Card, message, Modal } from 'antd';
import moment from 'moment';
import star from '../../../../assets/images/equipment/设备名称.png';
import er from '../../../../assets/images/equipment/设备二维码.png';
import time from '../../../../assets/images/equipment/安装时间.png';
import state from '../../../../assets/images/equipment/布设状态.png';
import model from '../../../../assets/images/equipment/采集模块.png';
import create from '../../../../assets/images/equipment/创立时间.png';
import unit from '../../../../assets/images/equipment/单位.png';
import address from '../../../../assets/images/equipment/地址.png';
import type from '../../../../assets/images/equipment/检测类型.png';
import dtype from '../../../../assets/images/equipment/设备型号.png';
import shang from '../../../../assets/images/equipment/生产厂家.png';
import area from '../../../../assets/images/equipment/所属区域.png';
import net from '../../../../assets/images/equipment/网关地址.png';
import './alarmconcenbasicmes.css';
import listStore from './listStore';

// 结构出参量表
const { armtypeList, ResultState, dStateList } = listStore;

//取出户籍类型
let Orgtypes = JSON.parse(sessionStorage.getItem('Orgtypes')) || [];
const TabPane = Tabs.TabPane;

message.config({
  top: 216,
  duration: 2
})

class deviceState {
  constructor() {
    extendObservable(this, {
      runData: [{ key: 1, id: 1, state: '合格', createTime: '2016-09-26 08:50:08' }],
      patrolData: [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }],
      maintainData: [{ key: 1, id: 1, userId: 1, type: '巡查', state: '正常', createTime: '2015-09-26 08:50:08', reportId: 1, remark: 'My name is' }],
      id: null,
      addRun: action(function () {
        this.runData.push({ key: 2, id: 2, state: '不合格', createTime: '2016-10-26 08:50:08' })
      })
    })
  }
}

class AlarmConcenBasicMes extends Component {
  constructor() {
    super();
    this.state = {
      runData: [],
      alarm: {
        state: "123",
        userId: "123",
        id: null,
      },
      rData: [],
      area: [],
      owner: [],
      OrgsType: null,
      id: null,
      device: {
        name: '',
        location: '',
        setupTime: '',
        expiryTime: '',
        lastTime: '',
        armtype: '',
        dtype: '',
        rstate: '',
        patrolId: '',
        idQc: 123,
        isShow: 'block',
      }
    };
  }
  componentDidMount() {
    let id = parseInt(this.props.id, 10) || 1;
    window.rpc.device.getInfoById(id).then((result) => {
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.area.getLocationName(result.location).then((res) => {
        const device = { ...result, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, location: res, };
        this.setState({ device });
      }, (err) => {
        console.warn(err);
      })

    }, (err) => {
      console.warn(err);
    })
    //建筑
    window.rpc.area.getInfoById(id).then((result) => {
      let area = { ...result, name: result.name, layer: result.layer, galleryful: result.galleryful, face: result.face, hight: result.hight, };
      this.setState({ area });
    }, (err) => {
      console.warn(err);
    })

    // 户籍
    const getType = () => {
      return window.rpc.owner.types.getArray(0, 0).then((x) => {
        let Type = [];
        x.forEach((res) => {
          Type[res.id] = res.name;
        }, this);
        return Type;
      });
    }
    const getState = () => {
      return window.rpc.alias.getValueByName("owner.state");
    }
    const getAll = () => {
      return window.rpc.owner.getInfoById(id);
    }

    const setOwner = async () => {
      try {
        let Type = await getType();
        let State = await getState();
        let Owner = await getAll();
        let owner = { ...Owner, type: Type[Owner.type], state: State[Owner.state], name: Owner.name, asset: Owner.asset, face: Owner.face, address: Owner.address, peopleScale: Owner.peopleScale, registerTime: moment(Owner.registerTime).format("YYYY年MM月DD日") || new Date().toLocaleString, };
        this.setState({ owner });
      } catch (error) {
        console.warn(error)
      }
    }
    setOwner();

    //处理结果详情数据
    window.rpc.device.alarm.getInfoById(id).then((result) => {
      window.rpc.user.getArray(0, 0).then((res) => {
        const rData = { ...result, type: armtypeList[result.type], userId: res[result.userId]["name"], state: ResultState[result.state], createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };
        this.setState({ rData });
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    })
  }

  componentWillReceiveProps(nextProps) {
    let id = parseInt(nextProps.id, 10) || 1;
    window.rpc.device.getInfoById(id).then((result) => {
      let time;
      if (result.setupTime == null) {
        time = moment(new Date()).format("YYYY年MM月DD日")
      } else {
        time = moment(result.setupTime).format("YYYY年MM月DD日")
      }
      window.rpc.area.getLocationName(result.location).then((res) => {
        const device = { ...result, createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString, setupTime: time, location: res, };
        this.setState({ device });
      }, (err) => {
        console.warn(err);
      })

    }, (err) => {
      console.warn(err);
    })
    //建筑
    window.rpc.area.getInfoById(id).then((result) => {
      let area = { ...result, name: result.name, layer: result.layer, galleryful: result.galleryful, face: result.face, hight: result.hight, };
      this.setState({ area });
    }, (err) => {
      console.warn(err);
    })

    // 户籍
    const getType = () => {
      return window.rpc.owner.types.getArray(0, 0).then((x) => {
        let Type = [];
        x.forEach((res) => {
          Type[res.id] = res.name;
        }, this);
        return Type;
      });
    }
    const getState = () => {
      return window.rpc.alias.getValueByName("owner.state");
    }
    const getAll = () => {
      return window.rpc.owner.getInfoById(id);
    }

    const setOwner = async () => {
      try {
        let Type = await getType();
        let State = await getState();
        let Owner = await getAll();
        let owner = { ...Owner, type: Type[Owner.type], state: State[Owner.state], name: Owner.name, asset: Owner.asset, face: Owner.face, address: Owner.address, peopleScale: Owner.peopleScale, registerTime: moment(Owner.registerTime).format("YYYY年MM月DD日") || new Date().toLocaleString, };
        this.setState({ owner });
      } catch (error) {
        console.warn(error)
      }
    }
    setOwner();
    //处理结果详情数据
    window.rpc.device.alarm.getInfoById(id).then((result) => {
      window.rpc.user.getArray(0, 0).then((res) => {
        const rData = { ...result, type: armtypeList[result.type], userId: res[result.userId]["name"], state: ResultState[result.state], createTime: moment(result.createTime).format("YYYY年MM月DD日") || new Date().toLocaleString, lastTime: moment(result.lastTime).format("YYYY年MM月DD日") || new Date().toLocaleString };
        this.setState({ rData });
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err);
    })
  }

  onChangeDate(date, dateString) {
  }

  render() {
    return (
      <div className="AlarmConcenBasicMes " style={{ padding: "0px 12px", boxShadow: '0 0 20px rgb(0, 193, 222)' }}>
        <Tabs tabPosition="Top" type="card" className='alarminfoTabTwo' style={{ height: '100%' }} >
          <TabPane tab="基础信息" key="1" style={{}} >
            <div style={{ height: 17 }}></div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="alarmRow-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />处理结果：{this.state.rData.state}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />处理人：{this.state.rData.userId}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />设备名称：{this.state.device.name}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />报警类型：{this.state.rData.type}  </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />所属系统： </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />所在建筑： 圆球咖啡 </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={net} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />生产厂家：</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />安装时间： {this.state.device.setupTime}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />报警时间： {this.state.rData.createTime}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={create} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />处理时间： {this.state.rData.lastTime}</div></Col>
                </Row>
              </div>
            </div>

          </TabPane>
          <TabPane tab="单位信息" className='infoTabTwoBorder' key="2">
            <div style={{ height: 12 }}></div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />户籍名称：{this.state.owner.name}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />户籍类型：{this.state.owner.type}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />户籍状态：{this.state.owner.state}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />资产：{this.state.owner.asset} </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />面积(平方米)：{this.state.owner.face}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />详细地址：{this.state.owner.address} </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />人数规模：{this.state.owner.peopleScale} </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />注册时间：{this.state.owner.registerTime} </div></Col>
                </Row>
              </div>
            </div>
            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <br />
          </TabPane>

          <TabPane tab="建筑信息" className='infoTabTwoBorder' key="3">
            <div style={{ height: 12 }}></div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />建筑名称：{this.state.area.name}</div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />建筑类型：{this.state.area.type}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />层次数： {this.state.area.layer} </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />火灾危险性：{this.state.area.fireLevel} </div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />容纳人数：{this.state.area.galleryful} </div></Col>
                  <Col span={12}><div className="alarmRow-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />面积(平方米)： {this.state.area.face}</div></Col>
                </Row>
              </div>
            </div>
            <div style={{ fontsize: '0.75em', color: '#373e41' }}>
              <div style={{ fontsize: '0.75em', color: '#373e41' }}>
                <Row className="Row-info">
                  <Col span={12}><div className="alarmRow-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px", float: 'left', marginTop: 1 }} />高度(米)：{this.state.area.hight}</div></Col>
                  <Col span={12}></Col>
                </Row>
              </div>
            </div>

            <br />
            <hr style={{ border: 'none', height: '1px', color: '#CCC', background: '#eee' }} />
            <br />
          </TabPane>

        </Tabs>
      </div >
    )
  }
}

export default AlarmConcenBasicMes;