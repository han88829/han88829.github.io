/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-04 10:14:56
 */
import React, { Component } from 'react';
import { Form, Button, Row, Col, message, Icon } from 'antd';
//import concentFloor_pic from '../../../../../../assets/images/concentrate/cjzongpingtu.png';
//import './alarmconcenFloor.css';
import { Link } from 'react-router';
import moment from 'moment';
//import Alarm from '../../../../../../assets/images/application/hot.png';

import build from '../../../../../assets/images/build/build.png';
import Area from '../../../../../assets/images/build/Area.png';
import bDate from '../../../../../assets/images/build/bDate.png';
import bArea from '../../../../../assets/images/build/bArea.png';
import bd from '../../../../../assets/images/build/bd.png';
import bHeight from '../../../../../assets/images/build/bHeight.png';
import build_remark from '../../../../../assets/images/build/build-remark.png';
import build_time from '../../../../../assets/images/build/build-time.png';
import fireEleNum from '../../../../../assets/images/build/fireEleNum.png';

import maxTotleNum from '../../../../../assets/images/build/maxTotleNum.png';
import nature from '../../../../../assets/images/build/nature.png';
import refugeFloor_totalArea from '../../../../../assets/images/build/refugeFloor-totalArea.png';
import refugeFloor_number from '../../../../../assets/images/build/refugeFloor-number.png';

import safety from '../../../../../assets/images/build/safety.png';
import standardFloorArea from '../../../../../assets/images/build/standardFloorArea.png';
import subType from '../../../../../assets/images/build/subType.png';

import totalElevator from '../../../../../assets/images/build/totalElevator.png';


import underArea from '../../../../../assets/images/build/underArea.png';

import underNumber from '../../../../../assets/images/build/underNumber.png';
import upDown from '../../../../../assets/images/build/upDown.png';
import upperNumber from '../../../../../assets/images/build/upperNumber.png';
import workMen from '../../../../../assets/images/build/workMen.png';

import workPersonDay from '../../../../../assets/images/build/workPersonDay.png';
import fireLevel from '../../../../../assets/images/build/fireLevel.png';
import floorArea from '../../../../../assets/images/build/floorArea.png';

class AreaInfoClick extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'block',
      floors: [],
      id: null,
      builds: {}
    };
  }
  componentWillReceiveProps() {
    //查建筑相关图片和坐标
    let mesid = parseInt(this.props.mesid, 10) || 1;//楼id
    this.setState({ id: mesid });
    //console.log('mes'+mesid);
    //let locationId = parseInt(this.props.params.locationId, 10);//取到设备坐标
    window.rpc.area.getInfoById(mesid).then((x) => {
      window.rpc.alias.getValueByName('area.fireDanger').then((data) => {
        window.rpc.area.types.getMapIdNameByContainer(null, 0, 0).then(res => {
          let type = res[`${x.type}`] || '';//x.extend.subtype  subtype:x.extend.stype,
          let subtype = res[`${x.subtype}`] || '';
          let builds = {
            ...x,
            Fname: x.name, Frisk: data[x.fireDanger] || '', createTime: moment(x.buildTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'),
            key: x.id, Type: type, Farea: subtype, Fstructure: x.galleryful, Frefractory: x.layer, Felevator: x.ownerId, Earea: x.parentId, Ftotal: x.subtype,
            Fday: x.type, Fnote: x.number, galleryful: x.galleryful,
            x: x.x, y: x.y,
            tag: x.tag,
            usetype: x.extend.nature || '',
            rangebuild: x.extend.rangebuild || '', rangebase: x.extend.rangebase, overgroundarea: x.extend.overgroundarea || '', overgroundfloor: x.extend.overgroundfloor || '', undergroundfloor: x.extend.undergroundfloor || '', undergroundarea: x.extend.undergroundarea || '', refugestoreyarea: x.extend.refugestoreyarea || '', refugestoreyfloor: x.extend.refugestoreyfloor || ''
          };
          builds = {
            ...builds,
          };
          this.setState({
            builds
          })
        }, (err) => {
          console.warn(err);
        })
      }, (err) => {
        console.warn(err);
      })
    }, (err) => {
      console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
    })
  }
  handleFixClick() {
    //css({display:'none',position:'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff'})
  }
  render() {
    // CONSOLE.LOG()
    // console.log(this.state.builds)
    return (
      <div className="AlarmConcenFloor " style={{ fontSize: 14, fontFamily: '苹方中等', padding: '12px', height: '100%', width: '100%', boxShadow: '0 0 20px rgb(0, 193, 222)' }}>
        <div style={{ width: "80%", marginBottom: 12, overflow: 'hidden' }}>
          <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
          <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>建筑详情</span>
        </div>

        <div style={{ marginTop: -4, paddingTop: 5, height: '100%', maxHeight: '76vh', overflow: 'auto', }}>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41', borderTop: '1px solid #ddd' }}>
              <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>基础信息</p>
              <div className="Row-info">
                <div className="Row-info-left"><span><img src={build} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物名称：{this.state.builds.name}</span> <a id="seeImgInfo" style={{ display: 'inline-block', height: 20, width: 20, marginLeft: 10, borderRadius: '100%', background: '#fff', border: '1px solid #ccc', float: 'right', display: "none" }}><Icon type="upload" style={{ marginLeft: 4, }} /></a> </div>
                <div className="Row-info-right"> <img src={build_time} style={{ padding: '0 15px 0 12px' }} alt="" />建筑日期：{this.state.builds.createTime} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"><img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物类型：{this.state.builds.Type} </div>
                <div className="Row-info-right"> <img src={safety} style={{ padding: '0 15px 0 12px' }} alt="" />火灾危险性:{this.state.builds.Frisk} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"> <img src={nature} style={{ padding: '0 15px 0 12px' }} alt="" />使用性质：{this.state.builds.usetype} </div>
                <div className="Row-info-right">  <img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />结构类型:{this.state.builds.Farea} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"> <img src={fireLevel} style={{ padding: '0 15px 0 12px' }} alt="" />耐火等级：{this.state.builds.Frefractory} </div>
                <div className="Row-info-right">  <img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />NFC:{this.state.builds.tag}  </div>
              </div>
              {/*<div className="Row-info">
                    <div className="Row-info-left"> <img src={fireLevel} style={{ padding: '0 15px 0 12px' }} alt="" />建筑二维码：<QrCode builds={this.state.builds} /> </div>
                  </div>*/}
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>建筑信息</p>
              <div className="Row-info">
                <div className="Row-info-left"><img src={bHeight} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物高度： {this.state.builds.hight}</div>
                <div className="Row-info-right"> <img src={Area} style={{ padding: '0 15px 0 12px' }} alt="" />占地面积（平方米）：{this.state.builds.Earea} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"><img src={bArea} style={{ padding: '0 15px 0 12px' }} alt="" />建筑物面积(平方米)：{this.state.builds.rangebuild} </div>
                <div className="Row-info-right"><img src={standardFloorArea} style={{ padding: '0 15px 0 12px' }} alt="" />标准层面积(平方米)：{this.state.builds.rangebase} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"><img src={nature} style={{ padding: '0 15px 0 12px' }} alt="" />建筑坐标x：{this.state.builds.x} </div>
                <div className="Row-info-right"><img src={subType} style={{ padding: '0 15px 0 12px' }} alt="" />建筑坐标y：{this.state.builds.y} </div>
              </div>

              <div className="Row-info">
                <div className="Row-info-left"><img src={upperNumber} style={{ padding: '0 15px 0 12px' }} alt="" />地上层数：{this.state.builds.overgroundfloor} </div>
                <div className="Row-info-right"><img src={floorArea} style={{ padding: '0 15px 0 12px' }} alt="" />地上面积(平方米)： {this.state.builds.undergroundarea} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"> <img src={underNumber} style={{ padding: '0 15px 0 12px' }} alt="" />地下层数：{this.state.builds.undergroundfloor} </div>
                <div className="Row-info-right"> <img src={underArea} style={{ padding: '0 15px 0 12px' }} alt="" />地下面积(平方米)： {this.state.builds.undergroundarea} </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"><img src={refugeFloor_number} style={{ padding: '0 15px 0 12px' }} alt="" />避难层数量：{this.state.builds.refugestoreyfloor} </div>
                <div className="Row-info-right"> <img src={refugeFloor_totalArea} style={{ padding: '0 15px 0 12px' }} alt="" />避难层总面积(平方米)：{this.state.builds.refugestoreyarea} </div>
              </div>
              {/*<p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>建筑信息</p>*/}
              <div className="Row-info">
                <div className="Row-info-left"><img src={fireEleNum} style={{ padding: '0 15px 0 12px' }} alt="" />消防电梯数量：{this.state.builds.elevator}  </div>
                <div className="Row-info-right"><img src={totalElevator} style={{ padding: '0 15px 0 12px' }} alt="" />电梯容量：{this.state.builds.elevatornum}  </div>
              </div>
              <div className="Row-info">
                <div className="Row-info-left"> <img src={maxTotleNum} style={{ padding: '0 15px 0 12px' }} alt="" />最大容纳人数：{this.state.builds.galleryful} </div>
                <div className="Row-info-right"><img src={workPersonDay} style={{ padding: '0 15px 0 12px' }} alt="" />日常工作时间人数：{this.state.builds.everyday} </div>
              </div>
            </div>
          </div>

          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <p style={{ color: '#adadad', fontsize: '0.75rem', fontFamily: '苹方中等', padding: '25px 0 12px 9px' }}>备注</p>
              <div className="Row-info-left"><img src={build_remark} style={{ padding: '0 15px 0 12px' }} alt="" />备注：{this.state.builds.remark}  </div>
            </div>
          </div>
        </div>
        <div>

        </div>

      </div>
    );
  }
}


export default AreaInfoClick;