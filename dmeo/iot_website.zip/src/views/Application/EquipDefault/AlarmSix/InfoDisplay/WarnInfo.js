/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-04 10:15:59
 */
import React, { Component } from 'react';
import { Form, Button, Row, Col, message, Icon, Modal } from 'antd';
//import concentFloor_pic from '../../../../../../../../../../assets/images/concentrate/cjzongpingtu.png';
//import './alarmconcenFloor.css';
import { Link } from 'react-router';
import moment from 'moment';
//import Alarm from '../../../../../../../../../../assets/images/application/hot.png';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import $ from 'jquery';
import star from '../../../../../assets/images/equipment/设备名称.png';
import er from '../../../../../assets/images/equipment/设备二维码.png';
import time from '../../../../../assets/images/equipment/安装时间.png';
import state from '../../../../../assets/images/equipment/布设状态.png';
import model from '../../../../../assets/images/equipment/采集模块.png';
import create from '../../../../../assets/images/equipment/创立时间.png';
import unit from '../../../../../assets/images/equipment/单位.png';
import address from '../../../../../assets/images/equipment/地址.png';
import type from '../../../../../assets/images/equipment/检测类型.png';
import dtype from '../../../../../assets/images/equipment/设备型号.png';
import shang from '../../../../../assets/images/equipment/生产厂家.png';
import area from '../../../../../assets/images/equipment/所属区域.png';
import net from '../../../../../assets/images/equipment/网关地址.png';
class QrCode extends React.Component {
  state = {
    modal2Visible: false
  }
  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }
  preview = () => {
    let id = 'PrintContentDiv';
    var sprnhtml = document.getElementById(id).innerHTML;
    var selfhtml = window.document.body.innerHTML; //获取当前页的html
    window.document.body.innerHTML = sprnhtml;
    window.print();
    //window.document.body.innerHTML = selfhtml;//改变html内容，使react事件失效；$()事件应该有效，。。 影响范围
    //正确方案 新打开窗口，问题 图片加载循序问题
    window.location.href = "/equip/device/info/1";
    //         var newWin = window.open("",'newwindow',' height=700,width=750,top=100,left=200,toolbar=no,menubar=no,resizable=no,location=no, status=no');
    //   　　  newWin.document.write(sprnhtml);
    // 　    　newWin.print();
    // console.log(sprnhtml);//新打开的窗口无法显示二维码图片
    //window.document.body.innerHTML = selfhtml;
    //this.setState({modal2Visible:false});
    //var newWin = window.open("",'newwindow',' height=700,width=750,top=100,left=200,toolbar=no,menubar=no,resizable=no,location=no, status=no');
    //newWin.document.write(prnhtml);
    //　newWin.print();
  }
  render() {
    let ie = `http://qr.liantu.com/api.php?&bg=ffffff&text=http://xiot.lszpcn.com/SEquipment/${this.props.id}`
    return (
      <span className="QrCode">
        <Button type="primary" onClick={() => this.setModal2Visible(true)} style={{ borderColor: "#ccc", color: "#000", backgroundColor: "white" }}>点我查看二维码</Button>
        <Modal
          title="请扫以下二维码"
          wrapClassName="vertical-center-modal"
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          style={{ height: "400px" }}
          className="QrCode"
        >
          <Button name="print" onClick={this.preview} style={{ position: 'absolute', left: 12, bottom: 12, zIndex: 999 }}>打印</Button>
          <span id="PrintContentDiv">
            <img src={ie} alt="" style={{ position: 'absolute', left: '50%', top: '50%', marginLeft: '-150px', marginTop: '-150px' }} />
          </span>
        </Modal>
      </span>
    );
  }
}

class appState {
  constructor() {
    extendObservable(this, {

      device: {
        tag: '',
        expiryTime: '',
        location: '',
        productId: '',//product.name, 
        brandId: '', ownerName: '', setupTime: '',
        param: {
          module: ''
        },
        networkUrl: '', networkId: '', networkNode: null,
        mapX: '', mapY: '', networkAddr: ''

      }
    })
  }
}
const WarnInfoC = observer(class appState extends React.Component {
  //class WarnInfoC extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'block',
      floors: [],
      id: null,
      builds: {},
      device: {
        tag: '',
        expiryTime: '',
        location: '',
        productId: '',//product.name, 
        brandId: '', ownerName: '', setupTime: '',
        param: {
          module: ''
        },
        networkUrl: '', networkId: '', networkNode: null,
        mapX: '', mapY: '', networkAddr: ''

      }
    }
  }
  componentWillReceiveProps(mesid) {
    //查建筑相关图片和坐标
    //let device=this.props.mesid;
    //console.log(mesid);
    //console.log(this.props.mesid);
    // let id = parseInt(data, 10);//楼id
    //
    let id = this.props.mesid || mesid.mesid;
    //this.setState({device});
    //console.log('mes'+id);
    if (id) {
      //console.log(id)
      window.rpc.device.getInfoById(id).then((x) => {
        window.rpc.alias.getValueByName('area.fireDanger').then((data) => {
          window.rpc.alias.getValueByName('device.networkmode').then((result) => {
            window.rpc.area.types.getMapIdNameByContainer(null, 0, 0).then(res => {
              window.rpc.public.device.getInfoExById(id).then(ex => {
                //let type = res[`${x.type}`] || '';//x.extend.subtype  subtype:x.extend.stype,
                //let subtype = res[`${x.subtype}`] || '';
                //console.log(x);
                if (x) {
                  let device = {
                    ...x,
                    tag: x.tag || '', expiryTime: moment(x.expiryTime).format("YYYY年MM月DD日") || new Date('2017-01-01 08:00:00').format('YYYY-MM-DD'), location: ex.locationName.replace(/,/g, '-') || x.location, productId: ex.productNumber || x.productId,//product.name, 
                    brandId: ex.makeName || '', ownerName: '', setupTime: x.setupTime ? moment(x.setupTime).format("YYYY年MM月DD日") : new Date('2017-01-01 08:00:00').format("YYYY年MM月DD日"), dtype: ex.typeName || x.dtype
                    , param: {
                      module: x.param.module || '', networkUrl: x.networkUrl || '', networkId: x.networkId || '', networkNode: x.networkNode || null, networkMode: result[x.networkMode] || null,
                      mapX: x.mapX || '', mapY: x.mapY || '', networkAddr: x.networkAddr || ''
                    }


                    // Fname: x.name, Frisk: data[x.fireDanger]||'', createTime: moment(x.buildTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'),
                    // key: x.id, Type: type, Farea: subtype, Fstructure: x.galleryful, Frefractory: x.layer, Felevator: x.ownerId, Earea: x.parentId, Ftotal: x.subtype,
                    // Fday: x.type, Fnote: x.number, galleryful: x.galleryful,
                    // x: x.x, y: x.y,
                    // tag: x.tag,
                    // usetype: x.extend.nature|| '',
                    // rangebuild: x.extend.rangebuild || '', rangebase: x.extend.rangebase, overgroundarea: x.extend.overgroundarea || '', overgroundfloor: x.extend.overgroundfloor || '', undergroundfloor: x.extend.undergroundfloor || '', undergroundarea: x.extend.undergroundarea || '', refugestoreyarea: x.extend.refugestoreyarea || '', refugestoreyfloor: x.extend.refugestoreyfloor || ''
                  };
                  //console.log(device)
                  this.setState({
                    device
                  });
                  this.props.appState.device = device;
                }
                //console.log(this.props.appState.device);
                // builds = {
                //   ...builds,
                // };
              }, (err) => {
                console.warn(err);
              })
            }, (err) => {
              console.warn(err);
            })
          }, (err) => {
            console.warn(err);
          })
        }, (err) => {
          console.warn(err);
        })
      }, (err) => {
        console.warn(err); function existError(err) { let t = err.toString(); let r = /E(\d+): (.+)/; let e = r.exec(t); if (e && e.length >= 3) { alertError(e[1], e[2]); } } function alertError(code, msg) { console.log('CODE:', code, "MSG:", msg); if (msg = 'Insufficient permissions') { alert(`暂无权限!`); } } existError(err);
      })
      //let locationId = parseInt(this.props.params.locationId, 10);//取到设备坐标
      //  window.rpc.device.getInfoById(id).then((result) => {
      //      console.log(result);
      //       window.rpc.brand.getInfoById(result.productId).then(product=>{
      //    window.rpc.brand.getInfoById(product.ownerId).then(brand=>{
      //      window.rpc.owner.getInfoById(result.ownerId).then(owner=>{
    }
  }
  handleFixClick() {
    //css({display:'none',position:'fixed', top: 0, left: 0, zIndex: 1000, height: '100vh', width: '100vw', backgroundColor: '#fff'})
  }
  render() {
    //console.log(this.props.appState.device);
    //console.log(this.props.appState.device)
    return (
      <div style={{ padding: 20 }}>
        <div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={star} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备名称： {this.props.appState.device.name}</div>
                <div className="Row-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备二维码：<QrCode style={{ display: this.props.appState.device.id ? 'block' : 'none' }} id={this.props.mesid} /> </div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px" }} />所属系统：{this.props.appState.device.ownerName}</div>
                <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />所在建筑： </div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={shang} alt="" style={{ padding: " 0px 12px 0px 16px" }} />生产厂家： {this.props.appState.device.brandId}</div>
                <div className="Row-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px" }} />安装时间： {this.props.appState.device.setupTime} </div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={dtype} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备型号： {this.props.appState.device.productId}</div>
                <div className="Row-info-left"><img src={time} alt="" style={{ padding: " 0px 12px 0px 16px" }} />有效期限： {this.props.appState.device.expiryTime} </div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={state} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备类型：{this.props.appState.device.dtype} </div>
                <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />安装位置： {this.props.appState.device.location} </div>
              </div>
            </div>
          </div>
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              {/*<div className="Row-info">
                  <div className="Row-info-left"><img src={net} alt="" style={{ padding: " 0px 12px 0px 16px" }} />网关地址：{this.props.appState.device.networkUrl}</div>
                  <div className="Row-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px" }} />网关序号：{this.props.appState.device.networkId} </div>
                </div>*/}
              <div className="Row-info">
                <div className="Row-info-left"><img src={net} alt="" style={{ padding: " 0px 12px 0px 16px" }} />相对坐标x：{this.props.appState.device.mapX}</div>
                <div className="Row-info-left"><img src={er} alt="" style={{ padding: " 0px 12px 0px 16px" }} />相对坐标y：{this.props.appState.device.mapY} </div>
              </div>
            </div>
          </div>
          {/*<div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={model} alt="" style={{ padding: " 0px 12px 0px 16px" }} />采集模块： {this.props.appState.device.param?this.props.appState.device.param.module:''}</div>
                  <div className="Row-info-left"><img src={create} alt="" style={{ padding: " 0px 12px 0px 16px" }} />监控类型： {this.props.appState.device.networkNode}</div>
                </div>
              </div>
            </div>
            <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
                <div className="Row-info">
                  <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />设备地址： {this.props.appState.device.networkAddr}</div>
                  <div className="Row-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px" }} />监测类型： </div>
                </div>
              </div>
            </div>*/}
          <div className="buildCard" style={{ fontsize: '0.75rem', color: '#373e41' }}>
            <div style={{ fontsize: '0.75rem', color: '#373e41' }}>
              <div className="Row-info">
                <div className="Row-info-left"><img src={area} alt="" style={{ padding: " 0px 12px 0px 16px" }} />联网模式：{this.state.device.networkMode} </div>
                <div className="Row-info-left"><img src={address} alt="" style={{ padding: " 0px 12px 0px 16px" }} />NFC： {this.props.appState.device.tag}</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    );
  }
})
class WarnInfo extends Component {
  render() {
    return (
      <WarnInfoC appState={new appState()} mesid={this.props.mesid} />
    )
  }
}

export default WarnInfo;