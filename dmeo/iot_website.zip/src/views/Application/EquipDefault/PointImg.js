import React, { Component } from 'react';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import {Checkbox,Tooltip,Button,Icon,Select,Row,Col,Form, message,DatePicker,Cascader} from 'antd';
import $ from 'jquery';
import moment from 'moment';
import delete_pic from '../../../assets/images/build/delete.png';
import big_pic from '../../../assets/images/build/big.png';
import small_pic from '../../../assets/images/build/small.png';
import left_pic from '../../../assets/images/build/left.png';
import right_pic from '../../../assets/images/build/right.png';
import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
import textbox from '../../../assets/images/apply/textbox.png';
import './equipDefault.css';
import './modal.css';
const { Option } = Select;
const FormItem = Form.Item;
const options = [{
  value: 'zhejiang',
  label: 'Zhejiang'
}, {
  value: 'jiangsu',
  label: 'Jiangsu'
}];
class patrolState {
  constructor() {
    extendObservable(this, {
      state: 0,
      mapPoints: [],
      mapPointsOne:[],
      mapPointsIcon:[],
      detailSrc:null,
      mapUrl:'',
      storey:null,
      storeys:{},
    })
  }
}
class AdvancedSearchForm extends React.Component {
  constructor() {
    super();
    this.state = {
      storeys:[],
      types: [],
      floorName:[],
      buildings:[],
      detailSrc:'',
      mapPoints: [],
      mapPointsOne:[]
    }
  }
  componentWillReceiveProps(id) {
     let Id=this.props.id;
     window.rpc.area.getArrayByContainer({parentId:Id},0,0).then((res)=>{
          let storeys= res.map(x=>({...x,id:x.id,value: `${x.id}`, label:x.name ,mapUrl: x.mapUrl? x.mapUrl : '',buildTime: moment(res.buildTime).format("YYYY年MM月DD日") }));
          this.setState({ storeys});
     },err=>{
        console.warn(err)
     })
  }
  onChange=(value)=>{
    let that=this;
    let storey=parseInt(value[0],10);
    window.rpc.device.getArrayByCond({storey:storey }, 0, 0).then((res) => {
       let mapPointsIcon = Array.from(new Set(res.filter(point => point.mapX).map(point => point.dtype)));
       this.props.patrolState.mapPointsIcon=mapPointsIcon;
        let mapPoints = res.filter(point => point.mapX);
       this.props.patrolState.mapPoints= mapPoints;
    });
    this.props.patrolState.storey=storey;
    window.rpc.area.getInfoById(storey).then((res)=>{
       let storeys={...res ,mapUrl: res.mapUrl,buildTime: moment(res.buildTime).format("YYYY年MM月DD日") };
       this.props.patrolState.storeys=storeys;
       this.props.patrolState.mapUrl=storey.mapUrl;   
    },err=>{
       console.warn(err)
    })
  }
  
  render() {
    const { getFieldDecorator } = this.props.form;

    let dtypes = this.state.floorName;
    let dtypeChildren = [];
    for (let value of dtypes) {
      if (value && value.id) {
        dtypeChildren.push(<Option key={`${value.id}`}>{value.name}</Option>)
      }
    }
    return (
      <Form layout="inline" style={{padding:' 0'}}>
        <Row>
          <Col span={18} key={1}>
             <span style={{margin:'0 12px 0 25px',fontSize:'0.75rem'}}>楼层选择：</span>
             <Cascader options={this.state.storeys} onChange={this.onChange.bind(this)} style={{width:"220px"}} placeholder="请选择" />
          </Col>
        </Row>
      </Form>
    );
  }
}
const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);
const PatrolDetailImgC = observer(class patrolState extends React.Component {
 constructor() {
    super();
    this.state = {
      new_pingmiantu:true,
      buildingImgUrl:'',
      areaId:[],
      mapPoints: [],
      mapPointsOne: [],
      buildImg:'',
      drag : 0,
      move:0,
      isdrag:false
    };
  }
  componentWillMount(){
    
  }
  
  handleStaffOne=()=>{
    this.setState({
        new_pingmiantu:true
    })
  }

  render() {

    return (
      <div className="equipDefaultImg" style={{width:'100%'}}>
          <div className="new_pingmiantu" style={{overflow: 'hidden' }}>
          <div className="pingmiantu-left" style={{position:'relative',width:'88%',float:'left'}} >
            <div className="ImgSearch" style={{backgroundColor:"rgba(224,224,224,0.7)",position:'absolute',top:0,left:0,width:'100%'}}>
              <WrappedAdvancedSearchForm patrolState={this.props.patrolState} id={this.props.id} style={{padding:"0"}} />       
          </div>
          <div className="showImg" style={{position:'relative',marginTop:32}}>
              <div style={{display: this.props.patrolState.storeys.mapUrl ? 'block' : 'none' }}>
                <img id="img2" src={this.props.patrolState.storeys.mapUrl} alt="暂无图片！" />
             </div>
             {this.props.patrolState.mapPoints.map((point,index) => (
               <div key={index} className={`map-point map-point-${point.dtype}`} style={{ position: 'absolute', height:20, width: 20, top:`${point.mapY}%`, left:`${point.mapX}%`}}></div>
             ))}
            </div>
          </div>
          <div className="pingmiantu-right" style={{width:'12%',float:'right',height: '95vh'}}>
            <div className="pingmiantu-oprate" title="正常" onClick={() => {
                window.rpc.device.getArrayByContainer({storey:this.props.patrolState.storey,rstate:1},0,0).then((res) => {
                   let mapPoints = res.filter(point => point.mapX);
                   this.setState({ mapPoints });
                   this.props.patrolState.mapPoints=mapPoints;
                });
              }}><i className="iconfont-lszp">&#xe62a;</i></div>
            <div className="pingmiantu-oprate" title="异常" onClick={() => {
                window.rpc.device.getArrayByContainer({storey:this.props.patrolState.storey,rstate:2},0,0).then((res) => {
                  let mapPoints = res.filter(point => point.mapX);
                  this.props.patrolState.mapPoints=mapPoints;
                });
              }}><i className="iconfont-lszp">&#xe7e6;</i></div>
            <div className="pingmiantu-oprate" title="离线" onClick={() => {
                window.rpc.device.getArrayByContainer({storey:this.props.patrolState.storey,rstate:3},0,0).then((res) => {
                  let mapPoints = res.filter(point => point.mapX);
                  this.props.patrolState.mapPoints=mapPoints;
                });
              }}><i className="iconfont-lszp">&#xe613;</i></div>
            {this.props.patrolState.mapPointsIcon.map((point, index) => (//title={types[point]}
              <div key={index} className={`pingmiantu-oprate pingmiantu-oprate-${point}`}  onClick={() => {
                window.rpc.device.getArrayByContainer({storey:this.props.patrolState.storey,dtype:point},0,0).then((res) => {
                   let mapPoints = res.filter(point => point.mapX);
                   this.props.patrolState.mapPoints=mapPoints;
                });
              }}></div>
            ))}
          </div>
        </div>
      </div>
    );
  }
})
class PointImg extends Component {
  render() {
    return (
      <PatrolDetailImgC patrolState={new patrolState()} id={this.props.id}  />
    )
  }
}
export default PointImg;