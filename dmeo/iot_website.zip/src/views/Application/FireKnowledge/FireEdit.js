/*
 * @Author: Han.beibei 
 * @Date: 2017-07-18 14:29:31 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-07-18 16:41:16
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { Card, Row, Input, message, } from 'antd';
import { observer } from 'mobx-react';
import '../../Account/NewSend.css';

const NewSendC = observer(class NewSendC extends Component {

    state = {
        title: '',
        body: "",
    }
    componentDidMount() {
        let id = parseInt(this.props.params.id, 10);
        window.rpc.knowledge.getInfoById(id).then((x) => {
            this.setState({
                title: x.name,
                body: x.body,
            });
        })
    }

    handleSubmit = () => {
        let { title, body } = this.state;
        let id = parseInt(this.props.params.id, 10);
        if (!title) {
            message.info("请输入标题！");
            return
        }
        if (!body) {
            message.info("请输入正文！");
            return
        }
        window.rpc.knowledge.setInfoById(id, { name: title, body: body }).then((x) => {
            if (x) {
                browserHistory.push('/fire');
            } else {
                message.info("创建失败！")
            }
        }), (err) => {
            console.warn(err)
        }
    }
    render() {
        return (
            <div className="NewSend" style={{ padding: 20 }}>
                <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
                    <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>消防知识新增</Link>
                </div> <br />
                <div style={{ marginTop: 20, borderTop: "1px solid rgb(203, 202, 202)", width: "100%" }}></div>
                <Card style={{ marginTop: 20, paddingBottom: 18 }}>
                    <Row>
                        <div style={{ float: "left", width: "4%", textAlign: "left", paddingTop: 5 }}>标题：</div>
                        <Input value={this.state.title} style={{ width: "96%", borderRadius: 0 }} onChange={(e) => {
                            this.setState({
                                title: e.target.value
                            });
                        }} />
                    </Row>
                    <Row style={{ marginTop: 15 }}>
                        <div style={{ float: "left", width: "4%", textAlign: "left", paddingTop: 5 }}>正文：</div>
                        <Input value={this.state.body} autosize style={{ width: "96%", borderRadius: 0, minHeight: 200 }} type="textarea" onChange={(e) => {
                            this.setState({
                                body: e.target.value
                            });
                        }} />
                    </Row>
                    <div style={{ width: "100vw", borderTop: "1px solid #e6b85c", marginTop: 50, marginLeft: "-50px" }}></div>
                    <Row style={{ marginTop: 10, position: "absolute", right: 10, width: 220 }}>
                        <div style={{ float: "right", width: 50, height: 28, marginTop: "-3px", textAlign: "center", lineHeight: "25px", cursor: "pointer", marginLeft: 15, backgroundColor: "#e6b85c", color: "white", border: "1px solid d6a647" }} onClick={this.handleSubmit}>修改</div>
                        <div style={{ float: "right", width: 50, height: 28, marginTop: "-3px", textAlign: "center", lineHeight: "25px", cursor: "pointer", marginLeft: 15, backgroundColor: "rgb(183, 180, 177)", color: "white", border: "1px solid d6a647" }} onClick={() => {
                            browserHistory.push('/fire');
                        }}>返回</div>
                    </Row>
                </Card>
            </div >
        );
    }
})


class FireEdit extends Component {
    render() {
        return (
            <NewSendC params={this.props.params} />
        );
    }
}


export default FireEdit;