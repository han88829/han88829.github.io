/*
 * @Author: Han.beibei 
 * @Date: 2017-07-20 16:35:14 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-08 15:26:26
 */
import React, { Component } from 'react';
import { Row, Col, Card, Input, Pagination, Icon, Menu, Select, Tree, DatePicker, Modal, Popconfirm, message, Button, Badge } from 'antd';
import { Link, browserHistory } from 'react-router';
import moment from 'moment';
import './Fire.css';

import logo from '../../../assets/logo.png';
import hot from '../../../assets/images/back/hot.png';
import safe from '../../../assets/images/account/safe.png';
import basis from '../../../assets/images/account/basis.png';
import real from '../../../assets/images/account/real.png';

const TreeNode = Tree.TreeNode;
const Search = Input.Search;
const Option = Select.Option;

class FireDetail extends React.Component {
  state = {
    selectedId: 0,
    visible: false,
    visibleNew: false,
    visibleB: false,
    type: "",
    id: 0,
    data: [],
    display: 0,
    title: '',
    context: '',
    edit: 0,
    parentId: 0,
    name: "",
    parentPId: 1,
    newname: "",
    editcontext: "",
    ownerSign: [],
    ownerSignId: 0,
    beginTime: "",
    ownerSign: [],
    dateBook: null,
    ownerSignIdBook: 1,
    displayOne: "none",
    fireData: [],
    visibleMe: false,
    Message: false,
    number: 0,
    messData: []
  }

  componentDidMount() {
    let id = parseInt(this.props.params.id, 10);

    window.rpc.knowledge.getInfoById(id).then((data) => {
      this.setState({
        selectedId: id,
        title: data.name,
        context: data.context,
        id: data.id,
        beginTime: moment(data.beginTime || new Date('2017-01-01')).format('YYYY-MM-DD'),
        ownerSignId: data.authorityId
      });
    }), (err) => {
      console.warn(err)
    }

    window.rpc.knowledge.getArray(0, 0).then((x) => {
      let data = [], datac = [], datacc = [];
      data = x.filter(x => x.parentId === 0);
      data.forEach(function (x) {
        x.children = []
      }, this);
      datac = x.filter(x => !x.context && x.parentId != 0);
      datac.forEach(function (x) {
        x.children = []
      }, this);
      datacc = x.filter(x => x.context && x.parentId != 0);
      for (let i = 0; i < datac.length; i++) {
        for (let j = 0; j < datacc.length; j++) {
          if (datacc[j].parentId === datac[i].id) {
            datac[i].children.push(datacc[j])
          }
        }
      }
      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j < datac.length; j++) {
          if (datac[j].parentId === data[i].id) {
            data[i].children.push(datac[j])
          }
        }
      }
      this.setState({ data });
    }), (err) => {
      console.warn(err)
    }
    window.rpc.knowledge.authority.getArray(0, 0).then((x) => {
      let ownerSign = [];
      x.forEach(function (res) {
        ownerSign[res.id] = res.name;
      }, this);
      this.setState({ ownerSign, });
    }), (error) => {
      console.warn(error)
    }
  }

  componentWillReceiveProps(nextProps) {
    // 消息
    window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then((result) => {
      let data = result.map((x) => ({ ...x, key: x.id, name: x.name, createTime: moment(x.createTime || new Date('2017-01-01 8:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
      this.setState({ messData: data, number: result.length });
    }), (err) => {
      console.warn(err)
    }
    this.setState({
      collapsed: true
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  onSelect = (selectedKeys, info) => {
    this.setState({
      selectedId: selectedKeys,
      displayOne: "none"
    });
  }

  handleClick = (type, id, name, parentPId, e) => {
    // e.stopPropagation();
    switch (type) {
      case "edit":
        this.setState({ visible: true, type, id, name, parentPId });
        break;
      case "new":
        this.setState({ visibleNew: true, type, id, parentId: name, parentPId });
        break;
      default:
        break;
    }
  }

  handleOk = (e) => {
    if (!this.state.name) {
      message.info("内容不能为空！");
      return
    }
    window.rpc.knowledge.setInfoById(this.state.id, { name: this.state.name }).then((set) => {
      if (set) {
        message.info("修改成功！");
        window.rpc.knowledge.getArray(0, 0).then((x) => {
          let data = [], datac = [], datacc = [];
          data = x.filter(x => x.parentId === 0);
          data.forEach(function (x) {
            x.children = []
          }, this);
          datac = x.filter(x => !x.context && x.parentId != 0);
          datac.forEach(function (x) {
            x.children = []
          }, this);
          datacc = x.filter(x => x.context && x.parentId != 0);
          for (let i = 0; i < datac.length; i++) {
            for (let j = 0; j < datacc.length; j++) {
              if (datacc[j].parentId === datac[i].id) {
                datac[i].children.push(datacc[j])
              }
            }
          }
          for (let i = 0; i < data.length; i++) {
            for (let j = 0; j < datac.length; j++) {
              if (datac[j].parentId === data[i].id) {
                data[i].children.push(datac[j])
              }
            }
          }
          this.setState({ data });
        }), (err) => {
          console.warn(err)
        }
        this.setState({
          visible: false,
        });
      } else {
        message.info("修改失败！");
      }
    }), (err) => {
      console.warn(err)
    }
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
      name: ""
    });
  }

  handleOkNew = (e) => {
    let { newname, dateBook, ownerSignIdBook } = this.state
    if (!newname) {
      message.info("请输入内容!");
      return
    }
    if (!dateBook && this.state.parentPId === 1) {
      message.info("请输入颁发时间!");
      return
    }
    if (!ownerSignIdBook) {
      message.info("请输入颁发机构!");
      return
    }

    if (this.state.parentPId === 1) {
      window.rpc.knowledge.create({ name: newname, beginTime: new Date(dateBook.format('YYYY-MM-DD')), authorityId: ownerSignIdBook, parentId: 0 }).then((create) => {
        if (create) {
          message.info("添加成功！");
          window.rpc.knowledge.getArray(0, 0).then((x) => {
            let data = [], datac = [], datacc = [];
            data = x.filter(x => x.parentId === 0);
            data.forEach(function (x) {
              x.children = []
            }, this);
            datac = x.filter(x => !x.context && x.parentId != 0);
            datac.forEach(function (x) {
              x.children = []
            }, this);
            datacc = x.filter(x => x.context && x.parentId != 0);
            for (let i = 0; i < datac.length; i++) {
              for (let j = 0; j < datacc.length; j++) {
                if (datacc[j].parentId === datac[i].id) {
                  datac[i].children.push(datacc[j])
                }
              }
            }
            for (let i = 0; i < data.length; i++) {
              for (let j = 0; j < datac.length; j++) {
                if (datac[j].parentId === data[i].id) {
                  data[i].children.push(datac[j])
                }
              }
            }
            this.setState({ data });
          }), (err) => {
            console.warn(err)
          }
          this.setState({
            visibleNew: false,
            newname: "",
            dateBook: null,
            ownerSignIdBook: 1
          });
        } else {
          message.info("修改失败！");

        }
      }), (err) => {
        console.warn(err)
      }
    } else if (this.state.parentPId === 2) {
      window.rpc.knowledge.create({ name: this.state.newname, authorityId: ownerSignIdBook, parentId: this.state.parentId }).then((create) => {
        if (create) {
          message.info("添加成功！");
          window.rpc.knowledge.getArray(0, 0).then((x) => {
            let data = [], datac = [], datacc = [];
            data = x.filter(x => x.parentId === 0);
            data.forEach(function (x) {
              x.children = []
            }, this);
            datac = x.filter(x => !x.context && x.parentId != 0);
            datac.forEach(function (x) {
              x.children = []
            }, this);
            datacc = x.filter(x => x.context && x.parentId != 0);
            for (let i = 0; i < datac.length; i++) {
              for (let j = 0; j < datacc.length; j++) {
                if (datacc[j].parentId === datac[i].id) {
                  datac[i].children.push(datacc[j])
                }
              }
            }
            for (let i = 0; i < data.length; i++) {
              for (let j = 0; j < datac.length; j++) {
                if (datac[j].parentId === data[i].id) {
                  data[i].children.push(datac[j])
                }
              }
            }
            this.setState({ data });
          }), (err) => {
            console.warn(err)
          }
          this.setState({
            visibleNew: false,
            newname: "",
            dateBook: null,
            ownerSignIdBook: 1
          });
        } else {
          message.info("修改失败！");

        }
      }), (err) => {
        console.warn(err)
      }
    } else if (this.state.parentPId === 3) {
      window.rpc.knowledge.create({ name: this.state.newname, authorityId: ownerSignIdBook, parentId: this.state.parentId, context: this.state.newname, type: 256 }).then((create) => {
        if (create) {
          message.info("添加成功！");
          window.rpc.knowledge.getArray(0, 0).then((x) => {
            let data = [], datac = [], datacc = [];
            data = x.filter(x => x.parentId === 0);
            data.forEach(function (x) {
              x.children = []
            }, this);
            datac = x.filter(x => !x.context && x.parentId != 0);
            datac.forEach(function (x) {
              x.children = []
            }, this);
            datacc = x.filter(x => x.context && x.parentId != 0);
            for (let i = 0; i < datac.length; i++) {
              for (let j = 0; j < datacc.length; j++) {
                if (datacc[j].parentId === datac[i].id) {
                  datac[i].children.push(datacc[j])
                }
              }
            }
            for (let i = 0; i < data.length; i++) {
              for (let j = 0; j < datac.length; j++) {
                if (datac[j].parentId === data[i].id) {
                  data[i].children.push(datac[j])
                }
              }
            }
            this.setState({ data });
          }), (err) => {
            console.warn(err)
          }
          this.setState({
            visibleNew: false,
            newname: "",
            dateBook: null,
            ownerSignIdBook: 1
          });
        } else {
          message.info("修改失败！");
        }
      }), (err) => {
        console.warn(err)
      }
    }
  }

  handleCancelNew = (e) => {
    this.setState({
      visibleNew: false,
      newname: ""
    });
  }

  confirm = (id, e) => {
    window.rpc.knowledge.removeById(id).then((remove) => {
      if (remove) {
        message.info("删除成功！");
        window.rpc.knowledge.getArray(0, 0).then((x) => {
          let data = [], datac = [], datacc = [];
          data = x.filter(x => x.parentId === 0);
          data.forEach(function (x) {
            x.children = []
          }, this);
          datac = x.filter(x => !x.context && x.parentId != 0);
          datac.forEach(function (x) {
            x.children = []
          }, this);
          datacc = x.filter(x => x.context && x.parentId != 0);
          for (let i = 0; i < datac.length; i++) {
            for (let j = 0; j < datacc.length; j++) {
              if (datacc[j].parentId === datac[i].id) {
                datac[i].children.push(datacc[j])
              }
            }
          }
          for (let i = 0; i < data.length; i++) {
            for (let j = 0; j < datac.length; j++) {
              if (datac[j].parentId === data[i].id) {
                data[i].children.push(datac[j])
              }
            }
          }
          this.setState({ data });
        }), (err) => {
          console.warn(err)
        }
      }
    }), (err) => {
      console.warn(err)
    }
  }

  cancel = (e) => {

  }
  handleOkB = () => {
    if (!this.state.editcontext) {
      message.info("内容不能为空！");
      return
    }
    let context = this.state.editcontext;
    window.rpc.knowledge.setInfoById(this.state.id, { context: context }).then((x) => {
      if (x) {
        message.info("修改成功！");
        this.setState({
          context,
          editcontext: "",
          visibleB: false,
        });
      } else {
        message.error("修改失败！")
      }
    }), (err) => {
      console.warn(err)
    }
  }

  handleCancelB = () => {
    this.setState({
      editcontext: "",
      visibleB: false,
    });
  }

  logout = (e) => {
    e.preventDefault();
    if (window.rpc) {
      window.rpc.user.session.destroy().then((result) => {
        message.success('注销成功！');
        window.location.href = '/login';
      }, (err) => {
        console.warn(err)
      })
    }
  }
  //个人中心
  showModalMe = () => {
    this.setState({
      visibleMe: true,
    });
  }

  handleOkMe = (e) => {
    this.setState({
      visibleMe: false,
    });
  }

  handleCancelMe = (e) => {
    this.setState({
      visibleMe: false,
    });
  }

  //消息
  showModalMessage = () => {
    this.setState({
      Message: true,
    });
  }

  handleOkMessage = (e) => {
    this.setState({
      Message: false,
    });
  }

  handleCancelMessage = (e) => {
    this.setState({
      Message: false,
    });
  }
  render() {
    let data = this.state.data;
    let ownerSign = this.state.ownerSign;
    let ownerSignChild = [];
    ownerSign.forEach((item, index, arr) => {
      ownerSignChild.push(<Option key={index.toString()} value={index.toString()}>{item}</Option>)
    })
    document.onkeydown = (e) => {
      if (e.keyCode == 13 && this.state.visibleNew) {
        this.handleOkNew();
      }
    }
    return (
      <div style={{ padding: 0, backgroundColor: "rgb(239, 239, 239)", }} onClick={() => {
      }}>
        <div style={{ height: 50, width: '100%', backgroundColor: "#373d41" }}>
          <div className="logo" style={{ backgroundColor: "#373d41", alignItems: 'center', justifyContent: 'space-between' }}>
            <img src={logo} style={{ height: 30, width: 30, float: 'left', marginTop: 10 }} className="App-logo" alt="logo" />
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', float: "left", backgroundColor: '#373d41', borderLeft: '1px solid #333', borderBottom: 'none', textAlign: 'left' }}
            >
              <Menu.Item key="l0" style={{ width: 130 }}><Link to="/safecenter"> 安全云中心</Link></Menu.Item>
              <Menu.Item key="l1" style={{ width: 130 }}><Link to="/back"> 工作台</Link></Menu.Item>
              <Menu.Item key="l2" style={{ width: 130 }}><Link to="/apply/equip"> 应急中心</Link></Menu.Item>
              <Menu.Item key="l3" style={{ width: 130 }}><Link to="/fire"> 消防知识库</Link></Menu.Item>
              <Menu.Item key="5"><div style={{ position: "relative", width: 100, textAlign: "right" }}><Link to="/acc/newsend" className="menuR"><img src={hot} alt="" style={{ top: 18, right: 70, position: "absolute" }} />热点发布</Link></div></Menu.Item>
            </Menu>
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', backgroundColor: '#373d41', float: 'right', fontSize: 15 }}
            >

              {/* <Menu.Item key="6"><Link to="/mess/send">站内消息</Link></Menu.Item> */}
              <Menu.Item key="2"><Link to="">技术支持</Link></Menu.Item>
              <Menu.Item key="3" style={{ borderLeft: '1px solid #333' }}>
                {/* <Link to="/mess/all"><Icon type="mail" />信息</Link> */}
                <div onClick={this.showModalMessage} style={{ position: 'relative' }} >
                  <Icon type="mail" />通知 <Badge count={this.state.number} />
                  <Modal
                    className="Message"
                    visible={this.state.Message}
                    onOk={this.handleOkMessage}
                    onCancel={this.handleCancelMessage}
                    footer={null}
                    style={{ top: 50 }}
                  >
                    <div>
                      <div className="messageOne">
                        <div className="Oneone">站内消息通知</div>
                        <div className="OneThree" onClick={this.handleCancelMessage}><Link to='/mess/send' style={{ color: "#111111" }}>站内消息发送</Link></div>
                        <div className="Onetwo" onClick={this.handleCancelMessage}><Link to='/mess/manage' style={{ color: "#111111" }}>消息接受管理</Link></div>
                      </div>
                      <div className="messageTwo">
                        {this.state.messData.map((x) => (
                          <div key={x.id} className="message-Detail" onClick={() => {
                            browserHistory.push('/mess/all');
                            this.setState({
                              Message: false,
                            });
                          }} >
                            <Link to='mess/all' onClick={() => {
                              {/*browserHistory.push('')*/ }
                              this.setState({
                                Message: false,
                              });

                            }}>{x.name}</Link>
                            < br />
                            {x.createTime}
                          </div>
                        ))}
                        {this.state.messData.length === 0 ? "您暂时没有新消息！" : ""}
                      </div>
                      <div className="messageThree">
                        <Link to="/mess/all" onClick={this.handleCancelMessage}>查看更多</Link>
                      </div>
                    </div>
                  </Modal>
                </div>
              </Menu.Item>
              <Menu.Item key="4" style={{ backgroundColor: '#2a2f32' }} >
                {/* <Link to="/acc/safe">
                  <div style={{ position: 'relative' }}>
                    <Icon type="user" />
                    <span >个人</span>
                  </div>
                </Link> */}
                <div onClick={this.showModalMe} style={{ position: 'relative' }}>
                  <Icon type="user" />
                  <span >个人</span>
                  <Modal
                    visible={this.state.visibleMe}
                    onOk={this.handleOkMe}
                    onCancel={this.handleCancelMe}
                    style={{ top: 50 }}
                    className="Account"
                  >
                    <div className="basis" onClick={this.handleCancelMe}>
                      <Link to="/acc/basis">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={basis} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="basis" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ color: '#111111' }} >基本信息</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="basis" onClick={this.handleCancelMe}>
                      <Link to="/acc/real">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={real} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="real" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ marginTop: 30, color: '#111111' }}> 实名认证</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="basis" onClick={this.handleCancelMe}>
                      <Link to="/acc/safe">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={safe} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="safe" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ marginTop: 30, color: '#111111' }}> 安全设置</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="easc" onClick={this.logout}>退出管理控制台</div>
                  </Modal>
                </div>
              </Menu.Item>
            </Menu>
          </div>
        </div>
        <div style={{ height: "calc(100vh - 50px)", padding: 20, width: "100%", backgroundColor: "white" }}>
          <div style={{ float: 'left', width: 110, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>消防知识相详情</Link>
          </div>
          <div style={{ float: 'right', marginTop: "-5px" }}>
            <Link to='/fire' style={{ color: '#373e41', }}><Icon style={{ fontSize: 35 }} type="arrow-left" /></Link>

          </div>
          <br />
          <div style={{ marginTop: 20, borderTop: "1px solid rgb(203, 202, 202)", width: "100%" }}></div>
          <Row style={{ minHeight: 700, marginTop: 20 }}>
            <Col span={7} style={{ minHeight: 700, borderRight: "1px solid rgb(203, 202, 202)", marginTop: 20 }}>
              <Search
                placeholder="请搜索内容"
                style={{ width: "90%" }}
                onSearch={(value) => {
                  window.rpc.knowledge.getArrayBriefByContainer({ context: value }, 0, 0).then((res) => {
                    message.info(`共搜索到${res.length}条内容！`);
                    let fireData = res.map((x) => ({ ...x, key: x.id, ownerSignId: x.authorityId, beginTime: moment(x.beginTime || new Date('2017-01-01')).format('YYYY-MM-DD'), }));
                    this.setState({
                      displayOne: "",
                      fireData
                    });
                  })
                }}
              />
              <Row style={{ marginTop: 20, fontSize: 16, fontFamily: "苹方" }} className="FireTree">
                <Tree
                  showLine
                  onSelect={this.onSelect}
                  autoExpandParent={true}
                  defaultExpandedKeys={[`${this.state.selectedId}`]}
                  defaultSelectedKeys={[`${this.state.selectedId}`]}
                  selectedKeys={[`${this.state.selectedId}`]}
                >
                  {data.map((x) => {
                    return (
                      <TreeNode title={<div onClick={() => {
                        this.setState({
                          title: x.name,
                          context: "",
                          id: x.id,
                          beginTime: moment(x.beginTime || new Date('2017-01-01')).format('YYYY-MM-DD'),
                          ownerSignId: x.authorityId
                        });
                      }}>
                        <span style={{ marginRight: 5 }}>{x.name}</span>
                        <div style={{ height: "100%", float: "right", display: this.state.selectedId == x.id ? '' : "none" }} onClick={(e) => {
                          e.stopPropagation();
                        }}>
                          <Icon style={{ marginRight: 5 }} type="edit" onClick={this.handleClick.bind(this, "edit", x.id, x.name, )} />
                          <Popconfirm title="确定要删除?" onConfirm={this.confirm.bind(this, x.id)} onCancel={this.cancel} okText="是" cancelText="否">
                            <Icon style={{ marginRight: 5 }} type="minus-circle-o" />
                          </Popconfirm>
                          <Icon type="plus-circle-o" onClick={this.handleClick.bind(this, "new", x.id, x.parentId, 1)} />
                        </div>
                      </div>} key={x.id}>

                        {x.children ? x.children.map((res) => {
                          return (
                            <TreeNode title={<div onClick={() => {
                              this.setState({
                                title: x.name + res.name,
                                context: "",
                                id: res.id,
                                beginTime: moment(res.beginTime || new Date('2017-01-01')).format('YYYY-MM-DD'),
                                ownerSignId: res.authorityId
                              });
                            }}>
                              <span style={{ marginRight: 5 }}>{res.name}</span>
                              <div style={{ height: "100%", float: "right", display: this.state.selectedId == res.id ? '' : "none" }} onClick={(e) => {
                                e.stopPropagation();
                              }}>
                                <Icon style={{ marginRight: 5 }} type="edit" onClick={this.handleClick.bind(this, "edit", res.id, res.name)} />
                                <Popconfirm title="确定要删除?" onConfirm={this.confirm.bind(this, res.id)} onCancel={this.cancel} okText="是" cancelText="否">
                                  <Icon style={{ marginRight: 5 }} type="minus-circle-o" />
                                </Popconfirm>
                                <Icon type="plus-circle-o" onClick={this.handleClick.bind(this, "new", res.id, res.parentId, 2)} />
                              </div>
                            </div>} key={res.id}>

                              {res.children ? res.children.map((data) => {
                                return (
                                  <TreeNode key={data.id} title={<div onClick={() => {
                                    this.setState({
                                      title: data.name,
                                      context: data.context,
                                      id: data.id,
                                      beginTime: moment(data.beginTime || new Date('2017-01-01')).format('YYYY-MM-DD'),
                                      ownerSignId: data.authorityId
                                    });
                                  }}>
                                    <span style={{ marginRight: 5 }}>{data.name}</span>
                                    <div style={{ height: "100%", float: "right", display: this.state.selectedId == data.id ? '' : "none" }} onClick={(e) => {
                                      e.stopPropagation();
                                    }} >
                                      <Icon style={{ marginRight: 5 }} type="edit" onClick={this.handleClick.bind(this, "edit", data.id, data.name)} />
                                      <Popconfirm title="确定要删除?" onConfirm={this.confirm.bind(this, data.id)} onCancel={this.cancel} okText="是" cancelText="否">
                                        <Icon style={{ marginRight: 5 }} type="minus-circle-o" />
                                      </Popconfirm>
                                      <Icon type="plus-circle-o" onClick={this.handleClick.bind(this, "new", data.id, data.parentId, 3)} />
                                    </div>
                                  </div>} />
                                )

                              }) : ""}
                            </TreeNode>
                          )
                        }) : ""}
                      </TreeNode>
                    )
                  })}
                </Tree>
              </Row>
            </Col>
            <Modal
              title="名称编辑"
              visible={this.state.visible}
              onOk={this.handleOk}
              onCancel={this.handleCancel}
            >
              <div style={{ paddingLeft: "16%", marginTop: 70 }}>
                <span style={{ float: "left", marginRight: 5, marginTop: 5 }}>名称 ： </span>
                <Input
                  placeholder="请编辑名称！"
                  style={{ width: '60%', float: 'left' }}
                  value={this.state.name}
                  onChange={(e) => {
                    this.setState({ name: e.target.value });
                  }}
                />
              </div>
            </Modal>
            <Modal
              title="新增"
              visible={this.state.visibleNew}
              onOk={this.handleOkNew}
              onCancel={this.handleCancelNew}
            >
              <div style={{ paddingLeft: "16%", marginTop: 30 }}>
                <span style={{ float: "left", marginRight: 5, marginTop: 5 }}>名称 ： </span>
                <Input
                  placeholder="请输入名称！"
                  style={{ width: '60%', float: 'left' }}
                  value={this.state.newname}
                  onChange={(e) => {
                    this.setState({ newname: e.target.value });
                  }}
                /><br /><br />
                <div style={{ marginLeft: "-20px", display: this.state.parentPId === 1 ? "" : "none" }}>
                  <div style={{ float: "left", lineHeight: "25px" }}>颁发时间：</div>
                  <DatePicker
                    value={this.state.dateBook}
                    onChange={(dateBook) => {
                      this.setState({ dateBook });
                    }}
                    style={{ marginLeft: 5 }}
                  />
                </div>
                <div style={{ marginLeft: "-20px", marginTop: 10 }}>
                  <div style={{ float: "left", lineHeight: "25px" }}>颁发机构：</div>
                  <Select
                    notFoundContent="暂无机构选择！"
                    defaultValue="请选择机构！"
                    style={{ width: 250, marginLeft: 5, }}
                    dropdownMatchSelectWidth={false}
                    dropdownStyle={{ width: 350, overflowX: "auto" }}
                    value={this.state.ownerSignIdBook.toString()}
                    onChange={(value) => {
                      this.setState({ ownerSignIdBook: parseInt(value, 10) });
                    }}>
                    {ownerSignChild}
                  </Select>
                </div>
              </div>
            </Modal>
            <Col span={17} style={{ padding: 20, }}>
              <Row style={{ display: this.state.displayOne === "none" ? "" : "none" }}>
                <Button onClick={() => {
                  let context = this.state.context;
                  if (!context) {
                    message.info("仅支持编辑每条法规的具体内容！")
                  } else {
                    this.setState({
                      editcontext: context,
                      visibleB: true
                    });
                  }
                }}>编辑内容</Button>
              </Row>
              <Row style={{ marginTop: 20, display: this.state.displayOne === "none" ? "" : "none" }}>
                <span style={{ fontWeight: "bold" }}>{this.state.title}</span>
                <span style={{ marginLeft: 15 }}> {this.state.context}</span>
                <Row style={{ marginTop: 30, display: this.state.title ? "" : "none" }}>
                  <span>颁发机构： {this.state.ownerSign[this.state.ownerSignId]} &nbsp;&nbsp;&nbsp;，</span>
                  <span style={{ marginLeft: 10 }}>颁发时间： {this.state.beginTime}</span>
                </Row>
                <Modal
                  visible={this.state.visibleB}
                  onOk={this.handleOkB}
                  onCancel={this.handleCancelB}
                >
                  <div style={{ paddingLeft: "6%", marginTop: 50 }}>
                    <span style={{ float: "left", marginRight: 5, marginTop: 5 }}>内容 ： </span>
                    <Input
                      autosize
                      placeholder="请输入名称！"
                      style={{ width: "80%", borderRadius: 0, minHeight: 100, maxHeight: 220 }}
                      type="textarea"
                      value={this.state.editcontext}
                      onChange={(e) => {
                        this.setState({
                          editcontext: e.target.value
                        });
                      }} />
                  </div>
                </Modal>
              </Row>
              <div style={{ marginTop: 20, display: this.state.displayOne }}>
                {this.state.fireData.map((x) => {
                  return (
                    <div key={x.id} style={{ marginTop: 35 }}>
                      <span style={{ fontWeight: "bold" }}>{x.name}</span>
                      <span style={{ marginLeft: 15 }}> {x.context}</span>
                      <div style={{ marginTop: 20 }}>
                        <span>颁发机构： {this.state.ownerSign[x.ownerSignId] || ""} &nbsp;&nbsp;&nbsp;，</span>
                        <span style={{ marginLeft: 10 }}>颁发时间： {x.beginTime}</span>
                      </div>
                      <hr style={{ marginTop: 10 }} />
                    </div>
                  )
                })}
              </div>
            </Col>
          </Row>
        </div>

      </div >

    );
  }
}

export default FireDetail;