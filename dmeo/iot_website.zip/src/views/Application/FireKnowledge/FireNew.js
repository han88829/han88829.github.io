/*
 * @Author: Han.beibei 
 * @Date: 2017-07-18 14:29:31 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-08 15:14:57
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { Card, Row, Input, message, Modal, Select, Col, Menu, Icon, Badge, DatePicker } from 'antd';
import { observer } from 'mobx-react';
import '../../Account/NewSend.css';
import moment from 'moment';

import logo from '../../../assets/logo.png';
import hot from '../../../assets/images/back/hot.png';
import safe from '../../../assets/images/account/safe.png';
import basis from '../../../assets/images/account/basis.png';
import real from '../../../assets/images/account/real.png';

const Option = Select.Option;

const NewSendC = observer(class NewSendC extends Component {

  state = {
    title: '',
    context: "",
    visibleBook: false,
    visibleZ: false,
    visibleO: false,
    Book: [],
    ChapterChild: [],
    BookId: 0,
    ChapterId: 0,
    BookName: "",
    ChapterName: "",
    messData: [],
    visible: false,
    Message: false,
    ownerSign: [],
    ownerSignId: 0,
    ownerSignName: "",
    date: null,
    dateBook: null,
    ownerSignIdZ: 109
  }

  componentDidMount() {
    window.rpc.knowledge.getArray(0, 0).then((x) => {
      let Book = []
      let res = x.filter(data => data.parentId === 0)
      for (let data of res) {
        Book[data.id] = data.name
      }
      this.setState({ Book });
    })
    window.rpc.knowledge.authority.getArray(0, 0).then((x) => {
      let ownerSign = [];
      x.forEach(function (res) {
        ownerSign[res.id] = res.name;
      }, this);
      this.setState({ ownerSign });
    }), (err) => {
      console.warn(err)
    }
  }

  componentWillReceiveProps(nextProps) {
    // 消息
    window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then((result) => {
      let data = result.map((x) => ({ ...x, key: x.id, name: x.name, createTime: moment(x.createTime || new Date('2017-01-01 8:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
      this.setState({ messData: data, number: result.length });
    }), (err) => {
      console.warn(err)
    }
    this.setState({
      collapsed: true
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  handleSubmit = () => {
    let { title, context, ChapterId, BookId, ownerSignId } = this.state;

    if (!title || !context || !ChapterId || !BookId || !ownerSignId) {
      message.info("内容不能为空，请输入内容！");
      return
    }

    window.rpc.knowledge.create({ name: title, authorityId: parseInt(ownerSignId, 10), context: context, type: 256, parentId: ChapterId }).then((x) => {
      if (x) {
        message.info("创建成功！")
        browserHistory.push('/fire');
      } else {
        message.info("创建失败！");
      }
    }), (err) => {
      console.warn(err)
    }
  }

  handleOkB = (e) => {
    let { BookName, ownerSignIdBook, dateBook } = this.state;
    if (!BookName) {
      message.info("书名不能为空！");
      return
    }
    if (!ownerSignIdBook) {
      message.info("颁发机构不能为空！");
      return
    }
    if (!dateBook) {
      message.info("颁发时间不能为空！");
      return
    }
    window.rpc.knowledge.create({ name: BookName, beginTime: new Date(dateBook.format('YYYY-MM-DD')), authorityId: ownerSignIdBook, parentId: 0 }).then((x) => {
      if (x) {
        message.info("添加成功！");
        window.rpc.knowledge.getArrayBriefByContainer({ parentId: this.state.BookId }, 0, 0).then((x) => {
          let Book = []
          let res = x.filter(data => data.parentId === 0)
          for (let data of res) {
            Book[data.id] = data.name
          }
          this.setState({ Book, visibleB: false, });
        }), (err) => {
          console.warn(err)
        }
      } else {
        message.info("添加失败！");
      }
    }), (err) => {
      console.warn(err)
    }
  }

  handleCancelB = (e) => {
    this.setState({
      visibleB: false,
    });
  }

  handleOkZ = (e) => {
    let ChapterName = this.state.ChapterName;
    let ownerSignIdZ = this.state.ownerSignIdZ;
    if (!ChapterName) {
      message.info("名称不能为空！");
      return
    }
    console.log(ownerSignIdZ)
    if (!ownerSignIdZ) {
      message.info("颁发机构不能为空！");
      return
    }

    window.rpc.knowledge.create({ name: ChapterName, authorityId: ownerSignIdZ, parentId: this.state.BookId }).then((x) => {
      if (x) {
        message.info("添加成功！");
        window.rpc.knowledge.getArrayBriefByContainer({ parentId: this.state.BookId }, 0, 0).then((x) => {
          let ChapterChild = [];
          x.forEach((item, index, arr) => {
            ChapterChild.push(<Option key={item.id.toString()} value={item.id.toString()}>{item.name}</Option>)
          })
          this.setState({ visibleZ: false, ChapterChild });

        }), (err) => {
          console.warn(err)
        }
      } else {
        message.info("添加失败！");
      }
    }), (err) => {
      console.warn(err)
    }
  }

  handleCancelZ = (e) => {
    this.setState({
      visibleZ: false,
    });
  }

  //个人中心
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOk = (e) => {
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  //消息
  showModalMessage = () => {
    this.setState({
      Message: true,
    });
  }

  handleOkMessage = (e) => {
    this.setState({
      Message: false,
    });
  }

  handleCancelMessage = (e) => {
    this.setState({
      Message: false,
    });
  }
  // 颁发机构
  handleOkO = (e) => {

    if (!this.state.ownerSignName) {
      message.info("机构名称不能为空！")
      return
    }
    window.rpc.knowledge.authority.create({ name: this.state.ownerSignName }).then((result) => {
      if (result) {
        message.info("创建成功!");
        window.rpc.knowledge.authority.getArray(0, 0).then((x) => {
          let ownerSign = [];
          x.forEach(function (res) {
            ownerSign[res.id] = res.name;
          }, this);
          this.setState({ ownerSign, visibleO: false, });
        }), (error) => {
          console.warn(error)
        }
      } else {
        message.info("创建失败！")
      }
    }), (err) => {
      console.warn(err)
    }
  }

  handleCancelO = (e) => {
    this.setState({
      visibleO: false,
    });
  }
  logout(e) {
    e.preventDefault();
    if (window.rpc) {
      window.rpc.user.session.destroy().then((result) => {
        message.success('注销成功！');
        window.location.href = '/login';
      }, (err) => {
        console.warn(err)
      })
    };
  }
  onChangeTime = (date, dateString) => {
    this.setState({ date });
  }
  render() {
    let { Book, ownerSign } = this.state;
    let BookChild = [], ownerSignChild = [];
    Book.forEach((item, index, arr) => {
      BookChild.push(<Option key={index.toString()} value={index.toString()}>{item}</Option>)
    })
    ownerSign.forEach((item, index, arr) => {
      ownerSignChild.push(<Option key={index.toString()} value={index.toString()}>{item}</Option>)
    })
    return (
      <div className="NewSend" style={{}}>
        <div style={{ height: 50, width: '100%', backgroundColor: "#373d41" }}>
          <div className="logo" style={{ backgroundColor: "#373d41", alignItems: 'center', justifyContent: 'space-between' }}>
            <img src={logo} style={{ height: 30, width: 30, float: 'left', marginTop: 10 }} className="App-logo" alt="logo" />
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', float: "left", backgroundColor: '#373d41', borderLeft: '1px solid #333', borderBottom: 'none', textAlign: 'left' }}
            >
              <Menu.Item key="l0" style={{ width: 130 }}><Link to="/safecenter"> 安全云中心</Link></Menu.Item>
              <Menu.Item key="l1" style={{ width: 130 }}><Link to="/back"> 工作台</Link></Menu.Item>
              <Menu.Item key="l2" style={{ width: 130 }}><Link to="/apply/equip"> 应急中心</Link></Menu.Item>
              <Menu.Item key="l3" style={{ width: 130 }}><Link to="/fire"> 消防知识库</Link></Menu.Item>
              <Menu.Item key="5"><div style={{ position: "relative", width: 100, textAlign: "right" }}><Link to="/acc/newsend" className="menuR"><img src={hot} alt="" style={{ top: 18, right: 70, position: "absolute" }} />热点发布</Link></div></Menu.Item>
            </Menu>
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', backgroundColor: '#373d41', float: 'right', fontSize: 15 }}
            >

              {/* <Menu.Item key="6"><Link to="/mess/send">站内消息</Link></Menu.Item> */}
              <Menu.Item key="2"><Link to="">技术支持</Link></Menu.Item>
              <Menu.Item key="3" style={{ borderLeft: '1px solid #333' }}>
                {/* <Link to="/mess/all"><Icon type="mail" />信息</Link> */}
                <div onClick={this.showModalMessage} style={{ position: 'relative' }} >
                  <Icon type="mail" />通知 <Badge count={this.state.number} />
                  <Modal
                    className="Message"
                    visible={this.state.Message}
                    onOk={this.handleOkMessage}
                    onCancel={this.handleCancelMessage}
                    footer={null}
                    style={{ top: 50 }}
                  >
                    <div>
                      <div className="messageOne">
                        <div className="Oneone">站内消息通知</div>
                        <div className="OneThree" onClick={this.handleCancelMessage}><Link to='/mess/send' style={{ color: "#111111" }}>站内消息发送</Link></div>
                        <div className="Onetwo" onClick={this.handleCancelMessage}><Link to='/mess/manage' style={{ color: "#111111" }}>消息接受管理</Link></div>
                      </div>
                      <div className="messageTwo">
                        {this.state.messData.map((x) => (
                          <div key={x.id} className="message-Detail" onClick={() => {
                            browserHistory.push('/mess/all');
                            this.setState({
                              Message: false,
                            });
                          }} >
                            <Link to='mess/all' onClick={() => {
                              {/*browserHistory.push('')*/ }
                              this.setState({
                                Message: false,
                              });

                            }}>{x.name}</Link>
                            < br />
                            {x.createTime}
                          </div>
                        ))}
                        {this.state.messData.length === 0 ? "您暂时没有新消息！" : ""}
                      </div>
                      <div className="messageThree">
                        <Link to="/mess/all" onClick={this.handleCancelMessage}>查看更多</Link>
                      </div>
                    </div>
                  </Modal>
                </div>
              </Menu.Item>
              <Menu.Item key="4" style={{ backgroundColor: '#2a2f32' }} >
                {/* <Link to="/acc/safe">
                  <div style={{ position: 'relative' }}>
                    <Icon type="user" />
                    <span >个人</span>
                  </div>
                </Link> */}
                <div onClick={this.showModal} style={{ position: 'relative' }}>
                  <Icon type="user" />
                  <span >个人</span>
                  <Modal
                    visible={this.state.visible}
                    onOk={this.handleOk} onCancel={this.handleCancel}
                    style={{ top: 50 }}
                    className="Account"
                  >
                    <div className="basis" onClick={this.handleCancel}>
                      <Link to="/acc/basis">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={basis} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="basis" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ color: '#111111' }} >基本信息</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="basis" onClick={this.handleCancel}>
                      <Link to="/acc/real">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={real} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="real" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ marginTop: 30, color: '#111111' }}> 实名认证</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="basis" onClick={this.handleCancel}>
                      <Link to="/acc/safe">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={safe} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="safe" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ marginTop: 30, color: '#111111' }}> 安全设置</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="easc" onClick={this.logout}>退出管理控制台</div>
                  </Modal>
                </div>
              </Menu.Item>
            </Menu>
          </div>
        </div>
        <div style={{ height: "calc(100vh - 50px)", padding: 20, width: "100%", backgroundColor: "white" }}>
          <div style={{ float: 'left', width: 100, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
            <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75em', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>消防知识新增</Link>
          </div> <br />
          <div style={{ marginTop: 20, borderTop: "1px solid rgb(203, 202, 202)", width: "100%" }}></div>
          <Card style={{ marginTop: 20, paddingBottom: 18 }}>
            <Row>
              <Col span={6}>
                <label htmlFor="Select">书名：</label>
                <Select
                  id="Select"
                  labelInValue
                  defaultValue={{ key: "0", label: "请选择书名！" }}
                  style={{ width: 180, marginLeft: "8%", }}
                  dropdownMatchSelectWidth={false}
                  dropdownStyle={{ width: 300, overflowX: "auto" }}
                  onChange={(value) => {
                    window.rpc.knowledge.getArrayBriefByContainer({ parentId: parseInt(value.key, 10) }, 0, 0).then((x) => {
                      let ChapterChild = [];
                      x.forEach((item, index, arr) => {
                        ChapterChild.push(<Option key={item.id.toString()} value={item.id.toString()}>{item.name}</Option>)
                      })
                      this.setState({ BookId: parseInt(value.key, 10), ChapterChild });
                    }), (err) => {
                      console.warn(err)
                    }
                  }}>
                  {BookChild}
                </Select>
                <span onClick={() => { this.setState({ visibleB: true }); }} style={{ cursor: "pointer", marginLeft: 10, fontSize: 12, color: "#be161e", fontFamily: "SimSun", textDecoration: "underline" }}>新增书名</span>
              </Col>

              <Col span={6}>
                <label htmlFor="Select">章节：</label>
                <Select
                  id="Select"
                  notFoundContent="暂无章节！"
                  labelInValue
                  defaultValue={{ key: "0", label: "请选择章节！" }}
                  style={{ width: 120, marginLeft: "4%", }}
                  dropdownMatchSelectWidth={false}
                  dropdownStyle={{ width: 200, overflowX: "auto" }}
                  onChange={(value) => {
                    this.setState({ ChapterId: parseInt(value.key, 10) });
                  }}>
                  {this.state.ChapterChild}
                </Select>
                <span onClick={() => { if (this.state.BookId) { this.setState({ visibleZ: true }); } else { message.info("请选择书名！") } }} style={{ cursor: "pointer", marginLeft: 10, fontSize: 12, color: "#be161e", fontFamily: "SimSun", textDecoration: "underline" }}>新增章节</span>
              </Col>

              <Col span={6}>
                <label htmlFor="Select">颁发机构：</label>
                <Select
                  id="Select"
                  notFoundContent="暂无机构选择！"
                  labelInValue defaultValue={{ key: "0", label: "请选择机构！" }}
                  style={{ width: 150, marginLeft: "4%", }}
                  dropdownMatchSelectWidth={false}
                  dropdownStyle={{ width: 350, overflowX: "auto" }}
                  onChange={(value) => {
                    this.setState({ ownerSignId: parseInt(value.key, 10) });
                  }}>
                  {ownerSignChild}
                </Select>
                <span onClick={() => { this.setState({ visibleO: true }); }} style={{ cursor: "pointer", marginLeft: 10, fontSize: 12, color: "#be161e", fontFamily: "SimSun", textDecoration: "underline" }}>新增颁发机构</span>
              </Col>

              {/* <Col span={6}>
                <label htmlFor="Select">颁发时间：</label>
                <DatePicker
                  id="Select"
                  onChange={this.onChangeTime}
                />
              </Col> */}

              {/* 书 */}
              <Modal
                visible={this.state.visibleB}
                onOk={this.handleOkB}
                onCancel={this.handleCancelB}
              >
                <div style={{ paddingLeft: "16%", marginTop: 70 }}>
                  <span style={{ float: "left", marginRight: 5, marginTop: 5 }}>名称 ： </span>
                  <Input
                    placeholder="请输入名称！"
                    style={{ width: 250, float: 'left' }}
                    value={this.state.BookName}
                    onChange={(e) => {
                      this.setState({ BookName: e.target.value });
                    }}
                  /><br /><br />
                  <div style={{ marginLeft: "-20px" }}>
                    <div style={{ float: "left", lineHeight: "25px" }}>颁发时间：</div>
                    <DatePicker
                      onChange={(dateBook) => {
                        this.setState({ dateBook });
                      }}
                      style={{ marginLeft: 5 }}
                    />
                  </div>
                  <div style={{ marginLeft: "-20px", marginTop: 10 }}>
                    <div style={{ float: "left", lineHeight: "25px" }}>颁发机构：</div>
                    <Select
                      notFoundContent="暂无机构选择！"
                      labelInValue
                      defaultValue={{ key: "0", label: "请选择机构！" }}
                      style={{ width: 250, marginLeft: 5, }}
                      dropdownMatchSelectWidth={false}
                      dropdownStyle={{ width: 350, overflowX: "auto" }}
                      onChange={(value) => {
                        this.setState({ ownerSignIdBook: parseInt(value.key, 10) });
                      }}>
                      {ownerSignChild}
                    </Select>
                  </div>
                </div>
              </Modal>
              {/* 章节 */}
              <Modal
                visible={this.state.visibleZ}
                onOk={this.handleOkZ}
                onCancel={this.handleCancelZ}
              >
                <div style={{ paddingLeft: "16%", marginTop: 70 }}>
                  <span style={{ float: "left", marginRight: 5, marginTop: 5 }}>名称 ： </span>
                  <Input
                    placeholder="请输入名称！"
                    style={{ width: '60%', float: 'left' }}
                    value={this.state.ChapterName}
                    onChange={(e) => {
                      this.setState({ ChapterName: e.target.value });
                    }}
                  /><br /><br />
                  <div style={{ marginLeft: "-20px" }}>
                    <div style={{ float: "left", lineHeight: "25px" }}>颁发机构：</div>
                    <Select
                      notFoundContent="暂无机构选择！"
                      defaultValue="请选择机构！"
                      style={{ width: 250, marginLeft: 5, }}
                      dropdownMatchSelectWidth={false}
                      dropdownStyle={{ width: 350, overflowX: "auto" }}
                      onChange={(value) => {
                        this.setState({ ownerSignIdZ: parseInt(value, 10) });
                      }}>
                      {ownerSignChild}
                    </Select>
                  </div>
                </div>
              </Modal>
              {/* 机构 */}
              <Modal
                visible={this.state.visibleO}
                onOk={this.handleOkO}
                onCancel={this.handleCancelO}
              >
                <div style={{ paddingLeft: "16%", marginTop: 70 }}>
                  <span style={{ float: "left", marginRight: 5, marginTop: 5 }}>名称 ： </span>
                  <Input
                    placeholder="请输入名称！"
                    style={{ width: '60%', float: 'left' }}
                    value={this.state.ownerSignName}
                    onChange={(e) => {
                      this.setState({ ownerSignName: e.target.value });
                    }}
                  />
                </div>
              </Modal>
            </Row>
            <Row style={{ marginTop: 10 }}>
              <div style={{ float: "left", width: "4%", textAlign: "left", paddingTop: 5 }}>名称：</div>
              <Input style={{ width: "96%", borderRadius: 0 }} onChange={(e) => {
                this.setState({
                  title: e.target.value
                });
              }} />
            </Row>
            <Row style={{ marginTop: 15 }}>
              <div style={{ float: "left", width: "4%", textAlign: "left", paddingTop: 5 }}>正文：</div>
              <Input autosize style={{ width: "96%", borderRadius: 0, minHeight: 200 }} type="textarea" onChange={(e) => {
                this.setState({
                  context: e.target.value
                });
              }} />
            </Row>
            <div style={{ width: "100vw", borderTop: "1px solid #e6b85c", marginTop: 50, marginLeft: "-50px" }}></div>
            <Row style={{ marginTop: 10, position: "absolute", right: 10, width: 220 }}>
              <div style={{ float: "right", width: 50, height: 28, marginTop: "-3px", textAlign: "center", lineHeight: "25px", cursor: "pointer", marginLeft: 15, backgroundColor: "#e6b85c", color: "white", border: "1px solid d6a647" }} onClick={this.handleSubmit}>发布</div>
              <div style={{ float: "right", width: 50, height: 28, marginTop: "-3px", textAlign: "center", lineHeight: "25px", cursor: "pointer", marginLeft: 15, backgroundColor: "rgb(183, 180, 177)", color: "white", border: "1px solid d6a647" }} onClick={() => {
                browserHistory.push('/fire');
              }}>取消</div>
            </Row>
          </Card>
        </div>

      </div >
    );
  }
})

class FireNew extends Component {
  render() {
    return (
      <NewSendC />
    );
  }
}

export default FireNew;