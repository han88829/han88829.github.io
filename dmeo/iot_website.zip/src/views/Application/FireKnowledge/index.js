/*
 * @Author: Han.beibei 
 * @Date: 2017-07-18 14:02:10 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-08-08 10:34:27
 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
import { Row, Col, Table, Button, Popconfirm, Form, Icon, Menu, Modal, Input, DatePicker, Select, message, Badge } from 'antd';
import moment from 'moment';

import logo from '../../../assets/logo.png';
import hot from '../../../assets/images/back/hot.png';
import safe from '../../../assets/images/account/safe.png';
import basis from '../../../assets/images/account/basis.png';
import real from '../../../assets/images/account/real.png';

const { RangePicker } = DatePicker;
const { Option } = Select;
const SubMenu = Menu.SubMenu;
const FormItem = Form.Item;

// 设置message消息
message.config({
  top: 216,
  duration: 2
})


// 初始化mobx设置
class appState {
  constructor() {
    extendObservable(this, {
      tableData: [],
      selectId: null,
      selectIdOne: null
    })
  }
}

class AdvancedSearchForm extends React.Component {
  handleSearch = (e) => {
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const name = fieldsValue['name'];
        let values = {};
        if (name) {
          values = { ...values, name };
        }
        let ownerSignId = [];
        window.rpc.knowledge.authority.getArray(0, 0).then((x) => {
          x.forEach(function (data) {
            ownerSignId[data.id] = data.name;
          }, this);
        }), (err) => {
          console.warn(err)
        }
        window.rpc.knowledge.getArrayByContainer(values, 0, 0).then((result) => {
          message.info(`共搜索到${result.filter(res => res.parentId === 0).length}条数据`);
          let users = result.filter(res => res.parentId === 0).map((x) => ({ ...x, authorityId: ownerSignId[x.authorityId] || "/", name: x.name || "", context: x.context && x.context.length > 30 ? x.context.substring(0, 30) + "..." : x.context, number: x.number || "", key: x.id, beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
          this.props.appState.tableData = users;
        }, (err) => {
          console.warn(err);
        })
      });
    } catch (e) {
      console.warn(e);
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0 }}>
        <Row>
          <Col span={3} key={1}>
            <FormItem label={`名称`}>
              {getFieldDecorator(`name`)(
                <Input style={{ width: 120 }} placeholder="请输入名称" />
              )}
            </FormItem>
          </Col>
          <Col span={1} key={7}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                icon="search"
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}

const WrappedAdvancedSearchForm = Form.create()(AdvancedSearchForm);


const StaffC = observer(class StaffC extends Component {
  componentDidMount() {
    let ownerSignId = [];
    window.rpc.knowledge.authority.getArray(0, 0).then((x) => {
      x.forEach(function (data) {
        ownerSignId[data.id] = data.name;
      }, this);
    }), (err) => {
      console.warn(err)
    }
    window.rpc.knowledge.getArray(0, 0).then((result) => {
      let users = result.filter(res => res.parentId === 0).map((x) => ({ ...x, authorityId: ownerSignId[x.authorityId] || "/", beginTime: moment(x.beginTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), name: x.name || "", context: x.context && x.context.length > 30 ? x.context.substring(0, 30) + "..." : x.context, number: x.number || "", key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
      this.props.appState.tableData = users;
    }, (err) => {
      console.warn(err);
    })
  }
  componentWillReceiveProps(nextProps) {
    // 消息
    window.rpc.message.receive.getArrayByContainer({ state: 1024 }, 0, 0).then((result) => {
      let data = result.map((x) => ({ ...x, key: x.id, name: x.name, createTime: moment(x.createTime || new Date('2017-01-01 8:00:00')).format('YYYY-MM-DD HH:mm:ss'), }))
      this.setState({ messData: data, number: result.length });
    }), (err) => {
      console.warn(err)
    }
    this.setState({
      collapsed: true
    })
  }
  handleSearch = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    });
  }

  //排序
  state = {
    filteredInfo: null,
    sortedInfo: null,
    messData: [],
    visible: false,
    Message: false,
  };
  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  }
  clearFilters = () => {
    this.setState({ filteredInfo: null });
  }
  clearAll = () => {
    this.setState({
      filteredInfo: null,
      sortedInfo: null,
    });
  }
  setAgeSort = () => {
    this.setState({
      sortedInfo: {
        order: 'descend',
        columnKey: 'age',
      },
    });
  }

  handleStaff = () => {
    if (this.props.appState.selectId != null) {
      browserHistory.push(`/fire/edit/${this.props.appState.selectId}`);
    } else {
      message.info('请选择消防知识！');
    }

  }
  //人员详情跳转
  handleStaffOne = () => {
    if (this.props.appState.selectId != null) {
      browserHistory.push(`/fire/detail/${this.props.appState.selectId}`);
    } else {
      browserHistory.push(`/fire/detail/1`);
    }

  }
  handleDelet = (id) => {

  }

  //个人中心
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleOk = (e) => {
    // //console.log(e);
    this.setState({
      visible: false,
    });
  }

  handleCancel = (e) => {
    // //console.log(e);
    this.setState({
      visible: false,
    });
  }

  //消息
  showModalMessage = () => {
    this.setState({
      Message: true,
    });
  }

  handleOkMessage = (e) => {
    // //console.log(e);
    this.setState({
      Message: false,
    });
  }

  handleCancelMessage = (e) => {
    // //console.log(e);
    this.setState({
      Message: false,
    });
  }
  logout(e) {
    e.preventDefault();
    if (window.rpc) {
      window.rpc.user.session.destroy().then((result) => {
        message.success('注销成功！');
        window.location.href = '/login';
      }, (err) => {
        console.warn(err)
      })
    };
  }

  confirm(id) {
    window.rpc.knowledge.removeById(id).then((result) => {
      if (result) {
        message.info("删除成功！");
        window.rpc.knowledge.getArray(0, 0).then((result) => {
          let users = result.filter(res => res.parentId === 0).map((x) => ({ ...x, name: x.name || "", context: x.context && x.context.length > 30 ? x.context.substring(0, 30) + "..." : x.context, number: x.number || "", key: x.id, createTime: moment(x.createTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss'), lastTime: moment(x.lastTime || new Date('2017-01-01 08:00:00')).format('YYYY-MM-DD HH:mm:ss') }))
          this.props.appState.tableData = users;
        }, (err) => {
          console.warn(err);
        })
      } else {
        message.info("删除失败！");
      }
    }, (err) => {
      console.warn(err);
    })
  }

  cancel(e) {
    message.error('Click on No');
  }

  render() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    const columns = [{
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      sorter: (a, b) => a.id - b.id,
      sortOrder: sortedInfo.columnKey === 'id' && sortedInfo.order,
      render: text => <span>{text}</span>,
    }, {
      title: '法规名称',
      dataIndex: 'name',
      key: 'name'
    },
    { title: '颁发机构', dataIndex: 'authorityId', key: 'authorityId' },
    { title: '发布时间', dataIndex: 'beginTime', key: 'createTime' },
    { title: '修改时间', dataIndex: 'lastTime', key: 'lastTime' },
    {
      title: '操作', dataIndex: '', key: 'x', render: (text, record) => (
        <span>
          <Link to={`/fire/detail/${record.id}`}>详情</Link>
          <span className="ant-divider" />
          <Popconfirm title="确定要删除?" onConfirm={this.confirm.bind(this, record.id)} onCancel={this.cancel} okText="确定" cancelText="取消">
            <a href="#">删除</a>
          </Popconfirm>
          {/* <Link to='' onClick={this.confirm.bind(this, record.id)}>删除</Link> */}
        </span>
      )
    },
    ];

    const data = [...this.props.appState.tableData];

    const pagination = {
      total: this.props.appState.tableData.length,
      showTotal: total => `共 ${total} 条`,
      showSizeChanger: true,
      showQuickJumper: true,
      onShowSizeChange: (current, pageSize) => {
      },
      onChange: (current) => {
      },
    };

    //表格单选框设置
    const rowSelection = {
      type: 'radio',
      onChange: (selectedRowKeys, selectedRows) => {
      },
      onSelect: (record, selected, selectedRows) => {
        this.props.appState.selectId = record.id;
        this.props.appState.selectIdOne = record.id;
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };

    return (

      <div className="ConcenHistory" style={{ padding: 0, backgroundColor: "rgb(239, 239, 239)", height: "100vh" }}>
        <div style={{ height: 50, width: '100%', backgroundColor: "#373d41" }}>
          <div className="logo" style={{ backgroundColor: "#373d41", alignItems: 'center', justifyContent: 'space-between' }}>
            <img src={logo} style={{ height: 32, lineHeight: '24px', borderRadius: "6px", float: 'left', margin: 9 }} className="App-logo" alt="logo" />
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', float: "left", backgroundColor: '#373d41', borderLeft: '1px solid #333', borderBottom: 'none', textAlign: 'left' }}
            >
              <Menu.Item key="l0" style={{ width: 130 }}><Link to="/safecenter"> 安全云中心</Link></Menu.Item>
              <Menu.Item key="l1" style={{ width: 130 }}><Link to="/back"> 工作台</Link></Menu.Item>
              <Menu.Item key="l2" style={{ width: 130 }}><Link to="/apply/equip"> 应急中心</Link></Menu.Item>
              <Menu.Item key="l3" style={{ width: 130 }}><Link to="/fire"> 消防知识库</Link></Menu.Item>
              <Menu.Item key="5"><div style={{ position: "relative", width: 100, textAlign: "right" }}><Link to="/acc/newsend" className="menuR"><img src={hot} alt="" style={{ top: 18, right: 70, position: "absolute" }} />热点发布</Link></div></Menu.Item>
            </Menu>
            <Menu
              theme="dark"
              mode="horizontal"
              style={{ lineHeight: '50px', backgroundColor: '#373d41', float: 'right', fontSize: 15 }}
            >

              {/* <Menu.Item key="6"><Link to="/mess/send">站内消息</Link></Menu.Item> */}
              <Menu.Item key="2"><Link to="">技术支持</Link></Menu.Item>
              <Menu.Item key="3" style={{ borderLeft: '1px solid #333' }}>
                {/* <Link to="/mess/all"><Icon type="mail" />信息</Link> */}
                <div onClick={this.showModalMessage} style={{ position: 'relative' }} >
                  <Icon type="mail" />通知 <Badge count={this.state.number} />
                  <Modal
                    className="Message"
                    visible={this.state.Message}
                    onOk={this.handleOkMessage}
                    onCancel={this.handleCancelMessage}
                    footer={null}
                    style={{ top: 50 }}
                  >
                    <div>
                      <div className="messageOne">
                        <div className="Oneone">站内消息通知</div>
                        <div className="OneThree" onClick={this.handleCancelMessage}><Link to='/mess/send' style={{ color: "#111111" }}>站内消息发送</Link></div>
                        <div className="Onetwo" onClick={this.handleCancelMessage}><Link to='/mess/manage' style={{ color: "#111111" }}>消息接受管理</Link></div>
                      </div>
                      <div className="messageTwo">
                        {this.state.messData.map((x) => (
                          <div key={x.id} className="message-Detail" onClick={() => {
                            browserHistory.push('/mess/all');
                            this.setState({
                              Message: false,
                            });
                          }} >
                            <Link to='mess/all' onClick={() => {
                              {/*browserHistory.push('')*/ }
                              this.setState({
                                Message: false,
                              });

                            }}>{x.name}</Link>
                            < br />
                            {x.createTime}
                          </div>
                        ))}
                        {this.state.messData.length === 0 ? "您暂时没有新消息！" : ""}
                      </div>
                      <div className="messageThree">
                        <Link to="/mess/all" onClick={this.handleCancelMessage}>查看更多</Link>
                      </div>
                    </div>
                  </Modal>
                </div>
              </Menu.Item>
              <Menu.Item key="4" style={{ backgroundColor: '#2a2f32' }} >
                {/* <Link to="/acc/safe">
                  <div style={{ position: 'relative' }}>
                    <Icon type="user" />
                    <span >个人</span>
                  </div>
                </Link> */}
                <div onClick={this.showModal} style={{ position: 'relative' }}>
                  <Icon type="user" />
                  <span >个人</span>
                  <Modal
                    visible={this.state.visible}
                    onOk={this.handleOk} onCancel={this.handleCancel}
                    style={{ top: 50 }}
                    className="Account"
                  >
                    <div className="basis" onClick={this.handleCancel}>
                      <Link to="/acc/basis">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={basis} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="basis" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ color: '#111111' }} >基本信息</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="basis" onClick={this.handleCancel}>
                      <Link to="/acc/real">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={real} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="real" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ marginTop: 30, color: '#111111' }}> 实名认证</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="basis" onClick={this.handleCancel}>
                      <Link to="/acc/safe">
                        <div style={{ width: 80, height: 80, textAlign: 'center' }}>
                          <div style={{ width: 20, height: 50, textAlign: 'center' }}>
                            <img src={safe} style={{ width: 20, height: 20, marginLeft: 30, marginTop: 20 }} alt="safe" />
                          </div>
                          <div style={{ width: 80, height: 30, textAlign: 'center' }}>
                            <span style={{ marginTop: 30, color: '#111111' }}> 安全设置</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                    <div className="easc" onClick={this.logout}>退出管理控制台</div>
                  </Modal>
                </div>
              </Menu.Item>
            </Menu>
          </div>
        </div>

        <div style={{ height: "calc(100vh - 50px)", padding: 20, width: "100%", backgroundColor: "white" }}>
          <div style={{ height: 35, paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等', borderBottom: '#ddd 1px solid', marginBottom: 20 }}>
            <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', }}>
              <Link to='' style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>消防知识</Link>
            </div>
            <div style={{ float: 'left', marginRight: 4, marginTop: '-7px' }}>
              <Button style={{ float: 'left', background: '#536679', color: '#fff', padding: '0 15px', height: '32px', borderRadius: 0 }}><Link to="/fire/new">新增消防知识</Link></Button>
              {/* <Button style={{ marginLeft: 5, float: 'left', background: '#d9dee4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaff} >编辑</Button> */}
              <Button style={{ marginLeft: 5, float: 'left', background: '#d9dee4', padding: '0 15px', height: '32px', borderRadius: 0 }} onClick={this.handleStaffOne} >详情</Button>
            </div>
          </div>
          <WrappedAdvancedSearchForm appState={this.props.appState} />
          <Row style={{ marginTop: 20 }}>
            <Col span={24}>
              <Table
                //bordered
                style={{ color: '#999' }}
                columns={columns}
                dataSource={data}
                pagination={pagination}
                onChange={this.handleChange}
                rowSelection={rowSelection}
              />
            </Col>
          </Row>
        </div>

      </div >
    );
  }
})

class FireKnowledge extends Component {
  render() {
    return (
      <StaffC appState={new appState()} />
    )
  }
}

export default FireKnowledge;