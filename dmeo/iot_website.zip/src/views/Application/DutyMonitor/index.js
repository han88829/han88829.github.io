import React, { Component } from 'react';
import { extendObservable, action } from 'mobx';
import { Link } from 'react-router';
import { observer } from 'mobx-react';
import { Icon, Row, Col, DatePicker, Button, Form,  Card, message,notification,Radio} from 'antd';
import echarts from 'echarts';
import moment from 'moment';
import $ from 'jquery';

import './DutyHistory.css';
import UnAlarm from '../../../assets/images/equipment/unalarm.png';
import Alarm from '../../../assets/images/apply/member.png';
import People from '../../../assets/images/apply/people.png';
import QuitScreen from '../../../assets/images/application/exit-fullscreen.png';
import Close from '../../../assets/images/application/shut-o.png';
import date  from '../../../assets/images/apply/date.png';
import down  from '../../../assets/images/apply/down.png';
import proguess  from '../../../assets/images/apply/proguess.png';
import realtime_monitor from '../../../assets/images/apply/realtime-monitor.png';
import supervision  from '../../../assets/images/apply/supervision.png';
import surpass_num  from '../../../assets/images/apply/surpass-num.png';
import up  from '../../../assets/images/apply/up.png';

import duty_person_pic  from '../../../assets/images/apply/duty-person.png';
import wait_deal_with  from '../../../assets/images/apply/wait-deal-with.png';
import world  from '../../../assets/images/apply/world.png';
import Delete from '../../../assets/images/application/删除.png';

//const { TabPane } = Tabs;
const { RangePicker } = DatePicker;
const FormItem = Form.Item;

//import Music from '../../../assets/6709.mp3';
var audio;
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
    placement: 'bottomRight',
    duration: 30,
    
  });
};
//EchartsSearchForm 
class appState {
  constructor(){
    extendObservable(this,{
      tableData:[],
      chartData:[]
    })
  }
}
  

const AdvancedSearchForm = Form.create()(React.createClass({
  componentWillMount() {
    // console.log(this.props.form);
    this.props.form.setFieldsValue({
      periods: 'month'
    })
  },
  handleSearch(e){
    e.preventDefault();
    try {
      this.props.form.validateFields((err, fieldsValue) => {
        const rangeValue = fieldsValue['setupTime'];
        let values = {};
        values = {createTime: [new Date(rangeValue[0].format('YYYY-MM-DD')), new Date(rangeValue[1].format('YYYY-MM-DD'))]}
        // console.log('Received values of form: ', values);

        window.rpc.user.getArrayByContainer(values,0,0).then((result) =>{
          // console.log(result);
          message.info(`共搜索到${result.length}条数据`);
          let devices = result.map((x) => ({...x, attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: x.id}));
          this.props.appState.tableData = devices;
        }, (err) => {
          console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
        })
      });
    } catch(e) {
      console.warn(e);
    }
  },

  handlePeriods(e){
    // console.log(e.target.value);
    let createTime = e.target.value;
    let values = {};
    switch (createTime) {
      case 'month':
        values = {createTime: [new Date(moment().subtract(1, 'month').format('YYYY-MM-DD')), new Date()]};
        break;
      case 'year':
        values = {createTime: [new Date(moment().subtract(1, 'year').format('YYYY-MM-DD')), new Date()]};
        break;
      case 'quarter':
        values = {createTime: [new Date(moment().subtract(3, 'month').format('YYYY-MM-DD')), new Date()]};
        break;
      default:
        console.log('haha!');
        break;
    }
    // console.log(values);
    // window.rpc.user.getArrayByContainer(values,0,0).then((result) =>{
    //   // console.log(result);
    //   message.info(`共搜索到${result.length}条数据`);
    //   let devices = result.map((x) => ({...x, attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: x.id}));
    //   //this.props.appState.chartData = devices;
    // }, (err) => {
    //   console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    // })
  },

  render(){
    const { getFieldDecorator } = this.props.form;

    return (
      <Form layout="inline" style={{ margin: 0, padding: '0 0 15px',width:'100% '}} >
        <Row style={{width:'100%'}}>
          <Col span={7} key={1}>
            <FormItem>
							{/*{getFieldDecorator('periods')(*/}
								<Radio.Group onChange={this.handlePeriods} defaultValue="week" style={{width:180,height:32}}>
									<Radio.Button value="week">本周</Radio.Button>
									<Radio.Button value="month">本月</Radio.Button>
									<Radio.Button value="year">本年</Radio.Button>
								</Radio.Group>
							{/*})}*/}
						</FormItem>
          </Col>
          <Col span={14} key={2}>
            <FormItem label={`时间`}>
              {getFieldDecorator(`setupTime`)(
                <RangePicker style={{borderRadius: 0,width:280}} />
              )}
            </FormItem>
          </Col>
          <Col span={2} key={3}>
            <FormItem>
              <Button
                type="primary"
                onClick={this.handleSearch}
                style={{borderRadius: 0,width:60}}
              >
                搜索
              </Button>
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }
}))

//@observer
//class EchartsSearchForm extends Component {
 const EchartsSearchForm  = observer(class appState extends React.Component { 
   constructor() {
		super();
		this.state = {
		
		};
	}
  componentWillMount(){
    //  window.rpc.user.getArrayByContainer({ownerId:1},0,0).then((result) =>{
    //  // let devices = result.map((x) => ({...x, attendance: (Math.random() * 100).toFixed(2), completion: `${Math.round(Math.random() * 100)}/${Math.round(Math.random() * 100)}`,score: (Math.random() * 100).toFixed(2), key: x.id}));
    //   //this.props.appState.chartData = result;
    // }, (err) => {
    //   console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    // })
  }
  componentDidMount(){
    let myChart = echarts.init(document.getElementById('MemberMonitor01'));
      let option={
        tooltip: {
           trigger: 'axis',
        },
        grid: {
            containLabel:false
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                //formatter: '{value} °C'
            },
            splitLine: {
                show: false
            }
            
        },
        xAxis: {
            type: 'category',
            axisLine: {onZero: false},
            axisLabel: {
                //formatter: '{value} km'
            },
            
            splitLine: {
                show: true
            },
            boundaryGap: false,
            data: ['0', '10', '20', '30', '40', '50', '60', '70', '80']
        },
        series: [
            {
                name: '当前已办事项数目',
                type: 'line',
                color:['#00c1de','blue','red', 'yellow','green'],
                smooth: true,
                lineStyle: {
                    normal: {
                        width: 3,
                        shadowColor: 'rgba(0,0,0,0.4)',
                        shadowBlur: 10,
                        shadowOffsetY: 10
                    }
                },
                data:[15, 20, 4, 12, 34,32, 10, 32, 34]
            }
        ]
    };
    myChart.setOption(option);
  }
  render=()=>{
    //let data=[...this.props.appState.chartData];
    //console.log(data);
   return(
         <div className="eChart">
            <div className="eChart-search">
                < AdvancedSearchForm   appState={this.props.appState} />   
            </div>
           {/*<div className="eChart" style={{width:'100%'}}>
               <Row style={{padding:5}}>
                  <Col span={24} style={{ padding: '-2px'}}>
						      
					       </Col>
		          </Row>   
            </div>*/}
        </div>
   )
  }
});


const DutyMonitor = observer(class appState extends React.Component {
  	constructor() {
		super();
		this.state = {
		   CardData:[],
       isShow: 'block',
       ownerId:null,
         obj1:{
             name:'',
              num:'',
              email:'',//加密处理
              groupId:'',//在请求
              number:""
         },
         count:null
		};
	}

//class DutyMonitor extends Component {
  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
    // point.lng
    // point.lat
  }
  componentWillMount() {
     var ownerId=null;
    window.rpc.user.getInfo().then(data=>{
    //console.log(data.ownerId);
      // ownerId=data.ownerId;
      // let groupId=data.groupId;
      // console.log(groupId);
      window.rpc.user.getCountByContainer({groupId:data.groupId}).then(res=>{
      //window.rpc.user.getCountByContainer({ownerId:ownerId}).then(res=>{
        //console.log(res) ;   
        this.setState({count:res}) 
      },err=>{

      })
    });
    //console.log(ownerId);
  
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    loadJScript();
  }

  componentDidMount() {
    var ownerId=null;
    window.rpc.user.getInfo().then(data=>{
     // console.log(data.ownerId);
     ownerId=data.ownerId;
      this.setState({ownerId:data.ownerId});
    });
    
    //var ownerId=this.state.ownerId;
    //console.log(ownerId);
    const that = this;
    function init() {
      let newId = [], param = '';
      function callBack(data) {
        //console.log(data);
        sessionStorage.setItem('flag', 1)
        // audio = new Audio(Music);
        // audio.loop='loop';
        // audio.play();
        newId = [];
        //console.log(ownerId);
        window.rpc.area.getArrayDeviceCountByContainer({ownerId:ownerId}, 0, 0).then((res) => {
          res.forEach(function (value) {
            data.forEach(function (x) {
              if (value.id === x.floor) {
               // openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
                alarm(Alarm);
                mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
                var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), value.count, mouseoverTxt);
                var content = x.name;
                var obj = x;
                newId = x.id;
                param = {
                  id: newId
                };

                map.addOverlay(maker)// 将标注添加到地图中
                addClickHandler(content, param, newId, obj, maker);
              }
            })
          })
        },(err) =>{
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);
  
      var map = new window.BMap.Map("allmap");
      var point = new window.BMap.Point(121.618835,29.920698);//121.627363,29.925424
      //map.addControl(new  window.BMap.MapTypeControl()); 
      //var point = new window.BMap.Point(121.618864,29.921381);
      map.centerAndZoom(new window.BMap.Point(116.3964, 39.9093), 15);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';

      function setPlace() {
        map.clearOverlays();    //清除地图上所有覆盖物
        function myFun() {
          var pp = local.getResults().getPoi(0).point;    //获取第一个智能搜索的结果
          map.centerAndZoom(pp, 18);
          map.addOverlay(new window.BMap.Marker(pp));    //添加标注
        }
        var local = new window.BMap.LocalSearch(map, { //智能搜索
          onSearchComplete: myFun
        });
        local.search(myValue);
      }

      // function myFun(result) {
      //   var cityName = result.name;
      //   map.setCenter(cityName);
      // }
      // var myCity = new window.BMap.LocalCity();
      // myCity.get(myFun);
      map.centerAndZoom(point, 17);
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);
      function G(id) {
        return document.getElementById(id);
      }
      map.centerAndZoom("宁波镇海区庄市街道创E慧谷", 18);   
      map.addControl(new  window.BMap.MapTypeControl({mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP]}));        
      // 初始化地图,设置城市和地图级别。
     // map.centerAndZoom(new window.BMap.Point(121.618864,29.921381), 18);  
      var ac = new window.BMap.Autocomplete(    //建立一个自动完成的对象
        {
          "input": "suggestId"
          , "location": map
        });

      ac.addEventListener("onhighlight", function (e) {  //鼠标放在下拉列表上的事件
        var str = "";
        var _value = e.fromitem.value;
        var value = "";
        if (e.fromitem.index > -1) {
          value = _value.province + _value.city + _value.district + _value.street + _value.business;
        }
        str = "FromItem<br />index = " + e.fromitem.index + "<br />value = " + value;

        value = "";
        if (e.toitem.index > -1) {
          _value = e.toitem.value;
          value = _value.province + _value.city + _value.district + _value.street + _value.business;
        }
        str += "<br />ToItem<br />index = " + e.toitem.index + "<br />value = " + value;
        G("searchResultPanel").innerHTML = str;
      });

      var myValue;
      ac.addEventListener("onconfirm", function (e) {    //鼠标点击下拉列表后的事件
        var _value = e.item.value;
        myValue = _value.province + _value.city + _value.district + _value.street + _value.business;
        G("searchResultPanel").innerHTML = "onconfirm<br />index = " + e.item.index + "<br />myValue = " + myValue;

        setPlace();
      });
      map.centerAndZoom(new window.BMap.Point(116.417854, 39.921988), 15);
      var data_info = [[116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
      [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
      [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
      ];
      var opts = {
        width: 100,     // 信息窗口宽度
        height: 50,     // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true//设置允许信息窗发送短息
      };
      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "33px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "33px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(p);
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            //this.getElementsByTagName("span")[0].innerHTML = that._text;
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountByContainer({ownerId:ownerId}, 0, 0).then((res) => {
        //console.log(res);
        newId = '';
        res.map((x) => {
          alarm(Alarm)
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);
        })
      },(err) =>{
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })

      function addClickHandler(content, param, newId, obj, marker) {
       //  console.log(param);
        //console.log(param+'~~'+content+'~~'+newId) ;   
        marker.addEventListener("click", function (e) {
          createDom(newId);
          //nconsole.log('dislpay:none');
          CardDisplay();
        function createDom(newId){
          
          const ghost = () => {
            return window.rpc.user.getArrayByContainer({ownerId:newId},0,0)
          }
          const gho = async () => {
            const res = await ghost();
            const param = [];
            res.map(x => {
              param.push(x.param)
            })
            that.setState({
              param
            })
            return param
          }
          let de;
          const ghosts = async () => {
            const res = await ghost();
            const o = await gho();
            //console.log(res.length);
           
              //console.log(res);
                de = res.map((x, index) => {
              return (`<div class="everyData" ><div class="DclearFix DutyInfo"><img src=${duty_person_pic} alt=""  /><span>姓名：${x.name}</span></div>
              <div class="DclearFix DutyInfo"><div class="floatLeft">联系电话:${x.mobile}</div><div class="floatRight">邮箱:${x.email}</div></div>
             <div  class="DclearFix DutyInfo"><div class="floatLeft"> 所属部门:${x.groupId}</div><div class="floatRight">工号:${x.number||'******'} </div></div>
             <p class="DutyInfo DclearFix"><a href=/apply/track/${x.id}>查看更多</a></p></div>`)
            })
          
           //console.log(de);
            var arr = [1, 2, 3];
            if(de.length!==0){
              document.getElementsByClassName('CardData')[0].innerHTML = de.join(',')
            }else{
              document.getElementsByClassName('CardData')[0].innerHTML = `<div class="everyDataNone" ><div class=""><span>暂无数据</span></div></div>`
            }
         
            $('.watch').click(() => {
              that.setState({
                display: 1
              })
            })
            // $('.deletes').each((i) => {
            //   console.log(i);
            //   $('.deletes').eq(i).click(() => {
            //     $('.deletes').eq(i).parent('div').animate({ left: -600, opacity: 0 })
            //     $('.deletes').eq(i).parent('div').css("position", 'absolute')
            //   })
            // })

          }
          ghosts();
          document.getElementsByClassName('Card')[0].style.left = '0';
          document.getElementsByClassName('Card')[0].style.opacity = '1';   
      
     }
      function CardDisplay(){
          let flag=1;    
           if(flag){
             $('.Card').css({'display':'block'});
             flag=!flag;
           }else{
              $('.Card').css({'display':'none'});
              flag=!flag;
           }
          
        }                                                                                                                                                                                     
        });
      }
      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts);  // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }
    }
    setTimeout(() => {
      init();
    }, 1000);
     let myChart = echarts.init(document.getElementById('MemberMonitor01'));
			 let option={
            backgroundColor: 'rgba(0,23,55,0)',
            tooltip: {
              trigger: 'axis',
              axisPointer: {
                lineStyle: {
                   color: '#57617B'
                }
              }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: [{
                type: 'category',
                boundaryGap: false,
                axisLine: {
                  lineStyle: {
                     color: '#04ffff'
                  }
                },
                splitLine: {
                    show:true
                },
                data: ['0', '20', '40', '60', '100', '120']
            }],
            yAxis: [{
                type: 'value',
                axisTick: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                      color: '#04ffff'
                    }
                },
                axisLabel: {
                    margin: 10,
                    textStyle: {
                        fontSize: 14
                    }
                },
                splitLine: {
                    show:false
                }
            }],
            series: [{
                name: '故障设备',
                type: 'line',
                smooth: true,
                 color:['#00c1de'],
                symbol: 'circle',
                symbolSize: 5,
                showSymbol: false,
                lineStyle: {
                    normal: {
                        width: 1
                    }
                },
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(0,193,222, 0.8)' // 'rgba(137, 189, 27, 0.3)'
                        }, {
                            offset: 0.8,
                            color: 'rgba(0,193,222, 0.1)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {
                    normal: {
                        color: 'rgb(0,193,222)',
                        borderColor: 'rgba(0,193,222,0.87)',
                        borderWidth: 12

                    }
                },
                data: [220, 182, 191, 134, 150, 120, 110, 125, 145, 122, 165, 122]
            }]
        }//)
   
    myChart.setOption(option);
  }
  //隐藏执勤实时监督详情页点击按钮
  handleChange=(e)=>{
    // console.log(1);
  }
  handleButtonClick=(e)=>{
    $('.Card').css({'display':'none'});
  }
  onHandleClick=(e)=>{
    this.setState({isShow:"none"})
  }
  
  render() {
    let flag=Math.floor(Math.random()*1);
    let allAffair=Math.floor(Math.random()*100);
    let Progress=Math.floor(Math.random()*100)+ '%';
    let WaitEvent=Math.floor(Math.random()*30);
    let OverDateEvent=Math.floor(Math.random()*10);
    let allPerson=this.state.count;
    let workPerson=Math.floor(Math.random()*allPerson);
    let realPerson=allPerson-workPerson;

    return (
      <div className="DutyMonitor" style={{padding:'16px 0 0 0px'}}>
        <div style={{ position: 'absolute', right: 0, top: 20, zIndex: 999, display: this.state.isShow }} onClick={this.onHandleClick}>
          <span className="new-button" style={{display:'inline-block', background: 'rgba(55, 61, 65,.5)', marginRight: 0, overflow: 'hidden',padding:'0 5px'   }}><img src={QuitScreen} alt="" style={{ marginTop:8, marginRight: 2, float: 'left' }} /><Link to='/safecenter' style={{ color: '#fff' }}>退出全屏</Link></span>
          <span className="new-button" style={{display:'inline-block',marginLeft:'12px', background: 'rgba(55, 61, 65,.5)', overflow: 'hidden',padding:'0 5px',width:80   }}><img src={Close} alt="" style={{ marginTop: 8, marginRight: 2,marginLeft:'8px',float: 'left' }} /><Link to='/safecenter' style={{ color: '#fff' }}>关闭</Link></span>
        </div>
        <div className="duty-monitor DclearFix">
            <div style={{ height: 100, background: "#f9f9fa" }}>
              <img  src={realtime_monitor} style={{ float: "left", margin: "14px 16px 0 12px" }} />
              <h3 style={{ float: "left", fontSize: 24, fontWeight: 100, color: "#373d41", marginTop:30 }}>执勤实时监督</h3>
           </div>
      
          {/*<div className=" DclearFix " style={{lineHeight:"100px",backgroundColor:'#f9f9fa',position:"relative"}}>
            <div style={{fontSize:'1.5em',fontFamily:'微软雅黑 regular',lineHeight:'64px',float:'left'}}>
               <img src={realtime_monitor} style={{padding:'0 16px'}} alt=""/><span>执勤实时监控</span>
            </div>
            <div onChange={this.handleChange} style={{height:22,lineHeight:"22px",width:170}}>
              <button style={{fontFamily:'微软雅黑 regular',fontSize:'0.875em',color:'#373d41',width:170,height:22,lineHeight:"22px",border:"1px solid #eee",position:"absolute",right:0,bottom:39}}>隐藏执勤实时监督详情页</button>
            </div>
          </div>*/}
          <div style={{fontSize:"0.875em",color:'#373d41',fontFamily:'苹方中等 Sansation Regula',padding:"0 16px"}}>
            <p style={{margin:'26px 0 16px',padding:'2px  0 2px 10px',borderLeft:'2px solid #0099cc',padding:`0px 0px 0px 10px`,lineHeight: `16px`,height:16}}>实时总括</p>
            <p style={{height:38,lineHeight:'38px',boxShadow:'0 0 2px  #ddd',paddingLeft:'10px'}}>总执勤人数 <span><Link to="/memb/staff">{this.state.count}</Link></span>个，执勤人数<span><Link to="/memb/staff">{workPerson}</Link></span>个，缺勤人数<span><Link to="/memb/staff">{realPerson}</Link></span>个。</p>
          </div>
          <div style={{fontSize:"0.875em",color:'#666',fontFamily:'苹方中等 Sansation Regula',padding:"0 16px"}}>
            <p style={{margin:'26px 0 16px',padding:'2px  0 2px 10px',borderLeft:'2px solid #0099cc',padding:`0px 0px 0px 10px`,lineHeight: `16px`,height:16}}>实时预览</p>
            <div style={{height:68,lineHeight:'68px',backgroundColor:'#f9f9fa'}}>
              <ul className="preview Dclearfix" style={{width:'100%'}}>
                <li style={{width:'19.9%',float:'left',height:68,lineHeight:'68px'}} className=" DclearFix">
                  <p style={{padding:'0  5%'}}>
                    <img src={supervision} style={{ float: "left", margin: "14px 16px 0 12px" }} alt=""/>
                    <div style={{ float: "left",  fontWeight: 400, color: "#373d41", marginTop:0 }}>
                        <span>实时监督：</span>
                        <span style={{fontSize:"1.125em",color:'#00d3bf',fontFamily:'Adobe 黑体'}}>{flag?"正常":"异常"}</span>     
                    </div>
                 </p>
               </li>
                <li style={{width:'19.9%',float:'left'}}>
                    <p style={{padding:'0 5%'}}>
                    <img src={world} style={{ float: "left", margin: "24px 16px 0 12px" }} alt=""/>
                    <div style={{ float: "left",  fontWeight: 400, color: "#373d41", marginTop:0 }}>
                        <span>总事项（件）：</span>
                        <span style={{fontSize:"1.125em",color:'#00d3bf',fontFamily:'Adobe 黑体'}}>{allAffair}</span>     
                    </div>
                 </p>
                </li>
                <li style={{width:'19.9%',float:'left'}}>
                    <p style={{padding:'0 3%'}}>
                    <img src={proguess} style={{ float: "left", margin: "24px 16px 0 12px" }} alt=""/>
                    <div style={{ float: "left",  fontWeight: 400, color: "#373d41", marginTop:0 }}>
                        <span>指标完成百分进度：</span>
                        <span style={{fontSize:"1.125em",color:'#00d3bf',fontFamily:'Adobe 黑体'}}>{Progress}</span>     
                    </div>
                 </p>
                </li>
                <li style={{width:'19.9%',float:'left'}}>
                    <p style={{padding:'0 3%'}}>
                    <img src={wait_deal_with} style={{ float: "left", margin: "24px 16px 0 12px" }} alt=""/>
                    <div style={{ float: "left",  fontWeight: 400, color: "#373d41", marginTop:0 }}>
                        <span>等待处理的事项（件）：</span>
                        <span style={{fontSize:"1.125em",color:'#00d3bf',fontFamily:'Adobe 黑体'}}>{WaitEvent}</span>     
                    </div>
                 </p>
                </li>
                <li style={{width:'19.9%',float:'left'}}>
                    <p style={{padding:'0 3%'}}>
                    <img src={surpass_num} style={{ float: "left", margin: "24px 16px 0 12px" }} alt=""/>
                    <div style={{ float: "left",  fontWeight: 400, color: "#373d41", marginTop:0 }}>
                        <span>以超期的事项（件）：</span>
                        <span style={{fontSize:"1.125em",color:'#00d3bf',fontFamily:'Adobe 黑体'}}>{OverDateEvent}</span>     
                    </div>
                 </p>
                </li>
              </ul>
            </div>
          </div>
          <div className="eChart-map Dclearfix" style={{width:'100%',height:480,padding:"0 16px"}}> 
             <p style={{margin:'26px 0 16px',padding:'2px  0 2px 10px',borderLeft:'2px solid #0099cc',padding:`0px 0px 0px 10px`,lineHeight: `16px`,height:16}}>执行近况</p>
             <div className="DclearFix">
               <div style={{float:'left',width:'37.9%',marginRight:'0.1%'}}>
                  <EchartsSearchForm appState={this.props.appState} /> 
                   <div id="MemberMonitor01" style={{ height: '420px', width: '80%' }}></div> 
               </div>
               <div style={{float:'right',width:'62%',position:'relative'}}>
                   <div className="cardLists Card" style={{maxHeight:470,height:470,overflow:'auto', position: 'absolute', left: 0, top: 0, zIndex: 999,display:'none'}} >
                     {/*<div style={{ position: 'absolute',right:0,top:0,border:'1px solid #ddd',}} ><button>X</button></div>          */}
                         <Card title="执勤人员总览信息（今日数据）" style={{width:470,minHeight:180,backgroundColor:'#fff',paddingBottom:10, position: "relative", top: 0,left:0,opacity :1, transition: 'all 1s'}} extra={<a href="javascript:;" onClick={this.handleButtonClick}><img src={Delete} style={{paddingTop:0}} alt="" /></a>}>
                           <div className="CreateCard"  title="执勤人员总览信息（今日数据）" style={{width:470,minHeight:180,backgroundColor:'#fff',paddingBottom:10,  position: "relative", top: 0,left:0,opacity :1, transition: 'all 1s',padding:'0 0 10px 0'}} extra={<a href="javascript:;" onClick={this.handleButtonClick}><img src={Delete} style={{paddingTop:0}} alt="" /></a>}>
                            <div className="CardData" onClick={this.onHrefHandleClick}>
                              {/*<p style={{ fontSize: '0.75em', width: "100%", overflow: 'hidden' }}>
                                <img src={duty_person_pic} alt="" style={{ marginRight: 6, float: "left", marginTop: 5 }} />
                                <span style={{ float: "left" }}>姓名：{this.state.obj1.name||'xiaosong'}</span>
                                </p>
                              <p style={{  fontSize: '0.75em', width: "100%", overflow: 'hidden', paddingLeft: 67 }}>
                                <Row>
                                  <Col span={10} key="1">
                                    联系电话:{this.state.obj1.num||'******'}
                                  </Col>
                                   <Col span={10} key="2">
                                    邮箱:{this.state.obj1.email||'******'}
                                  </Col>
                                </Row>
                               </p>   
                               
                              <p style={{ fontSize: '0.75em', width: "100%", overflow: 'hidden', paddingLeft: 67 }}>
                                <Row>
                                  <Col span={10} key="1">
                                    所属部门{this.state.obj1.groupId||'2'}
                                  </Col>
                                   <Col span={10} key="2">
                                    工号:{`*******`}
                                  </Col>
                                </Row>
                               </p>   */}
                             </div>
                            </div>
                             {/*{ linksLists}*/}
                           </Card>
                      </div>
                  <div style={{float:'right',width:'100%'}} className="map" id="allmap"></div>   
               </div>
             </div>
          </div>  
        </div>
      </div>
    );
  }
})

export default DutyMonitor;
