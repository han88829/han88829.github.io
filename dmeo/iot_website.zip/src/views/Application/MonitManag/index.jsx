import React, { Component } from 'react';
// import { BaiduMap } from 'react-baidu-map';
import { notification, Icon, Card, Button } from 'antd';
import { browserHistory } from 'react-router';
import './equipMapMonitore.css';
import UnAlarm from '../../../assets/images/application/探测.gif';
import Alarm from '../../../assets/images/application/探测.gif';
import Watch from '../../../assets/images/application/监控.png';
import Remind from '../../../assets/images/application/提醒.png';
import Delete from '../../../assets/images/application/删除.png';
import Up from '../../../assets/images/application/up.png';
import Down from '../../../assets/images/application/down.png';
import $ from 'jquery';
import ico_image from '../../../assets/images/monitoring/全屏-icon.png';
import red from '../../../assets/images/application/探测-red.png';
import blue from '../../../assets/images/application/探测-blue.png';

let arrFlag = 0;
const openNotification = (data) => {
  notification.open({
    message: data,
    icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
    placement: 'bottomRight',
    duration: 30,
    onClose: function (e) {
      e.stopPropagation()
    }
  });
};
function createMarkup() {
  return { __html: 'First &middot; Second' };
}
class MonitManag extends Component {
  constructor() {
    super();
    this.state = {
      arr: [],
      display: 0,
      param: []
    }
  }
  onChange(event) {
    this.refs.location.search(event.target.value);
  }
  onSelect(point) {
    // point.lng
    // point.lat
  }
  componentWillMount() {
    function loadJScript() {
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "http://api.map.baidu.com/api?v=2.0&ak=m0n40wWWABOyF6g8wDnarIKChvFGGuFA&callback=init";
      document.body.appendChild(script);
    }
    loadJScript();
  }

  componentDidMount() {
    const that = this
    function init() {
      let newId = [], param = '';
      function callBack(data) {
        console.log(data);
        sessionStorage.setItem('flag', 1)
        newId = [];
        // window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        //   res.forEach(function (value) {
        //     data.forEach(function (x) {
        //       if (value.id === x.floor) {
        //         openNotification(`${x.locationName.replace(/\,/ig, '的')}的${x.name}报警了}`);
        //         alarm(Alarm);
        //         mouseoverTxt = x.locationName.slice(0, x.locationName.indexOf(','));
        //         var maker = new ComplexCustomOverlay(new window.BMap.Point(x.floorX, x.floorY), value.count, mouseoverTxt);
        //         var content = x.name;
        //         var obj = x;
        //         newId = x.id;
        //         param = {
        //           id: newId
        //         };
        //         map.addOverlay(maker)// 将标注添加到地图中
        //         addClickHandler(content, param, newId, obj, maker);
        //       }
        //     })
        //   })
        // }, (err) => {
        //   console.warn(err);
        // })
      }
      window.rpc.subscribe('/owner:*/device:*/fault:*', callBack);
      window.rpc.subscribe('/owner:*/device:*/alarm:*', callBack);

      var map = new window.BMap.Map("allmap1");
      var point = new window.BMap.Point(121.618835, 29.920698);
      map.enableScrollWheelZoom();
      // 复杂的自定义覆盖物
      function ComplexCustomOverlay(point, text, mouseoverText) {
        this._point = point;
        this._text = text;
        this._overText = mouseoverText;
      }
      ComplexCustomOverlay.prototype = new window.BMap.Overlay();
      ComplexCustomOverlay.prototype.addEventListener = function (event, fun) {
        this._div['on' + event] = fun;
      }
      ComplexCustomOverlay.prototype.draw = function () {
        var map = this._map;
        var pixel = map.pointToOverlayPixel(this._point);
        this._div.style.left = pixel.x - parseInt(this._arrow.style.left) + "px";
        this._div.style.top = pixel.y - 30 + "px";
      }
      var mouseoverTxt = '';

  
      // function myFun(result) {
      //   var cityName = result.name;
      //   map.setCenter(cityName);
      // }
      // var myCity = new window.BMap.LocalCity();
      // myCity.get(myFun);
      map.centerAndZoom(point, 12);
      map.enableScrollWheelZoom();   //启用滚轮放大缩小，默认禁用
      map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
      // 编写自定义函数,创建标注
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 11);
      // 添加带有定位的导航控件
      var navigationControl = new window.BMap.NavigationControl({
        // 靠左上角位置
        anchor: window.BMAP_ANCHOR_TOP_LEFT,
        // LARGE类型
        type: window.BMAP_NAVIGATION_CONTROL_LARGE,
        // 启用显示定位
        enableGeolocation: true
      });
      map.addControl(navigationControl);
      // 添加定位控件
      var geolocationControl = new window.BMap.GeolocationControl();
      geolocationControl.addEventListener("locationSuccess", function (e) {
        // 定位成功事件
        var address = '';
        address += e.addressComponent.province;
        address += e.addressComponent.city;
        address += e.addressComponent.district;
        address += e.addressComponent.street;
        address += e.addressComponent.streetNumber;
      });
      geolocationControl.addEventListener("locationError", function (e) {
        // 定位失败事件
        alert(e.message);
      });
      map.addControl(geolocationControl);
      function G(id) {
        return document.getElementById(id);
      }
      map.centerAndZoom(point, 50);                   // 初始化地图,设置城市和地图级别。
      map.centerAndZoom(point, 18);
      map.addControl(new  window.BMap.MapTypeControl({mapTypes: [window.BMAP_NORMAL_MAP, window.BMAP_SATELLITE_MAP, window.BMAP_HYBRID_MAP]}));           
      var data_info = [[116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
      [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
      [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
      ];
      var opts = {
        width: 100,     // 信息窗口宽度
        height: 50,     // 信息窗口高度
        title: "", // 信息窗口标题
        enableMessage: true//设置允许信息窗发送短息
      };
      function alarm(src) {
        ComplexCustomOverlay.prototype.initialize = function (map) {
          this._map = map;
          var div = this._div = document.createElement("div");
          div.style.position = "absolute";
          div.style.zIndex = window.BMap.Overlay.getZIndex(this._point.lat);
          div.style.color = "white";
          div.style.width = "24px";
          div.style.height = "24px";
          div.style.padding = "2px";
          div.style.textAlign = "center";
          div.style.lineHeight = "18px";
          div.style.whiteSpace = "nowrap";
          div.style.MozUserSelect = "none";
          div.style.fontSize = "12px";
          var p = this._p = document.createElement("p");
          p.style.position = 'absolute';
          p.style.left = "0px";
          p.style.top = "-30px";
          p.style.fontSize = "14px";
          p.style.height = "30px";
          p.style.lineHeight = "25px";
          p.style.display = "none";
          p.style.borderRadius = "5px";
          p.style.color = "#111";
          p.style.border = '2px solid #666';
          p.style.padding = '0 5px';
          p.style.background = "rgba(255,255,255,.6)";
          p.innerHTML = this._overText;
          var img = this._img = document.createElement("img");
          img.src = src;
          img.style.width = "24px";
          img.style.height = "24px";
          img.style.float = 'left';
          div.appendChild(img);
          div.appendChild(p);
          var that = this;

          var arrow = this._arrow = document.createElement("div");
          arrow.style.background = "url(http://map.baidu.com/fwmap/upload/r/map/fwmap/static/house/images/label.png) no-repeat";
          arrow.style.position = "absolute";
          arrow.style.height = "25px";
          arrow.style.top = "22px";
          arrow.style.left = "10px";
          arrow.style.overflow = "hidden";
          div.appendChild(arrow);

          div.onmouseover = function () {
            this.getElementsByTagName("p")[0].style.display = 'block';
            arrow.style.backgroundPosition = "0px -20px";
          }

          div.onmouseout = function () {
            this.getElementsByTagName("p")[0].style.display = 'none';
            arrow.style.backgroundPosition = "0px 0px";
          }

          map.getPanes().labelPane.appendChild(div);

          return div;
        }
      }
      window.rpc.area.getArrayDeviceCountByContainer({}, 0, 0).then((res) => {
        console.log(res)
        newId = '';
        res.map((x) => {
          alarm(Alarm)
          mouseoverTxt = x.name;
          var maker = new ComplexCustomOverlay(new window.BMap.Point(x.x, x.y), x.count, mouseoverTxt);
          var content = x.name;
          var obj = x;
          newId = x.id;
          param = { 'floor': newId };
          map.addOverlay(maker)// 将标注添加到地图中
          addClickHandler(content, param, newId, obj, maker);
        })
      }, (err) => {
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
      })

      function addClickHandler(content, param, newId, obj, marker) {
        marker.addEventListener("click", function (e) {
          e.stopPropagation();
          const ghost = () => {
            return window.rpc.device.getArrayCameraByContainer({ ...param, dtype: 56 }, 0, 10, console.log, console.error)
          }
          const gho = async () => {
            const res = await ghost();
            const param = []
            res.map(x => {
              param.push(x.param)
            })
            that.setState({
              param
            })
            return param
          }
          let de = "";
          const ghosts = async () => {
            const res = await ghost();
            const o = await gho();
            res.map((x, index) => {
              de += `<div style=" margin-top:10px;padding: 16px 10px 20px;overflow: hidden;width: 100%;position: relative;" class="cards">
                <span style="float: left;margin: 0px 8px 0px 16px;" class="deletes"><a href="javascript:;" ><img src=${red} alt="" /></a> </span>
                <div style="float: left;width:80%;">
                <h3 style="font-family:'微软雅黑';color: rgb(0, 193, 222);margin-bottom: 18px;font-weight:100;">摄像头</h3>     
                <div>
                  <p style="margin-bottom: 6px;"><span>安装位置:${x.location || "无"}</span></p>
                  <p>Ip地址:${o[index].IP}</p>
                </div>   
                <a href="javascript:;" style="display: block;width: 45px;height: 24px;font-size: 12px;font-family: PingFang-SC-Medium;color: rgb(255, 255, 255);text-align: center;line-height: 24px;position: absolute;right: 10px;bottom: 0px;background: #00c1de;" class="watch" data-id=${x.id}>查看</a>
                </div>
              </div>`
            })
            var arr = [1, 2, 3]
            document.getElementsByClassName('Card')[0].innerHTML = de
            $('.watch').each((i) => {
              $('.watch').eq(i).click((e) => {
                e.stopPropagation()
                console.log($('.watch').eq(i).attr('data-id'))
                that.setState({
                  display: 1
                })
              })
            })

            $('.cards').each((i) => {
              $('.cards').eq(i).hover((e) => {
                e.stopPropagation()
                $('.cards').eq(i).css('background', '#f6f6f6')
                $('.cards').eq(i).find('img').attr('src',`${blue}`)
                $('.cards').eq(i).find('.watch').css({ background: '#fff', border: "1px solid #00c1de", color: "#00c1de", webkitBoxSizing: 'border-box' })
              }, (e) => {
                e.stopPropagation()
                $('.cards').eq(i).css('background', '#fff')
                 $('.cards').eq(i).find('img').attr('src',`${red}`)
                $('.cards').eq(i).find('.watch').css({ background: '#00c1de', border: "none", color: "#fff" })
              })
            })

          }
          ghosts();
          document.getElementsByClassName('Card')[0].style.left = '16px';
          document.getElementsByClassName('Card')[0].style.opacity = '1';
        }
        );
      }
      document.body.onclick = () => {
        $('.Card').animate({ left: -600, opacity: 0 })
      }
      function openInfo(content, e) {
        var p = e.target;
        var point = new window.BMap.Point(p.getPosition().lng, p.getPosition().lat);
        var infoWindow = new window.BMap.InfoWindow(content, opts);  // 创建信息窗口对象 
        map.openInfoWindow(infoWindow, point); //开启信息窗口
      }
    }
    setTimeout(() => {
      init();
    }, 1000)
  }
  delete = () => {
    this.setState({
      display: 0
    })
  }
  ff() {
    alert("确定要播放");
    var SSOcx = document.getElementById("playOcx");
    console.log(SSOcx)
    SSOcx.SetDeviceInfo("10.0.1.8", 37777, 0, "admin", "admin");
    SSOcx.StartPlay(); //播放
    try {
      if (document.all.ocx.object == null) {
        alert("控件不存在，您还不能使用此功能！")
      } else {
        alert("控件已安装");
      }
    } catch (e) {
      alert("异常调用")
    }

  }

  StopPlay() {
    var SSOcx = document.getElementById("playOcx");
    SSOcx.StopPlay();//暂停
  }
  Capture() {
    var SSOcx = document.getElementById("playOcx");
    SSOcx.GetCapturePicture("d:\\1.bmp");//拍照
  }
  StartRecord() {
    alert("开始录屏");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.SaveRealData("d:\\1.avi"); //录屏
  }
  StopRecord() {
    alert("停止拍照");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.StopSaveRealDate();//停止录制
  }
  render() {
    console.log(arrFlag)
    return (
      <div className="EquipMapMonitore" style={{ padding: "0 16px", overflow: "hidden", background: "#fff" }}>
        <div className="hide" style={{ display: 'block', cursor: 'pointer', position: 'fixed', right: 16, top: 0, zIndex: 99, width: 48, height: 48, background: "rgba(51,55,68,0.5)", display: "flex", justifyContent: 'center', alignItems: 'center' }} onMouseOver={() => { document.getElementsByClassName('hidemesg')[0].style.display = 'block' }} onMouseOut={() => { document.getElementsByClassName('hidemesg')[0].style.display = 'none' }} onClick={() => { browserHistory.push('/safecenter') }}><img src={Down} alt="隐藏监控综合管理" /><span className="hidemesg" style={{ position: 'absolute', width: 168, height: 20, textAlign: 'center', border: '1px solid #000', display: 'none', background: '#fff', right: 24, bottom: 0 }}>隐藏监控综合管理详情页</span></div>
        <div style={{ height: 100, background: "#f9f9fa" }}><img src={Watch} alt="" style={{ float: "left", margin: "14px 16px 0 12px" }} /><h3 style={{ float: "left", fontSize: 24, fontWeight: 100, color: "#373d41", marginTop: 20 }}>监控综合管理</h3></div>
        <div id="allmap1"></div>
        <div className='Card' style={{ width: 360, position: 'absolute', left: -360, top: 116, transition: "all 1s", opacity: 1, fontFamily: "PingFang-SC-Medium", color: "#333744", fontSize: 14, height: '100%', background: "#fff"}}>
        </div>
        <div style={{ width: "50%", height: "50%", background: "pink", float: "left", border: "1px solid white", position: "absolute", right: 16, top: 116, display: this.state.display ? 'block' : 'none' }}>
          <div style={{ width: "100%", height: "10%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 5 }}><span style={{ position: "relative", top: 1 }}><img src="" alt="" /></span> 摄像头的信息</div>
          <div style={{ width: "100%", height: "80%", background: "black" }}></div>
          <div style={{ width: "100%", height: "10%", background: "#333" }}>
            <div className="button_list" style={{ position: 'absolute', left: "50%", width: 200, marginLeft: -100, padding: 0, bottom: 14 }}>
              <div className="zhanting_div" title="暂停" onClick={this.StopPlay.bind(this)}><a href="javascript:;" className="button_  zhanting"></a></div>
              <div title="播放" onClick={this.ff.bind(this)}><a href="javascript:;" className="button_  bofang"></a></div>
              <div title="拍照" onClick={this.Capture.bind(this)}><a href="javascript:;" className="button_  paizhao"></a>
              </div>
              <div title="录像" onClick={this.StartRecord.bind(this)}><a href="javascript:;" className="button_  luxiang"></a></div>
              <div title="停止录像" onClick={this.StopRecord.bind(this)}><a href="javascript:;" className="button_  luxiangt"></a></div>
            </div>
            <span style={{ position: 'absolute', right: 0, bottom: 7 }}><a href="/moni/realtime/screens/1" ><img src={ico_image} alt="全屏显示" /></a> </span>
            <span style={{ position: 'absolute', right: 16, top: 14 }} onClick={this.delete}><a href="javascript:;" ><img src={Delete} alt="" /></a> </span>
          </div>
        </div>
      </div >
    );
  }
}

export default MonitManag;
