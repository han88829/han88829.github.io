import React, { Component } from 'react';
import { Link} from 'react-router';
import ico_image from '../../../../assets/images/monitoring/全屏-icon.png';
import Duosxt_pic from '../../../../assets/images/application/duosxt.png';

class AlarmMonitoringScreens extends Component {
  componentDidMount() {
    var SSOcxs = document.getElementById("div_box");
    SSOcxs.innerHTML = '<object classid="clsid:30209FBC-57EB-4F87-BF3E-740E3D8019D2" id="playOcx" width="100%" height="100%" name="playOcx"><param name="wmode" value="transparent"> <embed width="300" height="200"></embed></object>';
  }

  ff() {
    alert("确定要播放");
    var SSOcx = document.getElementById("playOcx");
    console.log(SSOcx)
    SSOcx.SetDeviceInfo("10.0.1.8", 37777, 0, "admin", "admin");
    SSOcx.StartPlay(); //播放
    try {
      if (document.all.ocx.object == null) {
        alert("控件不存在，您还不能使用此功能！")
      } else {
        alert("控件已安装");
      }
    } catch (e) {
      alert("异常调用")
    }

  }

  StopPlay() {
    var SSOcx = document.getElementById("playOcx");
    SSOcx.StopPlay();//暂停
  }
  Capture() {
    var SSOcx = document.getElementById("playOcx");
    SSOcx.GetCapturePicture("d:\\1.bmp");//拍照
  }
  StartRecord() {
    alert("开始录屏");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.SaveRealData("d:\\1.avi"); //录屏
  }
  StopRecord() {
    alert("停止拍照");
    var SSOcx = document.getElementById("playOcx");
    SSOcx.StopSaveRealDate();//停止录制
  }
  render() {
       let mesid = parseInt(this.props.params.mesid, 10)||1;
    let backTo = '/apply/alarmcentral/'+ mesid;
    return (    
      <div className="MonitorScreen border-left" style={{ position: "absolute", width: "100%", height: "100%", top: 0, left: 0,padding: '12px',overflow:"hidden" }}>
       <div style={{ width: "100%", marginBottom:12,overflow:'hidden'}}>
            <span style={{ display:'block',width: 2, height: 16, marginRight: 10, background: "#88b9e1",float:'left',marginTop:3}}></span>
            <span style={{ display:'block',fontFamily: "苹方中等", color: "#373d41", fontSize: "14px",float:'left'}}>实时监控</span>
          </div> 
        <div style={{ width: "100%", height: "94%", background: "pink", float: "left", border: "1px solid white" }}>
          <div style={{ width: "100%", height: "3%", background: "#333744", color: "white", lineHeight: "26.66px", paddingLeft: 12, position: "relative" }}>摄像头的信息
             <span style={{ position: "absolute", right: 20, marginTop: 4 }}><Link to={backTo} title="退出全屏"><img src={ico_image} alt=""/></Link> </span>
          </div>
          <div style={{ width: "100%", height: "94%", background: "black" }}></div>
          <div style={{ width: "100%", height: "3%", background: "#333" }}>
            <div className="button_list" style={{ width:"200px",position: "absolute", marginLeft: '-100px', left: '50%',padding:0}}>
              <div onClick={this.StopPlay.bind(this)} className="zhanting_div" title="暂停"><a href="javascript:;" className="button_ bofang "></a></div>
              <div onClick={this.ff.bind(this)} title="播放"><a href="javascript:;" className="button_ zhanting "></a></div>
              <div onClick={this.Capture.bind(this)} title="拍照"><a href="javascript:;" className="button_  paizhao"></a>
              </div>
              <div onClick={this.StartRecord.bind(this)} title="录像"><a href="javascript:;" className="button_  luxiang"></a></div>
              <div onClick={this.StopRecord.bind(this)} title="停止录像"><a href="javascript:;" className="button_  luxiangt"></a></div>
            </div>
          </div>
        </div>
      </div>
     
    )
  }
}

export default AlarmMonitoringScreens;