/*
 * @Author: Han.beibei 
 * @Date: 2017-03-09 09:42:14 
 * @Last Modified by: mikey.zhaopeng
<<<<<<< HEAD
 * @Last Modified time: 2017-03-28 15:48:22
=======
 * @Last Modified time: 2017-07-04 11:05:12
>>>>>>> 84a9beca2f3f38cc1a9532537d5e40984652240a
 */
import React, { Component } from 'react';
import { Form, Button, Row, Col, message } from 'antd';
import concentFloor_pic from '../../../assets/images/concentrate/cjzongpingtu.png';
//import './alarmconcenFloor.css';
import { Link } from 'react-router';
import moment from 'moment';
import Alarm from '../../../assets/images/application/hot.png';


class AlarmConcenFloor extends Component {
  constructor() {
    super();
    this.state = {
      isShow: 'none',
      floors:[],
    };
  }
  componentDidMount() {
    const type = parseInt(this.props.params.type, 10);
    if (type) {
      this.setState({
        isShow: 'block',
      });
    } else {
      this.setState({
        isShow: 'none',
      });
    }
     //查建筑相关图片和坐标
    let mesid = parseInt(this.props.params.mesid, 10);//楼id
    //let locationId = parseInt(this.props.params.locationId, 10);//取到设备坐标
      window.rpc.area.getInfoById(mesid).then((result) => {
     
        const floors = { ...result, mapX: result.mapX||0, mapY: result.mapY||0, mapUrl: result.mapUrl };
        this.setState({ floors });
        //console.log(floors,floors.mapX,floors.mapY,floors.mapUrl);
      }, (err) => {
        console.warn(err);function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }
  render() {
    let mesid = parseInt(this.props.params.mesid, 10)||1;
    let locationId = parseInt(this.props.params.locationId, 10);
    let backTo = '/apply/alarmcentral/' + mesid;
    return (

      <div className="AlarmConcenFloor left-border" style={{ fontSize: 14, fontFamily: '苹方中等', padding: '12px', height: '100%' }}>
        <div style={{ width: "100%", marginBottom: 12, overflow: 'hidden' }}>
          <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 3 }}></span>
          <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left' }}>建筑物平面图</span>
        </div>
        <Row style={{ textAlign: 'center', height: '90%' }}>
          <div style={{ position: 'relative', width: '100%', height: '100%' }}>
            <img src={this.state.floors.mapUrl} alt="建筑物总平图" style={{ width: '100%', height: '100%' }} />
            {/*<span id="locationMark" style={{ position: 'absolute', left: '350px', top: '500px', display: 'block', width: 20, height: 20, borderRadius: 50, backgroundColor: '#ff0000', }}></span>*/}
           <img id="locationMark" src={Alarm} alt="建筑物位置" style={{ position: 'absolute', left: this.state.floors.mapX, top: this.state.floors.mapY}} />
          </div>
        </Row>
        <hr style={{ background: '#eee', display: this.state.isShow }} />
        <Row style={{ margin: '0', display: this.state.isShow }}>

          <Button type="success" style={{ backgroundColor: '#ccc', color: '#fff', fontSize: '14px', fontFamily: '微软雅黑', borderRadius: '5px', marginTop: 20 }}><Link to={backTo}>返回</Link></Button>

        </Row>
      </div>
    );
  }
}


export default AlarmConcenFloor;