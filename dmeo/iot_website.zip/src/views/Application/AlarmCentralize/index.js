import React, { Component } from 'react';
import { Row, Col, Card, Layout } from 'antd';
import { browserHistory } from 'react-router';
import AlarmConcenRoute from './AlarmConcenRoute';//最近警力
import AlarmConcenFloor from './AlarmConcenFloor';//建筑物平面图
import AlarmConcenBasicMes from './AlarmConcenBasicMes';//基础信息
import AlarmConcenResources from './AlarmConcenResources';//资源分布
import AlarmConcenEquipment from './AlarmConcenEquipment';//设备位置图
import AlarmRealTimeMonitor from './AlarmRealTimeMonitor';//实时监控
import AlarmEquipMapMonitore from './AlarmEquipMapMonitore';//园区地图监控
import applicationDown_pic from '../../../assets/images/application/down.png';
import './alarmcentralize.css';

const { Header, Content } = Layout;

 class AlarmCentralize extends Component {

    state = {
       isShowmes: 'none',
    }
    isShowMes= (mark) =>{
      if(mark){
        this.setState({
            isShowmes: 'block',
        });
      }else{
         this.setState({
            isShowmes: 'none',
        });
      }
    }
  render() {
    let mesid = this.props.params.mesid||1;
     let type = this.props.params.type=0;
     let locationId = this.props.params.locationId;
    //console.log(mesid);
    return (

      <Layout className="ConcenHandle">
        <Header>
        <div className="ConcenHandle-header">

          <dl className="ConcenHandle-chooseicon" onMouseOver={(mark) => this.isShowMes(1)} onMouseOut={(mark) => this.isShowMes(0)} onClick={() => browserHistory.push(`/apply/alarmequipmapmonitore/${mesid}`)}>
            <dt className="choosepic">
            <img src={applicationDown_pic} alt="隐藏页面" style={{ paddingTop: 16 }} />
            </dt>
            <dd style={{width:108,height:20,position:'absolute',top:37,right:30,border: '1px solid #666',paddingTop:9,display:this.state.isShowmes}}>
           隐藏页面
            </dd>
            </dl>
          <div style={{height:66,overflow: 'hidden'}}>
       
          <span style={{ display: 'block', width: 2, height: 16, marginRight: 10, background: "#88b9e1", float: 'left', marginTop: 25 }}></span>
          <span style={{ display: 'block', fontFamily: "苹方中等", color: "#373d41", fontSize: "14px", float: 'left', marginTop: 33 }}>报警六屏</span>
        </div>
         {/*<span style={{ width: '100%', height: 30, fontSize: 12, fontFamily: 'PingFang-SC-Medium', background: '#f9f9f9', color: '#666', border: '1px solid rgb(211, 211, 211)',display:'block',textAlign:'left',paddingLeft:12,paddingTop:13}}>以下信息均为平台提供....</span>*/}
        
        </div>
        </Header>
        <Content style={{ textAlign: 'center' }}>
          <div style={{ padding: '5px 15px 0', height: 'calc(100vh - 90px)' }}>

            <Row gutter={8}>
              <Col span={7}>
                <Row gutter={8} style={{ height: 'calc(100vh - 90px)', color: '#FFF' }}>
                  <Col span={6} style={{ height: 'calc(33vh - 43px)', width: '100%' }}>
                    <Card style={{ height: 'calc(33vh - 43px)', padding: '0', position: 'relative' }} >
                      <span onClick={() => browserHistory.push(`/apply/alarmconcenbasicmes/${mesid}/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                      <AlarmConcenBasicMes params={this.props.params} />
                    </Card>
                  </Col>

                  <Col span={6} style={{ height: 'calc(33vh - 43px)', width: '100%', marginTop: 24 }}>
                    <Card style={{ height: 'calc(33vh - 43px)', padding: '0',position: 'relative' }} >
                      <span onClick={() => browserHistory.push(`/apply/alarmconcenroute/${mesid}/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                      <AlarmConcenRoute params={this.props.params} />
                    </Card>
                  </Col>
                  <Col span={6} style={{ height: 'calc(33vh - 43px)', width: '100%', marginTop: 24 }}>
                    <Card style={{ height: 'calc(33vh - 43px)', padding: '0',  position: 'relative' }} >
                      <span onClick={() => browserHistory.push(`/apply/alarmconcenresources/${mesid}/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                      <AlarmConcenResources params={this.props.params} />
                    </Card>
                  </Col>
                </Row>
              </Col>



              <Col span={10}>
                <Row gutter={8} style={{ height: 'calc(100vh - 80px)', color: '#FFF' }}>
                  <Col span={12} style={{ height: 'calc(99vh - 80px)', width: '100%' }}>
                  
                      <Card style={{ height: 'calc(99vh - 80px)', padding: '0', position: 'relative' }} >
                        <span onClick={() => browserHistory.push(`/apply/alarmequipmapmonitore/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                        <AlarmEquipMapMonitore params={this.props.params} />
                      </Card>
                    
                  </Col>
                </Row>
              </Col>


              <Col span={7}>
                <Row gutter={8} style={{ height: 'calc(100vh - 80px)', color: '#FFF' }}>
                  <Col span={6} style={{ height: 'calc(33vh - 43px)', width: '100%' }}>
                    
                    <Card style={{ height: 'calc(33vh - 43px)', padding: '0', position: 'relative' }} >
                      <span onClick={() => browserHistory.push(`/apply/alarmrealtimemonitor/screens/${mesid}/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                      <AlarmRealTimeMonitor/>
                    </Card>
                   
                  </Col>

                  <Col span={6} style={{ height: 'calc(33vh - 35px)', width: '100%', marginTop: 16 }}>
                    <Card style={{ height: 'calc(33vh - 35px)', padding: '0', position: 'relative' }} >
                      <span onClick={() => browserHistory.push(`/apply/alarmconcenfloor/${mesid}/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                      <AlarmConcenFloor params={this.props.params} />
                    </Card>
                  </Col>
                  <Col span={6} style={{ height: 'calc(33vh - 35px)', width: '100%', marginTop: 16 }}>
                    <Card style={{ height: 'calc(33vh - 35px)', padding: '0', position: 'relative' }} >
                      <span onClick={() => browserHistory.push(`/apply/alarmconcenequipment/${mesid}/${this.props.params.type=1}`)} style={{ background: '#00c1de', position: 'absolute', bottom: 0, right: 0, color: '#f2f2f2', height: 24, width: 60, zIndex: 3, fontSize: 12, fontFamily: 'PingFang-SC-Medium',paddingTop: 2,cursor: 'pointer'}}>点击全屏</span>
                     <AlarmConcenEquipment params={this.props.params} />
                    </Card>
                  </Col>
                </Row>
              </Col>
            </Row>
          </div>
        </Content>
      </Layout>

    );
  }
}

export default AlarmCentralize;