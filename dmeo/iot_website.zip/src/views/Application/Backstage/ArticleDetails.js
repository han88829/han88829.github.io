import React, { Component } from 'react';
import { Link } from 'react-router';
import {Button} from 'antd';
import moment from 'moment';
import $ from 'jquery';
//import Alarm from '../../../../../../../../../../assets/images/application/hot.png';
import { extendObservable } from 'mobx';
import { observer } from 'mobx-react';
class appState {
  constructor() {
    extendObservable(this, {
      
  obj:{
    name:'',
    body:'',
    userId:'',
    type:''}
    })
  }
}
const ArticleDetailsC = observer(class appState extends React.Component {
//class ArticleDetails extends Component {
  state={
    obj:{
    name:'',
    body:'',
    userId:'',
    type:''
   }
  }
  //componentDidMount(mesid) {
    componentWillReceiveProps(mesid) {
        //console.log(this.props.id);
        let articleId = JSON.parse(sessionStorage.getItem('articleId')) || null;
        let id=this.props.id||articleId;
        window.rpc.article.getInfoById(id).then(res=>{
          window.rpc.alias.getValueByName('article.type').then(name=>{
            window.rpc.user.getInfoById(res.userId).then(user=>{
              // console.log(user);
           let data={...res,type:name[res.type],userId:user.name}
          // console.log(data)
           this.setState({obj:data});
           this.props.appState.obj=data;
           //console.log($('#body'))
           $('#body')[0].innerHTML=data.body;
           })
          })
          
        },err=>{
          console.warn(err);
        })
    }
  render() {
    return (
      <div style={{width:'100%'}}>
         
           <div style={{ overflow: 'hidden', paddingBottom: '1.125rem', color: '#333', fontSize: '0.75rem', fontFamily: '苹方中等',padding:'20px 0 10px 20px'}}>
             <div style={{ float: 'left', width: 75, height: '22px', linHeight: '22px', zIndex: 99, backgroundColor: '#fff', marginTop: 10 }}>
                <Link to=''  onClick={() => this.setState({warnInfoId:null})} style={{ padding: '2px 12px 2px 10px', margin: '8px 0', fontSize: '0.75rem', color: '#373e41', borderLeft: '2px solid #88b7e0' }}>解决方案</Link>
             </div>
            </div>
            <div style={{width: '60%',margin: '0 20%',fontSize: '14px'}}>
             <h3 style={{textAlign:'center',fontSize:28}}>{this.props.appState.obj.name||'题目'}</h3>
             <div style={{textAlign:'center',color:'#999'}}>{this.props.appState.obj.userId}</div>
             <div style={{fontSize:12,color:"#ccc"}}>分类：{this.props.appState.obj.type}</div>
             <div id='body' style={{padding:'20px 0'}}></div>
          </div>
      </div>
    )
  }
})
class ArticleDetails extends Component {
  render() {
    return (
      <ArticleDetailsC appState={new appState()} id={this.props.id}  />
    )
  }
}

export default ArticleDetails;