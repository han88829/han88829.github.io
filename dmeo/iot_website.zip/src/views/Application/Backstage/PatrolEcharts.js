import React, {Component} from 'react';
import echarts from 'echarts';
import moment from 'moment';
class PatrolEcharts extends Component {
  componentDidMount() {
    let colors = ['#5793f3', '#d14a61', '#675bba', 'yellow'];
    let myChartOne = echarts.init(document.getElementById('PatrolBackEcharts'));
    //时间暂定为当前年的月份
    let Year = new Date().getFullYear();
    let Month = new Date().getMonth() + 1;
    //console.log(Year);
    //let after=new Date(`${Year}-${Month.toString().length === 1 ? '0' + Month: Month}`);
    let after = new Date();
    let beforeM = new Date(`${Year}-01`);
    //console.log(after);
    //console.log(beforeM);
    let values = {
      createTime: [beforeM, after]
    };
    //console.log(values);
    let dataArr = [];
    //const reduces = (new Date(after).getTime()-new Date(before).getTime())/86400/1000;
    for (let i = 1; i <= Month; i++) {
      (function () { //afer=>d1Ms
        dataArr.push(`${Year}-${i.toString().length === 1 ? '0' + i: i}`)
      })(i)
    }
    // console.log(dataArr)
    if (window.rpc) {
      window.rpc.position.log.getTrendCountFieldByContainer(values, "state", "month").then(data => {
        // console.log(data);
        //此处数据处理
        let arr = [],
          arr1 = [];
        for (var i in data) {
          arr.unshift({
            name: i,
            value: data[i][1] || 0,
            key: i,
            createTime: moment(new Date()).format('YYYY-MM-DD')
          });
          arr1.unshift({
            name: i,
            value: data[i][2] || 0,
            key: i,
            createTime: moment(new Date()).format('YYYY-MM-DD')
          });
        }
        let nomalArr = chartArr(dataArr, arr);
        let specialArr = chartArr(dataArr, arr1);
        function chartArr(dataArr, arr) {
          let nomalArr = [];
          for (let i = 0; i < dataArr.length; i++) {
            for (let j = 0; j < arr.length; j++) {
              if (dataArr[i] == arr[j]['name']) {
                let value = arr[j]['value']
                getValueArr(value);
                break; //continue
              } else {
                if (j === (arr.length - 1)) {
                  getValueArr(0);
                  //console.log(j+'==i:='+i)
                }
              }
            }
          }
          function getValueArr(value) {
            nomalArr.push(value)
          }
          return nomalArr;
        }
        let option = {
          tooltip: {
            trigger: 'axis',
          },
          legend: {
            x: 'right',
            data: ['正常', '异常']
          },
          grid: {
            containLabel: false
          },
          yAxis: {
            type: 'value',
            name: '巡逻次数',
            axisLabel: {
              formatter: '{value} '
            },
            splitLine: {
              show: false
            }
          },
          xAxis: {
            type: 'category',
            name: '巡逻时间',
            axisLine: {
              onZero: false
            },
            axisLabel: {
              //formatter: '{value} km'
            },
            splitLine: {
              show: true
            },
            boundaryGap: false,
            data: dataArr //['0', '10', '20', '30', '40', '50', '60']
          },
          series: [{
              name: '正常',
              type: 'line',
              smooth: true,
              symbol: 'circle',
              symbolSize: 5,
              showSymbol: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              areaStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: 'rgba(127,255,212, 0.8)' // 'rgba(137, 189, 27, 0.3)'
                  }, {
                    offset: 0.8,
                    color: 'rgba(127,255,212, 0.3)'
                  }], false),
                }
              },
              itemStyle: {
                normal: {
                  color: 'rgb(127,255,212)',
                  borderColor: 'rgba(127,255,212,0.9)',
                  borderWidth: 12
                }
              },
              data: nomalArr
            },
            {
              name: '异常',
              type: 'line',
              smooth: true,
              symbol: 'circle',
              symbolSize: 5,
              showSymbol: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              areaStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: 'rgba(0,193,222, 0.8)' // 'rgba(137, 189, 27, 0.3)'
                  }, {
                    offset: 0.8,
                    color: 'rgba(0,193,222, 0.3)'
                  }], false),
                }
              },
              itemStyle: {
                normal: {
                  color: 'rgb(208,71,82)',
                  borderColor: 'rgba(208,71,82,0.7)',
                  borderWidth: 12
                }
              },
              data: specialArr
            },
          ]
        };
        myChartOne.setOption(option);
      }, err => {
        console.warn(err);
        function existError(err) {
          let t = err.toString();
          let r = /E(\d+): (.+)/;
          let e = r.exec(t);
          if (e && e.length >= 3) {
            alertError(e[1], e[2]);
          }
        }
        function alertError(code, msg) {
          console.log('CODE:', code, "MSG:", msg);
          if (msg = 'Insufficient permissions') {
            alert(`暂无权限!`);
          }
        }
        existError(err);
      })
    } else {
      let option = {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          x: 'left',
          data: ['正常', '异常']
        },
        grid: {
          containLabel: false
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: '{value} 次'
          },
          splitLine: {
            show: false
          }
        },
        xAxis: {
          type: 'category',
          axisLine: {
            onZero: false
          },
          axisLabel: {
            //formatter: '{value} km'
          },
          splitLine: {
            show: true
          },
          boundaryGap: false,
          data: dataArr //['0', '10', '20', '30', '40', '50', '60']
        },
        series: [{
            name: '正常',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 5,
            showSymbol: false,
            lineStyle: {
              normal: {
                width: 1
              }
            },
            areaStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: 'rgba(72,209,204, 0.8)' // 'rgba(137, 189, 27, 0.3)'
                }, {
                  offset: 0.8,
                  color: 'rgba(72,209,204, 0.1)'
                }], false),
              }
            },
            itemStyle: {
              normal: {
                color: 'rgb(72,209,204)',
                borderColor: 'rgba(72,209,204,0.27)',
                borderWidth: 12
              }
            },
            data: [10, 12, 11, 4, 0, 0, 2] //nomalArr
          },
          {
            name: '异常',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 5,
            showSymbol: false,
            lineStyle: {
              normal: {
                width: 1
              }
            },
            areaStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: 'rgba(208,71,82, 0.8)' // 'rgba(137, 189, 27, 0.3)'
                }, {
                  offset: 0.8,
                  color: 'rgba(208,71,82, 0.1)'
                }], false),
              }
            },
            itemStyle: {
              normal: {
                color: 'rgb(208,71,82)',
                borderColor: 'rgba(208,71,82,0.27)',
                borderWidth: 12
              }
            },
            data: [20, 12, 1, 4, 0, 0, 3] //specialArr
          },
        ]
      };
      myChartOne.setOption(option);
    }
  }
  render() {
    return ( 
      <div>
        <div id = "PatrolBackEcharts" style = {{height: '360px',width: '100%'}} > </div> 
      </div>
    )
  }
}

export default PatrolEcharts;