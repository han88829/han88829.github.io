import React, { Component } from 'react';
import echarts from 'echarts';
import moment from 'moment';
class SafeEcharts extends Component {
  componentDidMount(){
      let  colors = ['#5793f3', '#d14a61', '#675bba','yellow'];
    // let myChartOne = echarts.init(document.getElementById('PatrolBackEcharts'));
     let Year=new Date().getFullYear();
     let Month=new Date().getMonth()+1;
     //console.log(Year);
     //let after=new Date(`${Year}-${Month.toString().length === 1 ? '0' + Month: Month}`);
     let after=new Date();
     let beforeM =new Date(`${Year}-01`); 
    //console.log(after);
    //console.log(beforeM);
    let values={createTime:[beforeM,after]};
    //console.log(values);
        let dataArr=[];
         //const reduces = (new Date(after).getTime()-new Date(before).getTime())/86400/1000;
          for(let i=1; i <= Month; i++) {  
           (function () {//afer=>d1Ms
             dataArr.push(`${Year}-${i.toString().length === 1 ? '0' + i: i}`)
           })(i)
        }
    var data_val=[20, 16, 21, 30, 40, 3, 9],
    data_v=[20, 12, 9, 0, 40, 20, 20];
    //let xAxis_val=['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
     let myChartThree = echarts.init(document.getElementById('SafeBackEcharts'));
    var data_val1=[0,0,0,0,0,0,0];
           //data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6]//specialArr
   
    let   option = {
      backgroundColor:'#fff',
      grid:{
        left:10,
        top:'10%',
        bottom:20,
        right:40,
        containLabel:true
      },
      tooltip:{
        show:true,
        backgroundColor:'#384157',
        borderColor:'#384157',
        borderWidth:1,
        formatter:'{b}:{c}',
        extraCssText:'box-shadow: 0 0 5px rgba(0, 0, 0, 1)'
      },
      legend:{
        right:0,
        top:0,
        data:['合格','不合格'],
         textStyle:{
            color :'#5c6076'
        }
      },
    
      xAxis: {
        data:dataArr,
        boundaryGap:false,
        axisLine:{
            show:false
        },
         axisLabel: {
            textStyle: {
                color: '#384157',
                opacity:1
            }  
        },
        axisTick:{
            show:false
        }
      },
      yAxis: { 
        ayisLine:{
            show:false
        },
        //  axisLabel: {
        //     textStyle: {
        //         color: '#5c6076'
        //     }  
        // },
        splitLine:{
            show:true,
            lineStyle:{
                color:'#fff'
            }
        },
        axisLine: {
                lineStyle: {
                    color: '#384157'
                }
            }
      },
      series: [
        {
            type: 'bar',
            name:'linedemo',
            tooltip:{
                show:false
            },
            animation:false,
            barWidth:1.4,
            hoverAnimation:false,
            data:data_val,
            itemStyle:{
                normal:{
                    color:'#00c1de',
                    opacity:0.6,
                    label:{
                        show:false
                    }
                }
            }
          },
          {
            type: 'line',
            name:'合格',
            
            animation:false,
            symbol:'circle',
    
            hoverAnimation:false,
            data:data_val1,
            itemStyle:{
                normal:{
                    color:'#00c1de',
                    opacity:0,
                }
            },
            lineStyle:{
                normal:{
                    width:1,
                    color:'#384157',
                    opacity:1
                }
            }
          },
          {
            type: 'line',
            name:'linedemo',
            smooth:true,
            symbolSize:10,
            animation:false,
            lineWidth:1.2,
            hoverAnimation:false,
            data:data_val,
            symbol:'circle',
            itemStyle:{
                normal:{
                    color:'#00c1de',
                    shadowBlur: 40,
                    label:{
                        show:true,
                        position:'top',
                        textStyle:{
                            color:'#00c1de',
                    
                        }
                    }
                }
            },
           areaStyle:{
                normal:{
                    color:'#00c1de',
                    opacity:0.08
                }
            }
            
          },    {
            type: 'bar',
            name:'linedemo',  
            tooltip:{
                show:false
            },
            animation:false,
            barWidth:1.4,
            hoverAnimation:false,
            data:data_v,
            itemStyle:{
                normal:{
                    color:'#f17a52',
                    opacity:0.6,
                    label:{
                        show:false
                    }
                }
            }
          },
         
          {
            type: 'line',
            name:'不合格',
            smooth:true,
            symbolSize:10,
            animation:false,
            lineWidth:1.2,
            hoverAnimation:false,
            data:data_v,
            symbol:'circle',
            itemStyle:{
                normal:{
                    color:'#f17a52',
                    shadowBlur: 40,
                    label:{
                        show:true,
                        position:'top',
                        textStyle:{
                            color:'#f17a52',
                    
                        }
                    }
                }
            },
           areaStyle:{
                normal:{
                    color:'#f17a52',
                    opacity:0.08
                }
            }
            
          }
      ]
   };
   myChartThree.setOption(option);
  }
  render() {
    return (
      <div>
         	<div id="SafeBackEcharts" style={{ height: '340px', width: '100%'}}></div>
      </div>
    )
  }
}

export default SafeEcharts;