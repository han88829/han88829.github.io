import React, { Component } from 'react';
import echarts from 'echarts';
import moment from 'moment';
//let   rStateList=['/','正常', '异常', '离线'];
class EquipEcharts extends Component {
    componentDidMount(){
        //需要加上时间，检查已有接口是否有

        // window.rpc.device.getCountFieldByContainer({}, 'dstate').then((rest) => {
        //        // window.rpc.alias.getValueByName('device.state')
		// 	let rState = [];
		// 	for (let i = 1; i < rStateList.length; i++) {
		// 		rState.push({ key: i, value: rest[i] || 0, name: rStateList[i] });
		// 	}
		// 	this.setState({
		// 		data: rState
		// 	})
		// 	this.props.stateMountState.tableDate = rState;
		// 	let myChart = echarts.init(document.getElementById('DeviceStateMountEcharts'));

		// 	myChart.setOption({
		// 		tooltip: {
		// 			trigger: 'item',
		// 			formatter: "{a} <br/>{b}: {c} ({d}%)"
		// 		},
		// 		legend: {
		// 			orient: 'vertical',
		// 			x: 'left',
		// 			data: this.state.data.map(x => x.name)
		// 		},
		// 		series: [
		// 			{
		// 				name: '设备状态',
		// 				type: 'pie',
		// 				radius: ['50%', '70%'],
		// 				avoidLabelOverlap: false,
		// 				label: {
		// 					normal: {
		// 						show: false,
		// 						position: 'center'
		// 					},
		// 					emphasis: {
		// 						show: true,
		// 						textStyle: {
		// 							fontSize: '30',
		// 							fontWeight: 'bold'
		// 						}
		// 					}
		// 				},
		// 				labelLine: {
		// 					normal: {
		// 						show: false
		// 					}
		// 				},
		// 				data: [...rState]
		// 			}
		// 		]
		// 	});
		// }, (err) => {
		// 	console.warn(err);
		// 	 function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
		// });


     //let  colors = ['#5793f3', '#d14a61', '#675bba','yellow'];
     let myChartTwo = echarts.init(document.getElementById('DeviceStateMountEcharts'));
     let Year=new Date().getFullYear();
     let Month=new Date().getMonth()+1;
     //console.log(Year);
     //let after=new Date(`${Year}-${Month.toString().length === 1 ? '0' + Month: Month}`);
     let after=new Date();
     let beforeM =new Date(`${Year}-01`); 
    //console.log(after);
    //console.log(beforeM);
    let values={createTime:[beforeM,after]};
    //console.log(values);
        let 	 dataArr=[];
         //const reduces = (new Date(after).getTime()-new Date(before).getTime())/86400/1000;
          for(let i=1; i <= Month; i++) {  
           (function () {//afer=>d1Ms
              dataArr.push(`${Year}-${i.toString().length === 1 ? '0' + i: i}`)
           })(i)
        }
        //console.log(dataArr)
        //equip暂无接口，要使用真实数据
    if(3===4){
      window.rpc.position.log.getTrendCountFieldByContainer(values,"state","date").then(data=>{
       // console.log(data);
        //此处数据处理
        let arr=[],arr1=[];
       for (var i in data) {
			arr.unshift({ name: i, value:data[i][1] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') });
            arr1.unshift({ name: i, value:data[i][2] || 0, key: i, createTime: moment(new Date()).format('YYYY-MM-DD') });
		}
       let nomalArr=chartArr(dataArr,arr);
       let specialArr=chartArr(dataArr,arr1);
       function chartArr(dataArr,arr){
          let nomalArr=[];
          for(let i=0;i<dataArr.length;i++){
           for(let j=0;j<arr.length;j++){
           if(dataArr[i]==arr[j]['name']){
            let value=arr[j]['value']
                 getValueArr(value);
                 break;//continue
           }else{ if(j===(arr.length-1)){
              getValueArr(0);
              //console.log(j+'==i:='+i)
           }
           }
         }
        }
         function getValueArr(value){
         nomalArr.push(value)   
       }
       return nomalArr;
       }
      
    
      // console.log(nomalArr);
      // console.log(specialArr);
      //此处数据处理

       // data:['正常','异常']
   
         //   data:['2017-01-01','2017-01-02','2017-01-03','2017-01-04','2017-01-05','2017-01-06','2017-01-07'] //dataArr


        //data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6]//nomalArr //[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3]
        //data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6]//specialArr
   let option = {
   
    tooltip: {
        trigger: 'axis'
    },
    legend: {
		 x: 'right',
        data:['合格','不合格']
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },

    xAxis: {
        type: 'category',
        name:'时间',
        boundaryGap: false,
        data: dataArr
    },
    yAxis: {
        type: 'value',
        name:'设备数量',
    },
    series: [
        {
         name:'合格',
         type:'line',
         stack: '总量',
         smooth: true,
         symbol: 'circle',
         symbolSize: 5,
         showSymbol: false,
            data:[120, 132, 101, 134, 90, 230, 210]//nomalArr
        },
        {
         name:'不合格',
         type:'line',
         smooth: true,
         symbol: 'circle',
         symbolSize: 5,
         showSymbol: false,
            stack: '总量',
            data:[220, 182, 191, 234, 290, 330, 310]//specialArr
        }
    ]
   };
    myChartTwo.setOption(option);
    },err=>{
      console.warn(err);
       function existError(err){    let t = err.toString();    let r = /E(\d+): (.+)/;    let e = r.exec(t);     if(e && e.length >= 3){ alertError(e[1],e[2]);  }   }  function alertError(code,msg){  console.log('CODE:',code,"MSG:",msg);  if(msg='Insufficient permissions'){    alert(`暂无权限!`);  }    } existError(err);
    })
  }else{
   let  option = {
    
     tooltip: {
        trigger: 'axis'
     },
     legend: {
		  x: 'right',
        data:['合格','不合格']
     },
     grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
     },
 
     xAxis: {
        type: 'category',
        boundaryGap: false,
        data: dataArr
     },
     yAxis: {
        type: 'value'
     },
     series: [
        {
         name:'合格',
         type:'line',
         stack: '数量',
         smooth: true,
         symbol: 'circle',
         symbolSize: 5,
         showSymbol: false,
		 itemStyle: {
          normal: {
            color: 'rgb(0,193,222)',
            borderColor: 'rgba(0,193,222,0.27)',
            borderWidth: 12

          }
        },
            data:[120, 132, 101, 134, 90, 230, 210]
        },
        {
         name:'不合格',
         type:'line',
         smooth: true,
         symbol: 'circle',
         symbolSize: 5,
         showSymbol: false,
		itemStyle: {
          normal: {
            color: '#EE9A00',
            borderColor: '#EE9A00',
            borderWidth: 12

          }
        },
        stack: '总量',
         data:[220, 182, 191, 234, 290, 330, 310]
        }
     ]
    };
    myChartTwo.setOption(option);
 
    }
  }
  render() {
    return (
      <div>
          	<div id="DeviceStateMountEcharts" style={{ height: '340px', width: '100%'}}></div>
      </div>
    )
  }
}

export default EquipEcharts;