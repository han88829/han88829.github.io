/*
 * @Author: Han.beibei 
 * @Date: 2017-03-15 17:04:25 
 * @Last Modified by: Han.beibei
 * @Last Modified time: 2017-03-30 10:18:46
 */
import React, { Component } from 'react';
import { Row, Col } from 'antd';
import echarts from 'echarts';
import china from '../../../assets/images/logined/map-china.png';
import right from '../../../assets/images/logined/page-turning.png';
// import '../newLogined.css';

class LeftGraphs extends Component {
	componentDidMount(){
        //图一
		let myChartOne = echarts.init(document.getElementById('LeftGraphsOne'));
		myChartOne.setOption({
				title: {
        text: '城市定位图',
				color:'#04ffff',
        textStyle: {
            fontWeight: 'normal',
            fontSize: 14,
            color: '#04ffff'
        },
        left: '10%'
					},
				tooltip:{
					show:true,
					formatter:"{b} {c}"
				},
				grid:{
					left:'40%',
					top:'20%',
					bottom:'0',
					right:'0'
				},
					xAxis : [
							{
									max:100,
									type : 'value',
									nameTextStyle:{
											color:'#04ffff',
									},
									textStyle:{
										color:'#04ffff',
									},
									axisTick: {
									show: false,
								},
								axisLine: {
										show:false,
								},
								axisLabel: {
										show:false
								},
								splitLine: {
										show: false
								}
							}
					],
					yAxis : [
							{
									type : 'category',
									data : ['北京','上海','杭州','宁波','合肥','苏州'],
									nameTextStyle:{
										color:'#04ffff',
										fontSize:'18px'
									},
									axisTick: {
										show: false,
								},
								axisLine: {
										show: true,
										lineStyle:{  
                        color:'#04ffff',  
                    }  
								}
							}
					],
					series : [
							{ 
									name:' ',
									type: 'bar',
									textStyle:{
										color:'#04ffff'
									},
									barWidth:16,
									silent:true,
									itemStyle: {
											normal: {color: '#f2f2f2'}
									},
									barGap:'-100%',
									barCategoryGap:'50%',
									data: [17, 20, 45, 56, 60, 64].map(function(d){
											return 100
									}),
							},
							{
									name:' ',
									type:'bar',
									barWidth:16,
									label: {
										normal: {
												show: true,
												position: 'right',
												formatter: '{c}%',
										}
								},
									data:[
										{
													value:17,
													itemStyle:{
															normal:{color:'#b7ce9e'}
													}
										},{
													value:20,
													itemStyle:{
															normal:{color:'#acd680'}
													}
											},{
													value:45,
													itemStyle:{
															normal:{color:'#88e186'}
													}
											},{
													value:56,
													itemStyle:{
															normal:{color:'#81e7cf'}
													}
											},{
													value:60,
													itemStyle:{
															normal:{color:'#82dae6'}
													}
											},{
													value:64,
													itemStyle:{
															normal:{color:'#80cbc4'}
													}
											}
									],
									markLine : {
											label:{
												normal:{
													show:true,
													position:'end',
													formatter:'{b}{c}%'
												}
											},
										lineStyle:{
											normal:{
												color:'#04ffff'
											}
										},
										symbol:'none',
											data : [
												{name:'平均数',xAxis:30}
											]
									}
							}
					]
		})
    
		//图二
		let myChartTwo = echarts.init(document.getElementById('LeftGraphsTwo'));
		var dataBJ = [ [134,96,165,41,55,55],];
		var dataGZ = [[106,116,188,101,222,135],];
		var dataSH = [ [187,143,201,133,77,55]];
		var dataTJ= [[100,190,111,67,160,89]]
		var indicatorData = [
		{name: 'Mar', max: 300},
		{name: 'Feb', max: 300},
		{name: 'Lan', max: 300},
		{name: 'Ocr', max: 300},
		{name: 'Nov', max: 300},
		{name: 'Jar', max: 300},
	 ];
      var lineStyle = {
          normal: {
              width: 1,
              opacity: 0.5
          }
      };

      var option = {
                  color:["#cc6475","#c29764","#58a371","#e22b2b","#3f83c5","#09d5dc"],
                  backgroundColor: 'none',
                  legend: {
                	  orient: 'vertical',
	                  x: 'right',
                     data: [{name:'Mar', icon: 'circle', textStyle:{color:"#cc6475"}},{name:'Feb',icon: 'circle',textStyle:{color:"#c29764"}}, {name:'Lan',icon: 'circle',textStyle:{color:"#58a371"}},{name:'Ocr',icon: 'circle',textStyle:{color:"#e22b2b"}}],
	    
                  },
                  tooltip: {},
                  radar: {
                	  center:['50%','50%'],
                      indicator: indicatorData,
                      radius: '75%',
                      splitNumber: 1,
                      name: {
                          textStyle: {
                              color: '#fff',
                              fontSize: 12
                          }
                      },
                      splitLine: {
                    	  
                          lineStyle: {
                              color:'#4f8bbe',
                              opacity:0.5
                          }
                      },
                      splitArea: {
                          show: true,
                          areaStyle:{
                              color:'#0d6dba',
                              opacity:0.1
                          }
                      },
                      axisLine: {
                          show:true,
                          lineStyle: {
                              color:'#4f8bbe',
                              opacity:0.5
                          }
                      }
                  },
                  series: [
							{
							    name: '雷达线ALL',
							    type: 'radar',
							    silent:true,
							    lineStyle: {
							        normal: {
							      	  type:'solid',
							      	  color:"#375f9a",
							            width: 2,
							            opacity: 1,
							        
							        }
							    },
							    data: [[300,300,300,300,300,300]],
							    
							    itemStyle: {
							        normal: {
							      	  opacity:0
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: '#0d6dba',
							            opacity: 0.1
							        }
							    }
							},
							{
							    name: '雷达线2',
							    type: 'radar',
							    silent:true,
							    lineStyle: {
							        normal: {
							      	  type:'solid',
							      	  color:"#375f9a",
							            width: 2,
							            opacity: 0.8,
							        
							        }
							    },
							    data: [[250,250,250,250,250,250]],
							    
							    itemStyle: {
							        normal: {
							      	  opacity:0
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: 'rgba(0,0,0,0)',
							            opacity: 0.1
							        }
							    }
							},
							{
							    name: '雷达线3',
							    type: 'radar',
							    silent:true,
							    lineStyle: {
							        normal: {
							      	  type:'solid',
							      	  color:"#375f9a",
							            width: 2,
							            opacity: 0.6,
							        
							        }
							    },
							    data: [[200,200,200,200,200,200]],
							    
							    itemStyle: {
							        normal: {
							      	  opacity:0
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: 'rgba(0,0,0,0)',
							            opacity: 0.1
							        }
							    }
							},
							{
							    name: '雷达线4',
							    type: 'radar',
							    silent:true,
							    lineStyle: {
							        normal: {
							      	  type:'solid',
							      	  color:"#375f9a",
							            width: 2,
							            opacity: 0.4,
							        
							        }
							    },
							    data: [[150,150,150,150,150,150]],
							    
							    itemStyle: {
							        normal: {
							      	  opacity:0
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: 'rgba(0,0,0,0)',
							            opacity: 0.1
							        }
							    }
							},
							{
							    name: '雷达线5',
							    type: 'radar',
							    silent:true,
							    lineStyle: {
							        normal: {
							      	  type:'solid',
							      	  color:"#375f9a",
							            width: 2,
							            opacity: 0.2,
							        
							        }
							    },
							    data: [[100,100,100,100,100,100]],
							    
							    itemStyle: {
							        normal: {
							      	  opacity:0
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: 'rgba(0,0,0,0)',
							            opacity: 0.1
							        }
							    }
							},
							{
							    name: '雷达线6',
							    type: 'radar',
							    silent:true,
							    lineStyle: {
							        normal: {
							      	  type:'solid',
							      	  color:"#375f9a",
							            width: 2,
							            opacity: 0.2,
							        
							        }
							    },
							    data: [[50,50,50,50,50,50]],
							    
							    itemStyle: {
							        normal: {
							      	  opacity:0
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: 'rgba(0,0,0,0)',
							            opacity: 0.1
							        }
							    }
							},
							{
							    name: 'Mar',
							    type: 'radar',
							    lineStyle: lineStyle,
							    data: dataBJ,
							    symbolSize:4,
							    itemStyle: {
							        normal: {
							        	borderColor: '#fc20ff',
							             borderWidth:4,
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: '#fc20ff',
							            opacity: 0.5
							        }
							    }
							},
							{
							    name: 'Feb',
							    type: 'radar',
							    lineStyle: lineStyle,
							    data: dataSH,
							    symbolSize:2,
							    itemStyle: {
							        normal: {
							        	borderColor: '#ffc90e',
							            borderWidth:4,
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: '#ffc90e',
							            opacity: 0.5
							        }
							    }
							},
							{
							    name: 'Lan',
							    type: 'radar',
							    z:0,
							    lineStyle: lineStyle,
							    data: dataGZ,
							    symbolSize:4,
							    itemStyle: {
							        normal: {
							        	borderColor: '#99d9ea',
							            borderWidth:4,
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: '#99d9ea',
							            opacity: 0.5
							        }
							    }
							},
							{
                          name: '雷达线',
                          type: 'radar',
                          silent:true,
                          lineStyle: {
                              normal: {
                            	  type:'dotted',
                                  width: 4,
                                  opacity: 0.3,
                              
                              }
                          },
                          data: [[6,5,6,4,2,5]],
                          
                          itemStyle: {
                              normal: {
                            	  opacity:0
                                  
                              }
                          },
                          areaStyle: {
                              normal: {
                                  color: '#a7c0dc',
                                  opacity: 0.2
                              }
                          }
                      },
							{
							    name: 'Ocr',
							    type: 'radar',
							    lineStyle: lineStyle,
							    data: dataTJ,
							    symbolSize:4,
							    itemStyle: {
							        normal: {
							        	borderColor: '#a636ed',
							            borderWidth:4,
							            
							        }
							    },
							    areaStyle: {
							        normal: {
							            color: '#a636ed',
							            opacity: 0.5
							        }
							    }
							},
                      
                  ]
              };
              
      var i=0;
      var a=5;
      var b=5;
      var c=5;
      var e=5;
      var f=5;
      var g=5;
     
      var go=1;
        myChartTwo.setOption(option);
      setInterval(function(){
    	  var option2=option;
    	  if(go>0){
    		  if(i<=61){
    			  i+=1;
        		  option2.series[8].data=[[a*i,b*i,c*i,e*i,f*i,g*i]];
    		  }else{
    			  go=-1;
    		  }
    	  }else if(go<0){
    		  if(i>0){
    			  i-=1;
    			  option2.series[8].data=[[a*i,b*i,c*i,e*i,f*i,g*i]];
    		  }else if(i<=0){
    			  go=1;
    		  }
    	  }
    	  myChartTwo.setOption(option2);
      },50)

		//图三
		let myChartThree = echarts.init(document.getElementById('LeftGraphsThree'));
		myChartThree.setOption({
      	color: ['#162a5f', '#50acfe','272c34'], //设置颜色调色盘
				backgroundColor: '#001737',
				calculable : true,
				 title : {
        text: 'Line Chart Style',
        subtext: '',
				textStyle:{
          color:'#04ffff',
				},
        x:'left'
        },
				tooltip: {
					trigger: 'axris',
					 position: ['70%','0'],
					 backgroundColor:'rgba(0,0,0,0)',
					 textStyle:{
					 	color:'#04ffff',
					 	fontWeight:200,
					 	fontSize:16
					 }
				},
				// legend: {
				// 	data: ['邮件营销', '联盟广告', '电视广播'],
					
				// },
				grid: {
					show: false,
					containLabel: false,
					left: '0',
					right: '0',
					top: '50',
					bottom: '0'
				},
				xAxis: [{
					type: 'category',
					data: ['一月', '二月', '三月', '四月', '五月', '六月', '七月']
				}],
				yAxis: [{
					type: 'value',
					position: 'left',
				}],
				series: [{
					name: '北京',
					type: 'line',
					//          stack: '总量',
					
					areaStyle: {
						normal: {
							opacity: 0.9
						}
					},
					data: [85, 63, 41, 35, 90, 41, 33],
					smooth: true
				}, {
					name: '宁波',
					type: 'line',
					//          stack: '总量',
					areaStyle: {
						normal: {
							opacity: 0.9
						}
					},
					data: [22, 82, 131, 144, 90, 33, 80],
					smooth: true //数列的线平滑
				}, {
					name: '杭州',
					type: 'line',
					data: [129, 189, 161, 125, 123, 156, 199],
				}]
		})
	}
  render() {
    return (
      <div className="one" style={{height:'calc(100vh - 80px)',width:'23.5vw',marginLeft:10}}>
        <Row style={{height:'calc(33vh - 30px)',backgroundColor:'#001737',width:'100%',zIndex:1,border:'1px solid #162a5f',}} gutter={16}>
          <Row style={{marginTop:'-25px',textAlign:'center'}}>
            <h3 style={{margin:'auto',fontSize:14,fontFamily:'苹方',width:100,height:30,color:'#04ffff',marginTop:10,backgroundColor:'#162a5f',lineHeight:'30px'}}>城市地图分布</h3>
            <div style={{background:`url(${right})`,width:30,height:30,float:'right',backgroundRepeat:'no-repeat',marginTop:'-18px',marginRight:'-16px'}}></div>
		  </Row>
			<Col span={18} style={{ marginTop:10}}>
				<img src={china} style={{backgroundColor:'#001737',backgroundRepeat:'no-repeat'}} alt="china" />
			</Col>
			<Col span={6} style={{ padding: '-2px'}}>
				<div id="LeftGraphsOne"  style={{ height:'calc(31vh - 60px)',background:'none' }}></div>
			</Col>
		</Row>

        <Row style={{height:'calc(32vh -40px)',backgroundColor:'#001737',width:'100%',zIndex:1,border:'1px solid #162a5f',marginTop:25}} gutter={16}>
          <Row style={{marginTop:'-15px',textAlign:'center'}}>
            <h3 style={{margin:'auto',fontSize:14,fontFamily:'苹方',width:100,height:30,color:'#04ffff',backgroundColor:'#162a5f',lineHeight:'30px'}}>雷达图示详解</h3>
			<div style={{background:`url(${right})`,width:30,height:30,float:'right',backgroundRepeat:'no-repeat',marginTop:'-19px',marginRight:'-16px'}}></div>
          </Row>
          <Col span={10} style={{height:'calc(33vh - 70px)', width: '100%'}}>
			<div id="LeftGraphsTwo"  style={{ height:'calc(33vh - 70px)',background:'none' }}></div>
		  </Col>
		</Row>

        <Row style={{backgroundColor:'#001737',width:'100%',marginTop:20,border:'1px solid #162a5f'}} gutter={16}>
		  <Row style={{marginTop:'-15px',textAlign:'center'}}>
			<h3 style={{margin:'auto',fontSize:14,fontFamily:'苹方',width:100,height:30,color:'#04ffff',backgroundColor:'#162a5f',lineHeight:'30px'}}>面积趋势图示</h3>
			<div style={{background:`url(${right})`,width:30,height:30,float:'right',backgroundRepeat:'no-repeat',marginTop:'-19px',marginRight:'-16px'}}></div>
		  </Row>
		  <Col span={16} style={{height:'calc(33vh - 80px)', width: '100%' }}>
			<div id="LeftGraphsThree" style={{ height:'calc(33vh - 80px)', width: '100%' }}></div>
		  </Col>
		</Row>
      </div>
    );
  }
}

export default LeftGraphs;